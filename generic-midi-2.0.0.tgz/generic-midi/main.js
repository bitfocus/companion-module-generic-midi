import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/pkg-prebuilds/lib/prebuild.js
var require_prebuild = __commonJS({
  "node_modules/pkg-prebuilds/lib/prebuild.js"(exports, module) {
    var fs = __require("fs");
    function getPrebuildName(options) {
      if (!options.napi_version) throw new Error("NAN not implemented");
      const tokens = [
        options.name,
        options.platform,
        options.arch,
        // options.armv ? (options.arch === 'arm64' ? '8' : vars.arm_version) : null,
        options.libc && options.platform === "linux" ? options.libc : null
      ];
      return `${tokens.filter((t) => !!t).join("-")}/${options.runtime}-napi-v${options.napi_version}.node`;
    }
    function isNwjs() {
      return !!(process.versions && process.versions.nw);
    }
    function isElectron() {
      if (process.versions && process.versions.electron) return true;
      if (process.env.ELECTRON_RUN_AS_NODE) return true;
      return typeof window !== "undefined" && window.process && window.process.type === "renderer";
    }
    function isAlpine(platform) {
      return platform === "linux" && fs.existsSync("/etc/alpine-release");
    }
    module.exports = {
      getPrebuildName,
      isNwjs,
      isElectron,
      isAlpine
    };
  }
});

// node_modules/pkg-prebuilds/bindings.js
var require_bindings = __commonJS({
  "node_modules/pkg-prebuilds/bindings.js"(exports, module) {
    var path = __require("path");
    var os = __require("os");
    var { getPrebuildName, isNwjs, isElectron, isAlpine } = require_prebuild();
    var fs = typeof jest !== "undefined" ? jest.requireActual("fs") : __require("fs");
    var runtimeRequire = typeof __webpack_require__ === "function" ? __non_webpack_require__ : __require;
    function resolvePath(basePath, options, verifyPrebuild, throwOnMissing) {
      if (typeof basePath !== "string" || !basePath) throw new Error(`Invalid basePath to pkg-prebuilds`);
      if (typeof options !== "object" || !options) throw new Error(`Invalid options to pkg-prebuilds`);
      if (typeof options.name !== "string" || !options.name) throw new Error(`Invalid name to pkg-prebuilds`);
      let isNodeApi = false;
      if (options.napi_versions && Array.isArray(options.napi_versions)) {
        isNodeApi = true;
      }
      const arch = verifyPrebuild && process.env.npm_config_arch || os.arch();
      const platform = verifyPrebuild && process.env.npm_config_platform || os.platform();
      let runtime = "node";
      if (!isNodeApi) {
        if (verifyPrebuild && process.env.npm_config_runtime) {
          runtime = process.env.npm_config_runtime;
        } else if (isElectron()) {
          runtime = "electron";
        } else if (isNwjs()) {
          runtime = "node-webkit";
        }
      }
      const candidates = [];
      if (!verifyPrebuild) {
        candidates.push(
          path.join(basePath, "build", "Debug", `${options.name}.node`),
          path.join(basePath, "build", "Release", `${options.name}.node`)
        );
      }
      let libc = void 0;
      if (isAlpine(platform)) libc = "musl";
      if (isNodeApi) {
        for (const ver of options.napi_versions) {
          const prebuildName = getPrebuildName({
            name: options.name,
            platform,
            arch,
            libc,
            napi_version: ver,
            runtime
            // armv: options.armv ? (arch === 'arm64' ? '8' : vars.arm_version) : null,
          });
          candidates.push(path.join(basePath, "prebuilds", prebuildName));
        }
      } else {
        throw new Error("Not implemented for NAN!");
      }
      let foundPath = null;
      for (const candidate of candidates) {
        if (fs.existsSync(candidate)) {
          const stat = fs.statSync(candidate);
          if (stat.isFile()) {
            foundPath = candidate;
            break;
          }
        }
      }
      if (!foundPath && throwOnMissing) {
        const candidatesStr = candidates.map((cand) => ` - ${cand}`).join("\n");
        throw new Error(`Failed to find binding for ${options.name}
Tried paths:
${candidatesStr}`);
      }
      return foundPath;
    }
    function loadBinding(basePath, options) {
      const foundPath = resolvePath(basePath, options, false, true);
      if (!foundPath) throw new Error(`Failed to find binding for ${options.name}`);
      return runtimeRequire(foundPath);
    }
    loadBinding.resolve = resolvePath;
    module.exports = loadBinding;
  }
});

// node_modules/@julusian/midi/binding-options.js
var require_binding_options = __commonJS({
  "node_modules/@julusian/midi/binding-options.js"(exports, module) {
    module.exports = {
      name: "midi",
      napi_versions: [7]
    };
  }
});

// node_modules/@julusian/midi/lib/instruments.js
var require_instruments = __commonJS({
  "node_modules/@julusian/midi/lib/instruments.js"(exports, module) {
    module.exports = {
      ACOUSTIC_GRAND_PIANO: 0,
      BRIGHT_ACOUSTIC_PIANO: 1,
      ELECTRIC_GRAND_PIANO: 2,
      HONKY_TONK_PIANO: 3,
      ELECTRIC_PIANO_1: 4,
      ELECTRIC_PIANO_2: 5,
      HARPSICHORD: 6,
      CLAVI: 7,
      CELESTA: 8,
      GLOCKENSPIEL: 9,
      MUSIC_BOX: 10,
      VIBRAPHONE: 11,
      MARIMBA: 12,
      XYLOPHONE: 13,
      TUBULAR_BELLS: 14,
      DULCIMER: 15,
      DRAWBAR_ORGAN: 16,
      PERCUSSIVE_ORGAN: 17,
      ROCK_ORGAN: 18,
      CHURCH_ORGAN: 19,
      REED_ORGAN: 20,
      ACCORDION: 21,
      HARMONICA: 22,
      TANGO_ACCORDION: 23,
      ACOUSTIC_GUITAR_NYLON: 24,
      ACOUSTIC_GUITAR_STEEL: 25,
      ELECTRIC_GUITAR_JAZZ: 26,
      ELECTRIC_GUITAR_CLEAN: 27,
      ELECTRIC_GUITAR_MUTED: 28,
      OVERDRIVEN_GUITAR: 29,
      DISTORTION_GUITAR: 30,
      GUITAR_HARMONICS: 31,
      ACOUSTIC_BASS: 32,
      ELECTRIC_BASS_FINGER: 33,
      ELECTRIC_BASS_PICK: 34,
      FRETLESS_BASS: 35,
      SLAP_BASS_1: 36,
      SLAP_BASS_2: 37,
      SYNTH_BASS_1: 38,
      SYNTH_BASS_2: 39,
      VIOLIN: 40,
      VIOLA: 41,
      CELLO: 42,
      CONTRABASS: 43,
      TREMOLO_STRINGS: 44,
      PIZZICATO_STRINGS: 45,
      ORCHESTRAL_HARP: 46,
      TIMPANI: 47,
      STRING_ENSEMBLE_1: 48,
      STRING_ENSEMBLE_2: 49,
      SYNTHSTRINGS_1: 50,
      SYNTHSTRINGS_2: 51,
      CHOIR_AAHS: 52,
      VOICE_OOHS: 53,
      SYNTH_VOICE: 54,
      ORCHESTRA_HIT: 55,
      TRUMPET: 56,
      TROMBONE: 57,
      TUBA: 58,
      MUTED_TRUMPET: 59,
      FRENCH_HORN: 60,
      BRASS_SECTION: 61,
      SYNTHBRASS_1: 62,
      SYNTHBRASS_2: 63,
      SOPRANO_SAX: 64,
      ALTO_SAX: 65,
      TENOR_SAX: 66,
      BARITONE_SAX: 67,
      OBOE: 68,
      ENGLISH_HORN: 69,
      BASSOON: 70,
      CLARINET: 71,
      PICCOLO: 72,
      FLUTE: 73,
      RECORDER: 74,
      PAN_FLUTE: 75,
      BLOWN_BOTTLE: 76,
      SHAKUHACHI: 77,
      WHISTLE: 78,
      OCARINA: 79,
      LEAD_1_SQUARE: 80,
      LEAD_2_SAWTOOTH: 81,
      LEAD_3_CALLIOPE: 82,
      LEAD_4_CHIFF: 83,
      LEAD_5_CHARANG: 84,
      LEAD_6_VOICE: 85,
      LEAD_7_FIFTHS: 86,
      LEAD_8_BASS_AND_LEAD: 87,
      PAD_1_NEW_AGE: 88,
      PAD_2_WARM: 89,
      PAD_3_POLYSYNTH: 90,
      PAD_4_CHOIR: 91,
      PAD_5_BOWED: 92,
      PAD_6_METALLIC: 93,
      PAD_7_HALO: 94,
      PAD_8_SWEEP: 95,
      FX_1_RAIN: 96,
      FX_2_SOUNDTRACK: 97,
      FX_3_CRYSTAL: 98,
      FX_4_ATMOSPHERE: 99,
      FX_5_BRIGHTNESS: 100,
      FX_6_GOBLINS: 101,
      FX_7_ECHOES: 102,
      FX_8_SCIFI: 103,
      SITAR: 104,
      BANJO: 105,
      SHAMISEN: 106,
      KOTO: 107,
      KALIMBA: 108,
      BAG_PIPE: 109,
      FIDDLE: 110,
      SHANAI: 111,
      TINKLE_BELL: 112,
      AGOGO: 113,
      STEEL_DRUMS: 114,
      WOODBLOCK: 115,
      TAIKO_DRUM: 116,
      MELODIC_TOM: 117,
      SYNTH_DRUM: 118,
      REVERSE_CYMBAL: 119,
      GUITAR_FRET_NOISE: 120,
      BREATH_NOISE: 121,
      SEASHORE: 122,
      BIRD_TWEET: 123,
      TELEPHONE_RING: 124,
      HELICOPTER: 125,
      APPLAUSE: 126,
      GUNSHOT: 127
    };
  }
});

// node_modules/@julusian/midi/lib/drums.js
var require_drums = __commonJS({
  "node_modules/@julusian/midi/lib/drums.js"(exports, module) {
    module.exports = {
      ACOUSTIC_BASS_DRUM: 35,
      BASS_DRUM: 36,
      SIDE_STICK: 37,
      ACOUSTIC_SNARE: 38,
      HAND_CLAP: 39,
      ELECTRIC_SNARE: 40,
      LOW_FLOOR_TOM: 41,
      CLOSED_HI_HAT: 42,
      HIGH_FLOOR_TOM: 43,
      PEDAL_HI_HAT: 44,
      LOW_TOM: 45,
      OPEN_HI_HAT: 46,
      LOW_MID_TOM: 47,
      HI_MID_TOM: 48,
      CRASH_CYMBAL_1: 49,
      HIGH_TOM: 50,
      RIDE_CYMBAL_1: 51,
      CHINESE_CYMBAL: 52,
      RIDE_BELL: 53,
      TAMBOURINE: 54,
      SPLASH_CYMBAL: 55,
      COWBELL: 56,
      CRASH_CYMBAL_2: 57,
      VIBRA_SLAP: 58,
      RIDE_CYMBAL_2: 59,
      HI_BONGO: 60,
      LOW_BONGO: 61,
      MUTE_HI_CONGA: 62,
      OPEN_HI_CONGA: 63,
      LOW_CONGA: 64,
      HIGH_TIMBALE: 65,
      LOW_TIMBALE: 66,
      HIGH_AGOGO: 67,
      LOW_AGOGO: 68,
      CABASA: 69,
      MARACAS: 70,
      SHORT_WHISTLE: 71,
      LONG_WHISTLE: 72,
      SHORT_GUIRO: 73,
      LONG_GUIRO: 74,
      CLAVES: 75,
      HI_WOOD_BLOCK: 76,
      LOW_WOOD_BLOCK: 77,
      MUTE_CUICA: 78,
      OPEN_CUICA: 79,
      MUTE_TRIANGLE: 80,
      OPEN_TRIANGLE: 81
    };
  }
});

// node_modules/@julusian/midi/lib/notes.js
var require_notes = __commonJS({
  "node_modules/@julusian/midi/lib/notes.js"(exports, module) {
    module.exports = {
      /*
      ** The MIDI spec only indicates middle C to be
      ** 60. It doesn't indicate which octave this is.
      ** Some may consider 4, if they label octaves 
      ** from -1, instead of 0. I have adopted on octave
      ** number C here.
      */
      MIDDLE_C: 60,
      // Relative offsets
      C: 0,
      C_SHARP: 1,
      C_FLAT: -1,
      D: 2,
      D_SHARP: 3,
      D_FLAT: 1,
      E: 4,
      E_SHARP: 5,
      E_FLAT: 3,
      F: 5,
      F_SHARP: 6,
      F_FLAT: 4,
      G: 7,
      G_SHARP: 8,
      G_FLAT: 6,
      A: 9,
      A_SHARP: 10,
      A_FLAT: 8,
      B: 11,
      B_SHARP: 12,
      B_FLAT: 10,
      // For the octaves
      C0: 0,
      C1: 12,
      C2: 24,
      C3: 36,
      C4: 48,
      C5: 60,
      C6: 72,
      C7: 84,
      C8: 96,
      C9: 108,
      C10: 120
    };
  }
});

// node_modules/@julusian/midi/lib/messages.js
var require_messages = __commonJS({
  "node_modules/@julusian/midi/lib/messages.js"(exports, module) {
    module.exports = {
      // All basic messages are held in the root, because of how commonly they're
      // used. Luckily, there's no name clashes with sub-names
      NOTE_OFF: 128,
      /* [ pitch, volume ] */
      NOTE_ON: 144,
      /* [ pitch, volume ] */
      NOTE_KEY_PRESSURE: 160,
      /* [ pitch, pressure (after touch) ] */
      SET_PARAMETER: 176,
      /* [ param number (CC), setting ] */
      SET_PROGRAM: 192,
      /* [ program ] */
      CHANGE_PRESSURE: 208,
      /* [ pressure (after touch) ] */
      SET_PITCHWHEEL: 224,
      /* [ LSB,  MSB (two 7 bit values) ] */
      METAEVENT: 255,
      SYS_EX1: 240,
      SYS_EX2: 247,
      /* Alternative names */
      PATCH_CHANGE: 192,
      /* Equivalent to SET_PROGRAM */
      CONTROL_CHANGE: 176,
      /* Equivalent to SET_PARAMETER */
      SYSMASK: 240,
      // Control changes
      cc: {
        /* 0-31, where defined, all indicate the MSB */
        BANK_SELECT: 0,
        MODULATION: 1,
        BREATH_CONTROL: 2,
        UNDEFINED_3: 3,
        FOOT_CONTROL: 4,
        PORTAMENTO_TIME: 5,
        DATE_ENTRY: 6,
        VOLUME: 7,
        BALANCE: 8,
        UNDEFINED_9: 9,
        PAN: 10,
        EXPRESSION: 11,
        EFFECT_CONTROL_1: 12,
        EFFECT_CONTROL_2: 13,
        UNDEFINED_14: 14,
        UNDEFINED_15: 15,
        GENERAL_PURPOSE_1: 16,
        GENERAL_PURPOSE_2: 17,
        GENERAL_PURPOSE_3: 18,
        GENERAL_PURPOSE_4: 19,
        /* 20-31 are undefined */
        UNDEFINED_20: 20,
        UNDEFINED_21: 21,
        UNDEFINED_22: 22,
        UNDEFINED_23: 23,
        UNDEFINED_24: 24,
        UNDEFINED_25: 25,
        UNDEFINED_26: 26,
        UNDEFINED_27: 27,
        UNDEFINED_28: 28,
        UNDEFINED_29: 29,
        UNDEFINED_30: 30,
        UNDEFINED_31: 31,
        /* LSB for control changes 0-31		32-63 */
        BANK_SELECT_LSB: 32,
        MODULATION_LSB: 33,
        BREATH_CONTROL_LSB: 34,
        UNDEFINED_35: 35,
        FOOT_CONTROL_LSB: 36,
        PORTAMENTO_TIME_LSB: 37,
        DATA_ENTRY_LSB: 38,
        VOLUME_LSB: 39,
        BALANCE_LSB: 40,
        UNDEFINED_41: 41,
        PAN_LSB: 42,
        EXPRESSION_LSB: 43,
        EFFECT_CONTROL_1_LSB: 44,
        EFFECT_CONTROL_2_LSB: 45,
        UNDEFINED_46: 46,
        UNDEFINED_47: 47,
        GENERAL_PURPOSE_1_LSB: 48,
        GENERAL_PURPOSE_2_LSB: 49,
        GENERAL_PURPOSE_3_LSB: 50,
        GENERAL_PURPOSE_4_LSB: 51,
        /* 52-63 are undefined */
        UNDEFINED_52: 52,
        UNDEFINED_53: 53,
        UNDEFINED_54: 54,
        UNDEFINED_55: 55,
        UNDEFINED_56: 56,
        UNDEFINED_57: 57,
        UNDEFINED_58: 58,
        UNDEFINED_59: 59,
        UNDEFINED_60: 60,
        UNDEFINED_61: 61,
        UNDEFINED_62: 62,
        UNDEFINED_63: 63,
        SUSTAIN_PEDAL: 64,
        PORTAMENTO: 65,
        PEDAL_SUSTENUTO: 66,
        PEDAL_SOFT: 67,
        LEGATO_FOOT_SWITCH: 68,
        HOLD_2: 69,
        SOUND_VARIATION: 70,
        TIMBRE: 71,
        RELEASE_TIME: 72,
        ATTACKTIME: 73,
        BRIGHTNESS: 74,
        REVERB: 75,
        DELAY: 76,
        PITCH_TRANSPOSE: 77,
        FLANGE: 78,
        SPECIAL_FX: 79,
        GENERAL_PURPOSE_5_LSB: 80,
        GENERAL_PURPOSE_6_LSB: 81,
        GENERAL_PURPOSE_7_LSB: 82,
        GENERAL_PURPOSE_8_LSB: 83,
        PORTAMENTO_CONTROL: 84,
        /* 85-90 are undefined */
        UNDEFINED_85: 85,
        UNDEFINED_86: 86,
        UNDEFINED_87: 87,
        UNDEFINED_88: 88,
        UNDEFINED_89: 89,
        UNDEFINED_90: 90,
        /* Effects depth */
        FX_DEPTH: 91,
        TREMELO_DEPTH: 92,
        CHORUS_DEPTH: 93,
        CELESTA_DEPTH: 94,
        PHASER_DEPTH: 95,
        DATA_INC: 96,
        DATA_DEC: 97,
        NON_REG_PARAM_LSB: 98,
        NON_REG_PARAM_MSB: 99,
        REG_PARAM_LSB: 100,
        REG_PARAM_MSB: 101,
        /* 102-119 are undefined */
        UNDEFINED_102: 102,
        UNDEFINED_103: 103,
        UNDEFINED_104: 104,
        UNDEFINED_105: 105,
        UNDEFINED_106: 106,
        UNDEFINED_107: 107,
        UNDEFINED_108: 108,
        UNDEFINED_109: 109,
        UNDEFINED_110: 110,
        UNDEFINED_111: 111,
        UNDEFINED_112: 112,
        UNDEFINED_113: 113,
        UNDEFINED_114: 114,
        UNDEFINED_115: 115,
        UNDEFINED_116: 116,
        UNDEFINED_117: 117,
        UNDEFINED_118: 118,
        UNDEFINED_119: 119,
        // Modes
        ALL_SOUND_OFF: 120,
        RESET_ALL_CONTROLLERS: 121,
        LOCAL_CONTROL: 122,
        ALL_NOTES_OFF: 123,
        OMNI_MODE_OFF: 124,
        OMNI_MODE_ON: 125,
        MONO_MODE_ON: 126,
        POLY_MODE_ON: 127,
        /* Alternative names */
        MOD_WHEEL: 1,
        /* All sound controllers have only LSB */
        HARM_CONTENT: 71,
        SOUND_CONTROLLER_1: 70,
        SOUND_CONTROLLER_2: 71,
        SOUND_CONTROLLER_3: 72,
        SOUND_CONTROLLER_4: 73,
        SOUND_CONTROLLER_5: 74,
        SOUND_CONTROLLER_6: 75,
        SOUND_CONTROLLER_7: 76,
        SOUND_CONTROLLER_8: 77,
        SOUND_CONTROLLER_9: 78,
        SOUND_CONTROLLER_10: 79,
        EFFECT_1_DEPTH: 91,
        EFFECT_2_DEPTH: 92,
        EFFECT_3_DEPTH: 93,
        EFFECT_4_DEPTH: 94,
        EFFECT_5_DEPTH: 95,
        DETUNE_DEPTH: 94
      },
      /*
      ** System Common (Status byte: 1111 0ttt)
      */
      syscommon: {
        UNDEFINED_1: 241,
        SONG_POSITION: 242,
        /* [LSB, MSB] */
        SONG_SELECT: 243,
        UNDEFINED_4: 244,
        UNDEFINED_5: 245,
        TUNE_REQUEST: 246,
        EOX: 247
        /* End of Exclusive */
      },
      /*
      ** System Real Time (Status byte: 1111 1ttt)
      */
      realtime: {
        TIMING_CLOCK: 248,
        UNDEFINED_F9: 249,
        START: 250,
        CONTINUE: 251,
        STOP: 252,
        UNDEFINED_FD: 253,
        ACTIVE_SENSING: 254,
        SYSTEM_RESET: 255
      },
      /*
      ** System Exclusive (Status byte: 1111 0000)
      **
      ** The first byte of a sysex must be the identification number
      ** (7 bits, MSB=0). This is followed by an arbitary number of
      ** data bytes (all MSB=0), and ending in the sexEOX msg.
      ** Note: Any other status byte (where MSB=1) will also terminate
      ** a sysex message, with the exception of the System Real Time
      ** events above.
      */
      sysex: {
        EOX: 247
        /* End of Exclusive */
      }
    };
  }
});

// node_modules/@julusian/midi/midi.js
var require_midi = __commonJS({
  "node_modules/@julusian/midi/midi.js"(exports, module) {
    var midi = require_bindings()(
      __dirname,
      require_binding_options()
    );
    var Stream = __require("stream");
    var { EventEmitter: EventEmitter3 } = __require("events");
    var Instruments = require_instruments();
    var Drums = require_drums();
    var Notes = require_notes();
    var Messages = require_messages();
    var Input3 = class extends EventEmitter3 {
      constructor() {
        super();
        this.input = new midi.Input((deltaTime, message) => {
          this.emit("message", deltaTime, Array.from(message.values()));
        });
      }
      closePort() {
        return this.input.closePort();
      }
      destroy() {
        return this.input.destroy();
      }
      getPortCount() {
        return this.input.getPortCount();
      }
      getPortName(port) {
        return this.input.getPortName(port);
      }
      isPortOpen() {
        return this.input.isPortOpen();
      }
      ignoreTypes(sysex, timing, activeSensing) {
        return this.input.ignoreTypes(sysex, timing, activeSensing);
      }
      openPort(port) {
        return this.input.openPort(port);
      }
      openPortByName(name) {
        for (let port = 0; port < this.input.getPortCount(); ++port) {
          if (name === this.input.getPortName(port)) {
            return this.input.openPort(port);
          }
        }
        return void 0;
      }
      openVirtualPort(port) {
        return this.input.openVirtualPort(port);
      }
      setBufferSize(size, count = 4) {
        return this.input.setBufferSize(size, count);
      }
    };
    var Output3 = class {
      constructor() {
        this.output = new midi.Output();
      }
      closePort() {
        return this.output.closePort();
      }
      destroy() {
        return this.output.destroy();
      }
      getPortCount() {
        return this.output.getPortCount();
      }
      getPortName(port) {
        return this.output.getPortName(port);
      }
      isPortOpen() {
        return this.output.isPortOpen();
      }
      openPort(port) {
        return this.output.openPort(port);
      }
      openPortByName(name) {
        for (let port = 0; port < this.output.getPortCount(); ++port) {
          if (name === this.output.getPortName(port)) {
            return this.output.openPort(port);
          }
        }
        return void 0;
      }
      openVirtualPort(port) {
        return this.output.openVirtualPort(port);
      }
      send(message) {
        return this.sendMessage(message);
      }
      sendMessage(message) {
        if (Array.isArray(message)) {
          message = Buffer.from(message);
        }
        if (!Buffer.isBuffer(message)) {
          throw new Error("First argument must be an array or Buffer");
        }
        return this.output.sendMessage(message);
      }
    };
    function createReadStream(input) {
      input = input || new Input3();
      var stream = new Stream();
      stream.readable = true;
      stream.paused = false;
      stream.queue = [];
      input.on("message", function(deltaTime, message) {
        var packet = new Buffer.from(message);
        if (!stream.paused) {
          stream.emit("data", packet);
        } else {
          stream.queue.push(packet);
        }
      });
      stream.pause = function() {
        stream.paused = true;
      };
      stream.resume = function() {
        stream.paused = false;
        while (stream.queue.length && stream.emit("data", stream.queue.shift())) {
        }
      };
      return stream;
    }
    function createWriteStream(output) {
      output = output || new Output3();
      var stream = new Stream();
      stream.writable = true;
      stream.paused = false;
      stream.queue = [];
      stream.write = function(d) {
        if (Buffer.isBuffer(d)) {
          d = Array.prototype.slice.call(d, 0);
        }
        output.sendMessage(d);
        return !this.paused;
      };
      stream.end = function(buf) {
        buf && stream.write(buf);
        stream.writable = false;
      };
      stream.destroy = function() {
        stream.writable = false;
      };
      return stream;
    }
    module.exports = {
      Input: Input3,
      Output: Output3,
      createReadStream,
      createWriteStream,
      Constants: {
        Instruments,
        Drums,
        Notes,
        Messages
      },
      // Backwards compatibility.
      input: Input3,
      output: Output3
    };
  }
});

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables2) {
    if (Array.isArray(variables2))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables2);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path, args) {
    this.#context.oscSend(host, port, path, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/midi/midi.js
var node_midi = __toESM(require_midi(), 1);
import { EventEmitter as EventEmitter2 } from "events";

// dist/midi/msgtypes.js
var MAX_7_BIT = 127;
var MAX_14_BIT = 16383;
var MIDI_STATUS_TYPES = /* @__PURE__ */ new Map([
  ["noteoff", 128],
  ["noteon", 144],
  ["aftertouch", 160],
  ["cc", 176],
  ["program", 192],
  ["channelpressure", 208],
  ["pitch", 224],
  ["sysex", 240],
  ["mtc", 241],
  ["position", 242],
  ["select", 243],
  ["tune", 246],
  ["sysex end", 247],
  ["clock", 248],
  ["start", 250],
  ["continue", 251],
  ["stop", 252],
  ["activesense", 254],
  ["reset", 255]
]);
var hex = (val) => `${val} (0x${val.toString(16).padStart(2, "0")})`;
var MidiMessage = class _MidiMessage {
  id = "";
  bytes;
  static noMsg = {
    bytes: [],
    status: 0,
    channel: 0,
    type: 0,
    note: 0,
    velocity: 0,
    controller: 0,
    pressure: 0,
    value: 0,
    program: 0,
    song: 0
  };
  constructor(bytes = []) {
    this.bytes = bytes;
  }
  get status() {
    return this.bytes[0] > 239 ? this.bytes[0] : this.bytes[0] & 240;
  }
  set status(v) {
    this.bytes[0] = v > 239 ? v : this.bytes[0] & 15 | v & 240;
  }
  get channel() {
    return (this.bytes[0] & 15) + 1;
  }
  set channel(v) {
    v--;
    v = _MidiMessage.constrain(v, 15);
    this.bytes[0] = this.bytes[0] & 240 | v & 15;
  }
  get data1() {
    return this.bytes[1] & 127;
  }
  set data1(v) {
    this.bytes[1] = _MidiMessage.constrain(v, MAX_7_BIT);
  }
  get data2() {
    return this.bytes[2] & 127;
  }
  set data2(v) {
    this.bytes[2] = _MidiMessage.constrain(v, MAX_7_BIT);
  }
  get args() {
    return { bytes: this.bytes };
  }
  toString() {
    return `${this.id} Message`;
  }
  static constrain(num, max) {
    return num > max ? max : num < 0 ? 0 : num;
  }
  static parseMessage(bytes = [], msg = this.noMsg) {
    let incoming = new _MidiMessage(bytes);
    let status = bytes.length > 0 ? incoming.status : msg.status || 0;
    if (status === 0 && typeof msg.id !== "undefined")
      status = MIDI_STATUS_TYPES.get(msg.id) || 0;
    switch (status) {
      case 128:
        incoming = new NoteOff(msg.channel, msg.note, msg.velocity);
        break;
      case 144:
        incoming = new NoteOn(msg.channel, msg.note, msg.velocity);
        break;
      case 160:
        incoming = new Aftertouch(msg.channel, msg.note, msg.pressure);
        break;
      case 176:
        incoming = new ControlChange(msg.channel, msg.controller, msg.value);
        break;
      case 192:
        incoming = new ProgramChange(msg.channel, msg.program);
        break;
      case 208:
        incoming = new ChannelPressure(msg.channel, msg.pressure);
        break;
      case 224:
        incoming = new PitchWheel(msg.channel, msg.value);
        break;
      case 240:
        incoming = new Sysex(msg.bytes);
        break;
      case 241:
        incoming = new Mtc(msg.type, msg.value);
        break;
      case 248:
        return;
      // ignore MIDI Clock messages
      default:
        console.log(`Unsupported MIDI message. Status = ${hex(status)}`);
        return;
    }
    if (bytes.length > 0)
      incoming.bytes = bytes;
    return incoming;
  }
};
var NoteOff = class extends MidiMessage {
  constructor(c, n, v) {
    super();
    this.id = "noteoff";
    this.status = 128;
    this.channel = c;
    this.note = n;
    this.velocity = v;
  }
  get note() {
    return this.data1;
  }
  set note(v) {
    this.data1 = v;
  }
  get velocity() {
    return this.data2;
  }
  set velocity(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, note: this.note, velocity: this.velocity };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, note: ${hex(this.note)}, velocity: ${hex(this.velocity)}`;
  }
};
var NoteOn = class extends NoteOff {
  constructor(c, n, v) {
    super(c, n, v);
    this.id = "noteon";
    this.status = 144;
  }
};
var Aftertouch = class extends MidiMessage {
  constructor(c, n, p) {
    super();
    this.id = "aftertouch";
    this.status = 160;
    this.channel = c;
    this.note = n;
    this.pressure = p;
  }
  get note() {
    return this.data1;
  }
  set note(v) {
    this.data1 = v;
  }
  get pressure() {
    return this.data2;
  }
  set pressure(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, note: this.note, pressure: this.pressure };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, note: ${hex(this.note)}, pressure: ${hex(this.pressure)}`;
  }
};
var ControlChange = class extends MidiMessage {
  constructor(c, cc, v) {
    super();
    this.id = "cc";
    this.status = 176;
    this.channel = c;
    this.controller = cc;
    this.value = v;
  }
  get controller() {
    return this.data1;
  }
  set controller(v) {
    this.data1 = v;
  }
  get value() {
    return this.data2;
  }
  set value(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, controller: this.controller, value: this.value };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, controller: ${hex(this.controller)}, value: ${hex(this.value)}`;
  }
};
var ProgramChange = class extends MidiMessage {
  constructor(c, n) {
    super();
    this.id = "program";
    this.status = 192;
    this.channel = c;
    this.program = n;
  }
  get program() {
    return this.data1 + 1;
  }
  set program(v) {
    v--;
    this.data1 = v;
  }
  get args() {
    return { channel: this.channel, program: this.program };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, program: ${hex(this.program)}`;
  }
};
var ChannelPressure = class extends MidiMessage {
  constructor(c, p) {
    super();
    this.id = "channelpressure";
    this.status = 208;
    this.channel = c;
    this.pressure = p;
  }
  get pressure() {
    return this.data1;
  }
  set pressure(v) {
    this.data1 = v;
  }
  get args() {
    return { channel: this.channel, pressure: this.pressure };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, pressure: ${hex(this.pressure)}`;
  }
};
var PitchWheel = class extends MidiMessage {
  constructor(c, v) {
    super();
    this.id = "pitch";
    this.status = 224;
    this.channel = c;
    this.value = v;
  }
  get value() {
    return (this.data2 << 7) + this.data1;
  }
  set value(v) {
    v = MidiMessage.constrain(v, MAX_14_BIT);
    this.data2 = v >> 7 & 127;
    this.data1 = v & 127;
  }
  get args() {
    return { channel: this.channel, value: this.value };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, value: ${hex(this.value)}`;
  }
};
var Sysex = class extends MidiMessage {
  constructor(b) {
    super();
    this.id = "sysex";
    this.bytes = b;
  }
  get args() {
    return { bytes: this.bytes };
  }
  toString() {
    return `${super.toString()}, bytes: ${this.bytes}`;
  }
};
var Mtc = class extends MidiMessage {
  constructor(t, v) {
    super();
    this.id = "mtc";
    this.status = 241;
    this.type = t;
    this.value = v;
  }
  get type() {
    return this.data1 >> 4 & 7;
  }
  set type(v) {
    this.data1 = this.data1 & 15 | v << 4;
  }
  get value() {
    return this.data1 & 15;
  }
  set value(v) {
    v = MidiMessage.constrain(v, 15);
    this.data1 = this.data1 & 240 | v;
  }
  get args() {
    return { channel: this.channel, type: this.type, value: this.value };
  }
  toString() {
    return `${super.toString()}, type: ${hex(this.type)}, value: ${hex(this.value)}`;
  }
};

// dist/midi/midi.js
var Input2 = class extends EventEmitter2 {
  _input;
  _smpte;
  _pendingSysex;
  _sysex;
  name;
  constructor(name, virtual) {
    super();
    this._input = new node_midi.Input();
    this._input.ignoreTypes(false, false, false);
    this._pendingSysex = false;
    this._sysex = [];
    this._smpte = [];
    this.name = name;
    const inputPortNumberedNames = getInputs();
    if (virtual) {
      this._input.openVirtualPort(name);
    } else {
      const numInputs = this._input.getPortCount();
      for (let i = 0; i < numInputs; i++) {
        if (name === inputPortNumberedNames[i]) {
          try {
            this._input.openPort(i);
          } catch (err) {
            console.log(`Error opening port ${name}.
Error: ${err}`);
          }
        }
      }
    }
    this._input.on("message", (deltaTime, bytes) => {
      const msg = MidiMessage.parseMessage(bytes);
      if (msg === void 0)
        return;
      this.emit("message", deltaTime, msg);
      if (msg.id == "mtc") {
        this.parseMtc(msg);
      }
    });
  }
  close() {
    this._input.closePort();
    this._input.destroy();
  }
  isPortOpen() {
    return this._input.isPortOpen();
  }
  parseMtc(data) {
    const FRAME_RATES = [24, 25, 29.97, 30];
    const byteNumber = data.type;
    let value = data.value;
    let smpteFrameRate;
    this._smpte[byteNumber] = value;
    if (byteNumber === 7 && typeof this._smpte[0] === "number") {
      const bits = [];
      for (let i = 3; i >= 0; i--) {
        const bit = value & 1 << i ? 1 : 0;
        bits.push(bit);
      }
      value = bits[3];
      smpteFrameRate = FRAME_RATES[(bits[1] << 1) + bits[2]];
      this._smpte[byteNumber] = value;
      const smpte = this._smpte;
      const smpteFormatted = ((smpte[7] << 4) + smpte[6]).toString().padStart(2, "0") + ":" + ((smpte[5] << 4) + smpte[4]).toString().padStart(2, "0") + ":" + ((smpte[3] << 4) + smpte[2]).toString().padStart(2, "0") + "." + ((smpte[1] << 4) + smpte[0]).toString().padStart(2, "0");
      this.emit("smpte", {
        smpte: smpteFormatted,
        smpteFR: smpteFrameRate
      });
    }
  }
};
var Output2 = class {
  _output;
  name;
  constructor(name, virtual) {
    this._output = new node_midi.Output();
    this.name = name;
    const outputPortNumberedNames = getOutputs();
    if (virtual) {
      this._output.openVirtualPort(name);
    } else {
      const numOutputs = this._output.getPortCount();
      for (let i = 0; i < numOutputs; i++) {
        if (name === outputPortNumberedNames[i]) {
          try {
            this._output.openPort(i);
          } catch (err) {
            console.log(`Error opening port ${name}.
Error: ${err}`);
          }
        }
      }
    }
  }
  close() {
    this._output.closePort();
    this._output.destroy();
  }
  isPortOpen() {
    return this._output.isPortOpen();
  }
  send(msg) {
    this._output.sendMessage(msg.bytes);
  }
};
function getInputs() {
  const input = new node_midi.Input();
  const inputs = [];
  for (let i = 0; i < input.getPortCount(); i++) {
    let counter = 0;
    const portName = input.getPortName(i);
    let numberedPortName = portName;
    while (inputs.includes(numberedPortName)) {
      counter++;
      numberedPortName += ` ${counter}`;
    }
    inputs.push(numberedPortName);
  }
  input.closePort();
  return inputs;
}
function getOutputs() {
  const output = new node_midi.Output();
  const outputs = [];
  for (let i = 0; i < output.getPortCount(); i++) {
    let counter = 0;
    const portName = output.getPortName(i);
    let numberedPortName = portName;
    while (outputs.includes(numberedPortName)) {
      counter++;
      numberedPortName += ` ${counter}`;
    }
    outputs.push(numberedPortName);
  }
  output.closePort();
  return outputs;
}

// dist/config.js
function GetConfigFields() {
  const inPortNames = [];
  const outPortNames = [];
  const inPorts = getInputs();
  const outPorts = getOutputs();
  inPorts.forEach((m) => {
    inPortNames.push({ id: m, label: m });
  });
  outPorts.forEach((m) => {
    outPortNames.push({ id: m, label: m });
  });
  return [
    {
      type: "dropdown",
      id: "inPortName",
      label: "MIDI In",
      width: 6,
      default: inPorts[0] || "NONE DETECTED",
      choices: inPortNames
      //	isVisible: (opts) => !opts.inPortIsVirtual,
    },
    /*
    {
        type: 'textinput',
        id: 'inPortVirtualName',
        label: 'MIDI In',
        width: 6,
        default: '',
        isVisible: (opts) => !!opts.inPortIsVirtual,
    },
    {
        type: 'checkbox',
        id: 'inPortIsVirtual',
        label: 'Virtual',
        width: 6,
        default: false,
    },
    */
    {
      type: "dropdown",
      id: "outPortName",
      label: "MIDI Out",
      width: 6,
      default: outPorts[0] || "NONE DETECTED",
      choices: outPortNames
      //	isVisible: (opts) => !opts.outPortIsVirtual,
    },
    /*
    {
        type: 'textinput',
        id: 'outPortVirtualName',
        label: 'MIDI Out',
        width: 6,
        default: '',
        isVisible: (opts) => !!opts.outPortIsVirtual,
    },
    {
        type: 'checkbox',
        id: 'outPortIsVirtual',
        label: 'Virtual',
        width: 6,
        default: false,
    },
    {
        type: 'static-text',
        id: 'customText',
        label: 'Choose existing ports, or type a custom name to create a Virtual Port',
        width: 12,
        value: '',
    },
    */
    {
      type: "checkbox",
      id: "useTimeStamp",
      label: "Use TimeStamp with Action Recorder",
      tooltip: "Enable this setting to include the delay time for actions created in Action Recorder",
      width: 6,
      default: false
    },
    {
      type: "checkbox",
      id: "autoCreateVars",
      label: 'Enable "Auto-Created Variables function"',
      tooltip: "Enable this setting ONLY if you need compatibility with existing Auto-Created variables",
      width: 6,
      default: false
    },
    {
      type: "static-text",
      id: "autoCreateVarNotice",
      label: '*** Support for the deprecated "Auto-Created Variables function" ***',
      value: 'The "Auto-Create Variable" function has now been superceded by the built-in Local Variables feature within Companion 4.2+.<br>If you still have auto-created variables, please change them to Value Feedbacks as support for Auto-Created Variables may disappear in the future!',
      tooltip: "Enable this setting ONLY if you need compatibility with existing Auto-Created variables",
      width: 12
    }
  ];
}

// dist/variables.js
var variables = {
  midiIn: { name: "Is a MIDI Message Incoming?" },
  midiOut: { name: "Is a MIDI Message Outgoing?" },
  lastMessage: { name: "Last Message Received" },
  smpte: { name: "SMPTE TC from MTC" },
  smpteFR: { name: "SMPTE Frame Rate from MTC" }
};
var midiTimers = /* @__PURE__ */ new Map();
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions(variables);
  self.setVariableValues({ midiIn: false, midiOut: false });
}
function HandleMidiIndicators(self, variable) {
  let t = midiTimers.get(variable) ?? null;
  if (t !== null)
    clearTimeout(t);
  t = setTimeout(() => {
    self.setVariableValues({ [variable]: false });
    self.checkFeedbacks(variable);
  }, 200);
  midiTimers.set(variable, t);
  self.setVariableValues({ [variable]: true });
  self.checkFeedbacks(variable);
}
function UpdateLastMsg(self, msg, data) {
  const msgInfo = CreateVarName(msg);
  const lastMsg = msgInfo.name + "_" + data;
  self.setVariableValues({ lastMessage: lastMsg });
  AddOrUpdateVar(self, "lastMsgType", "Last Message Type Received", msg.id);
  for (let i = 0; i < msgInfo.keys.length; i++) {
    const keyName = msgInfo.keys[i];
    const key = keyName;
    const CapKeyName = keyName[0].toUpperCase() + keyName.slice(1);
    AddOrUpdateVar(self, "last" + CapKeyName, "Last " + CapKeyName + " Received", Number(msg.args[key]));
  }
}
function FBCreatesVar(self, msg, data) {
  AddOrUpdateVar(self, "_" + CreateVarName(msg).name, "Auto-Created Variable", data);
}
function CreateVarName(msg) {
  let varName = msg.id;
  const msgKeys = Object.keys(msg.args);
  for (let i = 0; i < msgKeys.length - 1; i++) {
    const key = msgKeys[i];
    const val = Number(msg.args[key]);
    if (val !== void 0) {
      varName += `_${val}`;
    }
  }
  return { name: varName, keys: msgKeys };
}
function AddOrUpdateVar(self, varName, varDescr, data) {
  variables[varName] = { name: varDescr };
  self.setVariableDefinitions(variables);
  self.setVariableValues({ [varName]: data });
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  function(context, props) {
    const changes = {
      updatedConfig: null,
      updatedActions: [],
      updatedFeedbacks: []
    };
    console.log("\nRunning Update Scripts...\n");
    for (const a of props.actions) {
      if (a.actionId == "program") {
        console.log("Updating action\n", a);
        a.options.program = a.options.number || a.options.program;
        delete a.options.number;
      }
      if (!a.options.chValue)
        a.options.chValue = a.options.channel;
      if (!a.options.noteValue)
        a.options.noteValue = a.options.note;
      if (!a.options.ccValue)
        a.options.ccValue = a.options.controller;
      changes.updatedActions.push(a);
      console.log("to\n", a);
    }
    for (const f of props.feedbacks) {
      if (f.feedbackId == "receive_message") {
        console.log("Updating feedback\n", f);
        f.feedbackId = String(f.options.msgType);
        delete f.options.msgType;
        switch (f.feedbackId) {
          case "program":
            f.options.program = f.options.number;
            delete f.options.number;
            break;
          case "sysex":
            f.options.bytes = f.options.message;
            delete f.options.message;
            break;
          case "pitch":
            f.options.value = f.options.pitch;
            delete f.options.pitch;
        }
      }
      if (!f.options.chValue)
        f.options.chValue = f.options.channel;
      if (!f.options.noteValue)
        f.options.noteValue = f.options.note;
      if (!f.options.ccValue)
        f.options.ccValue = f.options.controller;
      changes.updatedFeedbacks.push(f);
      console.log("to\n", f);
    }
    return changes;
  },
  function(context, props) {
    const changes = {
      updatedConfig: null,
      updatedActions: [],
      updatedFeedbacks: []
    };
    console.log("\nRunning Update Scripts...\n");
    for (const a of props.actions) {
      console.log("\nUpdating action\n", a);
      if (!a.options.sendOverTime)
        a.options.sendOverTime = { isExpression: false, value: false };
      if (!a.options.timeStartValue)
        a.options.timeStartValue = { isExpression: false, value: 0 };
      if (!a.options.time)
        a.options.time = { isExpression: false, value: 0 };
      if (!a.options.curve)
        a.options.curve = { isExpression: false, value: "linear" };
      changes.updatedActions.push(a);
      console.log("\nto\n", a);
    }
    return changes;
  }
];

// dist/operations.js
var midiMsgTypes = [
  {
    id: "noteoff",
    label: "Note Off",
    desc: "Note Off Messsage",
    valId: "velocity",
    valLabel: "Velocity",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  },
  {
    id: "noteon",
    label: "Note On",
    desc: "Note On Message",
    valId: "velocity",
    valLabel: "Velocity",
    valMin: 0,
    valMax: 127,
    valDefault: 127
  },
  //		{ id: 'aftertouch', name: 'Aftertouch' },
  {
    id: "cc",
    label: "CC",
    desc: "Control Change Message",
    valId: "value",
    valLabel: "Value",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  },
  {
    id: "program",
    label: "Program Change",
    desc: "Program Change Message",
    valId: "program",
    valLabel: "Program Number",
    valMin: 1,
    valMax: 128,
    valDefault: 1
  },
  //		{ id: 'channelpressure', 	name: 'Channel Pressure' },
  {
    id: "pitch",
    label: "Pitch Wheel",
    desc: "Pitch Wheel Message",
    valId: "value",
    valLabel: "Value",
    valMin: 0,
    valMax: 16383,
    valDefault: 8192
  },
  {
    id: "sysex",
    label: "SysEx",
    desc: "System Exclusive Message",
    valId: "bytes",
    valLabel: "SysEx Bytes",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  }
  //		{ id: 'mtc', 				name: 'MIDI Time Code' },
  //		{ id: 'position',			name: 'Song Position Pointer' },
  //		{ id: 'select',				name: 'Song Select' },
  //		{ id: 'tune',				name: 'Tune Request' },
  //		{ id: 'sysex end',			name: 'SysEx End' },
  //		{ id: 'clock',				name: 'Clock' },
  //		{ id: 'start',				name: 'Start' },
  //		{ id: 'continue',			name: 'Continue' },
  //		{ id: 'stop',				name: 'Stop' },
  //		{ id: 'activesense',		name: 'Active Sensing' },
  //		{ id: 'reset',				name: 'Reset' },
];
function createOptions(newOpts, midiOp) {
  if (["noteoff", "noteon", "cc", "program", "pitch"].includes(midiOp.id)) {
    newOpts.push({
      id: "channel",
      type: "number",
      label: "Channel",
      default: 1,
      min: 1,
      max: 16
    });
  }
  if (["noteoff", "noteon"].includes(midiOp.id)) {
    newOpts.push({
      id: "note",
      type: "number",
      label: "Note Number",
      default: 60,
      min: 0,
      max: 127
    });
  }
  if (midiOp.id == "cc") {
    newOpts.push({
      id: "controller",
      type: "number",
      label: "Controller",
      default: 127,
      min: 0,
      max: 127
    });
  }
  if (midiOp.id != "sysex") {
    newOpts.push({
      id: midiOp.valId,
      type: "number",
      label: midiOp.valLabel,
      default: midiOp.valDefault,
      min: midiOp.valMin,
      max: midiOp.valMax
    });
  } else {
    newOpts.push({
      id: "bytes",
      type: "textinput",
      label: midiOp.valLabel,
      tooltip: "Enter a string of decimal or hex digits, with spaces or commas between. MUST start with 0xF0 or 240 and end with 0xF7 or 247",
      default: ""
    });
  }
  return newOpts;
}

// dist/actions.js
function UpdateActions(self) {
  self.setVariableValues({ midiOutData: false });
  const actions = {};
  for (const action of midiMsgTypes) {
    const newAction = {
      name: String(action.label),
      options: createOptions([], action),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        if (!self.config.outPortIsVirtual && !self.midiOutput.isPortOpen()) {
          self.log("error", `Output Port "${self.midiOutput.name}" not open!`);
          return;
        }
        if (action.id == "sysex") {
          const parsedSysex = await opts[action.valId];
          opts.bytes = parsedSysex.split(/[ ,]+/).map((n) => parseInt(n));
        }
        if (opts.relValue) {
          opts[action.valId] = Number(await opts.varValue);
          if (opts.chValue)
            opts.channel = Number(await opts.chValue);
          if (opts.noteValue)
            opts.note = Number(await opts.noteValue);
          if (opts.ccValue)
            opts.controller = Number(await opts.ccValue);
        }
        let msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
        if (opts.relValue) {
          const val = self.getFromDataStore(msg);
          if (val === void 0) {
            self.log("info", "Relative value not sent. Current value from device is needed!");
            return;
          }
          opts[action.valId] = val + Number(opts[action.valId] * 1);
        }
        if (opts.sendOverTime) {
          const durationMs = opts.time * 1e3;
          const curve = opts.curve;
          const tickMs = 15;
          let start = 0;
          if (opts.relValue) {
            start = self.getFromDataStore(msg) || 0;
          } else {
            start = Number(opts.timeStartValue);
          }
          let end = Number(opts[action.valId] * 1);
          if (end < 0) {
            end = 0;
          } else if (end > 127) {
            end = 127;
          }
          if (start > end) {
          }
          const t0 = Date.now();
          let last = -1;
          const easeFunctions = {
            linear: (x) => x,
            easeIn: (x) => x * x,
            easeOut: (x) => 1 - (1 - x) * (1 - x),
            easeInOut: (x) => x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2
          };
          const ease = easeFunctions[curve] || ((x) => x);
          const timer = setInterval(() => {
            const elapsed = Date.now() - t0;
            const u = Math.min(1, elapsed / durationMs);
            const val = Math.round(start + (end - start) * ease(u));
            if (val !== last) {
              opts[action.valId] = val;
              msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
              self.log("debug", `Sending:  ${msg} to "${self.midiOutput.name}"`);
              self.midiOutput.send(msg);
              HandleMidiIndicators(self, "midiOut");
              last = val;
            }
            if (u >= 1)
              clearInterval(timer);
          }, tickMs);
        } else {
          msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
          self.log("debug", `Sending:  ${msg} to "${self.midiOutput.name}"`);
          self.midiOutput.send(msg);
          HandleMidiIndicators(self, "midiOut");
        }
      }
    };
    if (action.id != "sysex") {
      newAction.options.at(-1).isVisibleExpression = "!$(options:relValue)";
      newAction.options.push({
        id: "varValue",
        type: "number",
        label: action.valLabel,
        default: action.valDefault,
        min: -action.valMax,
        max: action.valMax,
        isVisibleExpression: "!!$(options:relValue)"
      }, {
        id: "relText",
        type: "static-text",
        label: "** NOTE **",
        value: "Relative will only work after a value has been sent from the device!",
        isVisibleExpression: "$(options:relValue)"
      }, {
        id: "relValue",
        type: "checkbox",
        label: "Relative",
        default: false,
        disableAutoExpression: true
      });
      newAction.options.push({
        id: "sendOverTime",
        type: "checkbox",
        label: "Send Over Time",
        default: false,
        disableAutoExpression: true
      }, {
        id: "timeStartValue",
        type: "number",
        label: "Start Value",
        default: 0,
        min: 0,
        max: 127,
        isVisibleExpression: "!!$(options:sendOverTime) && !$(options:relValue)"
      }, {
        id: "time",
        type: "number",
        label: "Time (seconds)",
        default: 1,
        min: 0,
        max: 600,
        isVisibleExpression: "$(options:sendOverTime)"
      }, {
        id: "curve",
        type: "dropdown",
        label: "Curve Type",
        default: "linear",
        choices: [
          { label: "Linear", id: "linear" },
          { label: "Ease In", id: "easeIn" },
          { label: "Ease Out", id: "easeOut" },
          { label: "Ease In/Out", id: "easeInOut" }
        ],
        isVisibleExpression: "$(options:sendOverTime)"
      });
    }
    actions[action.id] = newAction;
  }
  self.setActionDefinitions(actions);
}

// dist/feedbacks.js
function UpdateFeedbacks(self) {
  const feedbacks = {};
  for (const feedback of midiMsgTypes) {
    const newFeedback = {
      name: feedback.label,
      description: feedback.desc,
      type: "boolean",
      defaultStyle: {
        bgcolor: combineRgb(255, 0, 0),
        color: combineRgb(0, 0, 0)
      },
      options: createOptions([], feedback),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        if (event.feedbackId == "sysex") {
          const parsedSysex = await opts[feedback.valId];
          opts.bytes = parsedSysex.split(/[ ,]+/).map((n) => parseInt(n));
        }
        if (opts.relValue) {
          opts[feedback.valId] = Number(await opts.varValue);
          if (opts.chValue)
            opts.channel = Number(await opts.chValue);
          if (opts.noteValue)
            opts.note = Number(await opts.noteValue);
          if (opts.ccValue)
            opts.controller = Number(await opts.ccValue);
        }
        const msg = MidiMessage.parseMessage(void 0, { id: event.feedbackId, ...opts });
        const dataStoreVal = self.getFromDataStore(msg);
        if (event.feedbackId !== "sysex" && opts.createVar && self.config.autoCreateVars && msg !== void 0)
          FBCreatesVar(self, msg, dataStoreVal);
        if (dataStoreVal == void 0)
          return false;
        if (dataStoreVal == self.getValFromMsg(msg).val) {
          return true;
        }
        return false;
      }
    };
    if (feedback.id != "sysex" && self.config.autoCreateVars) {
      newFeedback.options.at(-1).isVisibleExpression = "!$(options:createVar)";
      newFeedback.options.push({
        id: "createVar",
        type: "checkbox",
        label: "Auto-Create Variable",
        default: false,
        disableAutoExpression: true
      });
    }
    feedbacks[feedback.id] = newFeedback;
    feedbacks[feedback.id + "_value"] = {
      ...newFeedback,
      name: feedback.label + " Value",
      type: "value",
      options: newFeedback.options.filter((o) => o.id !== feedback.valId && o.id !== "createVar"),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        const msgId = event.feedbackId.replace("_value", "");
        const msg = MidiMessage.parseMessage(void 0, { id: msgId, ...opts });
        return self.getFromDataStore(msg) ?? 0;
      }
    };
  }
  feedbacks["midiIn"] = {
    name: "MIDI Message Incoming?",
    description: "Fire whenever ANY MIDI message is received",
    type: "boolean",
    defaultStyle: {
      bgcolor: combineRgb(255, 0, 0),
      color: combineRgb(0, 0, 0)
    },
    options: [],
    callback: async () => {
      return !!self.getVariableValue("midiIn");
    }
  };
  feedbacks["midiOut"] = {
    name: "MIDI Message Outgoing?",
    description: "Fire whenever ANY MIDI message is sent",
    type: "boolean",
    defaultStyle: {
      bgcolor: combineRgb(255, 0, 0),
      color: combineRgb(0, 0, 0)
    },
    options: [],
    callback: async () => {
      return !!self.getVariableValue("midiOut");
    }
  };
  self.setFeedbackDefinitions(feedbacks);
}

// dist/presets.js
function UpdatePresets(self) {
  const presets = {
    midi_in: {
      type: "simple",
      name: `MIDI Message In Indicator`,
      style: {
        text: `MIDI IN`,
        size: "auto",
        color: combineRgb(255, 255, 255),
        bgcolor: combineRgb(0, 0, 0)
      },
      steps: [],
      feedbacks: [
        {
          feedbackId: "midiIn",
          options: {},
          style: {
            color: combineRgb(255, 255, 255),
            bgcolor: combineRgb(0, 255, 0)
          }
        }
      ]
    },
    midi_out: {
      type: "simple",
      name: `MIDI Message Out Indicator`,
      style: {
        text: `MIDI OUT`,
        size: "auto",
        color: combineRgb(255, 255, 255),
        bgcolor: combineRgb(0, 0, 0)
      },
      steps: [],
      feedbacks: [
        {
          feedbackId: "midiOut",
          options: {},
          style: {
            color: combineRgb(255, 255, 255),
            bgcolor: combineRgb(0, 255, 0)
          }
        }
      ]
    }
  };
  const structure = [
    {
      id: "indicators",
      name: "Indicators",
      definitions: [
        {
          id: "midi_indicators",
          type: "simple",
          name: "MIDI Indicators",
          presets: ["midi_in", "midi_out"]
        }
      ]
    }
  ];
  self.setPresetDefinitions(structure, presets);
}

// dist/main.js
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  midiInput;
  midiOutput;
  dataStore;
  isRecordingActions;
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    this.dataStore = /* @__PURE__ */ new Map();
    this.updateActions();
    this.updateFeedbacks();
    this.updatePresets();
    this.updateVariableDefinitions();
    await this.configUpdated(config);
  }
  // When module gets deleted
  async destroy() {
    this.midiInput.close();
    this.midiOutput.close();
    this.log("debug", `${this.id} destroyed`);
  }
  async configUpdated(config) {
    this.config = config;
    this.config.inPortIsVirtual = false;
    this.config.outPortIsVirtual = false;
    const inPortName = this.config.inPortIsVirtual ? this.config.inPortVirtualName : this.config.inPortName;
    const outPortName = this.config.outPortIsVirtual ? this.config.outPortVirtualName : this.config.outPortName;
    this.log("debug", `Available MIDI Inputs: ${JSON.stringify(getInputs())}
	Selected MIDI Input:  ${inPortName}`);
    this.log("debug", `Available MIDI Outputs: ${JSON.stringify(getOutputs())}
	Selected MIDI Output: ${outPortName}`);
    this.log("debug", "");
    if (this.midiInput)
      this.midiInput.close();
    if (this.midiOutput)
      this.midiOutput.close();
    this.midiInput = new Input2(inPortName, this.config.inPortIsVirtual);
    this.midiOutput = new Output2(outPortName, this.config.outPortIsVirtual);
    const midiInStatus = this.config.inPortIsVirtual || this.midiInput.isPortOpen();
    const midiOutStatus = this.config.outPortIsVirtual || this.midiOutput.isPortOpen();
    this.log("info", `Selected In  Port "${this.midiInput.name}" is ${midiInStatus ? "" : "NOT "}Open.`);
    this.log("info", `Selected Out Port "${this.midiOutput.name}" is ${midiOutStatus ? "" : "NOT "}Open.`);
    this.updateStatus(InstanceStatus.Disconnected);
    if (!midiInStatus && midiOutStatus)
      this.updateStatus(InstanceStatus.BadConfig, "MIDI In Port not open");
    if (midiInStatus && !midiOutStatus)
      this.updateStatus(InstanceStatus.BadConfig, "MIDI Out Port not open");
    if (midiInStatus && midiOutStatus)
      this.updateStatus(InstanceStatus.Ok);
    this.start();
  }
  // Return config fields for web config
  getConfigFields() {
    return GetConfigFields();
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updatePresets() {
    UpdatePresets(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  // The main loop
  start() {
    this.log("debug", "\nEntering *main*\n");
    this.midiInput.on("smpte", (args) => {
      this.setVariableValues({
        smpte: args.smpte,
        smpteFR: args.smpteFR
      });
    });
    this.midiInput.on("message", (deltaTime, msg) => {
      if (msg.id !== "mtc") {
        this.log("debug", `[${deltaTime.toFixed(2).padStart(6, "0")}] Received: ${msg} from "${this.midiInput.name}"`);
        this.addToDataStore(msg);
        if (this.isRecordingActions)
          this.addToActionRecording(deltaTime, msg);
      }
      HandleMidiIndicators(this, "midiIn");
    });
  }
  addToDataStore(msg) {
    const data = this.getValFromMsg(msg);
    if (data.key > 0) {
      UpdateLastMsg(this, msg, data.val);
      this.dataStore.set(data.key, data.val);
      this.checkAllFeedbacks();
    }
  }
  getFromDataStore(msg) {
    const data = this.getValFromMsg(msg);
    if (data.key > 0) {
      return this.dataStore.get(data.key);
    }
    return void 0;
  }
  getValFromMsg(msg) {
    let lastIndex = msg.bytes.length - 1;
    let parsedKey = 0;
    let parsedVal = 0;
    if (lastIndex >= 0 && msg.status < 240) {
      if (msg.id == "pitch") {
        parsedVal = msg.args.value ?? 0;
        lastIndex--;
      } else {
        parsedVal = msg.bytes[lastIndex];
      }
      for (let i = 0; i < lastIndex; i++) {
        parsedKey += msg.bytes[i] << (lastIndex - i - 1 << 3);
      }
      if (parsedKey == 0)
        parsedKey = parsedVal;
    }
    return { key: parsedKey, val: parsedVal };
  }
  // Track whether actions are being recorded
  handleStartStopRecordActions(isRecording) {
    this.isRecordingActions = isRecording;
  }
  // Add a command to the Action Recorder
  addToActionRecording(deltaTime, msg) {
    const args = { ...msg.args };
    let uniqueId = `${msg.id} ${this.getValFromMsg(msg).key}`;
    if (this.config.useTimeStamp) {
      deltaTime = Math.round(deltaTime * 1e3);
      uniqueId = "";
    } else {
      deltaTime = 0;
    }
    this.recordAction({
      actionId: msg.id,
      options: args,
      delay: deltaTime
    }, uniqueId);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL3BrZy1wcmVidWlsZHMvbGliL3ByZWJ1aWxkLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9wa2ctcHJlYnVpbGRzL2JpbmRpbmdzLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AanVsdXNpYW4vbWlkaS9iaW5kaW5nLW9wdGlvbnMuanMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0BqdWx1c2lhbi9taWRpL2xpYi9pbnN0cnVtZW50cy5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGp1bHVzaWFuL21pZGkvbGliL2RydW1zLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AanVsdXNpYW4vbWlkaS9saWIvbm90ZXMuanMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0BqdWx1c2lhbi9taWRpL2xpYi9tZXNzYWdlcy5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGp1bHVzaWFuL21pZGkvbWlkaS5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbG9nZ2luZy50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvdXRpbC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9zaGFyZWQtdWRwLXNvY2tldC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvaG9zdC1hcGkvY29udGV4dC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9iYXNlLnRzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AY29tcGFuaW9uLW1vZHVsZS9iYXNlL3NyYy9tb2R1bGUtYXBpL2VudW1zLnRzIiwgIi4uLy4uL3NyYy9taWRpL21pZGkudHMiLCAiLi4vLi4vc3JjL21pZGkvbXNndHlwZXMudHMiLCAiLi4vLi4vc3JjL2NvbmZpZy50cyIsICIuLi8uLi9zcmMvdmFyaWFibGVzLnRzIiwgIi4uLy4uL3NyYy91cGdyYWRlcy50cyIsICIuLi8uLi9zcmMvb3BlcmF0aW9ucy50cyIsICIuLi8uLi9zcmMvYWN0aW9ucy50cyIsICIuLi8uLi9zcmMvZmVlZGJhY2tzLnRzIiwgIi4uLy4uL3NyYy9wcmVzZXRzLnRzIiwgIi4uLy4uL3NyYy9tYWluLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJjb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJylcblxuLyoqXG4gKiBHZW5lcmF0ZSB0aGUgZmlsZW5hbWUgb2YgdGhlIHByZWJ1aWxkIGZpbGUuXG4gKiBUaGUgZm9ybWF0IG9mIHRoZSBuYW1lIGlzIHBvc3NpYmxlIHRvIGNhbGN1bGF0ZSBiYXNlZCBvbiBzb21lIG9wdGlvbnNcbiAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zXG4gKiBAcmV0dXJuc1xuICovXG5mdW5jdGlvbiBnZXRQcmVidWlsZE5hbWUob3B0aW9ucykge1xuXHRpZiAoIW9wdGlvbnMubmFwaV92ZXJzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ05BTiBub3QgaW1wbGVtZW50ZWQnKSAvLyBUT0RPXG5cblx0Y29uc3QgdG9rZW5zID0gW1xuXHRcdG9wdGlvbnMubmFtZSxcblx0XHRvcHRpb25zLnBsYXRmb3JtLFxuXHRcdG9wdGlvbnMuYXJjaCxcblx0XHQvLyBvcHRpb25zLmFybXYgPyAob3B0aW9ucy5hcmNoID09PSAnYXJtNjQnID8gJzgnIDogdmFycy5hcm1fdmVyc2lvbikgOiBudWxsLFxuXHRcdG9wdGlvbnMubGliYyAmJiBvcHRpb25zLnBsYXRmb3JtID09PSAnbGludXgnID8gb3B0aW9ucy5saWJjIDogbnVsbCxcblx0XVxuXHRyZXR1cm4gYCR7dG9rZW5zLmZpbHRlcigodCkgPT4gISF0KS5qb2luKCctJyl9LyR7b3B0aW9ucy5ydW50aW1lfS1uYXBpLXYke29wdGlvbnMubmFwaV92ZXJzaW9ufS5ub2RlYFxufVxuXG5mdW5jdGlvbiBpc053anMoKSB7XG5cdHJldHVybiAhIShwcm9jZXNzLnZlcnNpb25zICYmIHByb2Nlc3MudmVyc2lvbnMubncpXG59XG5cbmZ1bmN0aW9uIGlzRWxlY3Ryb24oKSB7XG5cdGlmIChwcm9jZXNzLnZlcnNpb25zICYmIHByb2Nlc3MudmVyc2lvbnMuZWxlY3Ryb24pIHJldHVybiB0cnVlXG5cdGlmIChwcm9jZXNzLmVudi5FTEVDVFJPTl9SVU5fQVNfTk9ERSkgcmV0dXJuIHRydWVcblx0cmV0dXJuIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHdpbmRvdy5wcm9jZXNzICYmIHdpbmRvdy5wcm9jZXNzLnR5cGUgPT09ICdyZW5kZXJlcidcbn1cblxuZnVuY3Rpb24gaXNBbHBpbmUocGxhdGZvcm0pIHtcblx0cmV0dXJuIHBsYXRmb3JtID09PSAnbGludXgnICYmIGZzLmV4aXN0c1N5bmMoJy9ldGMvYWxwaW5lLXJlbGVhc2UnKVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0Z2V0UHJlYnVpbGROYW1lLFxuXHRpc053anMsXG5cdGlzRWxlY3Ryb24sXG5cdGlzQWxwaW5lLFxufVxuIiwgImNvbnN0IHBhdGggPSByZXF1aXJlKCdwYXRoJylcbmNvbnN0IG9zID0gcmVxdWlyZSgnb3MnKVxuY29uc3QgeyBnZXRQcmVidWlsZE5hbWUsIGlzTndqcywgaXNFbGVjdHJvbiwgaXNBbHBpbmUgfSA9IHJlcXVpcmUoJy4vbGliL3ByZWJ1aWxkJylcblxuLy8gSmVzdCBjYW4gYWxsb3cgdXNlcnMgdG8gbW9jayAnZnMnLCBidXQgd2UgbmVlZCB0aGUgcmVhbCBmc1xuY29uc3QgZnMgPSB0eXBlb2YgamVzdCAhPT0gJ3VuZGVmaW5lZCcgPyBqZXN0LnJlcXVpcmVBY3R1YWwoJ2ZzJykgOiByZXF1aXJlKCdmcycpXG5cbi8vIFdvcmthcm91bmQgdG8gZml4IHdlYnBhY2sncyBidWlsZCB3YXJuaW5nczogJ3RoZSByZXF1ZXN0IG9mIGEgZGVwZW5kZW5jeSBpcyBhbiBleHByZXNzaW9uJ1xuY29uc3QgcnVudGltZVJlcXVpcmUgPSB0eXBlb2YgX193ZWJwYWNrX3JlcXVpcmVfXyA9PT0gJ2Z1bmN0aW9uJyA/IF9fbm9uX3dlYnBhY2tfcmVxdWlyZV9fIDogcmVxdWlyZSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG5cbi8qKlxuICogRmluZCB0aGUgYmVzdCBwYXRoIHRvIHRoZSBiaW5kaW5nIGZpbGVcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYXNlUGF0aCAtIEJhc2UgcGF0aCBvZiB0aGUgbW9kdWxlLCB3aGVyZSBiaW5hcmllcyB3aWxsIGJlIGxvY2F0ZWRcbiAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zIC0gRGVzY3JpYmUgaG93IHRoZSBwcmVidWlsdCBiaW5hcnkgaXMgbmFtZWRcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gdmVyaWZ5UHJlYnVpbGQgLSBUcnVlIGlmIHdlIGFyZSB2ZXJpZnlpbmcgdGhhdCBhIHByZWJ1aWxkIGV4aXN0c1xuICogQHBhcmFtIHtib29sZWFufSB0aHJvd09uTWlzc2luZyAtIFRydWUgaWYgYW4gZXJyb3Igc2hvdWxkIGJlIHRocm93biB3aGVuIHRoZSBiaW5hcnkgaXMgbWlzc2luZ1xuICogQHJldHVybnNcbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZVBhdGgoYmFzZVBhdGgsIG9wdGlvbnMsIHZlcmlmeVByZWJ1aWxkLCB0aHJvd09uTWlzc2luZykge1xuXHRpZiAodHlwZW9mIGJhc2VQYXRoICE9PSAnc3RyaW5nJyB8fCAhYmFzZVBhdGgpIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBiYXNlUGF0aCB0byBwa2ctcHJlYnVpbGRzYClcblxuXHRpZiAodHlwZW9mIG9wdGlvbnMgIT09ICdvYmplY3QnIHx8ICFvcHRpb25zKSB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgb3B0aW9ucyB0byBwa2ctcHJlYnVpbGRzYClcblx0aWYgKHR5cGVvZiBvcHRpb25zLm5hbWUgIT09ICdzdHJpbmcnIHx8ICFvcHRpb25zLm5hbWUpIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBuYW1lIHRvIHBrZy1wcmVidWlsZHNgKVxuXG5cdGxldCBpc05vZGVBcGkgPSBmYWxzZVxuXHRpZiAob3B0aW9ucy5uYXBpX3ZlcnNpb25zICYmIEFycmF5LmlzQXJyYXkob3B0aW9ucy5uYXBpX3ZlcnNpb25zKSkge1xuXHRcdGlzTm9kZUFwaSA9IHRydWVcblx0fVxuXG5cdGNvbnN0IGFyY2ggPSAodmVyaWZ5UHJlYnVpbGQgJiYgcHJvY2Vzcy5lbnYubnBtX2NvbmZpZ19hcmNoKSB8fCBvcy5hcmNoKClcblx0Y29uc3QgcGxhdGZvcm0gPSAodmVyaWZ5UHJlYnVpbGQgJiYgcHJvY2Vzcy5lbnYubnBtX2NvbmZpZ19wbGF0Zm9ybSkgfHwgb3MucGxhdGZvcm0oKVxuXG5cdGxldCBydW50aW1lID0gJ25vZGUnXG5cdC8vIElmIG5vZGUtYXBpLCB0aGVuIGV2ZXJ5dGhpbmcgY2FuIHNoYXJlIHRoZSBzYW1lIGJpbmFyeVxuXHRpZiAoIWlzTm9kZUFwaSkge1xuXHRcdGlmICh2ZXJpZnlQcmVidWlsZCAmJiBwcm9jZXNzLmVudi5ucG1fY29uZmlnX3J1bnRpbWUpIHtcblx0XHRcdHJ1bnRpbWUgPSBwcm9jZXNzLmVudi5ucG1fY29uZmlnX3J1bnRpbWVcblx0XHR9IGVsc2UgaWYgKGlzRWxlY3Ryb24oKSkge1xuXHRcdFx0cnVudGltZSA9ICdlbGVjdHJvbidcblx0XHR9IGVsc2UgaWYgKGlzTndqcygpKSB7XG5cdFx0XHRydW50aW1lID0gJ25vZGUtd2Via2l0J1xuXHRcdH1cblx0fVxuXG5cdGNvbnN0IGNhbmRpZGF0ZXMgPSBbXVxuXG5cdGlmICghdmVyaWZ5UHJlYnVpbGQpIHtcblx0XHQvLyBUcnkgZm9yIGEgbG9jYWxseSBidWlsdCBiaW5kaW5nXG5cdFx0Y2FuZGlkYXRlcy5wdXNoKFxuXHRcdFx0cGF0aC5qb2luKGJhc2VQYXRoLCAnYnVpbGQnLCAnRGVidWcnLCBgJHtvcHRpb25zLm5hbWV9Lm5vZGVgKSxcblx0XHRcdHBhdGguam9pbihiYXNlUGF0aCwgJ2J1aWxkJywgJ1JlbGVhc2UnLCBgJHtvcHRpb25zLm5hbWV9Lm5vZGVgKVxuXHRcdClcblx0fVxuXG5cdGxldCBsaWJjID0gdW5kZWZpbmVkXG5cdGlmIChpc0FscGluZShwbGF0Zm9ybSkpIGxpYmMgPSAnbXVzbCdcblxuXHQvLyBMb29rIGZvciBwcmVidWlsZHNcblx0aWYgKGlzTm9kZUFwaSkge1xuXHRcdC8vIExvb2sgZm9yIG5vZGUtYXBpIHZlcnNpb25lZCBidWlsZHNcblx0XHRmb3IgKGNvbnN0IHZlciBvZiBvcHRpb25zLm5hcGlfdmVyc2lvbnMpIHtcblx0XHRcdGNvbnN0IHByZWJ1aWxkTmFtZSA9IGdldFByZWJ1aWxkTmFtZSh7XG5cdFx0XHRcdG5hbWU6IG9wdGlvbnMubmFtZSxcblx0XHRcdFx0cGxhdGZvcm0sXG5cdFx0XHRcdGFyY2gsXG5cdFx0XHRcdGxpYmMsXG5cdFx0XHRcdG5hcGlfdmVyc2lvbjogdmVyLFxuXHRcdFx0XHRydW50aW1lLFxuXHRcdFx0XHQvLyBhcm12OiBvcHRpb25zLmFybXYgPyAoYXJjaCA9PT0gJ2FybTY0JyA/ICc4JyA6IHZhcnMuYXJtX3ZlcnNpb24pIDogbnVsbCxcblx0XHRcdH0pXG5cdFx0XHRjYW5kaWRhdGVzLnB1c2gocGF0aC5qb2luKGJhc2VQYXRoLCAncHJlYnVpbGRzJywgcHJlYnVpbGROYW1lKSlcblx0XHR9XG5cdH0gZWxzZSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgaW1wbGVtZW50ZWQgZm9yIE5BTiEnKVxuXHR9XG5cblx0bGV0IGZvdW5kUGF0aCA9IG51bGxcblxuXHRmb3IgKGNvbnN0IGNhbmRpZGF0ZSBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0aWYgKGZzLmV4aXN0c1N5bmMoY2FuZGlkYXRlKSkge1xuXHRcdFx0Y29uc3Qgc3RhdCA9IGZzLnN0YXRTeW5jKGNhbmRpZGF0ZSlcblx0XHRcdGlmIChzdGF0LmlzRmlsZSgpKSB7XG5cdFx0XHRcdGZvdW5kUGF0aCA9IGNhbmRpZGF0ZVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGlmICghZm91bmRQYXRoICYmIHRocm93T25NaXNzaW5nKSB7XG5cdFx0Y29uc3QgY2FuZGlkYXRlc1N0ciA9IGNhbmRpZGF0ZXMubWFwKChjYW5kKSA9PiBgIC0gJHtjYW5kfWApLmpvaW4oJ1xcbicpXG5cdFx0dGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZmluZCBiaW5kaW5nIGZvciAke29wdGlvbnMubmFtZX1cXG5UcmllZCBwYXRoczpcXG4ke2NhbmRpZGF0ZXNTdHJ9YClcblx0fVxuXG5cdHJldHVybiBmb3VuZFBhdGhcbn1cblxuZnVuY3Rpb24gbG9hZEJpbmRpbmcoYmFzZVBhdGgsIG9wdGlvbnMpIHtcblx0Y29uc3QgZm91bmRQYXRoID0gcmVzb2x2ZVBhdGgoYmFzZVBhdGgsIG9wdGlvbnMsIGZhbHNlLCB0cnVlKVxuXG5cdC8vIE5vdGU6IHRoaXMgZXJyb3Igc2hvdWxkIG5vdCBiZSBoaXQsIGFzIHJlc29sdmVQYXRoIHdpbGwgdGhyb3cgaWYgdGhlIGJpbmRpbmcgaXMgbWlzc2luZ1xuXHRpZiAoIWZvdW5kUGF0aCkgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZmluZCBiaW5kaW5nIGZvciAke29wdGlvbnMubmFtZX1gKVxuXG5cdHJldHVybiBydW50aW1lUmVxdWlyZShmb3VuZFBhdGgpXG59XG5sb2FkQmluZGluZy5yZXNvbHZlID0gcmVzb2x2ZVBhdGhcblxubW9kdWxlLmV4cG9ydHMgPSBsb2FkQmluZGluZ1xuIiwgIm1vZHVsZS5leHBvcnRzID0ge1xuICBuYW1lOiAnbWlkaScsXG4gIG5hcGlfdmVyc2lvbnM6IFs3XSxcbn1cbiIsICIvLyBHZW5lcmFsIE1JREkgcGF0Y2hlc1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICBBQ09VU1RJQ19HUkFORF9QSUFOTyAgICAgICAgOiAwLCBcbiAgICBCUklHSFRfQUNPVVNUSUNfUElBTk8gICAgICAgOiAxLFxuICAgIEVMRUNUUklDX0dSQU5EX1BJQU5PICAgICAgICA6IDIsXG4gICAgSE9OS1lfVE9OS19QSUFOTyAgICAgICAgICAgIDogMyxcbiAgICBFTEVDVFJJQ19QSUFOT18xXHRcdFx0OiA0LFxuICAgIEVMRUNUUklDX1BJQU5PXzIgICAgICAgICAgICA6IDUsXG4gICAgSEFSUFNJQ0hPUkQgICAgICAgICAgICAgICAgIDogNixcbiAgICBDTEFWSVx0XHRcdFx0XHQgICAgOiA3LFxuICAgIENFTEVTVEEgICBcdFx0XHRcdCAgICA6IDgsXG4gICAgR0xPQ0tFTlNQSUVMXHRcdFx0XHQ6IDksXG4gICAgTVVTSUNfQk9YXHRcdFx0XHQgICAgOiAxMCxcbiAgICBWSUJSQVBIT05FXHRcdFx0XHQgICAgOiAxMSxcbiAgICBNQVJJTUJBXHRcdFx0XHRcdCAgICA6IDEyLFxuICAgIFhZTE9QSE9ORSAgICAgICBcdFx0XHQ6IDEzLFxuICAgIFRVQlVMQVJfQkVMTFMgICAgICAgICAgICAgICA6IDE0LFxuICAgIERVTENJTUVSXHRcdFx0XHRcdDogMTUsXG4gICAgRFJBV0JBUl9PUkdBTiAgICAgICAgICAgICAgIDogMTYsXG4gICAgUEVSQ1VTU0lWRV9PUkdBTiAgICAgICAgICAgIDogMTcsXG4gICAgUk9DS19PUkdBTlx0XHRcdFx0ICAgIDogMTgsXG4gICAgQ0hVUkNIX09SR0FOXHRcdFx0XHQ6IDE5LFxuICAgIFJFRURfT1JHQU5cdFx0XHRcdCAgICA6IDIwLFxuICAgIEFDQ09SRElPTlx0XHRcdFx0ICAgIDogMjEsXG4gICAgSEFSTU9OSUNBXHRcdFx0XHQgICAgOiAyMixcbiAgICBUQU5HT19BQ0NPUkRJT04gICAgICAgICAgICAgOiAyMyxcbiAgICBBQ09VU1RJQ19HVUlUQVJfTllMT04gICAgICAgOiAyNCxcbiAgICBBQ09VU1RJQ19HVUlUQVJfU1RFRUwgICAgICAgOiAyNSxcbiAgICBFTEVDVFJJQ19HVUlUQVJfSkFaWiAgICAgICAgOiAyNixcbiAgICBFTEVDVFJJQ19HVUlUQVJfQ0xFQU4gICAgICAgOiAyNyxcbiAgICBFTEVDVFJJQ19HVUlUQVJfTVVURUQgICAgICAgOiAyOCxcbiAgICBPVkVSRFJJVkVOX0dVSVRBUlx0XHQgICAgOiAyOSxcbiAgICBESVNUT1JUSU9OX0dVSVRBUlx0XHQgICAgOiAzMCxcbiAgICBHVUlUQVJfSEFSTU9OSUNTXHRcdFx0OiAzMSxcbiAgICBBQ09VU1RJQ19CQVNTXHRcdCAgICBcdDogMzIsXG4gICAgRUxFQ1RSSUNfQkFTU19GSU5HRVJcdFx0OiAzMyxcbiAgICBFTEVDVFJJQ19CQVNTX1BJQ0tcdCAgICBcdDogMzQsXG4gICAgRlJFVExFU1NfQkFTUyAgICAgICAgICAgICAgIDogMzUsXG4gICAgU0xBUF9CQVNTXzEgICAgICAgICAgICAgICAgIDogMzYsXG4gICAgU0xBUF9CQVNTXzIgICAgICAgICAgICAgICAgIDogMzcsXG4gICAgU1lOVEhfQkFTU18xICAgICAgICAgICAgICAgIDogMzgsXG4gICAgU1lOVEhfQkFTU18yXHRcdFx0XHQ6IDM5LFxuICAgIFZJT0xJTlx0XHRcdFx0ICAgIFx0OiA0MCxcbiAgICBWSU9MQVx0XHRcdCAgICBcdFx0OiA0MSxcbiAgICBDRUxMTyBcdFx0XHQgICAgXHRcdDogNDIsXG4gICAgQ09OVFJBQkFTUyAgICAgICAgICAgICAgXHQ6IDQzLFxuICAgIFRSRU1PTE9fU1RSSU5HUyAgICAgICAgIFx0OiA0NCxcbiAgICBQSVpaSUNBVE9fU1RSSU5HU1x0ICAgIFx0OiA0NSxcbiAgICBPUkNIRVNUUkFMX0hBUlBcdFx0XHQgICAgOiA0NixcbiAgICBUSU1QQU5JICAgICAgICBcdFx0ICAgIFx0OiA0NyxcbiAgICBTVFJJTkdfRU5TRU1CTEVfMVx0XHQgICAgOiA0OCxcbiAgICBTVFJJTkdfRU5TRU1CTEVfMiAgICAgICAgICAgOiA0OSxcbiAgICBTWU5USFNUUklOR1NfMSAgICAgICAgICAgICAgOiA1MCxcbiAgICBTWU5USFNUUklOR1NfMiAgICAgICAgICAgICAgOiA1MSxcbiAgICBDSE9JUl9BQUhTXHRcdFx0ICAgIFx0OiA1MixcbiAgICBWT0lDRV9PT0hTXHRcdFx0ICAgIFx0OiA1MyxcbiAgICBTWU5USF9WT0lDRVx0XHRcdCAgICBcdDogNTQsXG4gICAgT1JDSEVTVFJBX0hJVFx0XHQgICAgXHQ6IDU1LFxuICAgIFRSVU1QRVRcdFx0XHRcdCAgICBcdDogNTYsXG4gICAgVFJPTUJPTkVcdFx0XHRcdFx0OiA1NyxcbiAgICBUVUJBXHRcdFx0XHRcdFx0OiA1OCxcbiAgICBNVVRFRF9UUlVNUEVUXHRcdCAgICBcdDogNTksXG4gICAgRlJFTkNIX0hPUk5cdFx0ICAgIFx0XHQ6IDYwLFxuICAgIEJSQVNTX1NFQ1RJT05cdCAgICBcdFx0OiA2MSxcbiAgICBTWU5USEJSQVNTXzFcdFx0XHRcdDogNjIsXG4gICAgU1lOVEhCUkFTU18yXHRcdFx0XHQ6IDYzLFxuICAgIFNPUFJBTk9fU0FYXHRcdFx0ICAgIFx0OiA2NCxcbiAgICBBTFRPX1NBWFx0XHRcdFx0XHQ6IDY1LFxuICAgIFRFTk9SX1NBWCAgICAgICAgICAgXHRcdDogNjYsXG4gICAgQkFSSVRPTkVfU0FYICAgICAgICBcdFx0OiA2NyxcbiAgICBPQk9FICAgICAgICAgICAgXHRcdFx0OiA2OCxcbiAgICBFTkdMSVNIX0hPUk4gICAgXHRcdCAgXHQ6IDY5LFxuICAgIEJBU1NPT04gICAgICAgICAgICBcdCAgICBcdDogNzAsXG4gICAgQ0xBUklORVQgICAgICAgICAgICBcdFx0OiA3MSxcbiAgICBQSUNDT0xPICAgICAgICAgICAgICBcdCAgICA6IDcyLFxuICAgIEZMVVRFICAgICAgICAgICAgICBcdCAgICBcdDogNzMsXG4gICAgUkVDT1JERVIgICAgICAgICAgIFx0XHQgICAgOiA3NCxcbiAgICBQQU5fRkxVVEVcdFx0XHQgICAgXHQ6IDc1LFxuICAgIEJMT1dOX0JPVFRMRVx0XHRcdFx0OiA3NixcbiAgICBTSEFLVUhBQ0hJXHRcdFx0ICAgIFx0OiA3NyxcbiAgICBXSElTVExFXHRcdFx0XHQgICAgXHQ6IDc4LFxuICAgIE9DQVJJTkFcdFx0XHRcdFx0ICAgIDogNzksXG4gICAgTEVBRF8xX1NRVUFSRVx0ICAgICAgICAgICAgOiA4MCxcbiAgICBMRUFEXzJfU0FXVE9PVEhcdFx0XHQgICAgOiA4MSxcbiAgICBMRUFEXzNfQ0FMTElPUEVcdFx0XHQgICAgOiA4MixcbiAgICBMRUFEXzRfQ0hJRkZcdFx0XHRcdDogODMsXG4gICAgTEVBRF81X0NIQVJBTkdcdFx0ICAgIFx0OiA4NCxcbiAgICBMRUFEXzZfVk9JQ0UgXHRcdCAgICBcdDogODUsXG4gICAgTEVBRF83X0ZJRlRIU1x0XHRcdCAgICA6IDg2LFxuICAgIExFQURfOF9CQVNTX0FORF9MRUFEXHRcdDogODcsXG4gICAgUEFEXzFfTkVXX0FHRVx0XHQgICAgXHQ6IDg4LFxuICAgIFBBRF8yX1dBUk1cdFx0XHQgICAgXHQ6IDg5LFxuICAgIFBBRF8zX1BPTFlTWU5USFx0XHQgICAgXHQ6IDkwLFxuICAgIFBBRF80X0NIT0lSXHRcdCAgICBcdFx0OiA5MSxcbiAgICBQQURfNV9CT1dFRFx0XHQgICAgXHRcdDogOTIsXG4gICAgUEFEXzZfTUVUQUxMSUNcdCAgICBcdFx0OiA5MyxcbiAgICBQQURfN19IQUxPXHRcdCAgICBcdFx0OiA5NCxcbiAgICBQQURfOF9TV0VFUFx0XHQgICAgXHRcdDogOTUsXG4gICAgRlhfMV9SQUlOXHRcdCAgICBcdFx0OiA5NixcbiAgICBGWF8yX1NPVU5EVFJBQ0tcdCAgICBcdFx0OiA5NyxcbiAgICBGWF8zX0NSWVNUQUxcdFx0XHRcdDogOTgsXG4gICAgRlhfNF9BVE1PU1BIRVJFXHQgICAgXHRcdDogOTksXG4gICAgRlhfNV9CUklHSFRORVNTXHQgICAgXHRcdDogMTAwLFxuICAgIEZYXzZfR09CTElOU1x0XHRcdFx0OiAxMDEsXG4gICAgRlhfN19FQ0hPRVNcdFx0ICAgIFx0XHQ6IDEwMixcbiAgICBGWF84X1NDSUZJXHRcdCAgICBcdFx0OiAxMDMsXG4gICAgU0lUQVJcdFx0XHQgICAgXHRcdDogMTA0LFxuICAgIEJBTkpPXHRcdFx0ICAgIFx0XHQ6IDEwNSxcbiAgICBTSEFNSVNFTlx0XHRcdFx0XHQ6IDEwNixcbiAgICBLT1RPXHRcdFx0XHRcdFx0OiAxMDcsXG4gICAgS0FMSU1CQVx0XHRcdCAgICBcdFx0OiAxMDgsXG4gICAgQkFHX1BJUEVcdFx0XHRcdFx0OiAxMDksXG4gICAgRklERExFXHRcdFx0ICAgIFx0XHQ6IDExMCxcbiAgICBTSEFOQUlcdFx0XHRcdCAgICBcdDogMTExLFxuICAgIFRJTktMRV9CRUxMXHRcdFx0ICAgIFx0OiAxMTIsXG4gICAgQUdPR09cdFx0XHRcdCAgICBcdDogMTEzLFxuICAgIFNURUVMX0RSVU1TXHRcdFx0ICAgIFx0OiAxMTQsXG4gICAgV09PREJMT0NLXHRcdFx0XHQgICAgOiAxMTUsXG4gICAgVEFJS09fRFJVTSAgXHRcdFx0XHQ6IDExNixcbiAgICBNRUxPRElDX1RPTVx0ICAgIFx0XHRcdDogMTE3LFxuICAgIFNZTlRIX0RSVU1cdFx0ICAgIFx0XHQ6IDExOCxcbiAgICBSRVZFUlNFX0NZTUJBTFx0XHQgICAgXHQ6IDExOSxcbiAgICBHVUlUQVJfRlJFVF9OT0lTRVx0XHQgICAgOiAxMjAsXHRcbiAgICBCUkVBVEhfTk9JU0VcdFx0XHRcdDogMTIxLFxuICAgIFNFQVNIT1JFXHRcdFx0XHRcdDogMTIyLFxuICAgIEJJUkRfVFdFRVRcdFx0ICAgIFx0XHQ6IDEyMyxcbiAgICBURUxFUEhPTkVfUklOR1x0XHQgICAgXHQ6IDEyNCxcbiAgICBIRUxJQ09QVEVSXHRcdFx0XHQgICAgOiAxMjUsXG4gICAgQVBQTEFVU0VcdFx0XHRcdFx0OiAxMjYsXG4gICAgR1VOU0hPVCAgICAgICAgICAgICAgICAgICAgIDogMTI3LFxufTtcbiIsICIvLyBHZW5lcmFsIE1JREkgZHJ1bSBwYXRjaGVzLCB0cmFjayAxMFxubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICBBQ09VU1RJQ19CQVNTX0RSVU1cdCAgICA6IDM1LFxuICAgIEJBU1NfRFJVTVx0XHRcdFx0OiAzNixcbiAgICBTSURFX1NUSUNLXHRcdFx0ICAgIDogMzcsXG4gICAgQUNPVVNUSUNfU05BUkVcdFx0ICAgIDogMzgsXG4gICAgSEFORF9DTEFQXHRcdFx0XHQ6IDM5LFxuICAgIEVMRUNUUklDX1NOQVJFXHRcdCAgICA6IDQwLFxuICAgIExPV19GTE9PUl9UT01cdFx0XHQ6IDQxLFxuICAgIENMT1NFRF9ISV9IQVRcdFx0XHQ6IDQyLFxuICAgIEhJR0hfRkxPT1JfVE9NXHRcdCAgICA6IDQzLFxuICAgIFBFREFMX0hJX0hBVFx0XHRcdDogNDQsXG4gICAgTE9XX1RPTVx0XHRcdFx0ICAgIDogNDUsXG4gICAgT1BFTl9ISV9IQVRcdCAgICBcdFx0OiA0NixcbiAgICBMT1dfTUlEX1RPTVx0ICAgIFx0XHQ6IDQ3LFxuICAgIEhJX01JRF9UT01cdCAgICBcdFx0OiA0OCxcbiAgICBDUkFTSF9DWU1CQUxfMVx0ICAgIFx0OiA0OSxcbiAgICBISUdIX1RPTVx0XHRcdFx0OiA1MCxcbiAgICBSSURFX0NZTUJBTF8xXHRcdFx0OiA1MSxcbiAgICBDSElORVNFX0NZTUJBTFx0ICAgIFx0OiA1MixcbiAgICBSSURFX0JFTExcdFx0XHRcdDogNTMsXG4gICAgVEFNQk9VUklORVx0XHQgICAgXHQ6IDU0LFxuICAgIFNQTEFTSF9DWU1CQUxcdFx0XHQ6IDU1LFxuICAgIENPV0JFTExcdFx0XHQgICAgXHQ6IDU2LFxuICAgIENSQVNIX0NZTUJBTF8yXHQgICAgXHQ6IDU3LFxuICAgIFZJQlJBX1NMQVBcdFx0ICAgIFx0OiA1OCxcbiAgICBSSURFX0NZTUJBTF8yXHRcdFx0OiA1OSxcbiAgICBISV9CT05HT1x0XHRcdFx0OiA2MCxcbiAgICBMT1dfQk9OR09cdFx0XHRcdDogNjEsXG4gICAgTVVURV9ISV9DT05HQVx0XHRcdDogNjIsXG4gICAgT1BFTl9ISV9DT05HQVx0XHRcdDogNjMsXG4gICAgTE9XX0NPTkdBXHRcdFx0XHQ6IDY0LFxuICAgIEhJR0hfVElNQkFMRVx0XHRcdDogNjUsXG4gICAgTE9XX1RJTUJBTEVcdCAgICBcdFx0OiA2NixcbiAgICBISUdIX0FHT0dPXHRcdCAgICBcdDogNjcsXG4gICAgTE9XX0FHT0dPXHRcdFx0XHQ6IDY4LFxuICAgIENBQkFTQVx0XHRcdCAgICBcdDogNjksXG4gICAgTUFSQUNBU1x0XHRcdCAgICBcdDogNzAsXG4gICAgU0hPUlRfV0hJU1RMRVx0XHRcdDogNzEsXG4gICAgTE9OR19XSElTVExFXHRcdFx0OiA3MixcbiAgICBTSE9SVF9HVUlST1x0XHQgICAgXHQ6IDczLFxuICAgIExPTkdfR1VJUk9cdFx0ICAgIFx0OiA3NCxcbiAgICBDTEFWRVNcdFx0XHQgICAgXHQ6IDc1LFxuICAgIEhJX1dPT0RfQkxPQ0tcdFx0XHQ6IDc2LFxuICAgIExPV19XT09EX0JMT0NLXHQgICAgXHQ6IDc3LFxuICAgIE1VVEVfQ1VJQ0FcdFx0ICAgIFx0OiA3OCxcbiAgICBPUEVOX0NVSUNBXHRcdCAgICBcdDogNzksXG4gICAgTVVURV9UUklBTkdMRVx0XHRcdDogODAsXG4gICAgT1BFTl9UUklBTkdMRVx0XHRcdDogODEsXG59O1xuIiwgIi8vIE1JREkgbm90ZXNcbm1vZHVsZS5leHBvcnRzID0ge1xuXG4gICAgLypcbiAgICAqKiBUaGUgTUlESSBzcGVjIG9ubHkgaW5kaWNhdGVzIG1pZGRsZSBDIHRvIGJlXG4gICAgKiogNjAuIEl0IGRvZXNuJ3QgaW5kaWNhdGUgd2hpY2ggb2N0YXZlIHRoaXMgaXMuXG4gICAgKiogU29tZSBtYXkgY29uc2lkZXIgNCwgaWYgdGhleSBsYWJlbCBvY3RhdmVzIFxuICAgICoqIGZyb20gLTEsIGluc3RlYWQgb2YgMC4gSSBoYXZlIGFkb3B0ZWQgb24gb2N0YXZlXG4gICAgKiogbnVtYmVyIEMgaGVyZS5cbiAgICAqL1xuICAgIE1JRERMRV9DIDogNjAsXG4gICAgXG4gICAgLy8gUmVsYXRpdmUgb2Zmc2V0c1xuICAgIENcdFx0OiAwLFxuICAgIENfU0hBUlAgOiAxLFxuICAgIENfRkxBVFx0OiAtMSxcbiAgICBEXHRcdDogMixcbiAgICBEX1NIQVJQIDogMyxcbiAgICBEX0ZMQVQgIDogMSxcbiAgICBFXHRcdDogNCxcbiAgICBFX1NIQVJQIDogNSxcbiAgICBFX0ZMQVQgIDogMyxcbiAgICBGXHRcdDogNSxcbiAgICBGX1NIQVJQIDogNixcbiAgICBGX0ZMQVQgIDogNCxcbiAgICBHXHRcdDogNyxcbiAgICBHX1NIQVJQIDogOCxcbiAgICBHX0ZMQVQgIDogNixcbiAgICBBXHRcdDogOSxcbiAgICBBX1NIQVJQIDogMTAsXG4gICAgQV9GTEFUICA6IDgsXG4gICAgQlx0XHQ6IDExLFxuICAgIEJfU0hBUlAgOiAxMixcbiAgICBCX0ZMQVQgIDogMTAsXG5cbiAgICAvLyBGb3IgdGhlIG9jdGF2ZXNcbiAgICBDMFx0OiAwLCBcbiAgICBDMVx0OiAxMixcbiAgICBDMlx0OiAyNCxcbiAgICBDM1x0OiAzNixcbiAgICBDNFx0OiA0OCxcbiAgICBDNVx0OiA2MCxcbiAgICBDNlx0OiA3MixcbiAgICBDN1x0OiA4NCxcbiAgICBDOFx0OiA5NixcbiAgICBDOVx0OiAxMDgsXG4gICAgQzEwXHQ6IDEyMCxcblxufTtcblxuIiwgIi8vIE1JREkgbWVzc2FnZXNcbm1vZHVsZS5leHBvcnRzID0ge1xuXG4gICAgLy8gQWxsIGJhc2ljIG1lc3NhZ2VzIGFyZSBoZWxkIGluIHRoZSByb290LCBiZWNhdXNlIG9mIGhvdyBjb21tb25seSB0aGV5J3JlXG4gICAgLy8gdXNlZC4gTHVja2lseSwgdGhlcmUncyBubyBuYW1lIGNsYXNoZXMgd2l0aCBzdWItbmFtZXNcbiAgICBOT1RFX09GRjogICAgICAgICAgIDB4ODAsXHRcdC8qIFsgcGl0Y2gsIHZvbHVtZSBdICovXG4gICAgTk9URV9PTjogICAgICAgICAgICAweDkwLFx0XHQvKiBbIHBpdGNoLCB2b2x1bWUgXSAqL1xuICAgIE5PVEVfS0VZX1BSRVNTVVJFOiAgMHhhMCxcdFx0LyogWyBwaXRjaCwgcHJlc3N1cmUgKGFmdGVyIHRvdWNoKSBdICovXG4gICAgU0VUX1BBUkFNRVRFUjogICAgICAweGIwLFx0XHQvKiBbIHBhcmFtIG51bWJlciAoQ0MpLCBzZXR0aW5nIF0gKi9cbiAgICBTRVRfUFJPR1JBTTogICAgICAgIDB4YzAsXHRcdC8qIFsgcHJvZ3JhbSBdICovXG4gICAgQ0hBTkdFX1BSRVNTVVJFOiAgICAweGQwLFx0XHQvKiBbIHByZXNzdXJlIChhZnRlciB0b3VjaCkgXSAqL1xuICAgIFNFVF9QSVRDSFdIRUVMOiAgICAgMHhlMCxcdFx0LyogWyBMU0IsICBNU0IgKHR3byA3IGJpdCB2YWx1ZXMpIF0gKi9cbiAgICBcbiAgICBNRVRBRVZFTlQ6ICAgICAgICAgIDB4ZmYsXG4gICAgU1lTX0VYMTogICAgICAgICAgICAweGYwLFxuICAgIFNZU19FWDI6ICAgICAgICAgICAgMHhmNyxcblxuICAgIC8qIEFsdGVybmF0aXZlIG5hbWVzICovXG4gICAgUEFUQ0hfQ0hBTkdFOiAgICAgICAweGMwLCAgICAgICAvKiBFcXVpdmFsZW50IHRvIFNFVF9QUk9HUkFNICovXG4gICAgQ09OVFJPTF9DSEFOR0U6ICAgICAweGIwLCAgICAgICAvKiBFcXVpdmFsZW50IHRvIFNFVF9QQVJBTUVURVIgKi9cblxuICAgIFNZU01BU0s6ICAgICAgICAgICAgMHhmMCxcblxuXG4gICAgLy8gQ29udHJvbCBjaGFuZ2VzXG4gICAgY2M6IHtcblx0XHQvKiAwLTMxLCB3aGVyZSBkZWZpbmVkLCBhbGwgaW5kaWNhdGUgdGhlIE1TQiAqL1xuXHRcdEJBTktfU0VMRUNUOlx0XHQgICAgMCxcblx0XHRNT0RVTEFUSU9OOiAgICAgICAgICAgICAxLFxuXHRcdEJSRUFUSF9DT05UUk9MOiAgICAgICAgIDIsXG5cdFx0VU5ERUZJTkVEXzM6ICAgICAgICAgICAgMyxcblx0XHRGT09UX0NPTlRST0w6ICAgICAgICAgICA0LFxuXHRcdFBPUlRBTUVOVE9fVElNRTogICAgICAgIDUsXG5cdFx0REFURV9FTlRSWTogICAgICAgICAgICAgNixcblx0XHRWT0xVTUU6ICAgICAgICAgICAgICAgICA3LFxuXHRcdEJBTEFOQ0U6ICAgICAgICAgICAgICAgIDgsXG5cdFx0VU5ERUZJTkVEXzk6ICAgICAgICAgICAgOSxcblx0XHRQQU46ICAgICAgICAgICAgICAgICAgICAxMCxcblx0XHRFWFBSRVNTSU9OOiAgICAgICAgICAgICAxMSxcblx0XHRFRkZFQ1RfQ09OVFJPTF8xOiAgICAgICAxMixcblx0XHRFRkZFQ1RfQ09OVFJPTF8yOiAgICAgICAxMyxcblx0XHRVTkRFRklORURfMTQ6ICAgICAgICAgICAxNCxcblx0XHRVTkRFRklORURfMTU6ICAgICAgICAgICAxNSxcblx0XHRHRU5FUkFMX1BVUlBPU0VfMTogICAgICAxNixcblx0XHRHRU5FUkFMX1BVUlBPU0VfMjpcdFx0MTcsXG5cdFx0R0VORVJBTF9QVVJQT1NFXzM6XHRcdDE4LFxuXHRcdEdFTkVSQUxfUFVSUE9TRV80Olx0XHQxOSxcblxuICAgICAgICAvKiAyMC0zMSBhcmUgdW5kZWZpbmVkICovXG5cdFx0VU5ERUZJTkVEXzIwOiAgICAgICAgICAgMjAsXG5cdFx0VU5ERUZJTkVEXzIxOiAgICAgICAgICAgMjEsXG5cdFx0VU5ERUZJTkVEXzIyOiAgICAgICAgICAgMjIsXG5cdFx0VU5ERUZJTkVEXzIzOiAgICAgICAgICAgMjMsXG5cdFx0VU5ERUZJTkVEXzI0OiAgICAgICAgICAgMjQsXG5cdFx0VU5ERUZJTkVEXzI1OiAgICAgICAgICAgMjUsXG5cdFx0VU5ERUZJTkVEXzI2OiAgICAgICAgICAgMjYsXG5cdFx0VU5ERUZJTkVEXzI3OiAgICAgICAgICAgMjcsXG5cdFx0VU5ERUZJTkVEXzI4OiAgICAgICAgICAgMjgsXG5cdFx0VU5ERUZJTkVEXzI5OiAgICAgICAgICAgMjksXG5cdFx0VU5ERUZJTkVEXzMwOiAgICAgICAgICAgMzAsXG5cdFx0VU5ERUZJTkVEXzMxOiAgICAgICAgICAgMzEsXG5cbiAgICAgICAgLyogTFNCIGZvciBjb250cm9sIGNoYW5nZXMgMC0zMVx0XHQzMi02MyAqL1xuXHRcdEJBTktfU0VMRUNUX0xTQjpcdFx0MzIsXG4gICAgICAgIE1PRFVMQVRJT05fTFNCOiAgICAgICAgIDMzLFxuICAgICAgICBCUkVBVEhfQ09OVFJPTF9MU0I6ICAgICAzNCxcblx0XHRVTkRFRklORURfMzU6ICAgICAgICAgICAzNSxcbiAgICAgICAgRk9PVF9DT05UUk9MX0xTQjogICAgICAgMzYsXG4gICAgICAgIFBPUlRBTUVOVE9fVElNRV9MU0I6ICAgIDM3LFxuICAgICAgICBEQVRBX0VOVFJZX0xTQjogICAgICAgICAzOCxcbiAgICAgICAgVk9MVU1FX0xTQjogICAgICAgICAgICAgMzksXG4gICAgICAgIEJBTEFOQ0VfTFNCOiAgICAgICAgICAgIDQwLFxuXHRcdFVOREVGSU5FRF80MTogICAgICAgICAgIDQxLFxuICAgICAgICBQQU5fTFNCOiAgICAgICAgICAgICAgICA0MixcbiAgICAgICAgRVhQUkVTU0lPTl9MU0I6ICAgICAgICAgNDMsXG4gICAgICAgIEVGRkVDVF9DT05UUk9MXzFfTFNCOiAgIDQ0LFxuICAgICAgICBFRkZFQ1RfQ09OVFJPTF8yX0xTQjogICA0NSxcblxuICAgICAgICBVTkRFRklORURfNDY6ICAgICAgICAgICA0Nixcblx0XHRVTkRFRklORURfNDc6ICAgICAgICAgICA0NyxcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzFfTFNCOiAgNDgsXG4gICAgICAgIEdFTkVSQUxfUFVSUE9TRV8yX0xTQjogIDQ5LFxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfM19MU0I6ICA1MCxcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzRfTFNCOiAgNTEsXG5cbiAgICAgICAgLyogNTItNjMgYXJlIHVuZGVmaW5lZCAqL1xuXHRcdFVOREVGSU5FRF81MjogICAgICAgICAgIDUyLFxuXHRcdFVOREVGSU5FRF81MzogICAgICAgICAgIDUzLFxuXHRcdFVOREVGSU5FRF81NDogICAgICAgICAgIDU0LFxuXHRcdFVOREVGSU5FRF81NTogICAgICAgICAgIDU1LFxuXHRcdFVOREVGSU5FRF81NjogICAgICAgICAgIDU2LFxuXHRcdFVOREVGSU5FRF81NzogICAgICAgICAgIDU3LFxuXHRcdFVOREVGSU5FRF81ODogICAgICAgICAgIDU4LFxuXHRcdFVOREVGSU5FRF81OTogICAgICAgICAgIDU5LFxuXHRcdFVOREVGSU5FRF82MDogICAgICAgICAgIDYwLFxuXHRcdFVOREVGSU5FRF82MTogICAgICAgICAgIDYxLFxuXHRcdFVOREVGSU5FRF82MjogICAgICAgICAgIDYyLFxuXHRcdFVOREVGSU5FRF82MzogICAgICAgICAgIDYzLFxuXG4gICAgICAgIFNVU1RBSU5fUEVEQUw6ICAgICAgICAgIDY0LFxuXHRcdFBPUlRBTUVOVE86ICAgICAgICAgICAgIDY1LFxuICAgICAgICBQRURBTF9TVVNURU5VVE86ICAgICAgICA2NixcbiAgICAgICAgUEVEQUxfU09GVDogICAgICAgICAgICAgNjcsXG4gICAgICAgIExFR0FUT19GT09UX1NXSVRDSDogICAgIDY4LFxuXHRcdEhPTERfMjogICAgICAgICAgICAgICAgIDY5LFxuICAgICAgICBTT1VORF9WQVJJQVRJT046ICAgICAgICA3MCxcblx0XHRUSU1CUkU6ICAgICAgICAgICAgICAgICA3MSxcbiAgICAgICAgUkVMRUFTRV9USU1FOiAgICAgICAgICAgNzIsXG5cdFx0QVRUQUNLVElNRTogICAgICAgICAgICAgNzMsXG4gICAgICAgIEJSSUdIVE5FU1M6ICAgICAgICAgICAgIDc0LFxuXHRcdFJFVkVSQjogICAgICAgICAgICAgICAgIDc1LFxuXHRcdERFTEFZOiAgICAgICAgICAgICAgICAgIDc2LFxuICAgICAgICBQSVRDSF9UUkFOU1BPU0U6ICAgICAgICA3Nyxcblx0XHRGTEFOR0U6ICAgICAgICAgICAgICAgICA3OCxcbiAgICAgICAgU1BFQ0lBTF9GWDogICAgICAgICAgICAgNzksXG5cbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzVfTFNCOiAgODAsXG4gICAgICAgIEdFTkVSQUxfUFVSUE9TRV82X0xTQjogIDgxLFxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfN19MU0I6ICA4MixcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzhfTFNCOiAgODMsXG5cbiAgICAgICAgUE9SVEFNRU5UT19DT05UUk9MOiAgICAgODQsXG5cbiAgICAgICAgLyogODUtOTAgYXJlIHVuZGVmaW5lZCAqL1xuXHRcdFVOREVGSU5FRF84NTogICAgICAgICAgIDg1LFxuXHRcdFVOREVGSU5FRF84NjogICAgICAgICAgIDg2LFxuXHRcdFVOREVGSU5FRF84NzogICAgICAgICAgIDg3LFxuXHRcdFVOREVGSU5FRF84ODogICAgICAgICAgIDg4LFxuXHRcdFVOREVGSU5FRF84OTogICAgICAgICAgIDg5LFxuXHRcdFVOREVGSU5FRF85MDogICAgICAgICAgIDkwLFxuXG4gICAgICAgIC8qIEVmZmVjdHMgZGVwdGggKi9cblx0XHRGWF9ERVBUSDogICAgICAgICAgICAgICA5MSxcblx0XHRUUkVNRUxPX0RFUFRIOiAgICAgICAgICA5MixcbiAgICAgICAgQ0hPUlVTX0RFUFRIOiAgICAgICAgICAgOTMsXG4gICAgICAgIENFTEVTVEFfREVQVEg6ICAgICAgICAgIDk0LFxuICAgICAgICBQSEFTRVJfREVQVEg6ICAgICAgICAgICA5NSxcblx0XHREQVRBX0lOQzogICAgICAgICAgICAgICA5Nixcblx0XHREQVRBX0RFQzogICAgICAgICAgICAgICA5NyxcbiAgICAgICAgTk9OX1JFR19QQVJBTV9MU0I6ICAgICAgOTgsXG4gICAgICAgIE5PTl9SRUdfUEFSQU1fTVNCOiAgICAgIDk5LFxuICAgICAgICBSRUdfUEFSQU1fTFNCOiAgICAgICAgICAxMDAsXG4gICAgICAgIFJFR19QQVJBTV9NU0I6ICAgICAgICAgIDEwMSxcblxuICAgICAgICAvKiAxMDItMTE5IGFyZSB1bmRlZmluZWQgKi9cblx0XHRVTkRFRklORURfMTAyOiAgICAgICAgICAxMDIsXG5cdFx0VU5ERUZJTkVEXzEwMzogICAgICAgICAgMTAzLFxuXHRcdFVOREVGSU5FRF8xMDQ6ICAgICAgICAgIDEwNCxcblx0XHRVTkRFRklORURfMTA1OiAgICAgICAgICAxMDUsXG5cdFx0VU5ERUZJTkVEXzEwNjogICAgICAgICAgMTA2LFxuXHRcdFVOREVGSU5FRF8xMDc6ICAgICAgICAgIDEwNyxcblx0XHRVTkRFRklORURfMTA4OiAgICAgICAgICAxMDgsXG5cdFx0VU5ERUZJTkVEXzEwOTogICAgICAgICAgMTA5LFxuXHRcdFVOREVGSU5FRF8xMTA6ICAgICAgICAgIDExMCxcblx0XHRVTkRFRklORURfMTExOiAgICAgICAgICAxMTEsXG5cdFx0VU5ERUZJTkVEXzExMjogICAgICAgICAgMTEyLFxuXHRcdFVOREVGSU5FRF8xMTM6ICAgICAgICAgIDExMyxcblx0XHRVTkRFRklORURfMTE0OiAgICAgICAgICAxMTQsXG5cdFx0VU5ERUZJTkVEXzExNTogICAgICAgICAgMTE1LFxuXHRcdFVOREVGSU5FRF8xMTY6ICAgICAgICAgIDExNixcblx0XHRVTkRFRklORURfMTE3OiAgICAgICAgICAxMTcsXG5cdFx0VU5ERUZJTkVEXzExODogICAgICAgICAgMTE4LFxuXHRcdFVOREVGSU5FRF8xMTk6ICAgICAgICAgIDExOSxcblxuICAgICAgICAvLyBNb2Rlc1xuICAgICAgICBBTExfU09VTkRfT0ZGOiAgICAgICAgICAxMjAsXG4gICAgICAgIFJFU0VUX0FMTF9DT05UUk9MTEVSUzogIDEyMSxcblx0XHRMT0NBTF9DT05UUk9MOiAgICAgICAgICAxMjIsXG4gICAgICAgIEFMTF9OT1RFU19PRkY6ICAgICAgICAgIDEyMyxcblx0XHRPTU5JX01PREVfT0ZGOiAgICAgICAgICAxMjQsXG5cdFx0T01OSV9NT0RFX09OOiAgICAgICAgICAgMTI1LFxuXHRcdE1PTk9fTU9ERV9PTjogICAgICAgICAgIDEyNixcblx0XHRQT0xZX01PREVfT046ICAgICAgICAgICAxMjcsXG5cblx0XHQvKiBBbHRlcm5hdGl2ZSBuYW1lcyAqL1xuXHRcdE1PRF9XSEVFTDogICAgICAgICAgICAgIDEsXG5cblx0XHQvKiBBbGwgc291bmQgY29udHJvbGxlcnMgaGF2ZSBvbmx5IExTQiAqL1xuXHRcdEhBUk1fQ09OVEVOVDogICAgICAgICAgIDcxLFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzE6ICAgICA3MCxcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl8yOiAgICAgNzEsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfMzogICAgIDcyLFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzQ6ICAgICA3MyxcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl81OiAgICAgNzQsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfNjogICAgIDc1LFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzc6ICAgICA3NixcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl84OiAgICAgNzcsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfOTogICAgIDc4LFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzEwOiAgICA3OSxcblxuICAgICAgICBFRkZFQ1RfMV9ERVBUSDogICAgICAgICA5MSxcblx0XHRFRkZFQ1RfMl9ERVBUSDogICAgICAgICA5Mixcblx0XHRFRkZFQ1RfM19ERVBUSDogICAgICAgICA5Myxcblx0XHRFRkZFQ1RfNF9ERVBUSDogICAgICAgICA5NCxcblx0XHRFRkZFQ1RfNV9ERVBUSDogICAgICAgICA5NSxcblxuICAgICAgICBERVRVTkVfREVQVEg6ICAgICAgICAgICA5NCxcbiAgICB9LFxuXG5cbiAgICAvKlxuICAgICoqIFN5c3RlbSBDb21tb24gKFN0YXR1cyBieXRlOiAxMTExIDB0dHQpXG4gICAgKi9cbiAgICBzeXNjb21tb246IHtcbiAgICAgICAgVU5ERUZJTkVEXzE6ICAgICAgICAgICAgMHhmMSxcbiAgICAgICAgU09OR19QT1NJVElPTjogICAgICAgICAgMHhmMiwgLyogW0xTQiwgTVNCXSAqL1xuICAgICAgICBTT05HX1NFTEVDVDogICAgICAgICAgICAweGYzLFxuICAgICAgICBVTkRFRklORURfNDogICAgICAgICAgICAweGY0LFxuICAgICAgICBVTkRFRklORURfNTogICAgICAgICAgICAweGY1LFxuICAgICAgICBUVU5FX1JFUVVFU1Q6ICAgICAgICAgICAweGY2LFxuICAgICAgICBFT1g6ICAgICAgICAgICAgICAgICAgICAweGY3LCAvKiBFbmQgb2YgRXhjbHVzaXZlICovXG4gICAgfSxcblxuXG4gICAgLypcbiAgICAqKiBTeXN0ZW0gUmVhbCBUaW1lIChTdGF0dXMgYnl0ZTogMTExMSAxdHR0KVxuICAgICovXG4gICAgcmVhbHRpbWU6IHtcbiAgICAgICAgVElNSU5HX0NMT0NLOiAgIDB4ZjgsXG4gICAgICAgIFVOREVGSU5FRF9GOTogICAweGY5LFxuICAgICAgICBTVEFSVDogICAgICAgICAgMHhmYSxcbiAgICAgICAgQ09OVElOVUU6ICAgICAgIDB4ZmIsXG4gICAgICAgIFNUT1A6ICAgICAgICAgICAweGZjLFxuICAgICAgICBVTkRFRklORURfRkQ6ICAgMHhmZCxcbiAgICAgICAgQUNUSVZFX1NFTlNJTkc6IDB4ZmUsXG4gICAgICAgIFNZU1RFTV9SRVNFVDogICAweGZmLFxuICAgIH0sXG5cblxuICAgIC8qXG4gICAgKiogU3lzdGVtIEV4Y2x1c2l2ZSAoU3RhdHVzIGJ5dGU6IDExMTEgMDAwMClcbiAgICAqKlxuICAgICoqIFRoZSBmaXJzdCBieXRlIG9mIGEgc3lzZXggbXVzdCBiZSB0aGUgaWRlbnRpZmljYXRpb24gbnVtYmVyXG4gICAgKiogKDcgYml0cywgTVNCPTApLiBUaGlzIGlzIGZvbGxvd2VkIGJ5IGFuIGFyYml0YXJ5IG51bWJlciBvZlxuICAgICoqIGRhdGEgYnl0ZXMgKGFsbCBNU0I9MCksIGFuZCBlbmRpbmcgaW4gdGhlIHNleEVPWCBtc2cuXG4gICAgKiogTm90ZTogQW55IG90aGVyIHN0YXR1cyBieXRlICh3aGVyZSBNU0I9MSkgd2lsbCBhbHNvIHRlcm1pbmF0ZVxuICAgICoqIGEgc3lzZXggbWVzc2FnZSwgd2l0aCB0aGUgZXhjZXB0aW9uIG9mIHRoZSBTeXN0ZW0gUmVhbCBUaW1lXG4gICAgKiogZXZlbnRzIGFib3ZlLlxuICAgICovXG4gICAgc3lzZXg6IHtcbiAgICAgICAgRU9YOiAgICAgICAgICAgICAgICAgICAgMHhmNywgLyogRW5kIG9mIEV4Y2x1c2l2ZSAqL1xuICAgIH0sXG5cbn07XG4iLCAiY29uc3QgbWlkaSA9IHJlcXVpcmUoXCJwa2ctcHJlYnVpbGRzL2JpbmRpbmdzXCIpKFxuICBfX2Rpcm5hbWUsXG4gIHJlcXVpcmUoXCIuL2JpbmRpbmctb3B0aW9uc1wiKVxuKTtcbmNvbnN0IFN0cmVhbSA9IHJlcXVpcmUoJ3N0cmVhbScpO1xuXG4vLyBNSURJIGlucHV0IGluaGVyaXRzIGZyb20gRXZlbnRFbWl0dGVyXG5jb25zdCB7IEV2ZW50RW1pdHRlciB9ID0gcmVxdWlyZSgnZXZlbnRzJyk7XG5cbi8vIEJyaW5nIGluIHRoZSBzZXQgb2YgY29uc3RhbnRzIHRvIHJlZmxlY3QgTUlESSBtZXNzYWdlcyBhbmQgdGhlaXJcbi8vIHBhcmFtZXRlcnMsIHRvIGVsaW1pbmF0ZSB0aGUgbmVlZCBmb3IgbWFnaWMgbnVtYmVycy5cbi8qKiBBbiBpbnN0cnVtZW50IGxpc3QsIG9ubHkgdmFsaWQgaW4gdGhlIEdlbmVyYWwgTUlESSBzdGFuZGFyZCAqL1xuY29uc3QgSW5zdHJ1bWVudHMgPSByZXF1aXJlKCcuL2xpYi9pbnN0cnVtZW50cycpO1xuLyoqIEEgZHJ1bSBtYXAsIG9ubHkgdmFsaWQgaW4gdGhlIEdlbmVyYWwgTUlESSBzdGFuZGFyZCAqL1xuY29uc3QgRHJ1bXMgPSByZXF1aXJlKCcuL2xpYi9kcnVtcycpO1xuLyoqIE5vdGUgZGVzY3JpcHRpb25zLCB3aXRoIE1pZGRsZSBDID0gQzUgPSBNSURJIG5vdGUgNjAgKi9cbmNvbnN0IE5vdGVzID0gcmVxdWlyZSgnLi9saWIvbm90ZXMnKTtcbi8qKiBNZXNzYWdlIG5hbWVzLCBpbmNsdWRpbmcgQ0NzICovXG5jb25zdCBNZXNzYWdlcyA9IHJlcXVpcmUoJy4vbGliL21lc3NhZ2VzJyk7XG5cbmNsYXNzIElucHV0IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIFxuICAgIHRoaXMuaW5wdXQgPSBuZXcgbWlkaS5JbnB1dCgoZGVsdGFUaW1lLCBtZXNzYWdlKSA9PiB7XG4gICAgICB0aGlzLmVtaXQoJ21lc3NhZ2UnLCBkZWx0YVRpbWUsIEFycmF5LmZyb20obWVzc2FnZS52YWx1ZXMoKSkpXG4gICAgfSlcbiAgfVxuXG4gIGNsb3NlUG9ydCgpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5jbG9zZVBvcnQoKVxuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuZGVzdHJveSgpXG4gIH1cbiAgZ2V0UG9ydENvdW50KCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0LmdldFBvcnRDb3VudCgpXG4gIH1cbiAgZ2V0UG9ydE5hbWUocG9ydCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0LmdldFBvcnROYW1lKHBvcnQpXG4gIH1cbiAgaXNQb3J0T3BlbigpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5pc1BvcnRPcGVuKClcbiAgfVxuICBpZ25vcmVUeXBlcyhzeXNleCwgdGltaW5nLCBhY3RpdmVTZW5zaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuaWdub3JlVHlwZXMoc3lzZXgsIHRpbWluZywgYWN0aXZlU2Vuc2luZylcbiAgfVxuICBvcGVuUG9ydChwb3J0KSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQub3BlblBvcnQocG9ydClcbiAgfVxuICBvcGVuUG9ydEJ5TmFtZShuYW1lKSB7XG4gICAgZm9yKGxldCBwb3J0PTA7IHBvcnQ8dGhpcy5pbnB1dC5nZXRQb3J0Q291bnQoKTsgKytwb3J0KSB7XG4gICAgICBpZiAobmFtZSA9PT0gdGhpcy5pbnB1dC5nZXRQb3J0TmFtZShwb3J0KSkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dC5vcGVuUG9ydChwb3J0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBvcGVuVmlydHVhbFBvcnQocG9ydCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0Lm9wZW5WaXJ0dWFsUG9ydChwb3J0KVxuICB9XG4gIHNldEJ1ZmZlclNpemUoc2l6ZSwgY291bnQgPSA0KSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuc2V0QnVmZmVyU2l6ZShzaXplLCBjb3VudClcbiAgfVxufVxuXG5jbGFzcyBPdXRwdXQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLm91dHB1dCA9IG5ldyBtaWRpLk91dHB1dCgpXG4gIH1cblxuICBjbG9zZVBvcnQoKSB7XG4gICAgcmV0dXJuIHRoaXMub3V0cHV0LmNsb3NlUG9ydCgpXG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQuZGVzdHJveSgpXG4gIH1cbiAgZ2V0UG9ydENvdW50KCkge1xuICAgIHJldHVybiB0aGlzLm91dHB1dC5nZXRQb3J0Q291bnQoKVxuICB9XG4gIGdldFBvcnROYW1lKHBvcnQpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQuZ2V0UG9ydE5hbWUocG9ydClcbiAgfVxuICBpc1BvcnRPcGVuKCkge1xuICAgIHJldHVybiB0aGlzLm91dHB1dC5pc1BvcnRPcGVuKClcbiAgfVxuICBvcGVuUG9ydChwb3J0KSB7XG4gICAgcmV0dXJuIHRoaXMub3V0cHV0Lm9wZW5Qb3J0KHBvcnQpXG4gIH1cbiAgb3BlblBvcnRCeU5hbWUobmFtZSkge1xuICAgIGZvcihsZXQgcG9ydD0wOyBwb3J0PHRoaXMub3V0cHV0LmdldFBvcnRDb3VudCgpOyArK3BvcnQpIHtcbiAgICAgIGlmIChuYW1lID09PSB0aGlzLm91dHB1dC5nZXRQb3J0TmFtZShwb3J0KSkge1xuICAgICAgICByZXR1cm4gdGhpcy5vdXRwdXQub3BlblBvcnQocG9ydCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgb3BlblZpcnR1YWxQb3J0KHBvcnQpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQub3BlblZpcnR1YWxQb3J0KHBvcnQpXG4gIH1cbiAgc2VuZChtZXNzYWdlKSB7XG4gICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UobWVzc2FnZSlcbiAgfVxuICBzZW5kTWVzc2FnZShtZXNzYWdlKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobWVzc2FnZSkpIHtcbiAgICAgIG1lc3NhZ2UgPSBCdWZmZXIuZnJvbShtZXNzYWdlKVxuICAgIH1cbiAgICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihtZXNzYWdlKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdGaXJzdCBhcmd1bWVudCBtdXN0IGJlIGFuIGFycmF5IG9yIEJ1ZmZlcicpXG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMub3V0cHV0LnNlbmRNZXNzYWdlKG1lc3NhZ2UpXG4gIH1cbn1cblxuXG5mdW5jdGlvbiBjcmVhdGVSZWFkU3RyZWFtKGlucHV0KSB7XG4gIGlucHV0ID0gaW5wdXQgfHwgbmV3IElucHV0KCk7XG4gIHZhciBzdHJlYW0gPSBuZXcgU3RyZWFtKCk7XG4gIHN0cmVhbS5yZWFkYWJsZSA9IHRydWU7XG4gIHN0cmVhbS5wYXVzZWQgPSBmYWxzZTtcbiAgc3RyZWFtLnF1ZXVlID0gW107XG5cbiAgaW5wdXQub24oJ21lc3NhZ2UnLCBmdW5jdGlvbihkZWx0YVRpbWUsIG1lc3NhZ2UpIHtcblxuICAgIHZhciBwYWNrZXQgPSBuZXcgQnVmZmVyLmZyb20obWVzc2FnZSk7XG5cbiAgICBpZiAoIXN0cmVhbS5wYXVzZWQpIHtcbiAgICAgIHN0cmVhbS5lbWl0KCdkYXRhJywgcGFja2V0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RyZWFtLnF1ZXVlLnB1c2gocGFja2V0KTtcbiAgICB9XG4gIH0pO1xuXG4gIHN0cmVhbS5wYXVzZSA9IGZ1bmN0aW9uKCkge1xuICAgIHN0cmVhbS5wYXVzZWQgPSB0cnVlO1xuICB9O1xuXG4gIHN0cmVhbS5yZXN1bWUgPSBmdW5jdGlvbigpIHtcbiAgICBzdHJlYW0ucGF1c2VkID0gZmFsc2U7XG4gICAgd2hpbGUgKHN0cmVhbS5xdWV1ZS5sZW5ndGggJiYgc3RyZWFtLmVtaXQoJ2RhdGEnLCBzdHJlYW0ucXVldWUuc2hpZnQoKSkpIHt9XG4gIH07XG5cbiAgcmV0dXJuIHN0cmVhbTtcbn07XG5cbmZ1bmN0aW9uIGNyZWF0ZVdyaXRlU3RyZWFtKG91dHB1dCkge1xuICBvdXRwdXQgPSBvdXRwdXQgfHwgbmV3IE91dHB1dCgpO1xuICB2YXIgc3RyZWFtID0gbmV3IFN0cmVhbSgpO1xuICBzdHJlYW0ud3JpdGFibGUgPSB0cnVlO1xuICBzdHJlYW0ucGF1c2VkID0gZmFsc2U7XG4gIHN0cmVhbS5xdWV1ZSA9IFtdO1xuXG4gIHN0cmVhbS53cml0ZSA9IGZ1bmN0aW9uKGQpIHtcblxuICAgIGlmIChCdWZmZXIuaXNCdWZmZXIoZCkpIHtcbiAgICAgIGQgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChkLCAwKTtcbiAgICB9XG5cbiAgICBvdXRwdXQuc2VuZE1lc3NhZ2UoZCk7XG5cbiAgICByZXR1cm4gIXRoaXMucGF1c2VkO1xuICB9XG5cbiAgc3RyZWFtLmVuZCA9IGZ1bmN0aW9uKGJ1Zikge1xuICAgIGJ1ZiAmJiBzdHJlYW0ud3JpdGUoYnVmKTtcbiAgICBzdHJlYW0ud3JpdGFibGUgPSBmYWxzZTtcbiAgfTtcblxuICBzdHJlYW0uZGVzdHJveSA9IGZ1bmN0aW9uKCkge1xuICAgIHN0cmVhbS53cml0YWJsZSA9IGZhbHNlO1xuICB9XG5cbiAgcmV0dXJuIHN0cmVhbTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBJbnB1dCxcbiAgT3V0cHV0LFxuXG4gIGNyZWF0ZVJlYWRTdHJlYW0sXG4gIGNyZWF0ZVdyaXRlU3RyZWFtLFxuXG4gIENvbnN0YW50czoge1xuICAgIEluc3RydW1lbnRzLFxuICAgIERydW1zLFxuICAgIE5vdGVzLFxuICAgIE1lc3NhZ2VzLFxuICB9LFxuICBcbiAgLy8gQmFja3dhcmRzIGNvbXBhdGliaWxpdHkuXG4gIGlucHV0OiBJbnB1dCxcbiAgb3V0cHV0OiBPdXRwdXQsXG59O1xuIiwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCAqIGFzIG5vZGVfbWlkaSBmcm9tICdAanVsdXNpYW4vbWlkaSdcbmltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cydcbmltcG9ydCB7IE1pZGlNZXNzYWdlLCBNdGMgfSBmcm9tICcuL21zZ3R5cGVzLmpzJ1xuXG5leHBvcnQgY2xhc3MgSW5wdXQgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuXHRwcml2YXRlIF9pbnB1dFxuXHRwcml2YXRlIF9zbXB0ZTogbnVtYmVyW11cblx0cHJpdmF0ZSBfcGVuZGluZ1N5c2V4OiBib29sZWFuXG5cdHByaXZhdGUgX3N5c2V4OiBudW1iZXJbXVxuXHRwdWJsaWMgbmFtZTogc3RyaW5nXG5cblx0Y29uc3RydWN0b3IobmFtZTogc3RyaW5nLCB2aXJ0dWFsPzogYm9vbGVhbikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLl9pbnB1dCA9IG5ldyBub2RlX21pZGkuSW5wdXQoKVxuXHRcdHRoaXMuX2lucHV0Lmlnbm9yZVR5cGVzKGZhbHNlLCBmYWxzZSwgZmFsc2UpIC8vIEFsbG93IGFsbCBtZXNzYWdlIHR5cGVzXG5cdFx0dGhpcy5fcGVuZGluZ1N5c2V4ID0gZmFsc2Vcblx0XHR0aGlzLl9zeXNleCA9IFtdXG5cdFx0dGhpcy5fc21wdGUgPSBbXVxuXHRcdHRoaXMubmFtZSA9IG5hbWVcblx0XHRjb25zdCBpbnB1dFBvcnROdW1iZXJlZE5hbWVzOiBzdHJpbmdbXSA9IGdldElucHV0cygpXG5cblx0XHRpZiAodmlydHVhbCkge1xuXHRcdFx0dGhpcy5faW5wdXQub3BlblZpcnR1YWxQb3J0KG5hbWUpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IG51bUlucHV0cyA9IHRoaXMuX2lucHV0LmdldFBvcnRDb3VudCgpXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG51bUlucHV0czsgaSsrKSB7XG5cdFx0XHRcdGlmIChuYW1lID09PSBpbnB1dFBvcnROdW1iZXJlZE5hbWVzW2ldKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuX2lucHV0Lm9wZW5Qb3J0KGkpXG5cdFx0XHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhgRXJyb3Igb3BlbmluZyBwb3J0ICR7bmFtZX0uXFxuRXJyb3I6ICR7ZXJyfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0dGhpcy5faW5wdXQub24oJ21lc3NhZ2UnLCAoZGVsdGFUaW1lOiBudW1iZXIsIGJ5dGVzOiBudW1iZXJbXSk6IHZvaWQgPT4ge1xuXHRcdFx0Ly8gbm90IGRlYWxpbmcgd2l0aCBzeXNleCBjaHVua3MgbG9uZ2VyIHRoYW4gdGhlIGJ1ZmZlciBBVE1cblxuXHRcdFx0Y29uc3QgbXNnID0gTWlkaU1lc3NhZ2UucGFyc2VNZXNzYWdlKGJ5dGVzKVxuXHRcdFx0aWYgKG1zZyA9PT0gdW5kZWZpbmVkKSByZXR1cm5cblx0XHRcdHRoaXMuZW1pdCgnbWVzc2FnZScsIGRlbHRhVGltZSwgbXNnKVxuXHRcdFx0aWYgKG1zZy5pZCA9PSAnbXRjJykge1xuXHRcdFx0XHR0aGlzLnBhcnNlTXRjKG1zZyBhcyBNdGMpXG5cdFx0XHR9XG5cdFx0fSlcblx0fVxuXG5cdGNsb3NlKCk6IHZvaWQge1xuXHRcdHRoaXMuX2lucHV0LmNsb3NlUG9ydCgpXG5cdFx0dGhpcy5faW5wdXQuZGVzdHJveSgpXG5cdH1cblxuXHRpc1BvcnRPcGVuKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9pbnB1dC5pc1BvcnRPcGVuKClcblx0fVxuXG5cdHBhcnNlTXRjKGRhdGE6IE10Yyk6IHZvaWQge1xuXHRcdGNvbnN0IEZSQU1FX1JBVEVTID0gWzI0LCAyNSwgMjkuOTcsIDMwXVxuXHRcdGNvbnN0IGJ5dGVOdW1iZXI6IG51bWJlciA9IGRhdGEudHlwZVxuXHRcdGxldCB2YWx1ZTogbnVtYmVyID0gZGF0YS52YWx1ZVxuXHRcdGxldCBzbXB0ZUZyYW1lUmF0ZTogbnVtYmVyXG5cblx0XHR0aGlzLl9zbXB0ZVtieXRlTnVtYmVyXSA9IHZhbHVlXG5cblx0XHQvLyBDaGVjayBpZiB3ZSBoYXZlIDggY29tcGxldGUgbWVzc2FnZXMuIElmIHRoaXMuX3NtcHRlWzBdIGlzIHVuZGVmaW5lZCwgdGhlbiB3ZSBzdGFydGVkIGluIHRoZSBtaWRkbGUhXG5cdFx0aWYgKGJ5dGVOdW1iZXIgPT09IDcgJiYgdHlwZW9mIHRoaXMuX3NtcHRlWzBdID09PSAnbnVtYmVyJykge1xuXHRcdFx0Y29uc3QgYml0czogbnVtYmVyW10gPSBbXVxuXHRcdFx0Zm9yIChsZXQgaSA9IDM7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdGNvbnN0IGJpdCA9IHZhbHVlICYgKDEgPDwgaSkgPyAxIDogMFxuXHRcdFx0XHRiaXRzLnB1c2goYml0KVxuXHRcdFx0fVxuXHRcdFx0dmFsdWUgPSBiaXRzWzNdXG5cdFx0XHRzbXB0ZUZyYW1lUmF0ZSA9IEZSQU1FX1JBVEVTWyhiaXRzWzFdIDw8IDEpICsgYml0c1syXV1cblx0XHRcdHRoaXMuX3NtcHRlW2J5dGVOdW1iZXJdID0gdmFsdWVcblxuXHRcdFx0Y29uc3Qgc21wdGUgPSB0aGlzLl9zbXB0ZVxuXHRcdFx0Y29uc3Qgc21wdGVGb3JtYXR0ZWQgPVxuXHRcdFx0XHQoKHNtcHRlWzddIDw8IDQpICsgc21wdGVbNl0pLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSArXG5cdFx0XHRcdCc6JyArXG5cdFx0XHRcdCgoc21wdGVbNV0gPDwgNCkgKyBzbXB0ZVs0XSkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpICtcblx0XHRcdFx0JzonICtcblx0XHRcdFx0KChzbXB0ZVszXSA8PCA0KSArIHNtcHRlWzJdKS50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgK1xuXHRcdFx0XHQnLicgK1xuXHRcdFx0XHQoKHNtcHRlWzFdIDw8IDQpICsgc21wdGVbMF0pLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKVxuXHRcdFx0dGhpcy5lbWl0KCdzbXB0ZScsIHtcblx0XHRcdFx0c21wdGU6IHNtcHRlRm9ybWF0dGVkLFxuXHRcdFx0XHRzbXB0ZUZSOiBzbXB0ZUZyYW1lUmF0ZSxcblx0XHRcdH0pXG5cdFx0fVxuXHR9XG59XG5cbmV4cG9ydCBjbGFzcyBPdXRwdXQge1xuXHRwcml2YXRlIF9vdXRwdXRcblx0cHVibGljIG5hbWU6IHN0cmluZ1xuXG5cdGNvbnN0cnVjdG9yKG5hbWU6IHN0cmluZywgdmlydHVhbD86IGJvb2xlYW4pIHtcblx0XHR0aGlzLl9vdXRwdXQgPSBuZXcgbm9kZV9taWRpLk91dHB1dCgpXG5cdFx0dGhpcy5uYW1lID0gbmFtZVxuXHRcdGNvbnN0IG91dHB1dFBvcnROdW1iZXJlZE5hbWVzOiBzdHJpbmdbXSA9IGdldE91dHB1dHMoKVxuXG5cdFx0aWYgKHZpcnR1YWwpIHtcblx0XHRcdHRoaXMuX291dHB1dC5vcGVuVmlydHVhbFBvcnQobmFtZSlcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgbnVtT3V0cHV0cyA9IHRoaXMuX291dHB1dC5nZXRQb3J0Q291bnQoKVxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBudW1PdXRwdXRzOyBpKyspIHtcblx0XHRcdFx0aWYgKG5hbWUgPT09IG91dHB1dFBvcnROdW1iZXJlZE5hbWVzW2ldKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuX291dHB1dC5vcGVuUG9ydChpKVxuXHRcdFx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coYEVycm9yIG9wZW5pbmcgcG9ydCAke25hbWV9LlxcbkVycm9yOiAke2Vycn1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGNsb3NlKCk6IHZvaWQge1xuXHRcdHRoaXMuX291dHB1dC5jbG9zZVBvcnQoKVxuXHRcdHRoaXMuX291dHB1dC5kZXN0cm95KClcblx0fVxuXG5cdGlzUG9ydE9wZW4oKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX291dHB1dC5pc1BvcnRPcGVuKClcblx0fVxuXG5cdHNlbmQobXNnOiBNaWRpTWVzc2FnZSk6IHZvaWQge1xuXHRcdHRoaXMuX291dHB1dC5zZW5kTWVzc2FnZShtc2cuYnl0ZXMpXG5cdH1cbn1cblxuLy8gdXRpbGl0aWVzXG5leHBvcnQgZnVuY3Rpb24gZ2V0SW5wdXRzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3QgaW5wdXQgPSBuZXcgbm9kZV9taWRpLklucHV0KClcblx0Y29uc3QgaW5wdXRzOiBzdHJpbmdbXSA9IFtdXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQuZ2V0UG9ydENvdW50KCk7IGkrKykge1xuXHRcdGxldCBjb3VudGVyID0gMFxuXHRcdGNvbnN0IHBvcnROYW1lID0gaW5wdXQuZ2V0UG9ydE5hbWUoaSlcblx0XHRsZXQgbnVtYmVyZWRQb3J0TmFtZSA9IHBvcnROYW1lXG5cdFx0d2hpbGUgKGlucHV0cy5pbmNsdWRlcyhudW1iZXJlZFBvcnROYW1lKSkge1xuXHRcdFx0Y291bnRlcisrXG5cdFx0XHRudW1iZXJlZFBvcnROYW1lICs9IGAgJHtjb3VudGVyfWBcblx0XHR9XG5cdFx0aW5wdXRzLnB1c2gobnVtYmVyZWRQb3J0TmFtZSlcblx0fVxuXHRpbnB1dC5jbG9zZVBvcnQoKVxuXHRyZXR1cm4gaW5wdXRzXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRPdXRwdXRzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgb3V0cHV0ID0gbmV3IG5vZGVfbWlkaS5PdXRwdXQoKVxuXHRjb25zdCBvdXRwdXRzOiBzdHJpbmdbXSA9IFtdXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgb3V0cHV0LmdldFBvcnRDb3VudCgpOyBpKyspIHtcblx0XHRsZXQgY291bnRlciA9IDBcblx0XHRjb25zdCBwb3J0TmFtZSA9IG91dHB1dC5nZXRQb3J0TmFtZShpKVxuXHRcdGxldCBudW1iZXJlZFBvcnROYW1lID0gcG9ydE5hbWVcblx0XHR3aGlsZSAob3V0cHV0cy5pbmNsdWRlcyhudW1iZXJlZFBvcnROYW1lKSkge1xuXHRcdFx0Y291bnRlcisrXG5cdFx0XHRudW1iZXJlZFBvcnROYW1lICs9IGAgJHtjb3VudGVyfWBcblx0XHR9XG5cdFx0b3V0cHV0cy5wdXNoKG51bWJlcmVkUG9ydE5hbWUpXG5cdH1cblx0b3V0cHV0LmNsb3NlUG9ydCgpXG5cdHJldHVybiBvdXRwdXRzXG59XG4iLCAiY29uc3QgTUFYXzdfQklUID0gMHg3ZlxuY29uc3QgTUFYXzE0X0JJVCA9IDB4M2ZmZlxuXG5jb25zdCBNSURJX1NUQVRVU19UWVBFUyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KFtcblx0Wydub3Rlb2ZmJywgMHg4MF0sXG5cdFsnbm90ZW9uJywgMHg5MF0sXG5cdFsnYWZ0ZXJ0b3VjaCcsIDB4YTBdLFxuXHRbJ2NjJywgMHhiMF0sXG5cdFsncHJvZ3JhbScsIDB4YzBdLFxuXHRbJ2NoYW5uZWxwcmVzc3VyZScsIDB4ZDBdLFxuXHRbJ3BpdGNoJywgMHhlMF0sXG5cdFsnc3lzZXgnLCAweGYwXSxcblx0WydtdGMnLCAweGYxXSxcblx0Wydwb3NpdGlvbicsIDB4ZjJdLFxuXHRbJ3NlbGVjdCcsIDB4ZjNdLFxuXHRbJ3R1bmUnLCAweGY2XSxcblx0WydzeXNleCBlbmQnLCAweGY3XSxcblx0WydjbG9jaycsIDB4ZjhdLFxuXHRbJ3N0YXJ0JywgMHhmYV0sXG5cdFsnY29udGludWUnLCAweGZiXSxcblx0WydzdG9wJywgMHhmY10sXG5cdFsnYWN0aXZlc2Vuc2UnLCAweGZlXSxcblx0WydyZXNldCcsIDB4ZmZdLFxuXSlcblxuY29uc3QgaGV4ID0gKHZhbDogbnVtYmVyKSA9PiBgJHt2YWx9ICgweCR7dmFsLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfSlgXG5cbmV4cG9ydCBpbnRlcmZhY2UgSU1zZ0FyZ3Mge1xuXHRpZD86IHN0cmluZ1xuXHRieXRlcz86IG51bWJlcltdXG5cdHN0YXR1cz86IG51bWJlclxuXHRjaGFubmVsPzogbnVtYmVyXG5cdHR5cGU/OiBudW1iZXJcblx0bm90ZT86IG51bWJlclxuXHR2ZWxvY2l0eT86IG51bWJlclxuXHRjb250cm9sbGVyPzogbnVtYmVyXG5cdHByZXNzdXJlPzogbnVtYmVyXG5cdHZhbHVlPzogbnVtYmVyXG5cdHByb2dyYW0/OiBudW1iZXJcblx0c29uZz86IG51bWJlclxufVxuXG5leHBvcnQgY2xhc3MgTWlkaU1lc3NhZ2Uge1xuXHRpZCA9ICcnXG5cdGJ5dGVzOiBudW1iZXJbXVxuXHRzdGF0aWMgbm9Nc2c6IElNc2dBcmdzID0ge1xuXHRcdGJ5dGVzOiBbXSxcblx0XHRzdGF0dXM6IDAsXG5cdFx0Y2hhbm5lbDogMCxcblx0XHR0eXBlOiAwLFxuXHRcdG5vdGU6IDAsXG5cdFx0dmVsb2NpdHk6IDAsXG5cdFx0Y29udHJvbGxlcjogMCxcblx0XHRwcmVzc3VyZTogMCxcblx0XHR2YWx1ZTogMCxcblx0XHRwcm9ncmFtOiAwLFxuXHRcdHNvbmc6IDAsXG5cdH1cblxuXHRjb25zdHJ1Y3RvcihieXRlczogbnVtYmVyW10gPSBbXSkge1xuXHRcdHRoaXMuYnl0ZXMgPSBieXRlc1xuXHR9XG5cblx0Z2V0IHN0YXR1cygpOiBudW1iZXIge1xuXHRcdHJldHVybiB0aGlzLmJ5dGVzWzBdID4gMHhlZiA/IHRoaXMuYnl0ZXNbMF0gOiB0aGlzLmJ5dGVzWzBdICYgMHhmMFxuXHR9XG5cdHNldCBzdGF0dXModjogbnVtYmVyKSB7XG5cdFx0dGhpcy5ieXRlc1swXSA9IHYgPiAweGVmID8gdiA6ICh0aGlzLmJ5dGVzWzBdICYgMHgwZikgfCAodiAmIDB4ZjApXG5cdH1cblxuXHRnZXQgY2hhbm5lbCgpOiBudW1iZXIge1xuXHRcdHJldHVybiAodGhpcy5ieXRlc1swXSAmIDB4MGYpICsgMVxuXHR9XG5cdHNldCBjaGFubmVsKHY6IG51bWJlcikge1xuXHRcdHYtLSAvLyBDaGFubmVscyBhcmUgbm9ybWFsbHkgc2hvd24gYXMgMS0xNiBidXQgaW50ZXJuYWxseSBhcmUgMC0xNVxuXHRcdHYgPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgMTUpXG5cdFx0dGhpcy5ieXRlc1swXSA9ICh0aGlzLmJ5dGVzWzBdICYgMHhmMCkgfCAodiAmIDB4MGYpXG5cdH1cblxuXHRwcm90ZWN0ZWQgZ2V0IGRhdGExKCk6IG51bWJlciB7XG5cdFx0cmV0dXJuIHRoaXMuYnl0ZXNbMV0gJiAweDdmXG5cdH1cblx0cHJvdGVjdGVkIHNldCBkYXRhMSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmJ5dGVzWzFdID0gTWlkaU1lc3NhZ2UuY29uc3RyYWluKHYsIE1BWF83X0JJVClcblx0fVxuXG5cdHByb3RlY3RlZCBnZXQgZGF0YTIoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gdGhpcy5ieXRlc1syXSAmIDB4N2Zcblx0fVxuXHRwcm90ZWN0ZWQgc2V0IGRhdGEyKHY6IG51bWJlcikge1xuXHRcdHRoaXMuYnl0ZXNbMl0gPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgTUFYXzdfQklUKVxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGJ5dGVzOiB0aGlzLmJ5dGVzIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3RoaXMuaWR9IE1lc3NhZ2VgXG5cdH1cblxuXHRzdGF0aWMgY29uc3RyYWluKG51bTogbnVtYmVyLCBtYXg6IG51bWJlcik6IG51bWJlciB7XG5cdFx0cmV0dXJuIG51bSA+IG1heCA/IG1heCA6IG51bSA8IDAgPyAwIDogbnVtXG5cdH1cblxuXHRzdGF0aWMgcGFyc2VNZXNzYWdlKGJ5dGVzOiBudW1iZXJbXSA9IFtdLCBtc2c6IElNc2dBcmdzID0gdGhpcy5ub01zZyk6IE1pZGlNZXNzYWdlIHwgdW5kZWZpbmVkIHtcblx0XHRsZXQgaW5jb21pbmcgPSBuZXcgTWlkaU1lc3NhZ2UoYnl0ZXMpXG5cdFx0bGV0IHN0YXR1cyA9IGJ5dGVzLmxlbmd0aCA+IDAgPyBpbmNvbWluZy5zdGF0dXMgOiBtc2cuc3RhdHVzIHx8IDBcblx0XHRpZiAoc3RhdHVzID09PSAwICYmIHR5cGVvZiBtc2cuaWQgIT09ICd1bmRlZmluZWQnKSBzdGF0dXMgPSBNSURJX1NUQVRVU19UWVBFUy5nZXQobXNnLmlkKSB8fCAwXG5cblx0XHRzd2l0Y2ggKHN0YXR1cykge1xuXHRcdFx0Y2FzZSAweDgwOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBOb3RlT2ZmKG1zZy5jaGFubmVsISwgbXNnLm5vdGUhLCBtc2cudmVsb2NpdHkhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweDkwOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBOb3RlT24obXNnLmNoYW5uZWwhLCBtc2cubm90ZSEsIG1zZy52ZWxvY2l0eSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4YTA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IEFmdGVydG91Y2gobXNnLmNoYW5uZWwhLCBtc2cubm90ZSEsIG1zZy5wcmVzc3VyZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4YjA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IENvbnRyb2xDaGFuZ2UobXNnLmNoYW5uZWwhLCBtc2cuY29udHJvbGxlciEsIG1zZy52YWx1ZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4YzA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IFByb2dyYW1DaGFuZ2UobXNnLmNoYW5uZWwhLCBtc2cucHJvZ3JhbSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4ZDA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IENoYW5uZWxQcmVzc3VyZShtc2cuY2hhbm5lbCEsIG1zZy5wcmVzc3VyZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4ZTA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IFBpdGNoV2hlZWwobXNnLmNoYW5uZWwhLCBtc2cudmFsdWUhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweGYwOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBTeXNleChtc2cuYnl0ZXMhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweGYxOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBNdGMobXNnLnR5cGUhLCBtc2cudmFsdWUhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweGY4OlxuXHRcdFx0XHRyZXR1cm4gLy8gaWdub3JlIE1JREkgQ2xvY2sgbWVzc2FnZXNcblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdGNvbnNvbGUubG9nKGBVbnN1cHBvcnRlZCBNSURJIG1lc3NhZ2UuIFN0YXR1cyA9ICR7aGV4KHN0YXR1cyl9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKGJ5dGVzLmxlbmd0aCA+IDApIGluY29taW5nLmJ5dGVzID0gYnl0ZXMgLy8gcHVzaCB0aGUgZGF0YSB0byB0aGlzIG1lc3NhZ2Vcblx0XHRyZXR1cm4gaW5jb21pbmdcblx0fVxufVxuXG5jbGFzcyBOb3RlT2ZmIGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIG46IG51bWJlciwgdjogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAnbm90ZW9mZidcblx0XHR0aGlzLnN0YXR1cyA9IDB4ODBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy5ub3RlID0gblxuXHRcdHRoaXMudmVsb2NpdHkgPSB2XG5cdH1cblxuXHRnZXQgbm90ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMVxuXHR9XG5cdHNldCBub3RlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTEgPSB2XG5cdH1cblxuXHRnZXQgdmVsb2NpdHkoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTJcblx0fVxuXHRzZXQgdmVsb2NpdHkodjogbnVtYmVyKSB7XG5cdFx0dGhpcy5kYXRhMiA9IHZcblx0fVxuXG5cdGdldCBhcmdzKCk6IElNc2dBcmdzIHtcblx0XHRyZXR1cm4geyBjaGFubmVsOiB0aGlzLmNoYW5uZWwsIG5vdGU6IHRoaXMubm90ZSwgdmVsb2NpdHk6IHRoaXMudmVsb2NpdHkgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCBub3RlOiAke2hleCh0aGlzLm5vdGUpfSwgdmVsb2NpdHk6ICR7aGV4KFxuXHRcdFx0dGhpcy52ZWxvY2l0eSxcblx0XHQpfWBcblx0fVxufVxuXG5jbGFzcyBOb3RlT24gZXh0ZW5kcyBOb3RlT2ZmIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBuOiBudW1iZXIsIHY6IG51bWJlcikge1xuXHRcdHN1cGVyKGMsIG4sIHYpXG5cdFx0dGhpcy5pZCA9ICdub3Rlb24nXG5cdFx0dGhpcy5zdGF0dXMgPSAweDkwXG5cdH1cbn1cblxuY2xhc3MgQWZ0ZXJ0b3VjaCBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBuOiBudW1iZXIsIHA6IG51bWJlcikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ2FmdGVydG91Y2gnXG5cdFx0dGhpcy5zdGF0dXMgPSAweGEwXG5cdFx0dGhpcy5jaGFubmVsID0gY1xuXHRcdHRoaXMubm90ZSA9IG5cblx0XHR0aGlzLnByZXNzdXJlID0gcFxuXHR9XG5cblx0Z2V0IG5vdGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTFcblx0fVxuXHRzZXQgbm90ZSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IHByZXNzdXJlKCkge1xuXHRcdHJldHVybiB0aGlzLmRhdGEyXG5cdH1cblx0c2V0IHByZXNzdXJlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTIgPSB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCBub3RlOiB0aGlzLm5vdGUsIHByZXNzdXJlOiB0aGlzLnByZXNzdXJlIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCBjaGFubmVsOiAke2hleCh0aGlzLmNoYW5uZWwpfSwgbm90ZTogJHtoZXgodGhpcy5ub3RlKX0sIHByZXNzdXJlOiAke2hleChcblx0XHRcdHRoaXMucHJlc3N1cmUsXG5cdFx0KX1gXG5cdH1cbn1cblxuY2xhc3MgQ29udHJvbENoYW5nZSBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBjYzogbnVtYmVyLCB2OiBudW1iZXIpIHtcblx0XHRzdXBlcigpXG5cdFx0dGhpcy5pZCA9ICdjYydcblx0XHR0aGlzLnN0YXR1cyA9IDB4YjBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy5jb250cm9sbGVyID0gY2Ncblx0XHR0aGlzLnZhbHVlID0gdlxuXHR9XG5cblx0Z2V0IGNvbnRyb2xsZXIoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTFcblx0fVxuXHRzZXQgY29udHJvbGxlcih2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IHZhbHVlKCkge1xuXHRcdHJldHVybiB0aGlzLmRhdGEyXG5cdH1cblx0c2V0IHZhbHVlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTIgPSB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCBjb250cm9sbGVyOiB0aGlzLmNvbnRyb2xsZXIsIHZhbHVlOiB0aGlzLnZhbHVlIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCBjaGFubmVsOiAke2hleCh0aGlzLmNoYW5uZWwpfSwgY29udHJvbGxlcjogJHtoZXgodGhpcy5jb250cm9sbGVyKX0sIHZhbHVlOiAke2hleChcblx0XHRcdHRoaXMudmFsdWUsXG5cdFx0KX1gXG5cdH1cbn1cblxuY2xhc3MgUHJvZ3JhbUNoYW5nZSBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBuOiBudW1iZXIpIHtcblx0XHRzdXBlcigpXG5cdFx0dGhpcy5pZCA9ICdwcm9ncmFtJ1xuXHRcdHRoaXMuc3RhdHVzID0gMHhjMFxuXHRcdHRoaXMuY2hhbm5lbCA9IGNcblx0XHR0aGlzLnByb2dyYW0gPSBuXG5cdH1cblxuXHRnZXQgcHJvZ3JhbSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMSArIDEgLy8gUEMgaXMgbm9ybWFsbHkgc2hvd24gYXMgMS0xMjgsIGJ1dCBpdCdzIGludGVybmFsbHkgMC0xMjdcblx0fVxuXHRzZXQgcHJvZ3JhbSh2OiBudW1iZXIpIHtcblx0XHR2LS1cblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGNoYW5uZWw6IHRoaXMuY2hhbm5lbCwgcHJvZ3JhbTogdGhpcy5wcm9ncmFtIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCBjaGFubmVsOiAke2hleCh0aGlzLmNoYW5uZWwpfSwgcHJvZ3JhbTogJHtoZXgodGhpcy5wcm9ncmFtKX1gXG5cdH1cbn1cblxuY2xhc3MgQ2hhbm5lbFByZXNzdXJlIGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIHA6IG51bWJlcikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ2NoYW5uZWxwcmVzc3VyZSdcblx0XHR0aGlzLnN0YXR1cyA9IDB4ZDBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy5wcmVzc3VyZSA9IHBcblx0fVxuXG5cdGdldCBwcmVzc3VyZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMVxuXHR9XG5cdHNldCBwcmVzc3VyZSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGNoYW5uZWw6IHRoaXMuY2hhbm5lbCwgcHJlc3N1cmU6IHRoaXMucHJlc3N1cmUgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCBwcmVzc3VyZTogJHtoZXgodGhpcy5wcmVzc3VyZSl9YFxuXHR9XG59XG5cbmNsYXNzIFBpdGNoV2hlZWwgZXh0ZW5kcyBNaWRpTWVzc2FnZSB7XG5cdGNvbnN0cnVjdG9yKGM6IG51bWJlciwgdjogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAncGl0Y2gnXG5cdFx0dGhpcy5zdGF0dXMgPSAweGUwXG5cdFx0dGhpcy5jaGFubmVsID0gY1xuXHRcdHRoaXMudmFsdWUgPSB2XG5cdH1cblxuXHRnZXQgdmFsdWUoKSB7XG5cdFx0cmV0dXJuICh0aGlzLmRhdGEyIDw8IDcpICsgdGhpcy5kYXRhMVxuXHR9XG5cdHNldCB2YWx1ZSh2OiBudW1iZXIpIHtcblx0XHR2ID0gTWlkaU1lc3NhZ2UuY29uc3RyYWluKHYsIE1BWF8xNF9CSVQpXG5cdFx0dGhpcy5kYXRhMiA9ICh2ID4+IDcpICYgMHg3ZlxuXHRcdHRoaXMuZGF0YTEgPSB2ICYgMHg3ZlxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGNoYW5uZWw6IHRoaXMuY2hhbm5lbCwgdmFsdWU6IHRoaXMudmFsdWUgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCB2YWx1ZTogJHtoZXgodGhpcy52YWx1ZSl9YFxuXHR9XG59XG5cbmNsYXNzIFN5c2V4IGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihiOiBudW1iZXJbXSkge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ3N5c2V4J1xuXHRcdHRoaXMuYnl0ZXMgPSBiXG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgYnl0ZXM6IHRoaXMuYnl0ZXMgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGJ5dGVzOiAke3RoaXMuYnl0ZXN9YFxuXHR9XG59XG5cbmV4cG9ydCBjbGFzcyBNdGMgZXh0ZW5kcyBNaWRpTWVzc2FnZSB7XG5cdGNvbnN0cnVjdG9yKHQ6IG51bWJlciwgdjogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAnbXRjJ1xuXHRcdHRoaXMuc3RhdHVzID0gMHhmMVxuXHRcdHRoaXMudHlwZSA9IHRcblx0XHR0aGlzLnZhbHVlID0gdlxuXHR9XG5cblx0Z2V0IHR5cGUoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gKHRoaXMuZGF0YTEgPj4gNCkgJiAweDA3XG5cdH1cblx0c2V0IHR5cGUodjogbnVtYmVyKSB7XG5cdFx0dGhpcy5kYXRhMSA9ICh0aGlzLmRhdGExICYgMHgwZikgfCAodiA8PCA0KVxuXHR9XG5cblx0Z2V0IHZhbHVlKCk6IG51bWJlciB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTEgJiAweDBmXG5cdH1cblx0c2V0IHZhbHVlKHY6IG51bWJlcikge1xuXHRcdHYgPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgMTUpXG5cdFx0dGhpcy5kYXRhMSA9ICh0aGlzLmRhdGExICYgMHhmMCkgfCB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCB0eXBlOiB0aGlzLnR5cGUsIHZhbHVlOiB0aGlzLnZhbHVlIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCB0eXBlOiAke2hleCh0aGlzLnR5cGUpfSwgdmFsdWU6ICR7aGV4KHRoaXMudmFsdWUpfWBcblx0fVxufVxuIiwgImltcG9ydCB7IHR5cGUgU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLCBKc29uT2JqZWN0LCBEcm9wZG93bkNob2ljZSB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBnZXRJbnB1dHMsIGdldE91dHB1dHMgfSBmcm9tICcuL21pZGkvbWlkaS5qcydcblxuZXhwb3J0IGludGVyZmFjZSBNb2R1bGVDb25maWcgZXh0ZW5kcyBKc29uT2JqZWN0IHtcblx0aW5Qb3J0TmFtZTogc3RyaW5nXG5cdGluUG9ydFZpcnR1YWxOYW1lOiBzdHJpbmdcblx0aW5Qb3J0SXNWaXJ0dWFsOiBib29sZWFuXG5cdG91dFBvcnROYW1lOiBzdHJpbmdcblx0b3V0UG9ydFZpcnR1YWxOYW1lOiBzdHJpbmdcblx0b3V0UG9ydElzVmlydHVhbDogYm9vbGVhblxuXHR1c2VUaW1lU3RhbXA6IGJvb2xlYW5cblx0YXV0b0NyZWF0ZVZhcnM6IGJvb2xlYW5cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IGluUG9ydE5hbWVzOiBEcm9wZG93bkNob2ljZVtdID0gW11cblx0Y29uc3Qgb3V0UG9ydE5hbWVzOiBEcm9wZG93bkNob2ljZVtdID0gW11cblx0Y29uc3QgaW5Qb3J0czogc3RyaW5nW10gPSBnZXRJbnB1dHMoKVxuXHRjb25zdCBvdXRQb3J0czogc3RyaW5nW10gPSBnZXRPdXRwdXRzKClcblx0aW5Qb3J0cy5mb3JFYWNoKChtKSA9PiB7XG5cdFx0aW5Qb3J0TmFtZXMucHVzaCh7IGlkOiBtLCBsYWJlbDogbSB9KVxuXHR9KVxuXHRvdXRQb3J0cy5mb3JFYWNoKChtKSA9PiB7XG5cdFx0b3V0UG9ydE5hbWVzLnB1c2goeyBpZDogbSwgbGFiZWw6IG0gfSlcblx0fSlcblxuXHRyZXR1cm4gW1xuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2luUG9ydE5hbWUnLFxuXHRcdFx0bGFiZWw6ICdNSURJIEluJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogaW5Qb3J0c1swXSB8fCAnTk9ORSBERVRFQ1RFRCcsXG5cdFx0XHRjaG9pY2VzOiBpblBvcnROYW1lcyxcblx0XHRcdC8vXHRpc1Zpc2libGU6IChvcHRzKSA9PiAhb3B0cy5pblBvcnRJc1ZpcnR1YWwsXG5cdFx0fSxcblx0XHQvKlxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdpblBvcnRWaXJ0dWFsTmFtZScsXG5cdFx0XHRsYWJlbDogJ01JREkgSW4nLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdGlzVmlzaWJsZTogKG9wdHMpID0+ICEhb3B0cy5pblBvcnRJc1ZpcnR1YWwsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0aWQ6ICdpblBvcnRJc1ZpcnR1YWwnLFxuXHRcdFx0bGFiZWw6ICdWaXJ0dWFsJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHQqL1xuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ291dFBvcnROYW1lJyxcblx0XHRcdGxhYmVsOiAnTUlESSBPdXQnLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiBvdXRQb3J0c1swXSB8fCAnTk9ORSBERVRFQ1RFRCcsXG5cdFx0XHRjaG9pY2VzOiBvdXRQb3J0TmFtZXMsXG5cdFx0XHQvL1x0aXNWaXNpYmxlOiAob3B0cykgPT4gIW9wdHMub3V0UG9ydElzVmlydHVhbCxcblx0XHR9LFxuXHRcdC8qXG5cdFx0e1xuXHRcdFx0dHlwZTogJ3RleHRpbnB1dCcsXG5cdFx0XHRpZDogJ291dFBvcnRWaXJ0dWFsTmFtZScsXG5cdFx0XHRsYWJlbDogJ01JREkgT3V0Jyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRpc1Zpc2libGU6IChvcHRzKSA9PiAhIW9wdHMub3V0UG9ydElzVmlydHVhbCxcblx0XHR9LFxuXHRcdHtcblx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRpZDogJ291dFBvcnRJc1ZpcnR1YWwnLFxuXHRcdFx0bGFiZWw6ICdWaXJ0dWFsJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnc3RhdGljLXRleHQnLFxuXHRcdFx0aWQ6ICdjdXN0b21UZXh0Jyxcblx0XHRcdGxhYmVsOiAnQ2hvb3NlIGV4aXN0aW5nIHBvcnRzLCBvciB0eXBlIGEgY3VzdG9tIG5hbWUgdG8gY3JlYXRlIGEgVmlydHVhbCBQb3J0Jyxcblx0XHRcdHdpZHRoOiAxMixcblx0XHRcdHZhbHVlOiAnJyxcblx0XHR9LFxuXHRcdCovXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2NoZWNrYm94Jyxcblx0XHRcdGlkOiAndXNlVGltZVN0YW1wJyxcblx0XHRcdGxhYmVsOiAnVXNlIFRpbWVTdGFtcCB3aXRoIEFjdGlvbiBSZWNvcmRlcicsXG5cdFx0XHR0b29sdGlwOiAnRW5hYmxlIHRoaXMgc2V0dGluZyB0byBpbmNsdWRlIHRoZSBkZWxheSB0aW1lIGZvciBhY3Rpb25zIGNyZWF0ZWQgaW4gQWN0aW9uIFJlY29yZGVyJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0aWQ6ICdhdXRvQ3JlYXRlVmFycycsXG5cdFx0XHRsYWJlbDogJ0VuYWJsZSBcIkF1dG8tQ3JlYXRlZCBWYXJpYWJsZXMgZnVuY3Rpb25cIicsXG5cdFx0XHR0b29sdGlwOiAnRW5hYmxlIHRoaXMgc2V0dGluZyBPTkxZIGlmIHlvdSBuZWVkIGNvbXBhdGliaWxpdHkgd2l0aCBleGlzdGluZyBBdXRvLUNyZWF0ZWQgdmFyaWFibGVzJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnc3RhdGljLXRleHQnLFxuXHRcdFx0aWQ6ICdhdXRvQ3JlYXRlVmFyTm90aWNlJyxcblx0XHRcdGxhYmVsOiAnKioqIFN1cHBvcnQgZm9yIHRoZSBkZXByZWNhdGVkIFwiQXV0by1DcmVhdGVkIFZhcmlhYmxlcyBmdW5jdGlvblwiICoqKicsXG5cdFx0XHR2YWx1ZTpcblx0XHRcdFx0J1RoZSBcIkF1dG8tQ3JlYXRlIFZhcmlhYmxlXCIgZnVuY3Rpb24gaGFzIG5vdyBiZWVuIHN1cGVyY2VkZWQgYnkgdGhlIGJ1aWx0LWluIExvY2FsIFZhcmlhYmxlcyBmZWF0dXJlIHdpdGhpbiBDb21wYW5pb24gNC4yKy48YnI+SWYgeW91IHN0aWxsIGhhdmUgYXV0by1jcmVhdGVkIHZhcmlhYmxlcywgcGxlYXNlIGNoYW5nZSB0aGVtIHRvIFZhbHVlIEZlZWRiYWNrcyBhcyBzdXBwb3J0IGZvciBBdXRvLUNyZWF0ZWQgVmFyaWFibGVzIG1heSBkaXNhcHBlYXIgaW4gdGhlIGZ1dHVyZSEnLFxuXHRcdFx0dG9vbHRpcDogJ0VuYWJsZSB0aGlzIHNldHRpbmcgT05MWSBpZiB5b3UgbmVlZCBjb21wYXRpYmlsaXR5IHdpdGggZXhpc3RpbmcgQXV0by1DcmVhdGVkIHZhcmlhYmxlcycsXG5cdFx0XHR3aWR0aDogMTIsXG5cdFx0fSxcblx0XVxufVxuIiwgImltcG9ydCB7IENvbXBhbmlvblZhcmlhYmxlRGVmaW5pdGlvbnMsIEpzb25PYmplY3QgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IElNc2dBcmdzLCBNaWRpTWVzc2FnZSB9IGZyb20gJy4vbWlkaS9tc2d0eXBlcy5qcydcblxuZXhwb3J0IHR5cGUgbWlkaVZhcnMgPSB7XG5cdG1pZGlJbjogYm9vbGVhblxuXHRtaWRpT3V0OiBib29sZWFuXG5cdGxhc3RNZXNzYWdlOiBzdHJpbmdcblx0c21wdGU6IHN0cmluZ1xuXHRzbXB0ZUZSOiBudW1iZXJcbn1cblxuY29uc3QgdmFyaWFibGVzOiBDb21wYW5pb25WYXJpYWJsZURlZmluaXRpb25zPEpzb25PYmplY3Q+ID0ge1xuXHRtaWRpSW46IHsgbmFtZTogJ0lzIGEgTUlESSBNZXNzYWdlIEluY29taW5nPycgfSxcblx0bWlkaU91dDogeyBuYW1lOiAnSXMgYSBNSURJIE1lc3NhZ2UgT3V0Z29pbmc/JyB9LFxuXHRsYXN0TWVzc2FnZTogeyBuYW1lOiAnTGFzdCBNZXNzYWdlIFJlY2VpdmVkJyB9LFxuXHRzbXB0ZTogeyBuYW1lOiAnU01QVEUgVEMgZnJvbSBNVEMnIH0sXG5cdHNtcHRlRlI6IHsgbmFtZTogJ1NNUFRFIEZyYW1lIFJhdGUgZnJvbSBNVEMnIH0sXG59XG5cbmNvbnN0IG1pZGlUaW1lcnM6IE1hcDxzdHJpbmcsIFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbD4gPSBuZXcgTWFwKClcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0c2VsZi5zZXRWYXJpYWJsZURlZmluaXRpb25zKHZhcmlhYmxlcylcblx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7IG1pZGlJbjogZmFsc2UsIG1pZGlPdXQ6IGZhbHNlIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBIYW5kbGVNaWRpSW5kaWNhdG9ycyhzZWxmOiBNb2R1bGVJbnN0YW5jZSwgdmFyaWFibGU6IHN0cmluZyk6IHZvaWQge1xuXHRsZXQgdCA9IG1pZGlUaW1lcnMuZ2V0KHZhcmlhYmxlKSA/PyBudWxsXG5cdGlmICh0ICE9PSBudWxsKSBjbGVhclRpbWVvdXQodClcblx0dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBbdmFyaWFibGVdOiBmYWxzZSB9KVxuXHRcdHNlbGYuY2hlY2tGZWVkYmFja3ModmFyaWFibGUpXG5cdH0sIDIwMClcblx0bWlkaVRpbWVycy5zZXQodmFyaWFibGUsIHQpXG5cdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBbdmFyaWFibGVdOiB0cnVlIH0pXG5cdHNlbGYuY2hlY2tGZWVkYmFja3ModmFyaWFibGUpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVMYXN0TXNnKHNlbGY6IE1vZHVsZUluc3RhbmNlLCBtc2c6IE1pZGlNZXNzYWdlLCBkYXRhOiBudW1iZXIgfCB1bmRlZmluZWQpOiB2b2lkIHtcblx0Y29uc3QgbXNnSW5mbyA9IENyZWF0ZVZhck5hbWUobXNnKVxuXHRjb25zdCBsYXN0TXNnID0gbXNnSW5mby5uYW1lICsgJ18nICsgZGF0YVxuXHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHsgbGFzdE1lc3NhZ2U6IGxhc3RNc2cgfSlcblxuXHRBZGRPclVwZGF0ZVZhcihzZWxmLCAnbGFzdE1zZ1R5cGUnLCAnTGFzdCBNZXNzYWdlIFR5cGUgUmVjZWl2ZWQnLCBtc2cuaWQpXG5cblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBtc2dJbmZvLmtleXMubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBrZXlOYW1lID0gbXNnSW5mby5rZXlzW2ldXG5cdFx0Y29uc3Qga2V5ID0ga2V5TmFtZSBhcyBrZXlvZiBJTXNnQXJnc1xuXHRcdGNvbnN0IENhcEtleU5hbWUgPSBrZXlOYW1lWzBdLnRvVXBwZXJDYXNlKCkgKyBrZXlOYW1lLnNsaWNlKDEpXG5cdFx0QWRkT3JVcGRhdGVWYXIoc2VsZiwgJ2xhc3QnICsgQ2FwS2V5TmFtZSwgJ0xhc3QgJyArIENhcEtleU5hbWUgKyAnIFJlY2VpdmVkJywgTnVtYmVyKG1zZy5hcmdzW2tleV0pKVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBGQkNyZWF0ZXNWYXIoc2VsZjogTW9kdWxlSW5zdGFuY2UsIG1zZzogTWlkaU1lc3NhZ2UsIGRhdGE6IG51bWJlciB8IHVuZGVmaW5lZCk6IHZvaWQge1xuXHQvLyBBdXRvLWNyZWF0ZSBhIHZhcmlhYmxlXG5cdEFkZE9yVXBkYXRlVmFyKHNlbGYsICdfJyArIENyZWF0ZVZhck5hbWUobXNnKS5uYW1lLCAnQXV0by1DcmVhdGVkIFZhcmlhYmxlJywgZGF0YSlcbn1cblxuZnVuY3Rpb24gQ3JlYXRlVmFyTmFtZShtc2c6IE1pZGlNZXNzYWdlKTogeyBuYW1lOiBzdHJpbmc7IGtleXM6IHN0cmluZ1tdIH0ge1xuXHQvLyBBdXRvLWNyZWF0ZSBhIHZhcmlhYmxlIG5hbWVcblxuXHRsZXQgdmFyTmFtZSA9IG1zZy5pZFxuXHRjb25zdCBtc2dLZXlzID0gT2JqZWN0LmtleXMobXNnLmFyZ3MpXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbXNnS2V5cy5sZW5ndGggLSAxOyBpKyspIHtcblx0XHRjb25zdCBrZXkgPSBtc2dLZXlzW2ldIGFzIGtleW9mIElNc2dBcmdzXG5cdFx0Y29uc3QgdmFsOiBudW1iZXIgfCB1bmRlZmluZWQgPSBOdW1iZXIobXNnLmFyZ3Nba2V5XSlcblx0XHRpZiAodmFsICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdHZhck5hbWUgKz0gYF8ke3ZhbH1gXG5cdFx0fVxuXHR9XG5cdHJldHVybiB7IG5hbWU6IHZhck5hbWUsIGtleXM6IG1zZ0tleXMgfVxufVxuXG5mdW5jdGlvbiBBZGRPclVwZGF0ZVZhcihcblx0c2VsZjogTW9kdWxlSW5zdGFuY2UsXG5cdHZhck5hbWU6IHN0cmluZyxcblx0dmFyRGVzY3I6IHN0cmluZyxcblx0ZGF0YTogbnVtYmVyIHwgc3RyaW5nIHwgdW5kZWZpbmVkLFxuKTogdm9pZCB7XG5cdHZhcmlhYmxlc1t2YXJOYW1lXSA9IHsgbmFtZTogdmFyRGVzY3IgfSAvLyBpZiBWYXJpYWJsZSBkb2Vzbid0IGV4aXN0LCBhZGQgaXRcblx0c2VsZi5zZXRWYXJpYWJsZURlZmluaXRpb25zKHZhcmlhYmxlcylcblx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7IFt2YXJOYW1lXTogZGF0YSB9KVxufVxuIiwgImltcG9ydCB7XG5cdENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQsXG5cdENvbXBhbmlvblN0YXRpY1VwZ3JhZGVSZXN1bHQsXG5cdENvbXBhbmlvblN0YXRpY1VwZ3JhZGVQcm9wcyxcblx0Q29tcGFuaW9uVXBncmFkZUNvbnRleHQsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuXG5leHBvcnQgY29uc3QgVXBncmFkZVNjcmlwdHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVTY3JpcHQ8TW9kdWxlQ29uZmlnPltdID0gW1xuXHQvKlxuXHQgKiBQbGFjZSB5b3VyIHVwZ3JhZGUgc2NyaXB0cyBoZXJlXG5cdCAqIFJlbWVtYmVyIHRoYXQgb25jZSBpdCBoYXMgYmVlbiBhZGRlZCBpdCBjYW5ub3QgYmUgcmVtb3ZlZCFcblx0ICovXG5cdGZ1bmN0aW9uIChcblx0XHRjb250ZXh0OiBDb21wYW5pb25VcGdyYWRlQ29udGV4dDxNb2R1bGVDb25maWc+LFxuXHRcdHByb3BzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUHJvcHM8TW9kdWxlQ29uZmlnLCB1bmRlZmluZWQ+LFxuXHQpOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUmVzdWx0PE1vZHVsZUNvbmZpZywgdW5kZWZpbmVkPiB7XG5cdFx0Y29uc3QgY2hhbmdlczogQ29tcGFuaW9uU3RhdGljVXBncmFkZVJlc3VsdDxNb2R1bGVDb25maWcsIHVuZGVmaW5lZD4gPSB7XG5cdFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHRcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHRcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdFx0fVxuXG5cdFx0Y29uc29sZS5sb2coJ1xcblJ1bm5pbmcgVXBkYXRlIFNjcmlwdHMuLi5cXG4nKVxuXG5cdFx0Zm9yIChjb25zdCBhIG9mIHByb3BzLmFjdGlvbnMpIHtcblx0XHRcdGlmIChhLmFjdGlvbklkID09ICdwcm9ncmFtJykge1xuXHRcdFx0XHRjb25zb2xlLmxvZygnVXBkYXRpbmcgYWN0aW9uXFxuJywgYSlcblx0XHRcdFx0YS5vcHRpb25zLnByb2dyYW0gPSBhLm9wdGlvbnMubnVtYmVyIHx8IGEub3B0aW9ucy5wcm9ncmFtXG5cdFx0XHRcdGRlbGV0ZSBhLm9wdGlvbnMubnVtYmVyXG5cdFx0XHR9XG5cdFx0XHRpZiAoIWEub3B0aW9ucy5jaFZhbHVlKSBhLm9wdGlvbnMuY2hWYWx1ZSA9IGEub3B0aW9ucy5jaGFubmVsXG5cdFx0XHRpZiAoIWEub3B0aW9ucy5ub3RlVmFsdWUpIGEub3B0aW9ucy5ub3RlVmFsdWUgPSBhLm9wdGlvbnMubm90ZVxuXHRcdFx0aWYgKCFhLm9wdGlvbnMuY2NWYWx1ZSkgYS5vcHRpb25zLmNjVmFsdWUgPSBhLm9wdGlvbnMuY29udHJvbGxlclxuXG5cdFx0XHRjaGFuZ2VzLnVwZGF0ZWRBY3Rpb25zLnB1c2goYSlcblx0XHRcdGNvbnNvbGUubG9nKCd0b1xcbicsIGEpXG5cdFx0fVxuXG5cdFx0Zm9yIChjb25zdCBmIG9mIHByb3BzLmZlZWRiYWNrcykge1xuXHRcdFx0aWYgKGYuZmVlZGJhY2tJZCA9PSAncmVjZWl2ZV9tZXNzYWdlJykge1xuXHRcdFx0XHRjb25zb2xlLmxvZygnVXBkYXRpbmcgZmVlZGJhY2tcXG4nLCBmKVxuXHRcdFx0XHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWJhc2UtdG8tc3RyaW5nXG5cdFx0XHRcdGYuZmVlZGJhY2tJZCA9IFN0cmluZyhmLm9wdGlvbnMubXNnVHlwZSlcblx0XHRcdFx0ZGVsZXRlIGYub3B0aW9ucy5tc2dUeXBlXG5cdFx0XHRcdHN3aXRjaCAoZi5mZWVkYmFja0lkKSB7XG5cdFx0XHRcdFx0Y2FzZSAncHJvZ3JhbSc6XG5cdFx0XHRcdFx0XHRmLm9wdGlvbnMucHJvZ3JhbSA9IGYub3B0aW9ucy5udW1iZXJcblx0XHRcdFx0XHRcdGRlbGV0ZSBmLm9wdGlvbnMubnVtYmVyXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdGNhc2UgJ3N5c2V4Jzpcblx0XHRcdFx0XHRcdGYub3B0aW9ucy5ieXRlcyA9IGYub3B0aW9ucy5tZXNzYWdlXG5cdFx0XHRcdFx0XHRkZWxldGUgZi5vcHRpb25zLm1lc3NhZ2Vcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0Y2FzZSAncGl0Y2gnOlxuXHRcdFx0XHRcdFx0Zi5vcHRpb25zLnZhbHVlID0gZi5vcHRpb25zLnBpdGNoXG5cdFx0XHRcdFx0XHRkZWxldGUgZi5vcHRpb25zLnBpdGNoXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmICghZi5vcHRpb25zLmNoVmFsdWUpIGYub3B0aW9ucy5jaFZhbHVlID0gZi5vcHRpb25zLmNoYW5uZWxcblx0XHRcdGlmICghZi5vcHRpb25zLm5vdGVWYWx1ZSkgZi5vcHRpb25zLm5vdGVWYWx1ZSA9IGYub3B0aW9ucy5ub3RlXG5cdFx0XHRpZiAoIWYub3B0aW9ucy5jY1ZhbHVlKSBmLm9wdGlvbnMuY2NWYWx1ZSA9IGYub3B0aW9ucy5jb250cm9sbGVyXG5cblx0XHRcdGNoYW5nZXMudXBkYXRlZEZlZWRiYWNrcy5wdXNoKGYpXG5cdFx0XHRjb25zb2xlLmxvZygndG9cXG4nLCBmKVxuXHRcdH1cblxuXHRcdHJldHVybiBjaGFuZ2VzXG5cdH0sXG5cblx0ZnVuY3Rpb24gKFxuXHRcdGNvbnRleHQ6IENvbXBhbmlvblVwZ3JhZGVDb250ZXh0PE1vZHVsZUNvbmZpZz4sXG5cdFx0cHJvcHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVQcm9wczxNb2R1bGVDb25maWcsIHVuZGVmaW5lZD4sXG5cdCk6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVSZXN1bHQ8TW9kdWxlQ29uZmlnLCB1bmRlZmluZWQ+IHtcblx0XHRjb25zdCBjaGFuZ2VzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUmVzdWx0PE1vZHVsZUNvbmZpZywgdW5kZWZpbmVkPiA9IHtcblx0XHRcdHVwZGF0ZWRDb25maWc6IG51bGwsXG5cdFx0XHR1cGRhdGVkQWN0aW9uczogW10sXG5cdFx0XHR1cGRhdGVkRmVlZGJhY2tzOiBbXSxcblx0XHR9XG5cblx0XHRjb25zb2xlLmxvZygnXFxuUnVubmluZyBVcGRhdGUgU2NyaXB0cy4uLlxcbicpXG5cblx0XHRmb3IgKGNvbnN0IGEgb2YgcHJvcHMuYWN0aW9ucykge1xuXHRcdFx0Y29uc29sZS5sb2coJ1xcblVwZGF0aW5nIGFjdGlvblxcbicsIGEpXG5cblx0XHRcdGlmICghYS5vcHRpb25zLnNlbmRPdmVyVGltZSkgYS5vcHRpb25zLnNlbmRPdmVyVGltZSA9IHsgaXNFeHByZXNzaW9uOiBmYWxzZSwgdmFsdWU6IGZhbHNlIH1cblx0XHRcdGlmICghYS5vcHRpb25zLnRpbWVTdGFydFZhbHVlKSBhLm9wdGlvbnMudGltZVN0YXJ0VmFsdWUgPSB7IGlzRXhwcmVzc2lvbjogZmFsc2UsIHZhbHVlOiAwIH1cblx0XHRcdGlmICghYS5vcHRpb25zLnRpbWUpIGEub3B0aW9ucy50aW1lID0geyBpc0V4cHJlc3Npb246IGZhbHNlLCB2YWx1ZTogMCB9XG5cdFx0XHRpZiAoIWEub3B0aW9ucy5jdXJ2ZSkgYS5vcHRpb25zLmN1cnZlID0geyBpc0V4cHJlc3Npb246IGZhbHNlLCB2YWx1ZTogJ2xpbmVhcicgfVxuXG5cdFx0XHRjaGFuZ2VzLnVwZGF0ZWRBY3Rpb25zLnB1c2goYSlcblx0XHRcdGNvbnNvbGUubG9nKCdcXG50b1xcbicsIGEpXG5cdFx0fVxuXG5cdFx0cmV0dXJuIGNoYW5nZXNcblx0fSxcbl1cbiIsICJpbXBvcnQgeyBTb21lQ29tcGFuaW9uQWN0aW9uSW5wdXRGaWVsZCwgU29tZUNvbXBhbmlvbkZlZWRiYWNrSW5wdXRGaWVsZCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5cbmludGVyZmFjZSBtaWRpTXNnVHlwZSB7XG5cdGlkOiBzdHJpbmdcblx0bGFiZWw6IHN0cmluZ1xuXHRkZXNjOiBzdHJpbmdcblx0dmFsSWQ6IHN0cmluZ1xuXHR2YWxMYWJlbDogc3RyaW5nXG5cdHZhbE1pbjogbnVtYmVyXG5cdHZhbE1heDogbnVtYmVyXG5cdHZhbERlZmF1bHQ6IG51bWJlclxufVxuXG5leHBvcnQgY29uc3QgbWlkaU1zZ1R5cGVzOiBtaWRpTXNnVHlwZVtdID0gW1xuXHR7XG5cdFx0aWQ6ICdub3Rlb2ZmJyxcblx0XHRsYWJlbDogJ05vdGUgT2ZmJyxcblx0XHRkZXNjOiAnTm90ZSBPZmYgTWVzc3NhZ2UnLFxuXHRcdHZhbElkOiAndmVsb2NpdHknLFxuXHRcdHZhbExhYmVsOiAnVmVsb2NpdHknLFxuXHRcdHZhbE1pbjogMCxcblx0XHR2YWxNYXg6IDEyNyxcblx0XHR2YWxEZWZhdWx0OiAwLFxuXHR9LFxuXHR7XG5cdFx0aWQ6ICdub3Rlb24nLFxuXHRcdGxhYmVsOiAnTm90ZSBPbicsXG5cdFx0ZGVzYzogJ05vdGUgT24gTWVzc2FnZScsXG5cdFx0dmFsSWQ6ICd2ZWxvY2l0eScsXG5cdFx0dmFsTGFiZWw6ICdWZWxvY2l0eScsXG5cdFx0dmFsTWluOiAwLFxuXHRcdHZhbE1heDogMTI3LFxuXHRcdHZhbERlZmF1bHQ6IDEyNyxcblx0fSxcblx0Ly9cdFx0eyBpZDogJ2FmdGVydG91Y2gnLCBuYW1lOiAnQWZ0ZXJ0b3VjaCcgfSxcblx0e1xuXHRcdGlkOiAnY2MnLFxuXHRcdGxhYmVsOiAnQ0MnLFxuXHRcdGRlc2M6ICdDb250cm9sIENoYW5nZSBNZXNzYWdlJyxcblx0XHR2YWxJZDogJ3ZhbHVlJyxcblx0XHR2YWxMYWJlbDogJ1ZhbHVlJyxcblx0XHR2YWxNaW46IDAsXG5cdFx0dmFsTWF4OiAxMjcsXG5cdFx0dmFsRGVmYXVsdDogMCxcblx0fSxcblx0e1xuXHRcdGlkOiAncHJvZ3JhbScsXG5cdFx0bGFiZWw6ICdQcm9ncmFtIENoYW5nZScsXG5cdFx0ZGVzYzogJ1Byb2dyYW0gQ2hhbmdlIE1lc3NhZ2UnLFxuXHRcdHZhbElkOiAncHJvZ3JhbScsXG5cdFx0dmFsTGFiZWw6ICdQcm9ncmFtIE51bWJlcicsXG5cdFx0dmFsTWluOiAxLFxuXHRcdHZhbE1heDogMTI4LFxuXHRcdHZhbERlZmF1bHQ6IDEsXG5cdH0sXG5cdC8vXHRcdHsgaWQ6ICdjaGFubmVscHJlc3N1cmUnLCBcdG5hbWU6ICdDaGFubmVsIFByZXNzdXJlJyB9LFxuXHR7XG5cdFx0aWQ6ICdwaXRjaCcsXG5cdFx0bGFiZWw6ICdQaXRjaCBXaGVlbCcsXG5cdFx0ZGVzYzogJ1BpdGNoIFdoZWVsIE1lc3NhZ2UnLFxuXHRcdHZhbElkOiAndmFsdWUnLFxuXHRcdHZhbExhYmVsOiAnVmFsdWUnLFxuXHRcdHZhbE1pbjogMCxcblx0XHR2YWxNYXg6IDE2MzgzLFxuXHRcdHZhbERlZmF1bHQ6IDgxOTIsXG5cdH0sXG5cdHtcblx0XHRpZDogJ3N5c2V4Jyxcblx0XHRsYWJlbDogJ1N5c0V4Jyxcblx0XHRkZXNjOiAnU3lzdGVtIEV4Y2x1c2l2ZSBNZXNzYWdlJyxcblx0XHR2YWxJZDogJ2J5dGVzJyxcblx0XHR2YWxMYWJlbDogJ1N5c0V4IEJ5dGVzJyxcblx0XHR2YWxNaW46IDAsXG5cdFx0dmFsTWF4OiAxMjcsXG5cdFx0dmFsRGVmYXVsdDogMCxcblx0fSxcblx0Ly9cdFx0eyBpZDogJ210YycsIFx0XHRcdFx0bmFtZTogJ01JREkgVGltZSBDb2RlJyB9LFxuXHQvL1x0XHR7IGlkOiAncG9zaXRpb24nLFx0XHRcdG5hbWU6ICdTb25nIFBvc2l0aW9uIFBvaW50ZXInIH0sXG5cdC8vXHRcdHsgaWQ6ICdzZWxlY3QnLFx0XHRcdFx0bmFtZTogJ1NvbmcgU2VsZWN0JyB9LFxuXHQvL1x0XHR7IGlkOiAndHVuZScsXHRcdFx0XHRuYW1lOiAnVHVuZSBSZXF1ZXN0JyB9LFxuXHQvL1x0XHR7IGlkOiAnc3lzZXggZW5kJyxcdFx0XHRuYW1lOiAnU3lzRXggRW5kJyB9LFxuXHQvL1x0XHR7IGlkOiAnY2xvY2snLFx0XHRcdFx0bmFtZTogJ0Nsb2NrJyB9LFxuXHQvL1x0XHR7IGlkOiAnc3RhcnQnLFx0XHRcdFx0bmFtZTogJ1N0YXJ0JyB9LFxuXHQvL1x0XHR7IGlkOiAnY29udGludWUnLFx0XHRcdG5hbWU6ICdDb250aW51ZScgfSxcblx0Ly9cdFx0eyBpZDogJ3N0b3AnLFx0XHRcdFx0bmFtZTogJ1N0b3AnIH0sXG5cdC8vXHRcdHsgaWQ6ICdhY3RpdmVzZW5zZScsXHRcdG5hbWU6ICdBY3RpdmUgU2Vuc2luZycgfSxcblx0Ly9cdFx0eyBpZDogJ3Jlc2V0JyxcdFx0XHRcdG5hbWU6ICdSZXNldCcgfSxcbl1cblxudHlwZSBvcHRpb25UeXBlcyA9IFNvbWVDb21wYW5pb25BY3Rpb25JbnB1dEZpZWxkW10gfCBTb21lQ29tcGFuaW9uRmVlZGJhY2tJbnB1dEZpZWxkW11cblxuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZU9wdGlvbnMobmV3T3B0czogb3B0aW9uVHlwZXMsIG1pZGlPcDogbWlkaU1zZ1R5cGUpOiBvcHRpb25UeXBlcyB7XG5cdGlmIChbJ25vdGVvZmYnLCAnbm90ZW9uJywgJ2NjJywgJ3Byb2dyYW0nLCAncGl0Y2gnXS5pbmNsdWRlcyhtaWRpT3AuaWQpKSB7XG5cdFx0bmV3T3B0cy5wdXNoKHtcblx0XHRcdGlkOiAnY2hhbm5lbCcsXG5cdFx0XHR0eXBlOiAnbnVtYmVyJyxcblx0XHRcdGxhYmVsOiAnQ2hhbm5lbCcsXG5cdFx0XHRkZWZhdWx0OiAxLFxuXHRcdFx0bWluOiAxLFxuXHRcdFx0bWF4OiAxNixcblx0XHR9KVxuXHR9XG5cdGlmIChbJ25vdGVvZmYnLCAnbm90ZW9uJ10uaW5jbHVkZXMobWlkaU9wLmlkKSkge1xuXHRcdG5ld09wdHMucHVzaCh7XG5cdFx0XHRpZDogJ25vdGUnLFxuXHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRsYWJlbDogJ05vdGUgTnVtYmVyJyxcblx0XHRcdGRlZmF1bHQ6IDYwLFxuXHRcdFx0bWluOiAwLFxuXHRcdFx0bWF4OiAxMjcsXG5cdFx0fSlcblx0fVxuXHRpZiAobWlkaU9wLmlkID09ICdjYycpIHtcblx0XHRuZXdPcHRzLnB1c2goe1xuXHRcdFx0aWQ6ICdjb250cm9sbGVyJyxcblx0XHRcdHR5cGU6ICdudW1iZXInLFxuXHRcdFx0bGFiZWw6ICdDb250cm9sbGVyJyxcblx0XHRcdGRlZmF1bHQ6IDEyNyxcblx0XHRcdG1pbjogMCxcblx0XHRcdG1heDogMTI3LFxuXHRcdH0pXG5cdH1cblx0aWYgKG1pZGlPcC5pZCAhPSAnc3lzZXgnKSB7XG5cdFx0bmV3T3B0cy5wdXNoKHtcblx0XHRcdGlkOiBtaWRpT3AudmFsSWQsXG5cdFx0XHR0eXBlOiAnbnVtYmVyJyxcblx0XHRcdGxhYmVsOiBtaWRpT3AudmFsTGFiZWwsXG5cdFx0XHRkZWZhdWx0OiBtaWRpT3AudmFsRGVmYXVsdCxcblx0XHRcdG1pbjogbWlkaU9wLnZhbE1pbixcblx0XHRcdG1heDogbWlkaU9wLnZhbE1heCxcblx0XHR9KVxuXHR9IGVsc2Uge1xuXHRcdG5ld09wdHMucHVzaCh7XG5cdFx0XHRpZDogJ2J5dGVzJyxcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0bGFiZWw6IG1pZGlPcC52YWxMYWJlbCxcblx0XHRcdHRvb2x0aXA6XG5cdFx0XHRcdCdFbnRlciBhIHN0cmluZyBvZiBkZWNpbWFsIG9yIGhleCBkaWdpdHMsIHdpdGggc3BhY2VzIG9yIGNvbW1hcyBiZXR3ZWVuLiBNVVNUIHN0YXJ0IHdpdGggMHhGMCBvciAyNDAgYW5kIGVuZCB3aXRoIDB4Rjcgb3IgMjQ3Jyxcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gbmV3T3B0c1xufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLCBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBIYW5kbGVNaWRpSW5kaWNhdG9ycyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgTWlkaU1lc3NhZ2UgfSBmcm9tICcuL21pZGkvbXNndHlwZXMuanMnXG5pbXBvcnQgeyBtaWRpTXNnVHlwZXMsIGNyZWF0ZU9wdGlvbnMgfSBmcm9tICcuL29wZXJhdGlvbnMuanMnXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVBY3Rpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBtaWRpT3V0RGF0YTogZmFsc2UgfSlcblxuXHRjb25zdCBhY3Rpb25zOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyA9IHt9XG5cdGZvciAoY29uc3QgYWN0aW9uIG9mIG1pZGlNc2dUeXBlcykge1xuXHRcdGNvbnN0IG5ld0FjdGlvbjogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbiA9IHtcblx0XHRcdG5hbWU6IFN0cmluZyhhY3Rpb24ubGFiZWwpLFxuXHRcdFx0b3B0aW9uczogY3JlYXRlT3B0aW9ucyhbXSwgYWN0aW9uKSxcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQpOiBQcm9taXNlPHZvaWQ+ID0+IHtcblx0XHRcdFx0Y29uc3Qgb3B0cyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZXZlbnQub3B0aW9ucykpXG5cblx0XHRcdFx0aWYgKCFzZWxmLmNvbmZpZy5vdXRQb3J0SXNWaXJ0dWFsICYmICFzZWxmLm1pZGlPdXRwdXQuaXNQb3J0T3BlbigpKSB7XG5cdFx0XHRcdFx0c2VsZi5sb2coJ2Vycm9yJywgYE91dHB1dCBQb3J0IFwiJHtzZWxmLm1pZGlPdXRwdXQubmFtZX1cIiBub3Qgb3BlbiFgKVxuXHRcdFx0XHRcdHJldHVyblxuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKGFjdGlvbi5pZCA9PSAnc3lzZXgnKSB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyc2VkU3lzZXggPSBhd2FpdCBvcHRzW2FjdGlvbi52YWxJZF1cblx0XHRcdFx0XHRvcHRzLmJ5dGVzID0gcGFyc2VkU3lzZXguc3BsaXQoL1sgLF0rLykubWFwKChuOiBzdHJpbmcpOiBudW1iZXIgPT4gcGFyc2VJbnQobikpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAob3B0cy5yZWxWYWx1ZSkge1xuXHRcdFx0XHRcdG9wdHNbYWN0aW9uLnZhbElkXSA9IE51bWJlcihhd2FpdCBvcHRzLnZhclZhbHVlKVxuXHRcdFx0XHRcdGlmIChvcHRzLmNoVmFsdWUpIG9wdHMuY2hhbm5lbCA9IE51bWJlcihhd2FpdCBvcHRzLmNoVmFsdWUpXG5cdFx0XHRcdFx0aWYgKG9wdHMubm90ZVZhbHVlKSBvcHRzLm5vdGUgPSBOdW1iZXIoYXdhaXQgb3B0cy5ub3RlVmFsdWUpXG5cdFx0XHRcdFx0aWYgKG9wdHMuY2NWYWx1ZSkgb3B0cy5jb250cm9sbGVyID0gTnVtYmVyKGF3YWl0IG9wdHMuY2NWYWx1ZSlcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGxldCBtc2cgPSBNaWRpTWVzc2FnZS5wYXJzZU1lc3NhZ2UodW5kZWZpbmVkLCB7IGlkOiBhY3Rpb24uaWQsIC4uLm9wdHMgfSlcblx0XHRcdFx0aWYgKG9wdHMucmVsVmFsdWUpIHtcblx0XHRcdFx0XHRjb25zdCB2YWwgPSBzZWxmLmdldEZyb21EYXRhU3RvcmUobXNnISlcblx0XHRcdFx0XHRpZiAodmFsID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdHNlbGYubG9nKCdpbmZvJywgJ1JlbGF0aXZlIHZhbHVlIG5vdCBzZW50LiBDdXJyZW50IHZhbHVlIGZyb20gZGV2aWNlIGlzIG5lZWRlZCEnKVxuXHRcdFx0XHRcdFx0cmV0dXJuXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdG9wdHNbYWN0aW9uLnZhbElkXSA9IHZhbCArIE51bWJlcihvcHRzW2FjdGlvbi52YWxJZF0gKiAxKVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKG9wdHMuc2VuZE92ZXJUaW1lKSB7XG5cdFx0XHRcdFx0Ly8gSGFuZGxlIHNlbmRpbmcgb3ZlciB0aW1lXG5cdFx0XHRcdFx0Y29uc3QgZHVyYXRpb25NcyA9IG9wdHMudGltZSAqIDEwMDBcblx0XHRcdFx0XHRjb25zdCBjdXJ2ZSA9IG9wdHMuY3VydmVcblx0XHRcdFx0XHRjb25zdCB0aWNrTXMgPSAxNVxuXG5cdFx0XHRcdFx0bGV0IHN0YXJ0ID0gMFxuXHRcdFx0XHRcdGlmIChvcHRzLnJlbFZhbHVlKSB7XG5cdFx0XHRcdFx0XHRzdGFydCA9IHNlbGYuZ2V0RnJvbURhdGFTdG9yZShtc2chKSB8fCAwXG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdHN0YXJ0ID0gTnVtYmVyKG9wdHMudGltZVN0YXJ0VmFsdWUpXG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0bGV0IGVuZCA9IE51bWJlcihvcHRzW2FjdGlvbi52YWxJZF0gKiAxKVxuXG5cdFx0XHRcdFx0Ly9lbnN1cmUgZW5kIHZhbHVlIGlzIHdpdGhpbiBib3VuZHNcblx0XHRcdFx0XHRpZiAoZW5kIDwgMCkge1xuXHRcdFx0XHRcdFx0ZW5kID0gMFxuXHRcdFx0XHRcdH0gZWxzZSBpZiAoZW5kID4gMTI3KSB7XG5cdFx0XHRcdFx0XHRlbmQgPSAxMjdcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHQvL2lmIHN0YXJ0ID4gZW5kLCBzd2FwIHRoZW1cblx0XHRcdFx0XHRpZiAoc3RhcnQgPiBlbmQpIHtcblx0XHRcdFx0XHRcdC8vO1tzdGFydCwgZW5kXSA9IFtlbmQsIHN0YXJ0XVxuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdGNvbnN0IHQwID0gRGF0ZS5ub3coKVxuXHRcdFx0XHRcdGxldCBsYXN0ID0gLTFcblxuXHRcdFx0XHRcdGludGVyZmFjZSBFYXNlRnVuY3Rpb25zIHtcblx0XHRcdFx0XHRcdFtrZXk6IHN0cmluZ106ICh4OiBudW1iZXIpID0+IG51bWJlclxuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdGNvbnN0IGVhc2VGdW5jdGlvbnM6IEVhc2VGdW5jdGlvbnMgPSB7XG5cdFx0XHRcdFx0XHRsaW5lYXI6ICh4OiBudW1iZXIpOiBudW1iZXIgPT4geCxcblx0XHRcdFx0XHRcdGVhc2VJbjogKHg6IG51bWJlcik6IG51bWJlciA9PiB4ICogeCxcblx0XHRcdFx0XHRcdGVhc2VPdXQ6ICh4OiBudW1iZXIpOiBudW1iZXIgPT4gMSAtICgxIC0geCkgKiAoMSAtIHgpLFxuXHRcdFx0XHRcdFx0ZWFzZUluT3V0OiAoeDogbnVtYmVyKTogbnVtYmVyID0+ICh4IDwgMC41ID8gMiAqIHggKiB4IDogMSAtIE1hdGgucG93KC0yICogeCArIDIsIDIpIC8gMiksXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGNvbnN0IGVhc2U6ICh4OiBudW1iZXIpID0+IG51bWJlciA9IGVhc2VGdW5jdGlvbnNbY3VydmUgYXMgc3RyaW5nXSB8fCAoKHg6IG51bWJlcik6IG51bWJlciA9PiB4KVxuXG5cdFx0XHRcdFx0Y29uc3QgdGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG5cdFx0XHRcdFx0XHRjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIHQwXG5cdFx0XHRcdFx0XHRjb25zdCB1ID0gTWF0aC5taW4oMSwgZWxhcHNlZCAvIGR1cmF0aW9uTXMpXG5cdFx0XHRcdFx0XHRjb25zdCB2YWwgPSBNYXRoLnJvdW5kKHN0YXJ0ICsgKGVuZCAtIHN0YXJ0KSAqIGVhc2UodSkpXG5cblx0XHRcdFx0XHRcdGlmICh2YWwgIT09IGxhc3QpIHtcblx0XHRcdFx0XHRcdFx0b3B0c1thY3Rpb24udmFsSWRdID0gdmFsXG5cdFx0XHRcdFx0XHRcdG1zZyA9IE1pZGlNZXNzYWdlLnBhcnNlTWVzc2FnZSh1bmRlZmluZWQsIHsgaWQ6IGFjdGlvbi5pZCwgLi4ub3B0cyB9KVxuXHRcdFx0XHRcdFx0XHRzZWxmLmxvZygnZGVidWcnLCBgU2VuZGluZzogICR7bXNnfSB0byBcIiR7c2VsZi5taWRpT3V0cHV0Lm5hbWV9XCJgKVxuXHRcdFx0XHRcdFx0XHRzZWxmLm1pZGlPdXRwdXQuc2VuZChtc2chKVxuXHRcdFx0XHRcdFx0XHRIYW5kbGVNaWRpSW5kaWNhdG9ycyhzZWxmLCAnbWlkaU91dCcpXG5cdFx0XHRcdFx0XHRcdGxhc3QgPSB2YWxcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdGlmICh1ID49IDEpIGNsZWFySW50ZXJ2YWwodGltZXIpXG5cdFx0XHRcdFx0fSwgdGlja01zKVxuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdG1zZyA9IE1pZGlNZXNzYWdlLnBhcnNlTWVzc2FnZSh1bmRlZmluZWQsIHsgaWQ6IGFjdGlvbi5pZCwgLi4ub3B0cyB9KVxuXHRcdFx0XHRcdHNlbGYubG9nKCdkZWJ1ZycsIGBTZW5kaW5nOiAgJHttc2d9IHRvIFwiJHtzZWxmLm1pZGlPdXRwdXQubmFtZX1cImApXG5cdFx0XHRcdFx0c2VsZi5taWRpT3V0cHV0LnNlbmQobXNnISlcblx0XHRcdFx0XHRIYW5kbGVNaWRpSW5kaWNhdG9ycyhzZWxmLCAnbWlkaU91dCcpXG5cdFx0XHRcdH1cblx0XHRcdH0sXG5cdFx0fVxuXG5cdFx0aWYgKGFjdGlvbi5pZCAhPSAnc3lzZXgnKSB7XG5cdFx0XHRuZXdBY3Rpb24ub3B0aW9ucy5hdCgtMSkhLmlzVmlzaWJsZUV4cHJlc3Npb24gPSAnISQob3B0aW9uczpyZWxWYWx1ZSknXG5cdFx0XHRuZXdBY3Rpb24ub3B0aW9ucy5wdXNoKFxuXHRcdFx0XHR7XG5cdFx0XHRcdFx0aWQ6ICd2YXJWYWx1ZScsXG5cdFx0XHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRcdFx0bGFiZWw6IGFjdGlvbi52YWxMYWJlbCxcblx0XHRcdFx0XHRkZWZhdWx0OiBhY3Rpb24udmFsRGVmYXVsdCxcblx0XHRcdFx0XHRtaW46IC1hY3Rpb24udmFsTWF4LFxuXHRcdFx0XHRcdG1heDogYWN0aW9uLnZhbE1heCxcblx0XHRcdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiAnISEkKG9wdGlvbnM6cmVsVmFsdWUpJyxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAncmVsVGV4dCcsXG5cdFx0XHRcdFx0dHlwZTogJ3N0YXRpYy10ZXh0Jyxcblx0XHRcdFx0XHRsYWJlbDogJyoqIE5PVEUgKionLFxuXHRcdFx0XHRcdHZhbHVlOiAnUmVsYXRpdmUgd2lsbCBvbmx5IHdvcmsgYWZ0ZXIgYSB2YWx1ZSBoYXMgYmVlbiBzZW50IGZyb20gdGhlIGRldmljZSEnLFxuXHRcdFx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246ICckKG9wdGlvbnM6cmVsVmFsdWUpJyxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAncmVsVmFsdWUnLFxuXHRcdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdFx0bGFiZWw6ICdSZWxhdGl2ZScsXG5cdFx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdFx0ZGlzYWJsZUF1dG9FeHByZXNzaW9uOiB0cnVlLFxuXHRcdFx0XHR9LFxuXHRcdFx0KVxuXG5cdFx0XHQvL292ZXIgdGltZSBmZWF0dXJlcyAtIHRpbWUgaW4gc2Vjb25kcywgY3VydmUgdHlwZSAobGluZWFyLCBlYXNlIGluLCBlYXNlIG91dCwgZWFzZSBpbi9vdXQpXG5cdFx0XHRuZXdBY3Rpb24ub3B0aW9ucy5wdXNoKFxuXHRcdFx0XHR7XG5cdFx0XHRcdFx0aWQ6ICdzZW5kT3ZlclRpbWUnLFxuXHRcdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdFx0bGFiZWw6ICdTZW5kIE92ZXIgVGltZScsXG5cdFx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdFx0ZGlzYWJsZUF1dG9FeHByZXNzaW9uOiB0cnVlLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHR7XG5cdFx0XHRcdFx0aWQ6ICd0aW1lU3RhcnRWYWx1ZScsXG5cdFx0XHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRcdFx0bGFiZWw6ICdTdGFydCBWYWx1ZScsXG5cdFx0XHRcdFx0ZGVmYXVsdDogMCxcblx0XHRcdFx0XHRtaW46IDAsXG5cdFx0XHRcdFx0bWF4OiAxMjcsXG5cdFx0XHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogJyEhJChvcHRpb25zOnNlbmRPdmVyVGltZSkgJiYgISQob3B0aW9uczpyZWxWYWx1ZSknLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHR7XG5cdFx0XHRcdFx0aWQ6ICd0aW1lJyxcblx0XHRcdFx0XHR0eXBlOiAnbnVtYmVyJyxcblx0XHRcdFx0XHRsYWJlbDogJ1RpbWUgKHNlY29uZHMpJyxcblx0XHRcdFx0XHRkZWZhdWx0OiAxLFxuXHRcdFx0XHRcdG1pbjogMCxcblx0XHRcdFx0XHRtYXg6IDYwMCxcblx0XHRcdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiAnJChvcHRpb25zOnNlbmRPdmVyVGltZSknLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHR7XG5cdFx0XHRcdFx0aWQ6ICdjdXJ2ZScsXG5cdFx0XHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdFx0XHRsYWJlbDogJ0N1cnZlIFR5cGUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6ICdsaW5lYXInLFxuXHRcdFx0XHRcdGNob2ljZXM6IFtcblx0XHRcdFx0XHRcdHsgbGFiZWw6ICdMaW5lYXInLCBpZDogJ2xpbmVhcicgfSxcblx0XHRcdFx0XHRcdHsgbGFiZWw6ICdFYXNlIEluJywgaWQ6ICdlYXNlSW4nIH0sXG5cdFx0XHRcdFx0XHR7IGxhYmVsOiAnRWFzZSBPdXQnLCBpZDogJ2Vhc2VPdXQnIH0sXG5cdFx0XHRcdFx0XHR7IGxhYmVsOiAnRWFzZSBJbi9PdXQnLCBpZDogJ2Vhc2VJbk91dCcgfSxcblx0XHRcdFx0XHRdLFxuXHRcdFx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246ICckKG9wdGlvbnM6c2VuZE92ZXJUaW1lKScsXG5cdFx0XHRcdH0sXG5cdFx0XHQpXG5cdFx0fVxuXG5cdFx0YWN0aW9uc1thY3Rpb24uaWRdID0gbmV3QWN0aW9uXG5cdH1cblxuXHRzZWxmLnNldEFjdGlvbkRlZmluaXRpb25zKGFjdGlvbnMpXG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7XG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbixcblx0Q29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyxcblx0U29tZUNvbXBhbmlvbkZlZWRiYWNrSW5wdXRGaWVsZCxcblx0Y29tYmluZVJnYixcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IEZCQ3JlYXRlc1ZhciB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgTWlkaU1lc3NhZ2UgfSBmcm9tICcuL21pZGkvbXNndHlwZXMuanMnXG5pbXBvcnQgeyBtaWRpTXNnVHlwZXMsIGNyZWF0ZU9wdGlvbnMgfSBmcm9tICcuL29wZXJhdGlvbnMuanMnXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVGZWVkYmFja3Moc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3QgZmVlZGJhY2tzOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zID0ge31cblx0Zm9yIChjb25zdCBmZWVkYmFjayBvZiBtaWRpTXNnVHlwZXMpIHtcblx0XHRjb25zdCBuZXdGZWVkYmFjazogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9uID0ge1xuXHRcdFx0bmFtZTogZmVlZGJhY2subGFiZWwsXG5cdFx0XHRkZXNjcmlwdGlvbjogZmVlZGJhY2suZGVzYyxcblx0XHRcdHR5cGU6ICdib29sZWFuJyxcblx0XHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDI1NSwgMCwgMCksXG5cdFx0XHRcdGNvbG9yOiBjb21iaW5lUmdiKDAsIDAsIDApLFxuXHRcdFx0fSxcblx0XHRcdG9wdGlvbnM6IGNyZWF0ZU9wdGlvbnMoW10sIGZlZWRiYWNrKSBhcyBTb21lQ29tcGFuaW9uRmVlZGJhY2tJbnB1dEZpZWxkW10sXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKGV2ZW50KTogUHJvbWlzZTxib29sZWFuPiA9PiB7XG5cdFx0XHRcdGNvbnN0IG9wdHMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGV2ZW50Lm9wdGlvbnMpKVxuXG5cdFx0XHRcdGlmIChldmVudC5mZWVkYmFja0lkID09ICdzeXNleCcpIHtcblx0XHRcdFx0XHRjb25zdCBwYXJzZWRTeXNleCA9IGF3YWl0IG9wdHNbZmVlZGJhY2sudmFsSWRdXG5cdFx0XHRcdFx0b3B0cy5ieXRlcyA9IHBhcnNlZFN5c2V4LnNwbGl0KC9bICxdKy8pLm1hcCgobjogc3RyaW5nKTogbnVtYmVyID0+IHBhcnNlSW50KG4pKVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKG9wdHMucmVsVmFsdWUpIHtcblx0XHRcdFx0XHRvcHRzW2ZlZWRiYWNrLnZhbElkXSA9IE51bWJlcihhd2FpdCBvcHRzLnZhclZhbHVlKVxuXHRcdFx0XHRcdGlmIChvcHRzLmNoVmFsdWUpIG9wdHMuY2hhbm5lbCA9IE51bWJlcihhd2FpdCBvcHRzLmNoVmFsdWUpXG5cdFx0XHRcdFx0aWYgKG9wdHMubm90ZVZhbHVlKSBvcHRzLm5vdGUgPSBOdW1iZXIoYXdhaXQgb3B0cy5ub3RlVmFsdWUpXG5cdFx0XHRcdFx0aWYgKG9wdHMuY2NWYWx1ZSkgb3B0cy5jb250cm9sbGVyID0gTnVtYmVyKGF3YWl0IG9wdHMuY2NWYWx1ZSlcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IG1zZyA9IE1pZGlNZXNzYWdlLnBhcnNlTWVzc2FnZSh1bmRlZmluZWQsIHsgaWQ6IGV2ZW50LmZlZWRiYWNrSWQsIC4uLm9wdHMgfSlcblxuXHRcdFx0XHRjb25zdCBkYXRhU3RvcmVWYWwgPSBzZWxmLmdldEZyb21EYXRhU3RvcmUobXNnISlcblx0XHRcdFx0aWYgKGV2ZW50LmZlZWRiYWNrSWQgIT09ICdzeXNleCcgJiYgb3B0cy5jcmVhdGVWYXIgJiYgc2VsZi5jb25maWcuYXV0b0NyZWF0ZVZhcnMgJiYgbXNnICE9PSB1bmRlZmluZWQpXG5cdFx0XHRcdFx0RkJDcmVhdGVzVmFyKHNlbGYsIG1zZywgZGF0YVN0b3JlVmFsKVxuXHRcdFx0XHRpZiAoZGF0YVN0b3JlVmFsID09IHVuZGVmaW5lZCkgcmV0dXJuIGZhbHNlXG5cdFx0XHRcdGlmIChkYXRhU3RvcmVWYWwgPT0gc2VsZi5nZXRWYWxGcm9tTXNnKG1zZyEpLnZhbCkge1xuXHRcdFx0XHRcdHJldHVybiB0cnVlXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGZhbHNlXG5cdFx0XHR9LFxuXHRcdH1cblxuXHRcdGlmIChmZWVkYmFjay5pZCAhPSAnc3lzZXgnICYmIHNlbGYuY29uZmlnLmF1dG9DcmVhdGVWYXJzKSB7XG5cdFx0XHRuZXdGZWVkYmFjay5vcHRpb25zLmF0KC0xKSEuaXNWaXNpYmxlRXhwcmVzc2lvbiA9ICchJChvcHRpb25zOmNyZWF0ZVZhciknXG5cdFx0XHRuZXdGZWVkYmFjay5vcHRpb25zLnB1c2goe1xuXHRcdFx0XHRpZDogJ2NyZWF0ZVZhcicsXG5cdFx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRcdGxhYmVsOiAnQXV0by1DcmVhdGUgVmFyaWFibGUnLFxuXHRcdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHRcdFx0ZGlzYWJsZUF1dG9FeHByZXNzaW9uOiB0cnVlLFxuXHRcdFx0fSlcblx0XHR9XG5cblx0XHRmZWVkYmFja3NbZmVlZGJhY2suaWRdID0gbmV3RmVlZGJhY2tcblxuXHRcdGZlZWRiYWNrc1tmZWVkYmFjay5pZCArICdfdmFsdWUnXSA9IHtcblx0XHRcdC4uLm5ld0ZlZWRiYWNrLFxuXHRcdFx0bmFtZTogZmVlZGJhY2subGFiZWwgKyAnIFZhbHVlJyxcblx0XHRcdHR5cGU6ICd2YWx1ZScsXG5cdFx0XHRvcHRpb25zOiBuZXdGZWVkYmFjay5vcHRpb25zLmZpbHRlcigobykgPT4gby5pZCAhPT0gZmVlZGJhY2sudmFsSWQgJiYgby5pZCAhPT0gJ2NyZWF0ZVZhcicpLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudCk6IFByb21pc2U8bnVtYmVyPiA9PiB7XG5cdFx0XHRcdGNvbnN0IG9wdHMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGV2ZW50Lm9wdGlvbnMpKVxuXHRcdFx0XHRjb25zdCBtc2dJZCA9IGV2ZW50LmZlZWRiYWNrSWQucmVwbGFjZSgnX3ZhbHVlJywgJycpXG5cdFx0XHRcdGNvbnN0IG1zZyA9IE1pZGlNZXNzYWdlLnBhcnNlTWVzc2FnZSh1bmRlZmluZWQsIHsgaWQ6IG1zZ0lkLCAuLi5vcHRzIH0pXG5cdFx0XHRcdHJldHVybiBzZWxmLmdldEZyb21EYXRhU3RvcmUobXNnISkgPz8gMFxuXHRcdFx0fSxcblx0XHR9XG5cdH1cblxuXHRmZWVkYmFja3NbJ21pZGlJbiddID0ge1xuXHRcdG5hbWU6ICdNSURJIE1lc3NhZ2UgSW5jb21pbmc/Jyxcblx0XHRkZXNjcmlwdGlvbjogJ0ZpcmUgd2hlbmV2ZXIgQU5ZIE1JREkgbWVzc2FnZSBpcyByZWNlaXZlZCcsXG5cdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigyNTUsIDAsIDApLFxuXHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0fSxcblx0XHRvcHRpb25zOiBbXSxcblx0XHRjYWxsYmFjazogYXN5bmMgKCk6IFByb21pc2U8Ym9vbGVhbj4gPT4ge1xuXHRcdFx0cmV0dXJuICEhc2VsZi5nZXRWYXJpYWJsZVZhbHVlKCdtaWRpSW4nKVxuXHRcdH0sXG5cdH1cblxuXHRmZWVkYmFja3NbJ21pZGlPdXQnXSA9IHtcblx0XHRuYW1lOiAnTUlESSBNZXNzYWdlIE91dGdvaW5nPycsXG5cdFx0ZGVzY3JpcHRpb246ICdGaXJlIHdoZW5ldmVyIEFOWSBNSURJIG1lc3NhZ2UgaXMgc2VudCcsXG5cdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdGRlZmF1bHRTdHlsZToge1xuXHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigyNTUsIDAsIDApLFxuXHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0fSxcblx0XHRvcHRpb25zOiBbXSxcblx0XHRjYWxsYmFjazogYXN5bmMgKCk6IFByb21pc2U8Ym9vbGVhbj4gPT4ge1xuXHRcdFx0cmV0dXJuICEhc2VsZi5nZXRWYXJpYWJsZVZhbHVlKCdtaWRpT3V0Jylcblx0XHR9LFxuXHR9XG5cblx0c2VsZi5zZXRGZWVkYmFja0RlZmluaXRpb25zKGZlZWRiYWNrcylcbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgY29tYmluZVJnYiB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVQcmVzZXRzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IHByZXNldHMgPSB7XG5cdFx0bWlkaV9pbjoge1xuXHRcdFx0dHlwZTogJ3NpbXBsZScgYXMgY29uc3QsXG5cdFx0XHRuYW1lOiBgTUlESSBNZXNzYWdlIEluIEluZGljYXRvcmAsXG5cdFx0XHRzdHlsZToge1xuXHRcdFx0XHR0ZXh0OiBgTUlESSBJTmAsXG5cdFx0XHRcdHNpemU6ICdhdXRvJyBhcyBjb25zdCxcblx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMjU1LCAyNTUsIDI1NSksXG5cdFx0XHRcdGJnY29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHR9LFxuXHRcdFx0c3RlcHM6IFtdLFxuXHRcdFx0ZmVlZGJhY2tzOiBbXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRmZWVkYmFja0lkOiAnbWlkaUluJyxcblx0XHRcdFx0XHRvcHRpb25zOiB7fSxcblx0XHRcdFx0XHRzdHlsZToge1xuXHRcdFx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMjU1LCAyNTUsIDI1NSksXG5cdFx0XHRcdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDAsIDI1NSwgMCksXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0fSxcblx0XHRcdF0sXG5cdFx0fSxcblx0XHRtaWRpX291dDoge1xuXHRcdFx0dHlwZTogJ3NpbXBsZScgYXMgY29uc3QsXG5cdFx0XHRuYW1lOiBgTUlESSBNZXNzYWdlIE91dCBJbmRpY2F0b3JgLFxuXHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0dGV4dDogYE1JREkgT1VUYCxcblx0XHRcdFx0c2l6ZTogJ2F1dG8nIGFzIGNvbnN0LFxuXHRcdFx0XHRjb2xvcjogY29tYmluZVJnYigyNTUsIDI1NSwgMjU1KSxcblx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAwLCAwKSxcblx0XHRcdH0sXG5cdFx0XHRzdGVwczogW10sXG5cdFx0XHRmZWVkYmFja3M6IFtcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGZlZWRiYWNrSWQ6ICdtaWRpT3V0Jyxcblx0XHRcdFx0XHRvcHRpb25zOiB7fSxcblx0XHRcdFx0XHRzdHlsZToge1xuXHRcdFx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMjU1LCAyNTUsIDI1NSksXG5cdFx0XHRcdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDAsIDI1NSwgMCksXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0fSxcblx0XHRcdF0sXG5cdFx0fSxcblx0fVxuXG5cdGNvbnN0IHN0cnVjdHVyZSA9IFtcblx0XHR7XG5cdFx0XHRpZDogJ2luZGljYXRvcnMnLFxuXHRcdFx0bmFtZTogJ0luZGljYXRvcnMnLFxuXHRcdFx0ZGVmaW5pdGlvbnM6IFtcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAnbWlkaV9pbmRpY2F0b3JzJyxcblx0XHRcdFx0XHR0eXBlOiAnc2ltcGxlJyBhcyBjb25zdCxcblx0XHRcdFx0XHRuYW1lOiAnTUlESSBJbmRpY2F0b3JzJyxcblx0XHRcdFx0XHRwcmVzZXRzOiBbJ21pZGlfaW4nLCAnbWlkaV9vdXQnXSxcblx0XHRcdFx0fSxcblx0XHRcdF0sXG5cdFx0fSxcblx0XVxuXG5cdHNlbGYuc2V0UHJlc2V0RGVmaW5pdGlvbnMoc3RydWN0dXJlLCBwcmVzZXRzKVxufVxuIiwgImltcG9ydCB7IEluc3RhbmNlQmFzZSwgSW5zdGFuY2VUeXBlcywgSW5zdGFuY2VTdGF0dXMsIFNvbWVDb21wYW5pb25Db25maWdGaWVsZCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBHZXRDb25maWdGaWVsZHMsIHR5cGUgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zLCBIYW5kbGVNaWRpSW5kaWNhdG9ycywgVXBkYXRlTGFzdE1zZyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgVXBncmFkZVNjcmlwdHMgfSBmcm9tICcuL3VwZ3JhZGVzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlQWN0aW9ucyB9IGZyb20gJy4vYWN0aW9ucy5qcydcbmltcG9ydCB7IFVwZGF0ZUZlZWRiYWNrcyB9IGZyb20gJy4vZmVlZGJhY2tzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlUHJlc2V0cyB9IGZyb20gJy4vcHJlc2V0cy5qcydcbmltcG9ydCAqIGFzIG1pZGkgZnJvbSAnLi9taWRpL21pZGkuanMnXG5pbXBvcnQgeyBNaWRpTWVzc2FnZSB9IGZyb20gJy4vbWlkaS9tc2d0eXBlcy5qcydcblxuZXhwb3J0IGludGVyZmFjZSBEYXRhU3RvcmVFbnRyeSB7XG5cdGtleTogbnVtYmVyXG5cdHZhbDogbnVtYmVyXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vZHVsZUluc3RhbmNlIGV4dGVuZHMgSW5zdGFuY2VCYXNlPEluc3RhbmNlVHlwZXM+IHtcblx0Y29uZmlnITogTW9kdWxlQ29uZmlnIC8vIFNldHVwIGluIGluaXQoKVxuXHRtaWRpSW5wdXQhOiBtaWRpLklucHV0XG5cdG1pZGlPdXRwdXQhOiBtaWRpLk91dHB1dFxuXHRkYXRhU3RvcmUhOiBNYXA8bnVtYmVyLCBudW1iZXI+XG5cdGlzUmVjb3JkaW5nQWN0aW9ucyE6IGJvb2xlYW5cblxuXHRjb25zdHJ1Y3RvcihpbnRlcm5hbDogdW5rbm93bikge1xuXHRcdHN1cGVyKGludGVybmFsKVxuXHR9XG5cblx0YXN5bmMgaW5pdChjb25maWc6IE1vZHVsZUNvbmZpZyk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMuY29uZmlnID0gY29uZmlnXG5cdFx0dGhpcy5kYXRhU3RvcmUgPSBuZXcgTWFwKClcblxuXHRcdHRoaXMudXBkYXRlQWN0aW9ucygpXG5cdFx0dGhpcy51cGRhdGVGZWVkYmFja3MoKVxuXHRcdHRoaXMudXBkYXRlUHJlc2V0cygpXG5cdFx0dGhpcy51cGRhdGVWYXJpYWJsZURlZmluaXRpb25zKClcblx0XHRhd2FpdCB0aGlzLmNvbmZpZ1VwZGF0ZWQoY29uZmlnKVxuXHR9XG5cblx0Ly8gV2hlbiBtb2R1bGUgZ2V0cyBkZWxldGVkXG5cdGFzeW5jIGRlc3Ryb3koKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5taWRpSW5wdXQuY2xvc2UoKVxuXHRcdHRoaXMubWlkaU91dHB1dC5jbG9zZSgpXG5cdFx0dGhpcy5sb2coJ2RlYnVnJywgYCR7dGhpcy5pZH0gZGVzdHJveWVkYClcblx0fVxuXG5cdGFzeW5jIGNvbmZpZ1VwZGF0ZWQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdHRoaXMuY29uZmlnLmluUG9ydElzVmlydHVhbCA9IGZhbHNlIC8vIGRlbGV0ZSBpZiBWaXJ0dWFsIHBvcnRzIGV2ZXIgZ2V0IHN1cHBvcnRlZCBieSBXaW5kb3dzXG5cdFx0dGhpcy5jb25maWcub3V0UG9ydElzVmlydHVhbCA9IGZhbHNlXG5cdFx0Y29uc3QgaW5Qb3J0TmFtZSA9IHRoaXMuY29uZmlnLmluUG9ydElzVmlydHVhbCA/IHRoaXMuY29uZmlnLmluUG9ydFZpcnR1YWxOYW1lIDogdGhpcy5jb25maWcuaW5Qb3J0TmFtZVxuXHRcdGNvbnN0IG91dFBvcnROYW1lID0gdGhpcy5jb25maWcub3V0UG9ydElzVmlydHVhbCA/IHRoaXMuY29uZmlnLm91dFBvcnRWaXJ0dWFsTmFtZSA6IHRoaXMuY29uZmlnLm91dFBvcnROYW1lXG5cdFx0dGhpcy5sb2coXG5cdFx0XHQnZGVidWcnLFxuXHRcdFx0YEF2YWlsYWJsZSBNSURJIElucHV0czogJHtKU09OLnN0cmluZ2lmeShtaWRpLmdldElucHV0cygpKX1cXG5cXHRTZWxlY3RlZCBNSURJIElucHV0OiAgJHtpblBvcnROYW1lfWAsXG5cdFx0KVxuXHRcdHRoaXMubG9nKFxuXHRcdFx0J2RlYnVnJyxcblx0XHRcdGBBdmFpbGFibGUgTUlESSBPdXRwdXRzOiAke0pTT04uc3RyaW5naWZ5KG1pZGkuZ2V0T3V0cHV0cygpKX1cXG5cXHRTZWxlY3RlZCBNSURJIE91dHB1dDogJHtvdXRQb3J0TmFtZX1gLFxuXHRcdClcblx0XHR0aGlzLmxvZygnZGVidWcnLCAnJylcblx0XHRpZiAodGhpcy5taWRpSW5wdXQpIHRoaXMubWlkaUlucHV0LmNsb3NlKClcblx0XHRpZiAodGhpcy5taWRpT3V0cHV0KSB0aGlzLm1pZGlPdXRwdXQuY2xvc2UoKVxuXHRcdHRoaXMubWlkaUlucHV0ID0gbmV3IG1pZGkuSW5wdXQoaW5Qb3J0TmFtZSwgdGhpcy5jb25maWcuaW5Qb3J0SXNWaXJ0dWFsKVxuXHRcdHRoaXMubWlkaU91dHB1dCA9IG5ldyBtaWRpLk91dHB1dChvdXRQb3J0TmFtZSwgdGhpcy5jb25maWcub3V0UG9ydElzVmlydHVhbClcblx0XHRjb25zdCBtaWRpSW5TdGF0dXMgPSB0aGlzLmNvbmZpZy5pblBvcnRJc1ZpcnR1YWwgfHwgdGhpcy5taWRpSW5wdXQuaXNQb3J0T3BlbigpXG5cdFx0Y29uc3QgbWlkaU91dFN0YXR1cyA9IHRoaXMuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwgfHwgdGhpcy5taWRpT3V0cHV0LmlzUG9ydE9wZW4oKVxuXHRcdHRoaXMubG9nKCdpbmZvJywgYFNlbGVjdGVkIEluICBQb3J0IFwiJHt0aGlzLm1pZGlJbnB1dC5uYW1lfVwiIGlzICR7bWlkaUluU3RhdHVzID8gJycgOiAnTk9UICd9T3Blbi5gKVxuXHRcdHRoaXMubG9nKCdpbmZvJywgYFNlbGVjdGVkIE91dCBQb3J0IFwiJHt0aGlzLm1pZGlPdXRwdXQubmFtZX1cIiBpcyAke21pZGlPdXRTdGF0dXMgPyAnJyA6ICdOT1QgJ31PcGVuLmApXG5cdFx0dGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuRGlzY29ubmVjdGVkKVxuXHRcdGlmICghbWlkaUluU3RhdHVzICYmIG1pZGlPdXRTdGF0dXMpIHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkJhZENvbmZpZywgJ01JREkgSW4gUG9ydCBub3Qgb3BlbicpXG5cdFx0aWYgKG1pZGlJblN0YXR1cyAmJiAhbWlkaU91dFN0YXR1cykgdGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuQmFkQ29uZmlnLCAnTUlESSBPdXQgUG9ydCBub3Qgb3BlbicpXG5cdFx0aWYgKG1pZGlJblN0YXR1cyAmJiBtaWRpT3V0U3RhdHVzKSB0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5PaylcblxuXHRcdHRoaXMuc3RhcnQoKVxuXHR9XG5cblx0Ly8gUmV0dXJuIGNvbmZpZyBmaWVsZHMgZm9yIHdlYiBjb25maWdcblx0Z2V0Q29uZmlnRmllbGRzKCk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0XHRyZXR1cm4gR2V0Q29uZmlnRmllbGRzKClcblx0fVxuXHR1cGRhdGVBY3Rpb25zKCk6IHZvaWQge1xuXHRcdFVwZGF0ZUFjdGlvbnModGhpcylcblx0fVxuXG5cdHVwZGF0ZUZlZWRiYWNrcygpOiB2b2lkIHtcblx0XHRVcGRhdGVGZWVkYmFja3ModGhpcylcblx0fVxuXG5cdHVwZGF0ZVByZXNldHMoKTogdm9pZCB7XG5cdFx0VXBkYXRlUHJlc2V0cyh0aGlzKVxuXHR9XG5cblx0dXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zKHRoaXMpXG5cdH1cblxuXHQvLyBUaGUgbWFpbiBsb29wXG5cdHN0YXJ0KCk6IHZvaWQge1xuXHRcdHRoaXMubG9nKCdkZWJ1ZycsICdcXG5FbnRlcmluZyAqbWFpbipcXG4nKVxuXG5cdFx0dGhpcy5taWRpSW5wdXQub24oJ3NtcHRlJywgKGFyZ3M6IHsgc21wdGU6IHN0cmluZzsgc21wdGVGUjogbnVtYmVyIH0pID0+IHtcblx0XHRcdHRoaXMuc2V0VmFyaWFibGVWYWx1ZXMoe1xuXHRcdFx0XHRzbXB0ZTogYXJncy5zbXB0ZSxcblx0XHRcdFx0c21wdGVGUjogYXJncy5zbXB0ZUZSLFxuXHRcdFx0fSlcblx0XHR9KVxuXHRcdHRoaXMubWlkaUlucHV0Lm9uKCdtZXNzYWdlJywgKGRlbHRhVGltZTogbnVtYmVyLCBtc2c6IE1pZGlNZXNzYWdlKSA9PiB7XG5cdFx0XHRpZiAobXNnLmlkICE9PSAnbXRjJykge1xuXHRcdFx0XHR0aGlzLmxvZygnZGVidWcnLCBgWyR7ZGVsdGFUaW1lLnRvRml4ZWQoMikucGFkU3RhcnQoNiwgJzAnKX1dIFJlY2VpdmVkOiAke21zZ30gZnJvbSBcIiR7dGhpcy5taWRpSW5wdXQubmFtZX1cImApXG5cdFx0XHRcdHRoaXMuYWRkVG9EYXRhU3RvcmUobXNnKVxuXHRcdFx0XHRpZiAodGhpcy5pc1JlY29yZGluZ0FjdGlvbnMpIHRoaXMuYWRkVG9BY3Rpb25SZWNvcmRpbmcoZGVsdGFUaW1lLCBtc2cpXG5cdFx0XHR9XG5cdFx0XHRIYW5kbGVNaWRpSW5kaWNhdG9ycyh0aGlzLCAnbWlkaUluJylcblx0XHR9KVxuXHR9XG5cblx0YWRkVG9EYXRhU3RvcmUobXNnOiBNaWRpTWVzc2FnZSk6IHZvaWQge1xuXHRcdGNvbnN0IGRhdGE6IERhdGFTdG9yZUVudHJ5ID0gdGhpcy5nZXRWYWxGcm9tTXNnKG1zZylcblx0XHRpZiAoZGF0YS5rZXkgPiAwKSB7XG5cdFx0XHRVcGRhdGVMYXN0TXNnKHRoaXMsIG1zZywgZGF0YS52YWwpXG5cdFx0XHR0aGlzLmRhdGFTdG9yZS5zZXQoZGF0YS5rZXksIGRhdGEudmFsKVxuXHRcdFx0dGhpcy5jaGVja0FsbEZlZWRiYWNrcygpXG5cdFx0fVxuXHR9XG5cblx0Z2V0RnJvbURhdGFTdG9yZShtc2c6IE1pZGlNZXNzYWdlKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcblx0XHRjb25zdCBkYXRhOiBEYXRhU3RvcmVFbnRyeSA9IHRoaXMuZ2V0VmFsRnJvbU1zZyhtc2cpXG5cdFx0aWYgKGRhdGEua2V5ID4gMCkge1xuXHRcdFx0cmV0dXJuIHRoaXMuZGF0YVN0b3JlLmdldChkYXRhLmtleSlcblx0XHR9XG5cdFx0cmV0dXJuIHVuZGVmaW5lZFxuXHR9XG5cblx0Z2V0VmFsRnJvbU1zZyhtc2c6IE1pZGlNZXNzYWdlKTogRGF0YVN0b3JlRW50cnkge1xuXHRcdGxldCBsYXN0SW5kZXg6IG51bWJlciA9IG1zZy5ieXRlcy5sZW5ndGggLSAxXG5cdFx0bGV0IHBhcnNlZEtleSA9IDBcblx0XHRsZXQgcGFyc2VkVmFsID0gMFxuXHRcdC8vIHZhbCBpcyBsYXN0IGJ5dGUsIGtleSBpcyBhbGwgYnl0ZXMgdXAgdG8gdGhlIGxhc3Rcblx0XHQvLyBlLmcuIFsweDkwLCAweDYwLCAweDdGXToga2V5ID0gMHg5MDYwLCB2YWwgPSAweDdGXG5cdFx0aWYgKGxhc3RJbmRleCA+PSAwICYmIG1zZy5zdGF0dXMgPCAweGYwKSB7XG5cdFx0XHRpZiAobXNnLmlkID09ICdwaXRjaCcpIHtcblx0XHRcdFx0cGFyc2VkVmFsID0gbXNnLmFyZ3MudmFsdWUgPz8gMFxuXHRcdFx0XHRsYXN0SW5kZXgtLVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0cGFyc2VkVmFsID0gbXNnLmJ5dGVzW2xhc3RJbmRleF1cblx0XHRcdH1cblx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgbGFzdEluZGV4OyBpKyspIHtcblx0XHRcdFx0cGFyc2VkS2V5ICs9IG1zZy5ieXRlc1tpXSA8PCAoKGxhc3RJbmRleCAtIGkgLSAxKSA8PCAzKVxuXHRcdFx0fVxuXHRcdFx0aWYgKHBhcnNlZEtleSA9PSAwKSBwYXJzZWRLZXkgPSBwYXJzZWRWYWxcblx0XHR9XG5cdFx0cmV0dXJuIHsga2V5OiBwYXJzZWRLZXksIHZhbDogcGFyc2VkVmFsIH1cblx0fVxuXG5cdC8vIFRyYWNrIHdoZXRoZXIgYWN0aW9ucyBhcmUgYmVpbmcgcmVjb3JkZWRcblx0aGFuZGxlU3RhcnRTdG9wUmVjb3JkQWN0aW9ucyhpc1JlY29yZGluZzogYm9vbGVhbik6IHZvaWQge1xuXHRcdHRoaXMuaXNSZWNvcmRpbmdBY3Rpb25zID0gaXNSZWNvcmRpbmdcblx0fVxuXG5cdC8vIEFkZCBhIGNvbW1hbmQgdG8gdGhlIEFjdGlvbiBSZWNvcmRlclxuXHRhZGRUb0FjdGlvblJlY29yZGluZyhkZWx0YVRpbWU6IG51bWJlciwgbXNnOiBNaWRpTWVzc2FnZSk6IHZvaWQge1xuXHRcdGNvbnN0IGFyZ3MgPSB7IC4uLm1zZy5hcmdzIH1cblx0XHRsZXQgdW5pcXVlSWQgPSBgJHttc2cuaWR9ICR7dGhpcy5nZXRWYWxGcm9tTXNnKG1zZykua2V5fWBcblx0XHRpZiAodGhpcy5jb25maWcudXNlVGltZVN0YW1wKSB7XG5cdFx0XHRkZWx0YVRpbWUgPSBNYXRoLnJvdW5kKGRlbHRhVGltZSAqIDEwMDApXG5cdFx0XHR1bmlxdWVJZCA9ICcnXG5cdFx0fSBlbHNlIHtcblx0XHRcdGRlbHRhVGltZSA9IDBcblx0XHR9XG5cdFx0dGhpcy5yZWNvcmRBY3Rpb24oXG5cdFx0XHR7XG5cdFx0XHRcdGFjdGlvbklkOiBtc2cuaWQsXG5cdFx0XHRcdG9wdGlvbnM6IGFyZ3MsXG5cdFx0XHRcdGRlbGF5OiBkZWx0YVRpbWUsXG5cdFx0XHR9LFxuXHRcdFx0dW5pcXVlSWQsIC8vIHVuaXF1ZUlkIHRvIHN0b3AgZHVwbGljYXRlcyB3aGVuIG5vdCB1c2luZyBUaW1lU3RhbXBcblx0XHQpXG5cdH1cbn1cblxuZXhwb3J0IHsgVXBncmFkZVNjcmlwdHMgfVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBLFFBQU0sS0FBSyxVQUFRLElBQUk7QUFRdkIsYUFBUyxnQkFBZ0IsU0FBUztBQUNqQyxVQUFJLENBQUMsUUFBUSxhQUFjLE9BQU0sSUFBSSxNQUFNLHFCQUFxQjtBQUVoRSxZQUFNLFNBQVM7QUFBQSxRQUNkLFFBQVE7QUFBQSxRQUNSLFFBQVE7QUFBQSxRQUNSLFFBQVE7QUFBQTtBQUFBLFFBRVIsUUFBUSxRQUFRLFFBQVEsYUFBYSxVQUFVLFFBQVEsT0FBTztBQUFBLE1BQy9EO0FBQ0EsYUFBTyxHQUFHLE9BQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQyxJQUFJLFFBQVEsT0FBTyxVQUFVLFFBQVEsWUFBWTtBQUFBLElBQy9GO0FBRUEsYUFBUyxTQUFTO0FBQ2pCLGFBQU8sQ0FBQyxFQUFFLFFBQVEsWUFBWSxRQUFRLFNBQVM7QUFBQSxJQUNoRDtBQUVBLGFBQVMsYUFBYTtBQUNyQixVQUFJLFFBQVEsWUFBWSxRQUFRLFNBQVMsU0FBVSxRQUFPO0FBQzFELFVBQUksUUFBUSxJQUFJLHFCQUFzQixRQUFPO0FBQzdDLGFBQU8sT0FBTyxXQUFXLGVBQWUsT0FBTyxXQUFXLE9BQU8sUUFBUSxTQUFTO0FBQUEsSUFDbkY7QUFFQSxhQUFTLFNBQVMsVUFBVTtBQUMzQixhQUFPLGFBQWEsV0FBVyxHQUFHLFdBQVcscUJBQXFCO0FBQUEsSUFDbkU7QUFFQSxXQUFPLFVBQVU7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Q7QUFBQTtBQUFBOzs7QUN4Q0E7QUFBQTtBQUFBLFFBQU0sT0FBTyxVQUFRLE1BQU07QUFDM0IsUUFBTSxLQUFLLFVBQVEsSUFBSTtBQUN2QixRQUFNLEVBQUUsaUJBQWlCLFFBQVEsWUFBWSxTQUFTLElBQUk7QUFHMUQsUUFBTSxLQUFLLE9BQU8sU0FBUyxjQUFjLEtBQUssY0FBYyxJQUFJLElBQUksVUFBUSxJQUFJO0FBR2hGLFFBQU0saUJBQWlCLE9BQU8sd0JBQXdCLGFBQWEsMEJBQTBCO0FBVTdGLGFBQVMsWUFBWSxVQUFVLFNBQVMsZ0JBQWdCLGdCQUFnQjtBQUN2RSxVQUFJLE9BQU8sYUFBYSxZQUFZLENBQUMsU0FBVSxPQUFNLElBQUksTUFBTSxtQ0FBbUM7QUFFbEcsVUFBSSxPQUFPLFlBQVksWUFBWSxDQUFDLFFBQVMsT0FBTSxJQUFJLE1BQU0sa0NBQWtDO0FBQy9GLFVBQUksT0FBTyxRQUFRLFNBQVMsWUFBWSxDQUFDLFFBQVEsS0FBTSxPQUFNLElBQUksTUFBTSwrQkFBK0I7QUFFdEcsVUFBSSxZQUFZO0FBQ2hCLFVBQUksUUFBUSxpQkFBaUIsTUFBTSxRQUFRLFFBQVEsYUFBYSxHQUFHO0FBQ2xFLG9CQUFZO0FBQUEsTUFDYjtBQUVBLFlBQU0sT0FBUSxrQkFBa0IsUUFBUSxJQUFJLG1CQUFvQixHQUFHLEtBQUs7QUFDeEUsWUFBTSxXQUFZLGtCQUFrQixRQUFRLElBQUksdUJBQXdCLEdBQUcsU0FBUztBQUVwRixVQUFJLFVBQVU7QUFFZCxVQUFJLENBQUMsV0FBVztBQUNmLFlBQUksa0JBQWtCLFFBQVEsSUFBSSxvQkFBb0I7QUFDckQsb0JBQVUsUUFBUSxJQUFJO0FBQUEsUUFDdkIsV0FBVyxXQUFXLEdBQUc7QUFDeEIsb0JBQVU7QUFBQSxRQUNYLFdBQVcsT0FBTyxHQUFHO0FBQ3BCLG9CQUFVO0FBQUEsUUFDWDtBQUFBLE1BQ0Q7QUFFQSxZQUFNLGFBQWEsQ0FBQztBQUVwQixVQUFJLENBQUMsZ0JBQWdCO0FBRXBCLG1CQUFXO0FBQUEsVUFDVixLQUFLLEtBQUssVUFBVSxTQUFTLFNBQVMsR0FBRyxRQUFRLElBQUksT0FBTztBQUFBLFVBQzVELEtBQUssS0FBSyxVQUFVLFNBQVMsV0FBVyxHQUFHLFFBQVEsSUFBSSxPQUFPO0FBQUEsUUFDL0Q7QUFBQSxNQUNEO0FBRUEsVUFBSSxPQUFPO0FBQ1gsVUFBSSxTQUFTLFFBQVEsRUFBRyxRQUFPO0FBRy9CLFVBQUksV0FBVztBQUVkLG1CQUFXLE9BQU8sUUFBUSxlQUFlO0FBQ3hDLGdCQUFNLGVBQWUsZ0JBQWdCO0FBQUEsWUFDcEMsTUFBTSxRQUFRO0FBQUEsWUFDZDtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQSxjQUFjO0FBQUEsWUFDZDtBQUFBO0FBQUEsVUFFRCxDQUFDO0FBQ0QscUJBQVcsS0FBSyxLQUFLLEtBQUssVUFBVSxhQUFhLFlBQVksQ0FBQztBQUFBLFFBQy9EO0FBQUEsTUFDRCxPQUFPO0FBQ04sY0FBTSxJQUFJLE1BQU0sMEJBQTBCO0FBQUEsTUFDM0M7QUFFQSxVQUFJLFlBQVk7QUFFaEIsaUJBQVcsYUFBYSxZQUFZO0FBQ25DLFlBQUksR0FBRyxXQUFXLFNBQVMsR0FBRztBQUM3QixnQkFBTSxPQUFPLEdBQUcsU0FBUyxTQUFTO0FBQ2xDLGNBQUksS0FBSyxPQUFPLEdBQUc7QUFDbEIsd0JBQVk7QUFDWjtBQUFBLFVBQ0Q7QUFBQSxRQUNEO0FBQUEsTUFDRDtBQUVBLFVBQUksQ0FBQyxhQUFhLGdCQUFnQjtBQUNqQyxjQUFNLGdCQUFnQixXQUFXLElBQUksQ0FBQyxTQUFTLE1BQU0sSUFBSSxFQUFFLEVBQUUsS0FBSyxJQUFJO0FBQ3RFLGNBQU0sSUFBSSxNQUFNLDhCQUE4QixRQUFRLElBQUk7QUFBQTtBQUFBLEVBQW1CLGFBQWEsRUFBRTtBQUFBLE1BQzdGO0FBRUEsYUFBTztBQUFBLElBQ1I7QUFFQSxhQUFTLFlBQVksVUFBVSxTQUFTO0FBQ3ZDLFlBQU0sWUFBWSxZQUFZLFVBQVUsU0FBUyxPQUFPLElBQUk7QUFHNUQsVUFBSSxDQUFDLFVBQVcsT0FBTSxJQUFJLE1BQU0sOEJBQThCLFFBQVEsSUFBSSxFQUFFO0FBRTVFLGFBQU8sZUFBZSxTQUFTO0FBQUEsSUFDaEM7QUFDQSxnQkFBWSxVQUFVO0FBRXRCLFdBQU8sVUFBVTtBQUFBO0FBQUE7OztBQzFHakI7QUFBQTtBQUFBLFdBQU8sVUFBVTtBQUFBLE1BQ2YsTUFBTTtBQUFBLE1BQ04sZUFBZSxDQUFDLENBQUM7QUFBQSxJQUNuQjtBQUFBO0FBQUE7OztBQ0hBO0FBQUE7QUFDQSxXQUFPLFVBQVU7QUFBQSxNQUViLHNCQUE4QjtBQUFBLE1BQzlCLHVCQUE4QjtBQUFBLE1BQzlCLHNCQUE4QjtBQUFBLE1BQzlCLGtCQUE4QjtBQUFBLE1BQzlCLGtCQUFxQjtBQUFBLE1BQ3JCLGtCQUE4QjtBQUFBLE1BQzlCLGFBQThCO0FBQUEsTUFDOUIsT0FBZ0I7QUFBQSxNQUNoQixTQUFvQjtBQUFBLE1BQ3BCLGNBQWtCO0FBQUEsTUFDbEIsV0FBbUI7QUFBQSxNQUNuQixZQUFvQjtBQUFBLE1BQ3BCLFNBQWtCO0FBQUEsTUFDbEIsV0FBcUI7QUFBQSxNQUNyQixlQUE4QjtBQUFBLE1BQzlCLFVBQWU7QUFBQSxNQUNmLGVBQThCO0FBQUEsTUFDOUIsa0JBQThCO0FBQUEsTUFDOUIsWUFBb0I7QUFBQSxNQUNwQixjQUFrQjtBQUFBLE1BQ2xCLFlBQW9CO0FBQUEsTUFDcEIsV0FBbUI7QUFBQSxNQUNuQixXQUFtQjtBQUFBLE1BQ25CLGlCQUE4QjtBQUFBLE1BQzlCLHVCQUE4QjtBQUFBLE1BQzlCLHVCQUE4QjtBQUFBLE1BQzlCLHNCQUE4QjtBQUFBLE1BQzlCLHVCQUE4QjtBQUFBLE1BQzlCLHVCQUE4QjtBQUFBLE1BQzlCLG1CQUF5QjtBQUFBLE1BQ3pCLG1CQUF5QjtBQUFBLE1BQ3pCLGtCQUFxQjtBQUFBLE1BQ3JCLGVBQXNCO0FBQUEsTUFDdEIsc0JBQXdCO0FBQUEsTUFDeEIsb0JBQTBCO0FBQUEsTUFDMUIsZUFBOEI7QUFBQSxNQUM5QixhQUE4QjtBQUFBLE1BQzlCLGFBQThCO0FBQUEsTUFDOUIsY0FBOEI7QUFBQSxNQUM5QixjQUFrQjtBQUFBLE1BQ2xCLFFBQWlCO0FBQUEsTUFDakIsT0FBZ0I7QUFBQSxNQUNoQixPQUFpQjtBQUFBLE1BQ2pCLFlBQTJCO0FBQUEsTUFDM0IsaUJBQTJCO0FBQUEsTUFDM0IsbUJBQXlCO0FBQUEsTUFDekIsaUJBQXdCO0FBQUEsTUFDeEIsU0FBd0I7QUFBQSxNQUN4QixtQkFBeUI7QUFBQSxNQUN6QixtQkFBOEI7QUFBQSxNQUM5QixnQkFBOEI7QUFBQSxNQUM5QixnQkFBOEI7QUFBQSxNQUM5QixZQUFvQjtBQUFBLE1BQ3BCLFlBQW9CO0FBQUEsTUFDcEIsYUFBcUI7QUFBQSxNQUNyQixlQUFzQjtBQUFBLE1BQ3RCLFNBQWtCO0FBQUEsTUFDbEIsVUFBZTtBQUFBLE1BQ2YsTUFBWTtBQUFBLE1BQ1osZUFBc0I7QUFBQSxNQUN0QixhQUFxQjtBQUFBLE1BQ3JCLGVBQXNCO0FBQUEsTUFDdEIsY0FBa0I7QUFBQSxNQUNsQixjQUFrQjtBQUFBLE1BQ2xCLGFBQXFCO0FBQUEsTUFDckIsVUFBZTtBQUFBLE1BQ2YsV0FBd0I7QUFBQSxNQUN4QixjQUF3QjtBQUFBLE1BQ3hCLE1BQXFCO0FBQUEsTUFDckIsY0FBdUI7QUFBQSxNQUN2QixTQUEyQjtBQUFBLE1BQzNCLFVBQXdCO0FBQUEsTUFDeEIsU0FBNEI7QUFBQSxNQUM1QixPQUEyQjtBQUFBLE1BQzNCLFVBQTJCO0FBQUEsTUFDM0IsV0FBbUI7QUFBQSxNQUNuQixjQUFrQjtBQUFBLE1BQ2xCLFlBQW9CO0FBQUEsTUFDcEIsU0FBa0I7QUFBQSxNQUNsQixTQUFrQjtBQUFBLE1BQ2xCLGVBQTRCO0FBQUEsTUFDNUIsaUJBQXdCO0FBQUEsTUFDeEIsaUJBQXdCO0FBQUEsTUFDeEIsY0FBa0I7QUFBQSxNQUNsQixnQkFBdUI7QUFBQSxNQUN2QixjQUFzQjtBQUFBLE1BQ3RCLGVBQXNCO0FBQUEsTUFDdEIsc0JBQXdCO0FBQUEsTUFDeEIsZUFBc0I7QUFBQSxNQUN0QixZQUFvQjtBQUFBLE1BQ3BCLGlCQUF3QjtBQUFBLE1BQ3hCLGFBQXFCO0FBQUEsTUFDckIsYUFBcUI7QUFBQSxNQUNyQixnQkFBdUI7QUFBQSxNQUN2QixZQUFvQjtBQUFBLE1BQ3BCLGFBQXFCO0FBQUEsTUFDckIsV0FBbUI7QUFBQSxNQUNuQixpQkFBd0I7QUFBQSxNQUN4QixjQUFrQjtBQUFBLE1BQ2xCLGlCQUF3QjtBQUFBLE1BQ3hCLGlCQUF3QjtBQUFBLE1BQ3hCLGNBQWtCO0FBQUEsTUFDbEIsYUFBcUI7QUFBQSxNQUNyQixZQUFvQjtBQUFBLE1BQ3BCLE9BQWdCO0FBQUEsTUFDaEIsT0FBZ0I7QUFBQSxNQUNoQixVQUFlO0FBQUEsTUFDZixNQUFZO0FBQUEsTUFDWixTQUFrQjtBQUFBLE1BQ2xCLFVBQWU7QUFBQSxNQUNmLFFBQWlCO0FBQUEsTUFDakIsUUFBaUI7QUFBQSxNQUNqQixhQUFxQjtBQUFBLE1BQ3JCLE9BQWdCO0FBQUEsTUFDaEIsYUFBcUI7QUFBQSxNQUNyQixXQUFtQjtBQUFBLE1BQ25CLFlBQWtCO0FBQUEsTUFDbEIsYUFBcUI7QUFBQSxNQUNyQixZQUFvQjtBQUFBLE1BQ3BCLGdCQUF1QjtBQUFBLE1BQ3ZCLG1CQUF5QjtBQUFBLE1BQ3pCLGNBQWtCO0FBQUEsTUFDbEIsVUFBZTtBQUFBLE1BQ2YsWUFBb0I7QUFBQSxNQUNwQixnQkFBdUI7QUFBQSxNQUN2QixZQUFvQjtBQUFBLE1BQ3BCLFVBQWU7QUFBQSxNQUNmLFNBQThCO0FBQUEsSUFDbEM7QUFBQTtBQUFBOzs7QUNuSUE7QUFBQTtBQUNBLFdBQU8sVUFBVTtBQUFBLE1BRWIsb0JBQXlCO0FBQUEsTUFDekIsV0FBZTtBQUFBLE1BQ2YsWUFBbUI7QUFBQSxNQUNuQixnQkFBc0I7QUFBQSxNQUN0QixXQUFlO0FBQUEsTUFDZixnQkFBc0I7QUFBQSxNQUN0QixlQUFrQjtBQUFBLE1BQ2xCLGVBQWtCO0FBQUEsTUFDbEIsZ0JBQXNCO0FBQUEsTUFDdEIsY0FBaUI7QUFBQSxNQUNqQixTQUFpQjtBQUFBLE1BQ2pCLGFBQW9CO0FBQUEsTUFDcEIsYUFBb0I7QUFBQSxNQUNwQixZQUFtQjtBQUFBLE1BQ25CLGdCQUFzQjtBQUFBLE1BQ3RCLFVBQWM7QUFBQSxNQUNkLGVBQWtCO0FBQUEsTUFDbEIsZ0JBQXNCO0FBQUEsTUFDdEIsV0FBZTtBQUFBLE1BQ2YsWUFBbUI7QUFBQSxNQUNuQixlQUFrQjtBQUFBLE1BQ2xCLFNBQWlCO0FBQUEsTUFDakIsZ0JBQXNCO0FBQUEsTUFDdEIsWUFBbUI7QUFBQSxNQUNuQixlQUFrQjtBQUFBLE1BQ2xCLFVBQWM7QUFBQSxNQUNkLFdBQWU7QUFBQSxNQUNmLGVBQWtCO0FBQUEsTUFDbEIsZUFBa0I7QUFBQSxNQUNsQixXQUFlO0FBQUEsTUFDZixjQUFpQjtBQUFBLE1BQ2pCLGFBQW9CO0FBQUEsTUFDcEIsWUFBbUI7QUFBQSxNQUNuQixXQUFlO0FBQUEsTUFDZixRQUFnQjtBQUFBLE1BQ2hCLFNBQWlCO0FBQUEsTUFDakIsZUFBa0I7QUFBQSxNQUNsQixjQUFpQjtBQUFBLE1BQ2pCLGFBQW9CO0FBQUEsTUFDcEIsWUFBbUI7QUFBQSxNQUNuQixRQUFnQjtBQUFBLE1BQ2hCLGVBQWtCO0FBQUEsTUFDbEIsZ0JBQXNCO0FBQUEsTUFDdEIsWUFBbUI7QUFBQSxNQUNuQixZQUFtQjtBQUFBLE1BQ25CLGVBQWtCO0FBQUEsTUFDbEIsZUFBa0I7QUFBQSxJQUN0QjtBQUFBO0FBQUE7OztBQ2xEQTtBQUFBO0FBQ0EsV0FBTyxVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVNiLFVBQVc7QUFBQTtBQUFBLE1BR1gsR0FBSztBQUFBLE1BQ0wsU0FBVTtBQUFBLE1BQ1YsUUFBUztBQUFBLE1BQ1QsR0FBSztBQUFBLE1BQ0wsU0FBVTtBQUFBLE1BQ1YsUUFBVTtBQUFBLE1BQ1YsR0FBSztBQUFBLE1BQ0wsU0FBVTtBQUFBLE1BQ1YsUUFBVTtBQUFBLE1BQ1YsR0FBSztBQUFBLE1BQ0wsU0FBVTtBQUFBLE1BQ1YsUUFBVTtBQUFBLE1BQ1YsR0FBSztBQUFBLE1BQ0wsU0FBVTtBQUFBLE1BQ1YsUUFBVTtBQUFBLE1BQ1YsR0FBSztBQUFBLE1BQ0wsU0FBVTtBQUFBLE1BQ1YsUUFBVTtBQUFBLE1BQ1YsR0FBSztBQUFBLE1BQ0wsU0FBVTtBQUFBLE1BQ1YsUUFBVTtBQUFBO0FBQUEsTUFHVixJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxJQUFLO0FBQUEsTUFDTCxLQUFNO0FBQUEsSUFFVjtBQUFBO0FBQUE7OztBQ2hEQTtBQUFBO0FBQ0EsV0FBTyxVQUFVO0FBQUE7QUFBQTtBQUFBLE1BSWIsVUFBb0I7QUFBQTtBQUFBLE1BQ3BCLFNBQW9CO0FBQUE7QUFBQSxNQUNwQixtQkFBb0I7QUFBQTtBQUFBLE1BQ3BCLGVBQW9CO0FBQUE7QUFBQSxNQUNwQixhQUFvQjtBQUFBO0FBQUEsTUFDcEIsaUJBQW9CO0FBQUE7QUFBQSxNQUNwQixnQkFBb0I7QUFBQTtBQUFBLE1BRXBCLFdBQW9CO0FBQUEsTUFDcEIsU0FBb0I7QUFBQSxNQUNwQixTQUFvQjtBQUFBO0FBQUEsTUFHcEIsY0FBb0I7QUFBQTtBQUFBLE1BQ3BCLGdCQUFvQjtBQUFBO0FBQUEsTUFFcEIsU0FBb0I7QUFBQTtBQUFBLE1BSXBCLElBQUk7QUFBQTtBQUFBLFFBRU4sYUFBa0I7QUFBQSxRQUNsQixZQUF3QjtBQUFBLFFBQ3hCLGdCQUF3QjtBQUFBLFFBQ3hCLGFBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixpQkFBd0I7QUFBQSxRQUN4QixZQUF3QjtBQUFBLFFBQ3hCLFFBQXdCO0FBQUEsUUFDeEIsU0FBd0I7QUFBQSxRQUN4QixhQUF3QjtBQUFBLFFBQ3hCLEtBQXdCO0FBQUEsUUFDeEIsWUFBd0I7QUFBQSxRQUN4QixrQkFBd0I7QUFBQSxRQUN4QixrQkFBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsbUJBQXdCO0FBQUEsUUFDeEIsbUJBQW9CO0FBQUEsUUFDcEIsbUJBQW9CO0FBQUEsUUFDcEIsbUJBQW9CO0FBQUE7QUFBQSxRQUdwQixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQTtBQUFBLFFBR3hCLGlCQUFrQjtBQUFBLFFBQ1osZ0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDOUIsY0FBd0I7QUFBQSxRQUNsQixrQkFBd0I7QUFBQSxRQUN4QixxQkFBd0I7QUFBQSxRQUN4QixnQkFBd0I7QUFBQSxRQUN4QixZQUF3QjtBQUFBLFFBQ3hCLGFBQXdCO0FBQUEsUUFDOUIsY0FBd0I7QUFBQSxRQUNsQixTQUF3QjtBQUFBLFFBQ3hCLGdCQUF3QjtBQUFBLFFBQ3hCLHNCQUF3QjtBQUFBLFFBQ3hCLHNCQUF3QjtBQUFBLFFBRXhCLGNBQXdCO0FBQUEsUUFDOUIsY0FBd0I7QUFBQSxRQUNsQix1QkFBd0I7QUFBQSxRQUN4Qix1QkFBd0I7QUFBQSxRQUN4Qix1QkFBd0I7QUFBQSxRQUN4Qix1QkFBd0I7QUFBQTtBQUFBLFFBRzlCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBRWxCLGVBQXdCO0FBQUEsUUFDOUIsWUFBd0I7QUFBQSxRQUNsQixpQkFBd0I7QUFBQSxRQUN4QixZQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQzlCLFFBQXdCO0FBQUEsUUFDbEIsaUJBQXdCO0FBQUEsUUFDOUIsUUFBd0I7QUFBQSxRQUNsQixjQUF3QjtBQUFBLFFBQzlCLFlBQXdCO0FBQUEsUUFDbEIsWUFBd0I7QUFBQSxRQUM5QixRQUF3QjtBQUFBLFFBQ3hCLE9BQXdCO0FBQUEsUUFDbEIsaUJBQXdCO0FBQUEsUUFDOUIsUUFBd0I7QUFBQSxRQUNsQixZQUF3QjtBQUFBLFFBRXhCLHVCQUF3QjtBQUFBLFFBQ3hCLHVCQUF3QjtBQUFBLFFBQ3hCLHVCQUF3QjtBQUFBLFFBQ3hCLHVCQUF3QjtBQUFBLFFBRXhCLG9CQUF3QjtBQUFBO0FBQUEsUUFHOUIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUE7QUFBQSxRQUd4QixVQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDbEIsY0FBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDOUIsVUFBd0I7QUFBQSxRQUN4QixVQUF3QjtBQUFBLFFBQ2xCLG1CQUF3QjtBQUFBLFFBQ3hCLG1CQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQTtBQUFBLFFBRzlCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBO0FBQUEsUUFHbEIsZUFBd0I7QUFBQSxRQUN4Qix1QkFBd0I7QUFBQSxRQUM5QixlQUF3QjtBQUFBLFFBQ2xCLGVBQXdCO0FBQUEsUUFDOUIsZUFBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQTtBQUFBLFFBR3hCLFdBQXdCO0FBQUE7QUFBQSxRQUd4QixjQUF3QjtBQUFBLFFBQ2xCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQ3hCLHFCQUF3QjtBQUFBLFFBRXhCLGdCQUF3QjtBQUFBLFFBQzlCLGdCQUF3QjtBQUFBLFFBQ3hCLGdCQUF3QjtBQUFBLFFBQ3hCLGdCQUF3QjtBQUFBLFFBQ3hCLGdCQUF3QjtBQUFBLFFBRWxCLGNBQXdCO0FBQUEsTUFDNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BLFdBQVc7QUFBQSxRQUNQLGFBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQTtBQUFBLFFBQ3hCLGFBQXdCO0FBQUEsUUFDeEIsYUFBd0I7QUFBQSxRQUN4QixhQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsS0FBd0I7QUFBQTtBQUFBLE1BQzVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQSxVQUFVO0FBQUEsUUFDTixjQUFnQjtBQUFBLFFBQ2hCLGNBQWdCO0FBQUEsUUFDaEIsT0FBZ0I7QUFBQSxRQUNoQixVQUFnQjtBQUFBLFFBQ2hCLE1BQWdCO0FBQUEsUUFDaEIsY0FBZ0I7QUFBQSxRQUNoQixnQkFBZ0I7QUFBQSxRQUNoQixjQUFnQjtBQUFBLE1BQ3BCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWFBLE9BQU87QUFBQSxRQUNILEtBQXdCO0FBQUE7QUFBQSxNQUM1QjtBQUFBLElBRUo7QUFBQTtBQUFBOzs7QUNuUEE7QUFBQTtBQUFBLFFBQU0sT0FBTztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFFBQU0sU0FBUyxVQUFRLFFBQVE7QUFHL0IsUUFBTSxFQUFFLGNBQUFBLGNBQWEsSUFBSSxVQUFRLFFBQVE7QUFLekMsUUFBTSxjQUFjO0FBRXBCLFFBQU0sUUFBUTtBQUVkLFFBQU0sUUFBUTtBQUVkLFFBQU0sV0FBVztBQUVqQixRQUFNQyxTQUFOLGNBQW9CRCxjQUFhO0FBQUEsTUFDL0IsY0FBYztBQUNaLGNBQU07QUFFTixhQUFLLFFBQVEsSUFBSSxLQUFLLE1BQU0sQ0FBQyxXQUFXLFlBQVk7QUFDbEQsZUFBSyxLQUFLLFdBQVcsV0FBVyxNQUFNLEtBQUssUUFBUSxPQUFPLENBQUMsQ0FBQztBQUFBLFFBQzlELENBQUM7QUFBQSxNQUNIO0FBQUEsTUFFQSxZQUFZO0FBQ1YsZUFBTyxLQUFLLE1BQU0sVUFBVTtBQUFBLE1BQzlCO0FBQUEsTUFDQSxVQUFVO0FBQ1IsZUFBTyxLQUFLLE1BQU0sUUFBUTtBQUFBLE1BQzVCO0FBQUEsTUFDQSxlQUFlO0FBQ2IsZUFBTyxLQUFLLE1BQU0sYUFBYTtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxZQUFZLE1BQU07QUFDaEIsZUFBTyxLQUFLLE1BQU0sWUFBWSxJQUFJO0FBQUEsTUFDcEM7QUFBQSxNQUNBLGFBQWE7QUFDWCxlQUFPLEtBQUssTUFBTSxXQUFXO0FBQUEsTUFDL0I7QUFBQSxNQUNBLFlBQVksT0FBTyxRQUFRLGVBQWU7QUFDeEMsZUFBTyxLQUFLLE1BQU0sWUFBWSxPQUFPLFFBQVEsYUFBYTtBQUFBLE1BQzVEO0FBQUEsTUFDQSxTQUFTLE1BQU07QUFDYixlQUFPLEtBQUssTUFBTSxTQUFTLElBQUk7QUFBQSxNQUNqQztBQUFBLE1BQ0EsZUFBZSxNQUFNO0FBQ25CLGlCQUFRLE9BQUssR0FBRyxPQUFLLEtBQUssTUFBTSxhQUFhLEdBQUcsRUFBRSxNQUFNO0FBQ3RELGNBQUksU0FBUyxLQUFLLE1BQU0sWUFBWSxJQUFJLEdBQUc7QUFDekMsbUJBQU8sS0FBSyxNQUFNLFNBQVMsSUFBSTtBQUFBLFVBQ2pDO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFDQSxnQkFBZ0IsTUFBTTtBQUNwQixlQUFPLEtBQUssTUFBTSxnQkFBZ0IsSUFBSTtBQUFBLE1BQ3hDO0FBQUEsTUFDQSxjQUFjLE1BQU0sUUFBUSxHQUFHO0FBQzdCLGVBQU8sS0FBSyxNQUFNLGNBQWMsTUFBTSxLQUFLO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBRUEsUUFBTUUsVUFBTixNQUFhO0FBQUEsTUFDWCxjQUFjO0FBQ1osYUFBSyxTQUFTLElBQUksS0FBSyxPQUFPO0FBQUEsTUFDaEM7QUFBQSxNQUVBLFlBQVk7QUFDVixlQUFPLEtBQUssT0FBTyxVQUFVO0FBQUEsTUFDL0I7QUFBQSxNQUNBLFVBQVU7QUFDUixlQUFPLEtBQUssT0FBTyxRQUFRO0FBQUEsTUFDN0I7QUFBQSxNQUNBLGVBQWU7QUFDYixlQUFPLEtBQUssT0FBTyxhQUFhO0FBQUEsTUFDbEM7QUFBQSxNQUNBLFlBQVksTUFBTTtBQUNoQixlQUFPLEtBQUssT0FBTyxZQUFZLElBQUk7QUFBQSxNQUNyQztBQUFBLE1BQ0EsYUFBYTtBQUNYLGVBQU8sS0FBSyxPQUFPLFdBQVc7QUFBQSxNQUNoQztBQUFBLE1BQ0EsU0FBUyxNQUFNO0FBQ2IsZUFBTyxLQUFLLE9BQU8sU0FBUyxJQUFJO0FBQUEsTUFDbEM7QUFBQSxNQUNBLGVBQWUsTUFBTTtBQUNuQixpQkFBUSxPQUFLLEdBQUcsT0FBSyxLQUFLLE9BQU8sYUFBYSxHQUFHLEVBQUUsTUFBTTtBQUN2RCxjQUFJLFNBQVMsS0FBSyxPQUFPLFlBQVksSUFBSSxHQUFHO0FBQzFDLG1CQUFPLEtBQUssT0FBTyxTQUFTLElBQUk7QUFBQSxVQUNsQztBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BQ0EsZ0JBQWdCLE1BQU07QUFDcEIsZUFBTyxLQUFLLE9BQU8sZ0JBQWdCLElBQUk7QUFBQSxNQUN6QztBQUFBLE1BQ0EsS0FBSyxTQUFTO0FBQ1osZUFBTyxLQUFLLFlBQVksT0FBTztBQUFBLE1BQ2pDO0FBQUEsTUFDQSxZQUFZLFNBQVM7QUFDbkIsWUFBSSxNQUFNLFFBQVEsT0FBTyxHQUFHO0FBQzFCLG9CQUFVLE9BQU8sS0FBSyxPQUFPO0FBQUEsUUFDL0I7QUFDQSxZQUFJLENBQUMsT0FBTyxTQUFTLE9BQU8sR0FBRztBQUM3QixnQkFBTSxJQUFJLE1BQU0sMkNBQTJDO0FBQUEsUUFDN0Q7QUFFQSxlQUFPLEtBQUssT0FBTyxZQUFZLE9BQU87QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFHQSxhQUFTLGlCQUFpQixPQUFPO0FBQy9CLGNBQVEsU0FBUyxJQUFJRCxPQUFNO0FBQzNCLFVBQUksU0FBUyxJQUFJLE9BQU87QUFDeEIsYUFBTyxXQUFXO0FBQ2xCLGFBQU8sU0FBUztBQUNoQixhQUFPLFFBQVEsQ0FBQztBQUVoQixZQUFNLEdBQUcsV0FBVyxTQUFTLFdBQVcsU0FBUztBQUUvQyxZQUFJLFNBQVMsSUFBSSxPQUFPLEtBQUssT0FBTztBQUVwQyxZQUFJLENBQUMsT0FBTyxRQUFRO0FBQ2xCLGlCQUFPLEtBQUssUUFBUSxNQUFNO0FBQUEsUUFDNUIsT0FBTztBQUNMLGlCQUFPLE1BQU0sS0FBSyxNQUFNO0FBQUEsUUFDMUI7QUFBQSxNQUNGLENBQUM7QUFFRCxhQUFPLFFBQVEsV0FBVztBQUN4QixlQUFPLFNBQVM7QUFBQSxNQUNsQjtBQUVBLGFBQU8sU0FBUyxXQUFXO0FBQ3pCLGVBQU8sU0FBUztBQUNoQixlQUFPLE9BQU8sTUFBTSxVQUFVLE9BQU8sS0FBSyxRQUFRLE9BQU8sTUFBTSxNQUFNLENBQUMsR0FBRztBQUFBLFFBQUM7QUFBQSxNQUM1RTtBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxrQkFBa0IsUUFBUTtBQUNqQyxlQUFTLFVBQVUsSUFBSUMsUUFBTztBQUM5QixVQUFJLFNBQVMsSUFBSSxPQUFPO0FBQ3hCLGFBQU8sV0FBVztBQUNsQixhQUFPLFNBQVM7QUFDaEIsYUFBTyxRQUFRLENBQUM7QUFFaEIsYUFBTyxRQUFRLFNBQVMsR0FBRztBQUV6QixZQUFJLE9BQU8sU0FBUyxDQUFDLEdBQUc7QUFDdEIsY0FBSSxNQUFNLFVBQVUsTUFBTSxLQUFLLEdBQUcsQ0FBQztBQUFBLFFBQ3JDO0FBRUEsZUFBTyxZQUFZLENBQUM7QUFFcEIsZUFBTyxDQUFDLEtBQUs7QUFBQSxNQUNmO0FBRUEsYUFBTyxNQUFNLFNBQVMsS0FBSztBQUN6QixlQUFPLE9BQU8sTUFBTSxHQUFHO0FBQ3ZCLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBRUEsYUFBTyxVQUFVLFdBQVc7QUFDMUIsZUFBTyxXQUFXO0FBQUEsTUFDcEI7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU8sVUFBVTtBQUFBLE1BQ2YsT0FBQUQ7QUFBQSxNQUNBLFFBQUFDO0FBQUEsTUFFQTtBQUFBLE1BQ0E7QUFBQSxNQUVBLFdBQVc7QUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRjtBQUFBO0FBQUEsTUFHQSxPQUFPRDtBQUFBLE1BQ1AsUUFBUUM7QUFBQSxJQUNWO0FBQUE7QUFBQTs7O0FDL0tBLElBQU0scUJBQWtDLENBQUMsUUFBUSxPQUFPLFlBQVc7QUFFbEUsVUFBUSxJQUFJLElBQUksTUFBTSxZQUFXLENBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSxNQUFNLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFDakY7QUFFQSxTQUFTLFVBQVUsUUFBNEIsT0FBaUIsU0FBZTtBQUM5RSxRQUFNLE9BQU8sT0FBTyxPQUFPLHFCQUFxQixhQUFhLE9BQU8sbUJBQW1CO0FBQ3ZGLE9BQUssUUFBUSxPQUFPLE9BQU87QUFDNUI7QUFPTSxTQUFVLG1CQUFtQixRQUFlO0FBQ2pELFNBQU87SUFDTixPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTztJQUM5RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxNQUFNLENBQUMsWUFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTztJQUM1RCxPQUFPLENBQUMsWUFBb0IsVUFBVSxRQUFRLFNBQVMsT0FBTzs7QUFFaEU7OztBQ1RNLFNBQVUsWUFBWSxNQUFXO0FBRXZDO0FBeUJNLFNBQVUsV0FBVyxHQUFXLEdBQVcsR0FBVyxHQUFVO0FBQ3JFLE1BQUksZUFBd0IsSUFBSSxRQUFTLE1BQVEsSUFBSSxRQUFTLElBQU0sSUFBSTtBQUN4RSxNQUFJLEtBQUssS0FBSyxLQUFLLElBQUksR0FBRztBQUN6QixtQkFBZSxXQUFZLEtBQUssTUFBTSxPQUFPLElBQUksRUFBRTtFQUNwRDtBQUNBLFNBQU87QUFDUjs7O0FDL0RBLFNBQVMsb0JBQW9CO0FBMkV2QixJQUFPLHNCQUFQLGNBQW1DLGFBQW1DO0VBQ2xFO0VBQ0E7RUFFVCxJQUFXLFdBQVE7QUFDbEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFDQSxJQUFXLGFBQVU7QUFDcEIsV0FBTyxLQUFLLFlBQVk7RUFDekI7RUFFQSxJQUFZLGFBQVU7QUFDckIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtBQUNuRCxhQUFPLEtBQUs7SUFDYixPQUFPO0FBQ04sYUFBTztJQUNSO0VBQ0Q7RUFFQSxTQUF1RTtFQUV2RSxZQUFZLFNBQXlDLFNBQStCO0FBQ25GLFVBQUs7QUFFTCxTQUFLLFdBQVc7QUFDaEIsU0FBSyxXQUFXLEVBQUUsR0FBRyxRQUFPO0VBQzdCO0VBRUEsS0FBSyxNQUFjLFVBQW1CLFVBQXFCO0FBQzFELFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBQzdGLFlBQVEsS0FBSyxRQUFRO01BQ3BCLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxvQ0FBb0M7TUFDckQsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLHlCQUF5QjtNQUMxQyxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sbUJBQW1CO01BQ3BDLEtBQUs7QUFDSjtNQUNEO0FBQ0Msb0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGNBQU0sSUFBSSxNQUFNLHNCQUFzQjtJQUN4QztBQUVBLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsYUFBYSxRQUFRO0FBRTNDLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsUUFBUSxLQUFLLFNBQVM7TUFDdEIsWUFBWTs7S0FFWixFQUNBLEtBQ0EsQ0FBQyxhQUFZO0FBQ1osV0FBSyxTQUFTLEVBQUUsWUFBWSxNQUFNLFNBQVE7QUFDMUMsV0FBSyxTQUFTLHdCQUF3QixJQUFJLFVBQVUsSUFBSTtBQUN4RCxXQUFLLEtBQUssV0FBVztJQUN0QixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUztBQUNkLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEsTUFBTSxVQUFxQjtBQUMxQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0lBRXBELE9BQU87QUFDTixjQUFRLEtBQUssUUFBUTtRQUNwQixLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9DQUFvQztRQUNyRCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0JBQW9CO1FBQ3JDO0FBQ0Msc0JBQVksS0FBSyxNQUFNO0FBQ3ZCLGdCQUFNLElBQUksTUFBTSxzQkFBc0I7TUFDeEM7SUFDRDtBQUVBLFVBQU0sV0FBVyxLQUFLLE9BQU87QUFDN0IsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxTQUFTLFFBQVE7QUFFdkMsU0FBSyxTQUNILHFCQUFxQjtNQUNyQjtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLE9BQU87SUFDbEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQVdBLEtBQ0MsY0FDQSxjQUNBLGlCQUNBLGdCQUNBLFNBQ0EsVUFBcUI7QUFFckIsUUFBSSxPQUFPLGlCQUFpQjtBQUFVLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUN6RSxRQUFJLE9BQU8sb0JBQW9CLFVBQVU7QUFDeEMsVUFBSSxPQUFPLG1CQUFtQixZQUFZLE9BQU8sWUFBWTtBQUFVLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUMxRyxVQUFJLGFBQWEsVUFBYSxPQUFPLGFBQWE7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFakcsWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLGNBQWMsZUFBZTtBQUM5RSxXQUFLLFdBQVcsUUFBUSxnQkFBZ0IsU0FBUyxRQUFRO0lBQzFELFdBQVcsT0FBTyxvQkFBb0IsVUFBVTtBQUMvQyxVQUFJLG1CQUFtQixVQUFhLE9BQU8sbUJBQW1CO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRTdHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxHQUFHLE1BQVM7QUFDN0QsV0FBSyxXQUFXLFFBQVEsY0FBYyxpQkFBaUIsY0FBYztJQUN0RSxPQUFPO0FBQ04sWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0lBQ3BDO0VBQ0Q7RUFFQSxlQUNDLGNBQ0EsUUFDQSxRQUEwQjtBQUUxQixRQUFJO0FBQ0osUUFBSSxPQUFPLGlCQUFpQixVQUFVO0FBQ3JDLGVBQVMsT0FBTyxLQUFLLGNBQWMsT0FBTztJQUMzQyxXQUFXLE9BQU8sU0FBUyxZQUFZLEdBQUc7QUFDekMsZUFBUztJQUNWLFdBQVcsTUFBTSxRQUFRLFlBQVksR0FBRztBQUV2QyxhQUFPLE9BQU8sS0FBSyxZQUFZO0lBQ2hDLE9BQU87QUFDTixlQUFTLE9BQU8sS0FBSyxhQUFhLFFBQVEsYUFBYSxZQUFZLGFBQWEsVUFBVTtJQUMzRjtBQUVBLFdBQU8sT0FBTyxTQUFTLFFBQVEsV0FBVyxTQUFZLFNBQVMsU0FBUyxNQUFTO0VBQ2xGO0VBRUEsV0FBVyxRQUFnQixNQUFjLFNBQWlCLFVBQXFCO0FBQzlFLFFBQUksQ0FBQyxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFFekYsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixVQUFVLEtBQUssT0FBTztNQUN0QixTQUFTO01BRVQ7TUFDQTtLQUNBLEVBQ0EsS0FDQSxNQUFLO0FBQ0osaUJBQVU7SUFDWCxHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBRUEscUJBQXFCLFNBQStCO0FBQ25ELFFBQUk7QUFDSCxXQUFLLEtBQUssV0FBVyxRQUFRLFNBQVMsUUFBUSxNQUFNO0lBQ3JELFNBQVMsSUFBSTtJQUViO0VBQ0Q7RUFDQSxtQkFBbUIsT0FBWTtBQUM5QixTQUFLLFNBQVM7QUFFZCxVQUFNLGFBQWEsS0FBSztBQUN4QixRQUFJO0FBQVksV0FBSyxTQUFTLHdCQUF3QixPQUFPLFdBQVcsUUFBUTtBQUVoRixRQUFJO0FBQ0gsV0FBSyxLQUFLLFNBQVMsS0FBSztJQUN6QixTQUFTLElBQUk7SUFFYjtFQUNEOzs7O0FDOVBLLFNBQVUsa0JBQW1ELEtBQVk7QUFDOUUsUUFBTSxPQUFPO0FBQ2IsU0FBTyxDQUFDLENBQUMsUUFBUSxPQUFPLFNBQVMsWUFBWSxPQUFPLEtBQUssT0FBTyxZQUFZLEtBQUssdUJBQXVCO0FBQ3pHOzs7QUM2Qk0sSUFBZ0IsZUFBaEIsTUFBNEI7RUFDeEI7RUFDQTtFQUVBO0VBRVQsSUFBVyxLQUFFO0FBQ1osV0FBTyxLQUFLLFNBQVM7RUFDdEI7RUFFQSxJQUFXLGtCQUFlO0FBQ3pCLFdBQU8sS0FBSztFQUNiOzs7OztFQU1BLElBQVcsUUFBSztBQUNmLFdBQU8sS0FBSyxTQUFTO0VBQ3RCOzs7O0VBS0EsWUFBWSxVQUFpQjtBQUM1QixRQUFJLENBQUMsa0JBQTZCLFFBQVEsS0FBSyxDQUFDLFNBQVM7QUFDeEQsWUFBTSxJQUFJLE1BQ1QsbUdBQW1HO0FBR3JHLFNBQUssV0FBVztBQUVoQixTQUFLLFVBQVUsbUJBQWtCO0FBRWpDLFNBQUssd0JBQXdCLEtBQUssc0JBQXNCLEtBQUssSUFBSTtBQUVqRSxTQUFLLFdBQVc7TUFDZiwyQkFBMkI7TUFDM0Isd0JBQXdCOztBQUd6QixTQUFLLElBQUksU0FBUyxjQUFjO0VBQ2pDO0VBK0JBLFdBQVcsV0FBNEMsWUFBaUM7QUFDdkYsU0FBSyxTQUFTLFdBQVcsV0FBVyxVQUFVO0VBQy9DOzs7OztFQXVCQSxxQkFBcUIsU0FBeUQ7QUFDN0UsU0FBSyxTQUFTLHFCQUFxQixPQUFPO0VBQzNDOzs7OztFQU1BLHVCQUF1QixXQUErRDtBQUNyRixTQUFLLFNBQVMsdUJBQXVCLFNBQVM7RUFDL0M7Ozs7OztFQU9BLHFCQUNDLFdBQ0EsU0FBOEM7QUFFOUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXLE9BQU87RUFDdEQ7Ozs7O0VBTUEsdUJBQXVCQyxZQUErRDtBQUNyRixRQUFJLE1BQU0sUUFBUUEsVUFBUztBQUFHLFlBQU0sSUFBSSxNQUFNLHdEQUF3RDtBQUV0RyxTQUFLLFNBQVMsdUJBQXVCQSxVQUFTO0VBQy9DOzs7OztFQU1BLGtCQUFrQixRQUF1QztBQUN4RCxTQUFLLFNBQVMsa0JBQWtCLE1BQU07RUFDdkM7Ozs7OztFQU9BLGlCQUFtQyxZQUFhO0FBQy9DLFdBQU8sS0FBSyxTQUFTLGlCQUFpQixVQUFVO0VBQ2pEOzs7O0VBS0Esb0JBQWlCO0FBQ2hCLFNBQUssU0FBUyxrQkFBaUI7RUFDaEM7Ozs7Ozs7RUFRQSxlQUNDLGlCQUNHLGVBQW1EO0FBRXRELFNBQUssU0FBUyxlQUFlLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQztFQUM5RDs7Ozs7RUFNQSxzQkFBc0IsYUFBcUI7QUFDMUMsU0FBSyxTQUFTLG1CQUFtQixXQUFXO0VBQzdDOzs7Ozs7RUFPQSxvQkFBb0IsV0FBbUI7QUFDdEMsU0FBSyxTQUFTLGlCQUFpQixTQUFTO0VBQ3pDOzs7Ozs7RUFNQSxzQkFBc0IsV0FBbUI7QUFDeEMsU0FBSyxTQUFTLG1CQUFtQixTQUFTO0VBQzNDOzs7Ozs7RUFPQSx3QkFBd0IsYUFBcUI7QUFDNUMsU0FBSyxTQUFTLHFCQUFxQixXQUFXO0VBQy9DOzs7Ozs7RUFPQSxhQUFhLFFBQWlDLGNBQXFCO0FBQ2xFLFNBQUssU0FBUyxhQUFhLFFBQVEsWUFBWTtFQUNoRDs7Ozs7Ozs7RUFTQSxRQUFRLE1BQWMsTUFBYyxNQUFjLE1BQXNCO0FBQ3ZFLFNBQUssU0FBUyxRQUFRLE1BQU0sTUFBTSxNQUFNLElBQUk7RUFDN0M7Ozs7Ozs7Ozs7O0VBWUEsYUFBYSxRQUF3QixTQUF1QjtBQUMzRCxTQUFLLFNBQVMsYUFBYSxRQUFRLFdBQVcsSUFBSTtFQUNuRDs7Ozs7O0VBT0EsSUFBSSxPQUFpQixTQUFlO0FBQ25DLFlBQVEsT0FBTztNQUNkLEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsTUFBTSxPQUFPO0FBQzFCO01BQ0Q7QUFDQyxvQkFBWSxLQUFLO0FBQ2pCLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7SUFDRjtFQUNEO0VBWUEsc0JBQ0MsZUFDQSxVQUF5QztBQUV6QyxVQUFNLFVBQWtDLE9BQU8sa0JBQWtCLFdBQVcsRUFBRSxNQUFNLGNBQWEsSUFBSztBQUV0RyxVQUFNLFNBQVMsSUFBSSxvQkFBb0IsS0FBSyxVQUFVLE9BQU87QUFDN0QsUUFBSTtBQUFVLGFBQU8sR0FBRyxXQUFXLFFBQVE7QUFFM0MsV0FBTztFQUNSOzs7O0FDL1VELElBQVk7Q0FBWixTQUFZQyxpQkFBYztBQUN6QixFQUFBQSxnQkFBQSxJQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxZQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxtQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsV0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsZ0JBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHVCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx5QkFBQSxJQUFBO0FBQ0QsR0FWWSxtQkFBQSxpQkFBYyxDQUFBLEVBQUE7QUFhcEIsSUFBVztDQUFqQixTQUFpQkMsUUFBSztBQUVSLEVBQUFBLE9BQUEsS0FBSztBQUNMLEVBQUFBLE9BQUEsV0FDWjtBQUNZLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsT0FDWjtBQUNZLEVBQUFBLE9BQUEsY0FBYztBQUNkLEVBQUFBLE9BQUEsVUFBVTtBQUNWLEVBQUFBLE9BQUEsUUFBUTtBQUNSLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsZUFBZTtBQUNmLEVBQUFBLE9BQUEsU0FBUztBQUNULEVBQUFBLE9BQUEsZ0JBQWdCO0FBQ2hCLEVBQUFBLE9BQUEsWUFBWTtBQUNaLEVBQUFBLE9BQUEsV0FDWjtBQUNGLEdBbEJpQixVQUFBLFFBQUssQ0FBQSxFQUFBOzs7QUNqQnRCLGdCQUEyQjtBQUMzQixTQUFTLGdCQUFBQyxxQkFBb0I7OztBQ0Q3QixJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFhO0FBRW5CLElBQU0sb0JBQW9CLG9CQUFJLElBQW9CO0VBQ2pELENBQUMsV0FBVyxHQUFJO0VBQ2hCLENBQUMsVUFBVSxHQUFJO0VBQ2YsQ0FBQyxjQUFjLEdBQUk7RUFDbkIsQ0FBQyxNQUFNLEdBQUk7RUFDWCxDQUFDLFdBQVcsR0FBSTtFQUNoQixDQUFDLG1CQUFtQixHQUFJO0VBQ3hCLENBQUMsU0FBUyxHQUFJO0VBQ2QsQ0FBQyxTQUFTLEdBQUk7RUFDZCxDQUFDLE9BQU8sR0FBSTtFQUNaLENBQUMsWUFBWSxHQUFJO0VBQ2pCLENBQUMsVUFBVSxHQUFJO0VBQ2YsQ0FBQyxRQUFRLEdBQUk7RUFDYixDQUFDLGFBQWEsR0FBSTtFQUNsQixDQUFDLFNBQVMsR0FBSTtFQUNkLENBQUMsU0FBUyxHQUFJO0VBQ2QsQ0FBQyxZQUFZLEdBQUk7RUFDakIsQ0FBQyxRQUFRLEdBQUk7RUFDYixDQUFDLGVBQWUsR0FBSTtFQUNwQixDQUFDLFNBQVMsR0FBSTtDQUNkO0FBRUQsSUFBTSxNQUFNLENBQUMsUUFBZ0IsR0FBRyxHQUFHLE9BQU8sSUFBSSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDO0FBaUJyRSxJQUFPLGNBQVAsTUFBTyxhQUFXO0VBQ3ZCLEtBQUs7RUFDTDtFQUNBLE9BQU8sUUFBa0I7SUFDeEIsT0FBTyxDQUFBO0lBQ1AsUUFBUTtJQUNSLFNBQVM7SUFDVCxNQUFNO0lBQ04sTUFBTTtJQUNOLFVBQVU7SUFDVixZQUFZO0lBQ1osVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsTUFBTTs7RUFHUCxZQUFZLFFBQWtCLENBQUEsR0FBRTtBQUMvQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksU0FBTTtBQUNULFdBQU8sS0FBSyxNQUFNLENBQUMsSUFBSSxNQUFPLEtBQUssTUFBTSxDQUFDLElBQUksS0FBSyxNQUFNLENBQUMsSUFBSTtFQUMvRDtFQUNBLElBQUksT0FBTyxHQUFTO0FBQ25CLFNBQUssTUFBTSxDQUFDLElBQUksSUFBSSxNQUFPLElBQUssS0FBSyxNQUFNLENBQUMsSUFBSSxLQUFTLElBQUk7RUFDOUQ7RUFFQSxJQUFJLFVBQU87QUFDVixZQUFRLEtBQUssTUFBTSxDQUFDLElBQUksTUFBUTtFQUNqQztFQUNBLElBQUksUUFBUSxHQUFTO0FBQ3BCO0FBQ0EsUUFBSSxhQUFZLFVBQVUsR0FBRyxFQUFFO0FBQy9CLFNBQUssTUFBTSxDQUFDLElBQUssS0FBSyxNQUFNLENBQUMsSUFBSSxNQUFTLElBQUk7RUFDL0M7RUFFQSxJQUFjLFFBQUs7QUFDbEIsV0FBTyxLQUFLLE1BQU0sQ0FBQyxJQUFJO0VBQ3hCO0VBQ0EsSUFBYyxNQUFNLEdBQVM7QUFDNUIsU0FBSyxNQUFNLENBQUMsSUFBSSxhQUFZLFVBQVUsR0FBRyxTQUFTO0VBQ25EO0VBRUEsSUFBYyxRQUFLO0FBQ2xCLFdBQU8sS0FBSyxNQUFNLENBQUMsSUFBSTtFQUN4QjtFQUNBLElBQWMsTUFBTSxHQUFTO0FBQzVCLFNBQUssTUFBTSxDQUFDLElBQUksYUFBWSxVQUFVLEdBQUcsU0FBUztFQUNuRDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxPQUFPLEtBQUssTUFBSztFQUMzQjtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsS0FBSyxFQUFFO0VBQ2xCO0VBRUEsT0FBTyxVQUFVLEtBQWEsS0FBVztBQUN4QyxXQUFPLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxJQUFJO0VBQ3hDO0VBRUEsT0FBTyxhQUFhLFFBQWtCLENBQUEsR0FBSSxNQUFnQixLQUFLLE9BQUs7QUFDbkUsUUFBSSxXQUFXLElBQUksYUFBWSxLQUFLO0FBQ3BDLFFBQUksU0FBUyxNQUFNLFNBQVMsSUFBSSxTQUFTLFNBQVMsSUFBSSxVQUFVO0FBQ2hFLFFBQUksV0FBVyxLQUFLLE9BQU8sSUFBSSxPQUFPO0FBQWEsZUFBUyxrQkFBa0IsSUFBSSxJQUFJLEVBQUUsS0FBSztBQUU3RixZQUFRLFFBQVE7TUFDZixLQUFLO0FBQ0osbUJBQVcsSUFBSSxRQUFRLElBQUksU0FBVSxJQUFJLE1BQU8sSUFBSSxRQUFTO0FBQzdEO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksT0FBTyxJQUFJLFNBQVUsSUFBSSxNQUFPLElBQUksUUFBUztBQUM1RDtNQUNELEtBQUs7QUFDSixtQkFBVyxJQUFJLFdBQVcsSUFBSSxTQUFVLElBQUksTUFBTyxJQUFJLFFBQVM7QUFDaEU7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxjQUFjLElBQUksU0FBVSxJQUFJLFlBQWEsSUFBSSxLQUFNO0FBQ3RFO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksY0FBYyxJQUFJLFNBQVUsSUFBSSxPQUFRO0FBQ3ZEO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksZ0JBQWdCLElBQUksU0FBVSxJQUFJLFFBQVM7QUFDMUQ7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxXQUFXLElBQUksU0FBVSxJQUFJLEtBQU07QUFDbEQ7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxNQUFNLElBQUksS0FBTTtBQUMvQjtNQUNELEtBQUs7QUFDSixtQkFBVyxJQUFJLElBQUksSUFBSSxNQUFPLElBQUksS0FBTTtBQUN4QztNQUNELEtBQUs7QUFDSjs7TUFDRDtBQUNDLGdCQUFRLElBQUksc0NBQXNDLElBQUksTUFBTSxDQUFDLEVBQUU7QUFDL0Q7SUFDRjtBQUVBLFFBQUksTUFBTSxTQUFTO0FBQUcsZUFBUyxRQUFRO0FBQ3ZDLFdBQU87RUFDUjs7QUFHRCxJQUFNLFVBQU4sY0FBc0IsWUFBVztFQUNoQyxZQUFZLEdBQVcsR0FBVyxHQUFTO0FBQzFDLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLE9BQU87QUFDWixTQUFLLFdBQVc7RUFDakI7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEtBQUs7RUFDYjtFQUNBLElBQUksS0FBSyxHQUFTO0FBQ2pCLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxXQUFRO0FBQ1gsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLFNBQVMsR0FBUztBQUNyQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxTQUFTLEtBQUssU0FBUyxNQUFNLEtBQUssTUFBTSxVQUFVLEtBQUssU0FBUTtFQUN6RTtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsY0FBYyxJQUFJLEtBQUssT0FBTyxDQUFDLFdBQVcsSUFBSSxLQUFLLElBQUksQ0FBQyxlQUFlLElBQ2hHLEtBQUssUUFBUSxDQUNiO0VBQ0Y7O0FBR0QsSUFBTSxTQUFOLGNBQXFCLFFBQU87RUFDM0IsWUFBWSxHQUFXLEdBQVcsR0FBUztBQUMxQyxVQUFNLEdBQUcsR0FBRyxDQUFDO0FBQ2IsU0FBSyxLQUFLO0FBQ1YsU0FBSyxTQUFTO0VBQ2Y7O0FBR0QsSUFBTSxhQUFOLGNBQXlCLFlBQVc7RUFDbkMsWUFBWSxHQUFXLEdBQVcsR0FBUztBQUMxQyxVQUFLO0FBQ0wsU0FBSyxLQUFLO0FBQ1YsU0FBSyxTQUFTO0FBQ2QsU0FBSyxVQUFVO0FBQ2YsU0FBSyxPQUFPO0FBQ1osU0FBSyxXQUFXO0VBQ2pCO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLEtBQUssR0FBUztBQUNqQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksV0FBUTtBQUNYLFdBQU8sS0FBSztFQUNiO0VBQ0EsSUFBSSxTQUFTLEdBQVM7QUFDckIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsTUFBTSxLQUFLLE1BQU0sVUFBVSxLQUFLLFNBQVE7RUFDekU7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxXQUFXLElBQUksS0FBSyxJQUFJLENBQUMsZUFBZSxJQUNoRyxLQUFLLFFBQVEsQ0FDYjtFQUNGOztBQUdELElBQU0sZ0JBQU4sY0FBNEIsWUFBVztFQUN0QyxZQUFZLEdBQVcsSUFBWSxHQUFTO0FBQzNDLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLGFBQWE7QUFDbEIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLGFBQVU7QUFDYixXQUFPLEtBQUs7RUFDYjtFQUNBLElBQUksV0FBVyxHQUFTO0FBQ3ZCLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxRQUFLO0FBQ1IsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLE1BQU0sR0FBUztBQUNsQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxTQUFTLEtBQUssU0FBUyxZQUFZLEtBQUssWUFBWSxPQUFPLEtBQUssTUFBSztFQUMvRTtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsY0FBYyxJQUFJLEtBQUssT0FBTyxDQUFDLGlCQUFpQixJQUFJLEtBQUssVUFBVSxDQUFDLFlBQVksSUFDekcsS0FBSyxLQUFLLENBQ1Y7RUFDRjs7QUFHRCxJQUFNLGdCQUFOLGNBQTRCLFlBQVc7RUFDdEMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssVUFBVTtFQUNoQjtFQUVBLElBQUksVUFBTztBQUNWLFdBQU8sS0FBSyxRQUFRO0VBQ3JCO0VBQ0EsSUFBSSxRQUFRLEdBQVM7QUFDcEI7QUFDQSxTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxTQUFTLEtBQUssU0FBUyxTQUFTLEtBQUssUUFBTztFQUN0RDtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsY0FBYyxJQUFJLEtBQUssT0FBTyxDQUFDLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQztFQUN6Rjs7QUFHRCxJQUFNLGtCQUFOLGNBQThCLFlBQVc7RUFDeEMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssV0FBVztFQUNqQjtFQUVBLElBQUksV0FBUTtBQUNYLFdBQU8sS0FBSztFQUNiO0VBQ0EsSUFBSSxTQUFTLEdBQVM7QUFDckIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsVUFBVSxLQUFLLFNBQVE7RUFDeEQ7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxlQUFlLElBQUksS0FBSyxRQUFRLENBQUM7RUFDM0Y7O0FBR0QsSUFBTSxhQUFOLGNBQXlCLFlBQVc7RUFDbkMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxRQUFLO0FBQ1IsWUFBUSxLQUFLLFNBQVMsS0FBSyxLQUFLO0VBQ2pDO0VBQ0EsSUFBSSxNQUFNLEdBQVM7QUFDbEIsUUFBSSxZQUFZLFVBQVUsR0FBRyxVQUFVO0FBQ3ZDLFNBQUssUUFBUyxLQUFLLElBQUs7QUFDeEIsU0FBSyxRQUFRLElBQUk7RUFDbEI7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsT0FBTyxLQUFLLE1BQUs7RUFDbEQ7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxZQUFZLElBQUksS0FBSyxLQUFLLENBQUM7RUFDckY7O0FBR0QsSUFBTSxRQUFOLGNBQW9CLFlBQVc7RUFDOUIsWUFBWSxHQUFXO0FBQ3RCLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxPQUFPLEtBQUssTUFBSztFQUMzQjtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsWUFBWSxLQUFLLEtBQUs7RUFDakQ7O0FBR0ssSUFBTyxNQUFQLGNBQW1CLFlBQVc7RUFDbkMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssT0FBTztBQUNaLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBUSxLQUFLLFNBQVMsSUFBSztFQUM1QjtFQUNBLElBQUksS0FBSyxHQUFTO0FBQ2pCLFNBQUssUUFBUyxLQUFLLFFBQVEsS0FBUyxLQUFLO0VBQzFDO0VBRUEsSUFBSSxRQUFLO0FBQ1IsV0FBTyxLQUFLLFFBQVE7RUFDckI7RUFDQSxJQUFJLE1BQU0sR0FBUztBQUNsQixRQUFJLFlBQVksVUFBVSxHQUFHLEVBQUU7QUFDL0IsU0FBSyxRQUFTLEtBQUssUUFBUSxNQUFRO0VBQ3BDO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLE1BQU0sS0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFLO0VBQ25FO0VBRUEsV0FBUTtBQUNQLFdBQU8sR0FBRyxNQUFNLFNBQVEsQ0FBRSxXQUFXLElBQUksS0FBSyxJQUFJLENBQUMsWUFBWSxJQUFJLEtBQUssS0FBSyxDQUFDO0VBQy9FOzs7O0FEL1hLLElBQU9DLFNBQVAsY0FBcUJDLGNBQVk7RUFDOUI7RUFDQTtFQUNBO0VBQ0E7RUFDRDtFQUVQLFlBQVksTUFBYyxTQUFpQjtBQUMxQyxVQUFLO0FBQ0wsU0FBSyxTQUFTLElBQWMsZ0JBQUs7QUFDakMsU0FBSyxPQUFPLFlBQVksT0FBTyxPQUFPLEtBQUs7QUFDM0MsU0FBSyxnQkFBZ0I7QUFDckIsU0FBSyxTQUFTLENBQUE7QUFDZCxTQUFLLFNBQVMsQ0FBQTtBQUNkLFNBQUssT0FBTztBQUNaLFVBQU0seUJBQW1DLFVBQVM7QUFFbEQsUUFBSSxTQUFTO0FBQ1osV0FBSyxPQUFPLGdCQUFnQixJQUFJO0lBQ2pDLE9BQU87QUFDTixZQUFNLFlBQVksS0FBSyxPQUFPLGFBQVk7QUFDMUMsZUFBUyxJQUFJLEdBQUcsSUFBSSxXQUFXLEtBQUs7QUFDbkMsWUFBSSxTQUFTLHVCQUF1QixDQUFDLEdBQUc7QUFDdkMsY0FBSTtBQUNILGlCQUFLLE9BQU8sU0FBUyxDQUFDO1VBQ3ZCLFNBQVMsS0FBSztBQUNiLG9CQUFRLElBQUksc0JBQXNCLElBQUk7U0FBYSxHQUFHLEVBQUU7VUFDekQ7UUFDRDtNQUNEO0lBQ0Q7QUFFQSxTQUFLLE9BQU8sR0FBRyxXQUFXLENBQUMsV0FBbUIsVUFBeUI7QUFHdEUsWUFBTSxNQUFNLFlBQVksYUFBYSxLQUFLO0FBQzFDLFVBQUksUUFBUTtBQUFXO0FBQ3ZCLFdBQUssS0FBSyxXQUFXLFdBQVcsR0FBRztBQUNuQyxVQUFJLElBQUksTUFBTSxPQUFPO0FBQ3BCLGFBQUssU0FBUyxHQUFVO01BQ3pCO0lBQ0QsQ0FBQztFQUNGO0VBRUEsUUFBSztBQUNKLFNBQUssT0FBTyxVQUFTO0FBQ3JCLFNBQUssT0FBTyxRQUFPO0VBQ3BCO0VBRUEsYUFBVTtBQUNULFdBQU8sS0FBSyxPQUFPLFdBQVU7RUFDOUI7RUFFQSxTQUFTLE1BQVM7QUFDakIsVUFBTSxjQUFjLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRTtBQUN0QyxVQUFNLGFBQXFCLEtBQUs7QUFDaEMsUUFBSSxRQUFnQixLQUFLO0FBQ3pCLFFBQUk7QUFFSixTQUFLLE9BQU8sVUFBVSxJQUFJO0FBRzFCLFFBQUksZUFBZSxLQUFLLE9BQU8sS0FBSyxPQUFPLENBQUMsTUFBTSxVQUFVO0FBQzNELFlBQU0sT0FBaUIsQ0FBQTtBQUN2QixlQUFTLElBQUksR0FBRyxLQUFLLEdBQUcsS0FBSztBQUM1QixjQUFNLE1BQU0sUUFBUyxLQUFLLElBQUssSUFBSTtBQUNuQyxhQUFLLEtBQUssR0FBRztNQUNkO0FBQ0EsY0FBUSxLQUFLLENBQUM7QUFDZCx1QkFBaUIsYUFBYSxLQUFLLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQ3JELFdBQUssT0FBTyxVQUFVLElBQUk7QUFFMUIsWUFBTSxRQUFRLEtBQUs7QUFDbkIsWUFBTSxtQkFDSCxNQUFNLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxHQUFHLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRyxJQUN2RCxRQUNFLE1BQU0sQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDLEdBQUcsU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHLElBQ3ZELFFBQ0UsTUFBTSxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsR0FBRyxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUcsSUFDdkQsUUFDRSxNQUFNLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxHQUFHLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRztBQUN4RCxXQUFLLEtBQUssU0FBUztRQUNsQixPQUFPO1FBQ1AsU0FBUztPQUNUO0lBQ0Y7RUFDRDs7QUFHSyxJQUFPQyxVQUFQLE1BQWE7RUFDVjtFQUNEO0VBRVAsWUFBWSxNQUFjLFNBQWlCO0FBQzFDLFNBQUssVUFBVSxJQUFjLGlCQUFNO0FBQ25DLFNBQUssT0FBTztBQUNaLFVBQU0sMEJBQW9DLFdBQVU7QUFFcEQsUUFBSSxTQUFTO0FBQ1osV0FBSyxRQUFRLGdCQUFnQixJQUFJO0lBQ2xDLE9BQU87QUFDTixZQUFNLGFBQWEsS0FBSyxRQUFRLGFBQVk7QUFDNUMsZUFBUyxJQUFJLEdBQUcsSUFBSSxZQUFZLEtBQUs7QUFDcEMsWUFBSSxTQUFTLHdCQUF3QixDQUFDLEdBQUc7QUFDeEMsY0FBSTtBQUNILGlCQUFLLFFBQVEsU0FBUyxDQUFDO1VBQ3hCLFNBQVMsS0FBSztBQUNiLG9CQUFRLElBQUksc0JBQXNCLElBQUk7U0FBYSxHQUFHLEVBQUU7VUFDekQ7UUFDRDtNQUNEO0lBQ0Q7RUFDRDtFQUVBLFFBQUs7QUFDSixTQUFLLFFBQVEsVUFBUztBQUN0QixTQUFLLFFBQVEsUUFBTztFQUNyQjtFQUVBLGFBQVU7QUFDVCxXQUFPLEtBQUssUUFBUSxXQUFVO0VBQy9CO0VBRUEsS0FBSyxLQUFnQjtBQUNwQixTQUFLLFFBQVEsWUFBWSxJQUFJLEtBQUs7RUFDbkM7O0FBSUssU0FBVSxZQUFTO0FBQ3hCLFFBQU0sUUFBUSxJQUFjLGdCQUFLO0FBQ2pDLFFBQU0sU0FBbUIsQ0FBQTtBQUN6QixXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sYUFBWSxHQUFJLEtBQUs7QUFDOUMsUUFBSSxVQUFVO0FBQ2QsVUFBTSxXQUFXLE1BQU0sWUFBWSxDQUFDO0FBQ3BDLFFBQUksbUJBQW1CO0FBQ3ZCLFdBQU8sT0FBTyxTQUFTLGdCQUFnQixHQUFHO0FBQ3pDO0FBQ0EsMEJBQW9CLElBQUksT0FBTztJQUNoQztBQUNBLFdBQU8sS0FBSyxnQkFBZ0I7RUFDN0I7QUFDQSxRQUFNLFVBQVM7QUFDZixTQUFPO0FBQ1I7QUFFTSxTQUFVLGFBQVU7QUFDekIsUUFBTSxTQUFTLElBQWMsaUJBQU07QUFDbkMsUUFBTSxVQUFvQixDQUFBO0FBQzFCLFdBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxhQUFZLEdBQUksS0FBSztBQUMvQyxRQUFJLFVBQVU7QUFDZCxVQUFNLFdBQVcsT0FBTyxZQUFZLENBQUM7QUFDckMsUUFBSSxtQkFBbUI7QUFDdkIsV0FBTyxRQUFRLFNBQVMsZ0JBQWdCLEdBQUc7QUFDMUM7QUFDQSwwQkFBb0IsSUFBSSxPQUFPO0lBQ2hDO0FBQ0EsWUFBUSxLQUFLLGdCQUFnQjtFQUM5QjtBQUNBLFNBQU8sVUFBUztBQUNoQixTQUFPO0FBQ1I7OztBRXZKTSxTQUFVLGtCQUFlO0FBQzlCLFFBQU0sY0FBZ0MsQ0FBQTtBQUN0QyxRQUFNLGVBQWlDLENBQUE7QUFDdkMsUUFBTSxVQUFvQixVQUFTO0FBQ25DLFFBQU0sV0FBcUIsV0FBVTtBQUNyQyxVQUFRLFFBQVEsQ0FBQyxNQUFLO0FBQ3JCLGdCQUFZLEtBQUssRUFBRSxJQUFJLEdBQUcsT0FBTyxFQUFDLENBQUU7RUFDckMsQ0FBQztBQUNELFdBQVMsUUFBUSxDQUFDLE1BQUs7QUFDdEIsaUJBQWEsS0FBSyxFQUFFLElBQUksR0FBRyxPQUFPLEVBQUMsQ0FBRTtFQUN0QyxDQUFDO0FBRUQsU0FBTztJQUNOO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsUUFBUSxDQUFDLEtBQUs7TUFDdkIsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFvQlY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUyxTQUFTLENBQUMsS0FBSztNQUN4QixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUEyQlY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTztNQUNQLFNBQVM7O0lBRVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTztNQUNQLFNBQVM7O0lBRVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUNDO01BQ0QsU0FBUztNQUNULE9BQU87OztBQUdWOzs7QUNwR0EsSUFBTSxZQUFzRDtFQUMzRCxRQUFRLEVBQUUsTUFBTSw4QkFBNkI7RUFDN0MsU0FBUyxFQUFFLE1BQU0sOEJBQTZCO0VBQzlDLGFBQWEsRUFBRSxNQUFNLHdCQUF1QjtFQUM1QyxPQUFPLEVBQUUsTUFBTSxvQkFBbUI7RUFDbEMsU0FBUyxFQUFFLE1BQU0sNEJBQTJCOztBQUc3QyxJQUFNLGFBQWdFLG9CQUFJLElBQUc7QUFFdkUsU0FBVSwwQkFBMEIsTUFBb0I7QUFDN0QsT0FBSyx1QkFBdUIsU0FBUztBQUNyQyxPQUFLLGtCQUFrQixFQUFFLFFBQVEsT0FBTyxTQUFTLE1BQUssQ0FBRTtBQUN6RDtBQUVNLFNBQVUscUJBQXFCLE1BQXNCLFVBQWdCO0FBQzFFLE1BQUksSUFBSSxXQUFXLElBQUksUUFBUSxLQUFLO0FBQ3BDLE1BQUksTUFBTTtBQUFNLGlCQUFhLENBQUM7QUFDOUIsTUFBSSxXQUFXLE1BQUs7QUFDbkIsU0FBSyxrQkFBa0IsRUFBRSxDQUFDLFFBQVEsR0FBRyxNQUFLLENBQUU7QUFDNUMsU0FBSyxlQUFlLFFBQVE7RUFDN0IsR0FBRyxHQUFHO0FBQ04sYUFBVyxJQUFJLFVBQVUsQ0FBQztBQUMxQixPQUFLLGtCQUFrQixFQUFFLENBQUMsUUFBUSxHQUFHLEtBQUksQ0FBRTtBQUMzQyxPQUFLLGVBQWUsUUFBUTtBQUM3QjtBQUVNLFNBQVUsY0FBYyxNQUFzQixLQUFrQixNQUF3QjtBQUM3RixRQUFNLFVBQVUsY0FBYyxHQUFHO0FBQ2pDLFFBQU0sVUFBVSxRQUFRLE9BQU8sTUFBTTtBQUNyQyxPQUFLLGtCQUFrQixFQUFFLGFBQWEsUUFBTyxDQUFFO0FBRS9DLGlCQUFlLE1BQU0sZUFBZSw4QkFBOEIsSUFBSSxFQUFFO0FBRXhFLFdBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLLFFBQVEsS0FBSztBQUM3QyxVQUFNLFVBQVUsUUFBUSxLQUFLLENBQUM7QUFDOUIsVUFBTSxNQUFNO0FBQ1osVUFBTSxhQUFhLFFBQVEsQ0FBQyxFQUFFLFlBQVcsSUFBSyxRQUFRLE1BQU0sQ0FBQztBQUM3RCxtQkFBZSxNQUFNLFNBQVMsWUFBWSxVQUFVLGFBQWEsYUFBYSxPQUFPLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztFQUNwRztBQUNEO0FBRU0sU0FBVSxhQUFhLE1BQXNCLEtBQWtCLE1BQXdCO0FBRTVGLGlCQUFlLE1BQU0sTUFBTSxjQUFjLEdBQUcsRUFBRSxNQUFNLHlCQUF5QixJQUFJO0FBQ2xGO0FBRUEsU0FBUyxjQUFjLEtBQWdCO0FBR3RDLE1BQUksVUFBVSxJQUFJO0FBQ2xCLFFBQU0sVUFBVSxPQUFPLEtBQUssSUFBSSxJQUFJO0FBQ3BDLFdBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxTQUFTLEdBQUcsS0FBSztBQUM1QyxVQUFNLE1BQU0sUUFBUSxDQUFDO0FBQ3JCLFVBQU0sTUFBMEIsT0FBTyxJQUFJLEtBQUssR0FBRyxDQUFDO0FBQ3BELFFBQUksUUFBUSxRQUFXO0FBQ3RCLGlCQUFXLElBQUksR0FBRztJQUNuQjtFQUNEO0FBQ0EsU0FBTyxFQUFFLE1BQU0sU0FBUyxNQUFNLFFBQU87QUFDdEM7QUFFQSxTQUFTLGVBQ1IsTUFDQSxTQUNBLFVBQ0EsTUFBaUM7QUFFakMsWUFBVSxPQUFPLElBQUksRUFBRSxNQUFNLFNBQVE7QUFDckMsT0FBSyx1QkFBdUIsU0FBUztBQUNyQyxPQUFLLGtCQUFrQixFQUFFLENBQUMsT0FBTyxHQUFHLEtBQUksQ0FBRTtBQUMzQzs7O0FDM0VPLElBQU0saUJBQStEOzs7OztFQUszRSxTQUNDLFNBQ0EsT0FBMkQ7QUFFM0QsVUFBTSxVQUFpRTtNQUN0RSxlQUFlO01BQ2YsZ0JBQWdCLENBQUE7TUFDaEIsa0JBQWtCLENBQUE7O0FBR25CLFlBQVEsSUFBSSwrQkFBK0I7QUFFM0MsZUFBVyxLQUFLLE1BQU0sU0FBUztBQUM5QixVQUFJLEVBQUUsWUFBWSxXQUFXO0FBQzVCLGdCQUFRLElBQUkscUJBQXFCLENBQUM7QUFDbEMsVUFBRSxRQUFRLFVBQVUsRUFBRSxRQUFRLFVBQVUsRUFBRSxRQUFRO0FBQ2xELGVBQU8sRUFBRSxRQUFRO01BQ2xCO0FBQ0EsVUFBSSxDQUFDLEVBQUUsUUFBUTtBQUFTLFVBQUUsUUFBUSxVQUFVLEVBQUUsUUFBUTtBQUN0RCxVQUFJLENBQUMsRUFBRSxRQUFRO0FBQVcsVUFBRSxRQUFRLFlBQVksRUFBRSxRQUFRO0FBQzFELFVBQUksQ0FBQyxFQUFFLFFBQVE7QUFBUyxVQUFFLFFBQVEsVUFBVSxFQUFFLFFBQVE7QUFFdEQsY0FBUSxlQUFlLEtBQUssQ0FBQztBQUM3QixjQUFRLElBQUksUUFBUSxDQUFDO0lBQ3RCO0FBRUEsZUFBVyxLQUFLLE1BQU0sV0FBVztBQUNoQyxVQUFJLEVBQUUsY0FBYyxtQkFBbUI7QUFDdEMsZ0JBQVEsSUFBSSx1QkFBdUIsQ0FBQztBQUVwQyxVQUFFLGFBQWEsT0FBTyxFQUFFLFFBQVEsT0FBTztBQUN2QyxlQUFPLEVBQUUsUUFBUTtBQUNqQixnQkFBUSxFQUFFLFlBQVk7VUFDckIsS0FBSztBQUNKLGNBQUUsUUFBUSxVQUFVLEVBQUUsUUFBUTtBQUM5QixtQkFBTyxFQUFFLFFBQVE7QUFDakI7VUFDRCxLQUFLO0FBQ0osY0FBRSxRQUFRLFFBQVEsRUFBRSxRQUFRO0FBQzVCLG1CQUFPLEVBQUUsUUFBUTtBQUNqQjtVQUNELEtBQUs7QUFDSixjQUFFLFFBQVEsUUFBUSxFQUFFLFFBQVE7QUFDNUIsbUJBQU8sRUFBRSxRQUFRO1FBQ25CO01BQ0Q7QUFDQSxVQUFJLENBQUMsRUFBRSxRQUFRO0FBQVMsVUFBRSxRQUFRLFVBQVUsRUFBRSxRQUFRO0FBQ3RELFVBQUksQ0FBQyxFQUFFLFFBQVE7QUFBVyxVQUFFLFFBQVEsWUFBWSxFQUFFLFFBQVE7QUFDMUQsVUFBSSxDQUFDLEVBQUUsUUFBUTtBQUFTLFVBQUUsUUFBUSxVQUFVLEVBQUUsUUFBUTtBQUV0RCxjQUFRLGlCQUFpQixLQUFLLENBQUM7QUFDL0IsY0FBUSxJQUFJLFFBQVEsQ0FBQztJQUN0QjtBQUVBLFdBQU87RUFDUjtFQUVBLFNBQ0MsU0FDQSxPQUEyRDtBQUUzRCxVQUFNLFVBQWlFO01BQ3RFLGVBQWU7TUFDZixnQkFBZ0IsQ0FBQTtNQUNoQixrQkFBa0IsQ0FBQTs7QUFHbkIsWUFBUSxJQUFJLCtCQUErQjtBQUUzQyxlQUFXLEtBQUssTUFBTSxTQUFTO0FBQzlCLGNBQVEsSUFBSSx1QkFBdUIsQ0FBQztBQUVwQyxVQUFJLENBQUMsRUFBRSxRQUFRO0FBQWMsVUFBRSxRQUFRLGVBQWUsRUFBRSxjQUFjLE9BQU8sT0FBTyxNQUFLO0FBQ3pGLFVBQUksQ0FBQyxFQUFFLFFBQVE7QUFBZ0IsVUFBRSxRQUFRLGlCQUFpQixFQUFFLGNBQWMsT0FBTyxPQUFPLEVBQUM7QUFDekYsVUFBSSxDQUFDLEVBQUUsUUFBUTtBQUFNLFVBQUUsUUFBUSxPQUFPLEVBQUUsY0FBYyxPQUFPLE9BQU8sRUFBQztBQUNyRSxVQUFJLENBQUMsRUFBRSxRQUFRO0FBQU8sVUFBRSxRQUFRLFFBQVEsRUFBRSxjQUFjLE9BQU8sT0FBTyxTQUFRO0FBRTlFLGNBQVEsZUFBZSxLQUFLLENBQUM7QUFDN0IsY0FBUSxJQUFJLFVBQVUsQ0FBQztJQUN4QjtBQUVBLFdBQU87RUFDUjs7OztBQ2xGTSxJQUFNLGVBQThCO0VBQzFDO0lBQ0MsSUFBSTtJQUNKLE9BQU87SUFDUCxNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVU7SUFDVixRQUFRO0lBQ1IsUUFBUTtJQUNSLFlBQVk7O0VBRWI7SUFDQyxJQUFJO0lBQ0osT0FBTztJQUNQLE1BQU07SUFDTixPQUFPO0lBQ1AsVUFBVTtJQUNWLFFBQVE7SUFDUixRQUFRO0lBQ1IsWUFBWTs7O0VBR2I7SUFDQyxJQUFJO0lBQ0osT0FBTztJQUNQLE1BQU07SUFDTixPQUFPO0lBQ1AsVUFBVTtJQUNWLFFBQVE7SUFDUixRQUFRO0lBQ1IsWUFBWTs7RUFFYjtJQUNDLElBQUk7SUFDSixPQUFPO0lBQ1AsTUFBTTtJQUNOLE9BQU87SUFDUCxVQUFVO0lBQ1YsUUFBUTtJQUNSLFFBQVE7SUFDUixZQUFZOzs7RUFHYjtJQUNDLElBQUk7SUFDSixPQUFPO0lBQ1AsTUFBTTtJQUNOLE9BQU87SUFDUCxVQUFVO0lBQ1YsUUFBUTtJQUNSLFFBQVE7SUFDUixZQUFZOztFQUViO0lBQ0MsSUFBSTtJQUNKLE9BQU87SUFDUCxNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVU7SUFDVixRQUFRO0lBQ1IsUUFBUTtJQUNSLFlBQVk7Ozs7Ozs7Ozs7Ozs7O0FBaUJSLFNBQVUsY0FBYyxTQUFzQixRQUFtQjtBQUN0RSxNQUFJLENBQUMsV0FBVyxVQUFVLE1BQU0sV0FBVyxPQUFPLEVBQUUsU0FBUyxPQUFPLEVBQUUsR0FBRztBQUN4RSxZQUFRLEtBQUs7TUFDWixJQUFJO01BQ0osTUFBTTtNQUNOLE9BQU87TUFDUCxTQUFTO01BQ1QsS0FBSztNQUNMLEtBQUs7S0FDTDtFQUNGO0FBQ0EsTUFBSSxDQUFDLFdBQVcsUUFBUSxFQUFFLFNBQVMsT0FBTyxFQUFFLEdBQUc7QUFDOUMsWUFBUSxLQUFLO01BQ1osSUFBSTtNQUNKLE1BQU07TUFDTixPQUFPO01BQ1AsU0FBUztNQUNULEtBQUs7TUFDTCxLQUFLO0tBQ0w7RUFDRjtBQUNBLE1BQUksT0FBTyxNQUFNLE1BQU07QUFDdEIsWUFBUSxLQUFLO01BQ1osSUFBSTtNQUNKLE1BQU07TUFDTixPQUFPO01BQ1AsU0FBUztNQUNULEtBQUs7TUFDTCxLQUFLO0tBQ0w7RUFDRjtBQUNBLE1BQUksT0FBTyxNQUFNLFNBQVM7QUFDekIsWUFBUSxLQUFLO01BQ1osSUFBSSxPQUFPO01BQ1gsTUFBTTtNQUNOLE9BQU8sT0FBTztNQUNkLFNBQVMsT0FBTztNQUNoQixLQUFLLE9BQU87TUFDWixLQUFLLE9BQU87S0FDWjtFQUNGLE9BQU87QUFDTixZQUFRLEtBQUs7TUFDWixJQUFJO01BQ0osTUFBTTtNQUNOLE9BQU8sT0FBTztNQUNkLFNBQ0M7TUFDRCxTQUFTO0tBQ1Q7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDeklNLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxPQUFLLGtCQUFrQixFQUFFLGFBQWEsTUFBSyxDQUFFO0FBRTdDLFFBQU0sVUFBc0MsQ0FBQTtBQUM1QyxhQUFXLFVBQVUsY0FBYztBQUNsQyxVQUFNLFlBQXVDO01BQzVDLE1BQU0sT0FBTyxPQUFPLEtBQUs7TUFDekIsU0FBUyxjQUFjLENBQUEsR0FBSSxNQUFNO01BQ2pDLFVBQVUsT0FBTyxVQUF3QjtBQUN4QyxjQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU8sQ0FBQztBQUVyRCxZQUFJLENBQUMsS0FBSyxPQUFPLG9CQUFvQixDQUFDLEtBQUssV0FBVyxXQUFVLEdBQUk7QUFDbkUsZUFBSyxJQUFJLFNBQVMsZ0JBQWdCLEtBQUssV0FBVyxJQUFJLGFBQWE7QUFDbkU7UUFDRDtBQUVBLFlBQUksT0FBTyxNQUFNLFNBQVM7QUFDekIsZ0JBQU0sY0FBYyxNQUFNLEtBQUssT0FBTyxLQUFLO0FBQzNDLGVBQUssUUFBUSxZQUFZLE1BQU0sT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFzQixTQUFTLENBQUMsQ0FBQztRQUMvRTtBQUVBLFlBQUksS0FBSyxVQUFVO0FBQ2xCLGVBQUssT0FBTyxLQUFLLElBQUksT0FBTyxNQUFNLEtBQUssUUFBUTtBQUMvQyxjQUFJLEtBQUs7QUFBUyxpQkFBSyxVQUFVLE9BQU8sTUFBTSxLQUFLLE9BQU87QUFDMUQsY0FBSSxLQUFLO0FBQVcsaUJBQUssT0FBTyxPQUFPLE1BQU0sS0FBSyxTQUFTO0FBQzNELGNBQUksS0FBSztBQUFTLGlCQUFLLGFBQWEsT0FBTyxNQUFNLEtBQUssT0FBTztRQUM5RDtBQUVBLFlBQUksTUFBTSxZQUFZLGFBQWEsUUFBVyxFQUFFLElBQUksT0FBTyxJQUFJLEdBQUcsS0FBSSxDQUFFO0FBQ3hFLFlBQUksS0FBSyxVQUFVO0FBQ2xCLGdCQUFNLE1BQU0sS0FBSyxpQkFBaUIsR0FBSTtBQUN0QyxjQUFJLFFBQVEsUUFBVztBQUN0QixpQkFBSyxJQUFJLFFBQVEsK0RBQStEO0FBQ2hGO1VBQ0Q7QUFDQSxlQUFLLE9BQU8sS0FBSyxJQUFJLE1BQU0sT0FBTyxLQUFLLE9BQU8sS0FBSyxJQUFJLENBQUM7UUFDekQ7QUFFQSxZQUFJLEtBQUssY0FBYztBQUV0QixnQkFBTSxhQUFhLEtBQUssT0FBTztBQUMvQixnQkFBTSxRQUFRLEtBQUs7QUFDbkIsZ0JBQU0sU0FBUztBQUVmLGNBQUksUUFBUTtBQUNaLGNBQUksS0FBSyxVQUFVO0FBQ2xCLG9CQUFRLEtBQUssaUJBQWlCLEdBQUksS0FBSztVQUN4QyxPQUFPO0FBQ04sb0JBQVEsT0FBTyxLQUFLLGNBQWM7VUFDbkM7QUFFQSxjQUFJLE1BQU0sT0FBTyxLQUFLLE9BQU8sS0FBSyxJQUFJLENBQUM7QUFHdkMsY0FBSSxNQUFNLEdBQUc7QUFDWixrQkFBTTtVQUNQLFdBQVcsTUFBTSxLQUFLO0FBQ3JCLGtCQUFNO1VBQ1A7QUFHQSxjQUFJLFFBQVEsS0FBSztVQUVqQjtBQUVBLGdCQUFNLEtBQUssS0FBSyxJQUFHO0FBQ25CLGNBQUksT0FBTztBQU1YLGdCQUFNLGdCQUErQjtZQUNwQyxRQUFRLENBQUMsTUFBc0I7WUFDL0IsUUFBUSxDQUFDLE1BQXNCLElBQUk7WUFDbkMsU0FBUyxDQUFDLE1BQXNCLEtBQUssSUFBSSxNQUFNLElBQUk7WUFDbkQsV0FBVyxDQUFDLE1BQXVCLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxDQUFDLElBQUk7O0FBRXhGLGdCQUFNLE9BQThCLGNBQWMsS0FBZSxNQUFNLENBQUMsTUFBc0I7QUFFOUYsZ0JBQU0sUUFBUSxZQUFZLE1BQUs7QUFDOUIsa0JBQU0sVUFBVSxLQUFLLElBQUcsSUFBSztBQUM3QixrQkFBTSxJQUFJLEtBQUssSUFBSSxHQUFHLFVBQVUsVUFBVTtBQUMxQyxrQkFBTSxNQUFNLEtBQUssTUFBTSxTQUFTLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQztBQUV0RCxnQkFBSSxRQUFRLE1BQU07QUFDakIsbUJBQUssT0FBTyxLQUFLLElBQUk7QUFDckIsb0JBQU0sWUFBWSxhQUFhLFFBQVcsRUFBRSxJQUFJLE9BQU8sSUFBSSxHQUFHLEtBQUksQ0FBRTtBQUNwRSxtQkFBSyxJQUFJLFNBQVMsYUFBYSxHQUFHLFFBQVEsS0FBSyxXQUFXLElBQUksR0FBRztBQUNqRSxtQkFBSyxXQUFXLEtBQUssR0FBSTtBQUN6QixtQ0FBcUIsTUFBTSxTQUFTO0FBQ3BDLHFCQUFPO1lBQ1I7QUFDQSxnQkFBSSxLQUFLO0FBQUcsNEJBQWMsS0FBSztVQUNoQyxHQUFHLE1BQU07UUFDVixPQUFPO0FBQ04sZ0JBQU0sWUFBWSxhQUFhLFFBQVcsRUFBRSxJQUFJLE9BQU8sSUFBSSxHQUFHLEtBQUksQ0FBRTtBQUNwRSxlQUFLLElBQUksU0FBUyxhQUFhLEdBQUcsUUFBUSxLQUFLLFdBQVcsSUFBSSxHQUFHO0FBQ2pFLGVBQUssV0FBVyxLQUFLLEdBQUk7QUFDekIsK0JBQXFCLE1BQU0sU0FBUztRQUNyQztNQUNEOztBQUdELFFBQUksT0FBTyxNQUFNLFNBQVM7QUFDekIsZ0JBQVUsUUFBUSxHQUFHLEVBQUUsRUFBRyxzQkFBc0I7QUFDaEQsZ0JBQVUsUUFBUSxLQUNqQjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTyxPQUFPO1FBQ2QsU0FBUyxPQUFPO1FBQ2hCLEtBQUssQ0FBQyxPQUFPO1FBQ2IsS0FBSyxPQUFPO1FBQ1oscUJBQXFCO1NBRXRCO1FBQ0MsSUFBSTtRQUNKLE1BQU07UUFDTixPQUFPO1FBQ1AsT0FBTztRQUNQLHFCQUFxQjtTQUV0QjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCx1QkFBdUI7T0FDdkI7QUFJRixnQkFBVSxRQUFRLEtBQ2pCO1FBQ0MsSUFBSTtRQUNKLE1BQU07UUFDTixPQUFPO1FBQ1AsU0FBUztRQUNULHVCQUF1QjtTQUV4QjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCxLQUFLO1FBQ0wsS0FBSztRQUNMLHFCQUFxQjtTQUV0QjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCxLQUFLO1FBQ0wsS0FBSztRQUNMLHFCQUFxQjtTQUV0QjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCxTQUFTO1VBQ1IsRUFBRSxPQUFPLFVBQVUsSUFBSSxTQUFRO1VBQy9CLEVBQUUsT0FBTyxXQUFXLElBQUksU0FBUTtVQUNoQyxFQUFFLE9BQU8sWUFBWSxJQUFJLFVBQVM7VUFDbEMsRUFBRSxPQUFPLGVBQWUsSUFBSSxZQUFXOztRQUV4QyxxQkFBcUI7T0FDckI7SUFFSDtBQUVBLFlBQVEsT0FBTyxFQUFFLElBQUk7RUFDdEI7QUFFQSxPQUFLLHFCQUFxQixPQUFPO0FBQ2xDOzs7QUM5S00sU0FBVSxnQkFBZ0IsTUFBb0I7QUFDbkQsUUFBTSxZQUEwQyxDQUFBO0FBQ2hELGFBQVcsWUFBWSxjQUFjO0FBQ3BDLFVBQU0sY0FBMkM7TUFDaEQsTUFBTSxTQUFTO01BQ2YsYUFBYSxTQUFTO01BQ3RCLE1BQU07TUFDTixjQUFjO1FBQ2IsU0FBUyxXQUFXLEtBQUssR0FBRyxDQUFDO1FBQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7TUFFMUIsU0FBUyxjQUFjLENBQUEsR0FBSSxRQUFRO01BQ25DLFVBQVUsT0FBTyxVQUEyQjtBQUMzQyxjQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU8sQ0FBQztBQUVyRCxZQUFJLE1BQU0sY0FBYyxTQUFTO0FBQ2hDLGdCQUFNLGNBQWMsTUFBTSxLQUFLLFNBQVMsS0FBSztBQUM3QyxlQUFLLFFBQVEsWUFBWSxNQUFNLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBc0IsU0FBUyxDQUFDLENBQUM7UUFDL0U7QUFFQSxZQUFJLEtBQUssVUFBVTtBQUNsQixlQUFLLFNBQVMsS0FBSyxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7QUFDakQsY0FBSSxLQUFLO0FBQVMsaUJBQUssVUFBVSxPQUFPLE1BQU0sS0FBSyxPQUFPO0FBQzFELGNBQUksS0FBSztBQUFXLGlCQUFLLE9BQU8sT0FBTyxNQUFNLEtBQUssU0FBUztBQUMzRCxjQUFJLEtBQUs7QUFBUyxpQkFBSyxhQUFhLE9BQU8sTUFBTSxLQUFLLE9BQU87UUFDOUQ7QUFFQSxjQUFNLE1BQU0sWUFBWSxhQUFhLFFBQVcsRUFBRSxJQUFJLE1BQU0sWUFBWSxHQUFHLEtBQUksQ0FBRTtBQUVqRixjQUFNLGVBQWUsS0FBSyxpQkFBaUIsR0FBSTtBQUMvQyxZQUFJLE1BQU0sZUFBZSxXQUFXLEtBQUssYUFBYSxLQUFLLE9BQU8sa0JBQWtCLFFBQVE7QUFDM0YsdUJBQWEsTUFBTSxLQUFLLFlBQVk7QUFDckMsWUFBSSxnQkFBZ0I7QUFBVyxpQkFBTztBQUN0QyxZQUFJLGdCQUFnQixLQUFLLGNBQWMsR0FBSSxFQUFFLEtBQUs7QUFDakQsaUJBQU87UUFDUjtBQUNBLGVBQU87TUFDUjs7QUFHRCxRQUFJLFNBQVMsTUFBTSxXQUFXLEtBQUssT0FBTyxnQkFBZ0I7QUFDekQsa0JBQVksUUFBUSxHQUFHLEVBQUUsRUFBRyxzQkFBc0I7QUFDbEQsa0JBQVksUUFBUSxLQUFLO1FBQ3hCLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCx1QkFBdUI7T0FDdkI7SUFDRjtBQUVBLGNBQVUsU0FBUyxFQUFFLElBQUk7QUFFekIsY0FBVSxTQUFTLEtBQUssUUFBUSxJQUFJO01BQ25DLEdBQUc7TUFDSCxNQUFNLFNBQVMsUUFBUTtNQUN2QixNQUFNO01BQ04sU0FBUyxZQUFZLFFBQVEsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsU0FBUyxFQUFFLE9BQU8sV0FBVztNQUMxRixVQUFVLE9BQU8sVUFBMEI7QUFDMUMsY0FBTSxPQUFPLEtBQUssTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPLENBQUM7QUFDckQsY0FBTSxRQUFRLE1BQU0sV0FBVyxRQUFRLFVBQVUsRUFBRTtBQUNuRCxjQUFNLE1BQU0sWUFBWSxhQUFhLFFBQVcsRUFBRSxJQUFJLE9BQU8sR0FBRyxLQUFJLENBQUU7QUFDdEUsZUFBTyxLQUFLLGlCQUFpQixHQUFJLEtBQUs7TUFDdkM7O0VBRUY7QUFFQSxZQUFVLFFBQVEsSUFBSTtJQUNyQixNQUFNO0lBQ04sYUFBYTtJQUNiLE1BQU07SUFDTixjQUFjO01BQ2IsU0FBUyxXQUFXLEtBQUssR0FBRyxDQUFDO01BQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7SUFFMUIsU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUE2QjtBQUN0QyxhQUFPLENBQUMsQ0FBQyxLQUFLLGlCQUFpQixRQUFRO0lBQ3hDOztBQUdELFlBQVUsU0FBUyxJQUFJO0lBQ3RCLE1BQU07SUFDTixhQUFhO0lBQ2IsTUFBTTtJQUNOLGNBQWM7TUFDYixTQUFTLFdBQVcsS0FBSyxHQUFHLENBQUM7TUFDN0IsT0FBTyxXQUFXLEdBQUcsR0FBRyxDQUFDOztJQUUxQixTQUFTLENBQUE7SUFDVCxVQUFVLFlBQTZCO0FBQ3RDLGFBQU8sQ0FBQyxDQUFDLEtBQUssaUJBQWlCLFNBQVM7SUFDekM7O0FBR0QsT0FBSyx1QkFBdUIsU0FBUztBQUN0Qzs7O0FDeEdNLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxRQUFNLFVBQVU7SUFDZixTQUFTO01BQ1IsTUFBTTtNQUNOLE1BQU07TUFDTixPQUFPO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixPQUFPLFdBQVcsS0FBSyxLQUFLLEdBQUc7UUFDL0IsU0FBUyxXQUFXLEdBQUcsR0FBRyxDQUFDOztNQUU1QixPQUFPLENBQUE7TUFDUCxXQUFXO1FBQ1Y7VUFDQyxZQUFZO1VBQ1osU0FBUyxDQUFBO1VBQ1QsT0FBTztZQUNOLE9BQU8sV0FBVyxLQUFLLEtBQUssR0FBRztZQUMvQixTQUFTLFdBQVcsR0FBRyxLQUFLLENBQUM7Ozs7O0lBS2pDLFVBQVU7TUFDVCxNQUFNO01BQ04sTUFBTTtNQUNOLE9BQU87UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE9BQU8sV0FBVyxLQUFLLEtBQUssR0FBRztRQUMvQixTQUFTLFdBQVcsR0FBRyxHQUFHLENBQUM7O01BRTVCLE9BQU8sQ0FBQTtNQUNQLFdBQVc7UUFDVjtVQUNDLFlBQVk7VUFDWixTQUFTLENBQUE7VUFDVCxPQUFPO1lBQ04sT0FBTyxXQUFXLEtBQUssS0FBSyxHQUFHO1lBQy9CLFNBQVMsV0FBVyxHQUFHLEtBQUssQ0FBQzs7Ozs7O0FBT2xDLFFBQU0sWUFBWTtJQUNqQjtNQUNDLElBQUk7TUFDSixNQUFNO01BQ04sYUFBYTtRQUNaO1VBQ0MsSUFBSTtVQUNKLE1BQU07VUFDTixNQUFNO1VBQ04sU0FBUyxDQUFDLFdBQVcsVUFBVTs7Ozs7QUFNbkMsT0FBSyxxQkFBcUIsV0FBVyxPQUFPO0FBQzdDOzs7QUNsREEsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQTJCO0VBQ3RFOztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBRUEsWUFBWSxVQUFpQjtBQUM1QixVQUFNLFFBQVE7RUFDZjtFQUVBLE1BQU0sS0FBSyxRQUFvQjtBQUM5QixTQUFLLFNBQVM7QUFDZCxTQUFLLFlBQVksb0JBQUksSUFBRztBQUV4QixTQUFLLGNBQWE7QUFDbEIsU0FBSyxnQkFBZTtBQUNwQixTQUFLLGNBQWE7QUFDbEIsU0FBSywwQkFBeUI7QUFDOUIsVUFBTSxLQUFLLGNBQWMsTUFBTTtFQUNoQzs7RUFHQSxNQUFNLFVBQU87QUFDWixTQUFLLFVBQVUsTUFBSztBQUNwQixTQUFLLFdBQVcsTUFBSztBQUNyQixTQUFLLElBQUksU0FBUyxHQUFHLEtBQUssRUFBRSxZQUFZO0VBQ3pDO0VBRUEsTUFBTSxjQUFjLFFBQW9CO0FBQ3ZDLFNBQUssU0FBUztBQUNkLFNBQUssT0FBTyxrQkFBa0I7QUFDOUIsU0FBSyxPQUFPLG1CQUFtQjtBQUMvQixVQUFNLGFBQWEsS0FBSyxPQUFPLGtCQUFrQixLQUFLLE9BQU8sb0JBQW9CLEtBQUssT0FBTztBQUM3RixVQUFNLGNBQWMsS0FBSyxPQUFPLG1CQUFtQixLQUFLLE9BQU8scUJBQXFCLEtBQUssT0FBTztBQUNoRyxTQUFLLElBQ0osU0FDQSwwQkFBMEIsS0FBSyxVQUFlLFVBQVMsQ0FBRSxDQUFDO3lCQUE2QixVQUFVLEVBQUU7QUFFcEcsU0FBSyxJQUNKLFNBQ0EsMkJBQTJCLEtBQUssVUFBZSxXQUFVLENBQUUsQ0FBQzt5QkFBNkIsV0FBVyxFQUFFO0FBRXZHLFNBQUssSUFBSSxTQUFTLEVBQUU7QUFDcEIsUUFBSSxLQUFLO0FBQVcsV0FBSyxVQUFVLE1BQUs7QUFDeEMsUUFBSSxLQUFLO0FBQVksV0FBSyxXQUFXLE1BQUs7QUFDMUMsU0FBSyxZQUFZLElBQVNDLE9BQU0sWUFBWSxLQUFLLE9BQU8sZUFBZTtBQUN2RSxTQUFLLGFBQWEsSUFBU0MsUUFBTyxhQUFhLEtBQUssT0FBTyxnQkFBZ0I7QUFDM0UsVUFBTSxlQUFlLEtBQUssT0FBTyxtQkFBbUIsS0FBSyxVQUFVLFdBQVU7QUFDN0UsVUFBTSxnQkFBZ0IsS0FBSyxPQUFPLG9CQUFvQixLQUFLLFdBQVcsV0FBVTtBQUNoRixTQUFLLElBQUksUUFBUSxzQkFBc0IsS0FBSyxVQUFVLElBQUksUUFBUSxlQUFlLEtBQUssTUFBTSxPQUFPO0FBQ25HLFNBQUssSUFBSSxRQUFRLHNCQUFzQixLQUFLLFdBQVcsSUFBSSxRQUFRLGdCQUFnQixLQUFLLE1BQU0sT0FBTztBQUNyRyxTQUFLLGFBQWEsZUFBZSxZQUFZO0FBQzdDLFFBQUksQ0FBQyxnQkFBZ0I7QUFBZSxXQUFLLGFBQWEsZUFBZSxXQUFXLHVCQUF1QjtBQUN2RyxRQUFJLGdCQUFnQixDQUFDO0FBQWUsV0FBSyxhQUFhLGVBQWUsV0FBVyx3QkFBd0I7QUFDeEcsUUFBSSxnQkFBZ0I7QUFBZSxXQUFLLGFBQWEsZUFBZSxFQUFFO0FBRXRFLFNBQUssTUFBSztFQUNYOztFQUdBLGtCQUFlO0FBQ2QsV0FBTyxnQkFBZTtFQUN2QjtFQUNBLGdCQUFhO0FBQ1osa0JBQWMsSUFBSTtFQUNuQjtFQUVBLGtCQUFlO0FBQ2Qsb0JBQWdCLElBQUk7RUFDckI7RUFFQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSw0QkFBeUI7QUFDeEIsOEJBQTBCLElBQUk7RUFDL0I7O0VBR0EsUUFBSztBQUNKLFNBQUssSUFBSSxTQUFTLHFCQUFxQjtBQUV2QyxTQUFLLFVBQVUsR0FBRyxTQUFTLENBQUMsU0FBNEM7QUFDdkUsV0FBSyxrQkFBa0I7UUFDdEIsT0FBTyxLQUFLO1FBQ1osU0FBUyxLQUFLO09BQ2Q7SUFDRixDQUFDO0FBQ0QsU0FBSyxVQUFVLEdBQUcsV0FBVyxDQUFDLFdBQW1CLFFBQW9CO0FBQ3BFLFVBQUksSUFBSSxPQUFPLE9BQU87QUFDckIsYUFBSyxJQUFJLFNBQVMsSUFBSSxVQUFVLFFBQVEsQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsZUFBZSxHQUFHLFVBQVUsS0FBSyxVQUFVLElBQUksR0FBRztBQUM3RyxhQUFLLGVBQWUsR0FBRztBQUN2QixZQUFJLEtBQUs7QUFBb0IsZUFBSyxxQkFBcUIsV0FBVyxHQUFHO01BQ3RFO0FBQ0EsMkJBQXFCLE1BQU0sUUFBUTtJQUNwQyxDQUFDO0VBQ0Y7RUFFQSxlQUFlLEtBQWdCO0FBQzlCLFVBQU0sT0FBdUIsS0FBSyxjQUFjLEdBQUc7QUFDbkQsUUFBSSxLQUFLLE1BQU0sR0FBRztBQUNqQixvQkFBYyxNQUFNLEtBQUssS0FBSyxHQUFHO0FBQ2pDLFdBQUssVUFBVSxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUc7QUFDckMsV0FBSyxrQkFBaUI7SUFDdkI7RUFDRDtFQUVBLGlCQUFpQixLQUFnQjtBQUNoQyxVQUFNLE9BQXVCLEtBQUssY0FBYyxHQUFHO0FBQ25ELFFBQUksS0FBSyxNQUFNLEdBQUc7QUFDakIsYUFBTyxLQUFLLFVBQVUsSUFBSSxLQUFLLEdBQUc7SUFDbkM7QUFDQSxXQUFPO0VBQ1I7RUFFQSxjQUFjLEtBQWdCO0FBQzdCLFFBQUksWUFBb0IsSUFBSSxNQUFNLFNBQVM7QUFDM0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksWUFBWTtBQUdoQixRQUFJLGFBQWEsS0FBSyxJQUFJLFNBQVMsS0FBTTtBQUN4QyxVQUFJLElBQUksTUFBTSxTQUFTO0FBQ3RCLG9CQUFZLElBQUksS0FBSyxTQUFTO0FBQzlCO01BQ0QsT0FBTztBQUNOLG9CQUFZLElBQUksTUFBTSxTQUFTO01BQ2hDO0FBQ0EsZUFBUyxJQUFJLEdBQUcsSUFBSSxXQUFXLEtBQUs7QUFDbkMscUJBQWEsSUFBSSxNQUFNLENBQUMsTUFBTyxZQUFZLElBQUksS0FBTTtNQUN0RDtBQUNBLFVBQUksYUFBYTtBQUFHLG9CQUFZO0lBQ2pDO0FBQ0EsV0FBTyxFQUFFLEtBQUssV0FBVyxLQUFLLFVBQVM7RUFDeEM7O0VBR0EsNkJBQTZCLGFBQW9CO0FBQ2hELFNBQUsscUJBQXFCO0VBQzNCOztFQUdBLHFCQUFxQixXQUFtQixLQUFnQjtBQUN2RCxVQUFNLE9BQU8sRUFBRSxHQUFHLElBQUksS0FBSTtBQUMxQixRQUFJLFdBQVcsR0FBRyxJQUFJLEVBQUUsSUFBSSxLQUFLLGNBQWMsR0FBRyxFQUFFLEdBQUc7QUFDdkQsUUFBSSxLQUFLLE9BQU8sY0FBYztBQUM3QixrQkFBWSxLQUFLLE1BQU0sWUFBWSxHQUFJO0FBQ3ZDLGlCQUFXO0lBQ1osT0FBTztBQUNOLGtCQUFZO0lBQ2I7QUFDQSxTQUFLLGFBQ0o7TUFDQyxVQUFVLElBQUk7TUFDZCxTQUFTO01BQ1QsT0FBTztPQUVSLFFBQVE7RUFFVjs7IiwKICAibmFtZXMiOiBbIkV2ZW50RW1pdHRlciIsICJJbnB1dCIsICJPdXRwdXQiLCAidmFyaWFibGVzIiwgIkluc3RhbmNlU3RhdHVzIiwgIlJlZ2V4IiwgIkV2ZW50RW1pdHRlciIsICJJbnB1dCIsICJFdmVudEVtaXR0ZXIiLCAiT3V0cHV0IiwgIklucHV0IiwgIk91dHB1dCJdCn0K
