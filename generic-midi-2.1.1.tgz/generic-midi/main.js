import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/pkg-prebuilds/lib/prebuild.js
var require_prebuild = __commonJS({
  "node_modules/pkg-prebuilds/lib/prebuild.js"(exports, module) {
    var fs = __require("fs");
    function getPrebuildName(options) {
      if (!options.napi_version) throw new Error("NAN not implemented");
      const tokens = [
        options.name,
        options.platform,
        options.arch,
        // options.armv ? (options.arch === 'arm64' ? '8' : vars.arm_version) : null,
        options.libc && options.platform === "linux" ? options.libc : null
      ];
      return `${tokens.filter((t) => !!t).join("-")}/${options.runtime}-napi-v${options.napi_version}.node`;
    }
    function isNwjs() {
      return !!(process.versions && process.versions.nw);
    }
    function isElectron() {
      if (process.versions && process.versions.electron) return true;
      if (process.env.ELECTRON_RUN_AS_NODE) return true;
      return typeof window !== "undefined" && window.process && window.process.type === "renderer";
    }
    function isAlpine(platform) {
      return platform === "linux" && fs.existsSync("/etc/alpine-release");
    }
    module.exports = {
      getPrebuildName,
      isNwjs,
      isElectron,
      isAlpine
    };
  }
});

// node_modules/pkg-prebuilds/bindings.js
var require_bindings = __commonJS({
  "node_modules/pkg-prebuilds/bindings.js"(exports, module) {
    var path = __require("path");
    var os = __require("os");
    var { getPrebuildName, isNwjs, isElectron, isAlpine } = require_prebuild();
    var fs = typeof jest !== "undefined" ? jest.requireActual("fs") : __require("fs");
    var runtimeRequire = typeof __webpack_require__ === "function" ? __non_webpack_require__ : __require;
    function resolvePath(basePath, options, verifyPrebuild, throwOnMissing) {
      if (typeof basePath !== "string" || !basePath) throw new Error(`Invalid basePath to pkg-prebuilds`);
      if (typeof options !== "object" || !options) throw new Error(`Invalid options to pkg-prebuilds`);
      if (typeof options.name !== "string" || !options.name) throw new Error(`Invalid name to pkg-prebuilds`);
      let isNodeApi = false;
      if (options.napi_versions && Array.isArray(options.napi_versions)) {
        isNodeApi = true;
      }
      const arch = verifyPrebuild && process.env.npm_config_arch || os.arch();
      const platform = verifyPrebuild && process.env.npm_config_platform || os.platform();
      let runtime = "node";
      if (!isNodeApi) {
        if (verifyPrebuild && process.env.npm_config_runtime) {
          runtime = process.env.npm_config_runtime;
        } else if (isElectron()) {
          runtime = "electron";
        } else if (isNwjs()) {
          runtime = "node-webkit";
        }
      }
      const candidates = [];
      if (!verifyPrebuild) {
        candidates.push(
          path.join(basePath, "build", "Debug", `${options.name}.node`),
          path.join(basePath, "build", "Release", `${options.name}.node`)
        );
      }
      let libc = void 0;
      if (isAlpine(platform)) libc = "musl";
      if (isNodeApi) {
        for (const ver of options.napi_versions) {
          const prebuildName = getPrebuildName({
            name: options.name,
            platform,
            arch,
            libc,
            napi_version: ver,
            runtime
            // armv: options.armv ? (arch === 'arm64' ? '8' : vars.arm_version) : null,
          });
          candidates.push(path.join(basePath, "prebuilds", prebuildName));
        }
      } else {
        throw new Error("Not implemented for NAN!");
      }
      let foundPath = null;
      for (const candidate of candidates) {
        if (fs.existsSync(candidate)) {
          const stat = fs.statSync(candidate);
          if (stat.isFile()) {
            foundPath = candidate;
            break;
          }
        }
      }
      if (!foundPath && throwOnMissing) {
        const candidatesStr = candidates.map((cand) => ` - ${cand}`).join("\n");
        throw new Error(`Failed to find binding for ${options.name}
Tried paths:
${candidatesStr}`);
      }
      return foundPath;
    }
    function loadBinding(basePath, options) {
      const foundPath = resolvePath(basePath, options, false, true);
      if (!foundPath) throw new Error(`Failed to find binding for ${options.name}`);
      return runtimeRequire(foundPath);
    }
    loadBinding.resolve = resolvePath;
    module.exports = loadBinding;
  }
});

// node_modules/@julusian/midi/binding-options.js
var require_binding_options = __commonJS({
  "node_modules/@julusian/midi/binding-options.js"(exports, module) {
    module.exports = {
      name: "midi",
      napi_versions: [7]
    };
  }
});

// node_modules/@julusian/midi/lib/instruments.js
var require_instruments = __commonJS({
  "node_modules/@julusian/midi/lib/instruments.js"(exports, module) {
    module.exports = {
      ACOUSTIC_GRAND_PIANO: 0,
      BRIGHT_ACOUSTIC_PIANO: 1,
      ELECTRIC_GRAND_PIANO: 2,
      HONKY_TONK_PIANO: 3,
      ELECTRIC_PIANO_1: 4,
      ELECTRIC_PIANO_2: 5,
      HARPSICHORD: 6,
      CLAVI: 7,
      CELESTA: 8,
      GLOCKENSPIEL: 9,
      MUSIC_BOX: 10,
      VIBRAPHONE: 11,
      MARIMBA: 12,
      XYLOPHONE: 13,
      TUBULAR_BELLS: 14,
      DULCIMER: 15,
      DRAWBAR_ORGAN: 16,
      PERCUSSIVE_ORGAN: 17,
      ROCK_ORGAN: 18,
      CHURCH_ORGAN: 19,
      REED_ORGAN: 20,
      ACCORDION: 21,
      HARMONICA: 22,
      TANGO_ACCORDION: 23,
      ACOUSTIC_GUITAR_NYLON: 24,
      ACOUSTIC_GUITAR_STEEL: 25,
      ELECTRIC_GUITAR_JAZZ: 26,
      ELECTRIC_GUITAR_CLEAN: 27,
      ELECTRIC_GUITAR_MUTED: 28,
      OVERDRIVEN_GUITAR: 29,
      DISTORTION_GUITAR: 30,
      GUITAR_HARMONICS: 31,
      ACOUSTIC_BASS: 32,
      ELECTRIC_BASS_FINGER: 33,
      ELECTRIC_BASS_PICK: 34,
      FRETLESS_BASS: 35,
      SLAP_BASS_1: 36,
      SLAP_BASS_2: 37,
      SYNTH_BASS_1: 38,
      SYNTH_BASS_2: 39,
      VIOLIN: 40,
      VIOLA: 41,
      CELLO: 42,
      CONTRABASS: 43,
      TREMOLO_STRINGS: 44,
      PIZZICATO_STRINGS: 45,
      ORCHESTRAL_HARP: 46,
      TIMPANI: 47,
      STRING_ENSEMBLE_1: 48,
      STRING_ENSEMBLE_2: 49,
      SYNTHSTRINGS_1: 50,
      SYNTHSTRINGS_2: 51,
      CHOIR_AAHS: 52,
      VOICE_OOHS: 53,
      SYNTH_VOICE: 54,
      ORCHESTRA_HIT: 55,
      TRUMPET: 56,
      TROMBONE: 57,
      TUBA: 58,
      MUTED_TRUMPET: 59,
      FRENCH_HORN: 60,
      BRASS_SECTION: 61,
      SYNTHBRASS_1: 62,
      SYNTHBRASS_2: 63,
      SOPRANO_SAX: 64,
      ALTO_SAX: 65,
      TENOR_SAX: 66,
      BARITONE_SAX: 67,
      OBOE: 68,
      ENGLISH_HORN: 69,
      BASSOON: 70,
      CLARINET: 71,
      PICCOLO: 72,
      FLUTE: 73,
      RECORDER: 74,
      PAN_FLUTE: 75,
      BLOWN_BOTTLE: 76,
      SHAKUHACHI: 77,
      WHISTLE: 78,
      OCARINA: 79,
      LEAD_1_SQUARE: 80,
      LEAD_2_SAWTOOTH: 81,
      LEAD_3_CALLIOPE: 82,
      LEAD_4_CHIFF: 83,
      LEAD_5_CHARANG: 84,
      LEAD_6_VOICE: 85,
      LEAD_7_FIFTHS: 86,
      LEAD_8_BASS_AND_LEAD: 87,
      PAD_1_NEW_AGE: 88,
      PAD_2_WARM: 89,
      PAD_3_POLYSYNTH: 90,
      PAD_4_CHOIR: 91,
      PAD_5_BOWED: 92,
      PAD_6_METALLIC: 93,
      PAD_7_HALO: 94,
      PAD_8_SWEEP: 95,
      FX_1_RAIN: 96,
      FX_2_SOUNDTRACK: 97,
      FX_3_CRYSTAL: 98,
      FX_4_ATMOSPHERE: 99,
      FX_5_BRIGHTNESS: 100,
      FX_6_GOBLINS: 101,
      FX_7_ECHOES: 102,
      FX_8_SCIFI: 103,
      SITAR: 104,
      BANJO: 105,
      SHAMISEN: 106,
      KOTO: 107,
      KALIMBA: 108,
      BAG_PIPE: 109,
      FIDDLE: 110,
      SHANAI: 111,
      TINKLE_BELL: 112,
      AGOGO: 113,
      STEEL_DRUMS: 114,
      WOODBLOCK: 115,
      TAIKO_DRUM: 116,
      MELODIC_TOM: 117,
      SYNTH_DRUM: 118,
      REVERSE_CYMBAL: 119,
      GUITAR_FRET_NOISE: 120,
      BREATH_NOISE: 121,
      SEASHORE: 122,
      BIRD_TWEET: 123,
      TELEPHONE_RING: 124,
      HELICOPTER: 125,
      APPLAUSE: 126,
      GUNSHOT: 127
    };
  }
});

// node_modules/@julusian/midi/lib/drums.js
var require_drums = __commonJS({
  "node_modules/@julusian/midi/lib/drums.js"(exports, module) {
    module.exports = {
      ACOUSTIC_BASS_DRUM: 35,
      BASS_DRUM: 36,
      SIDE_STICK: 37,
      ACOUSTIC_SNARE: 38,
      HAND_CLAP: 39,
      ELECTRIC_SNARE: 40,
      LOW_FLOOR_TOM: 41,
      CLOSED_HI_HAT: 42,
      HIGH_FLOOR_TOM: 43,
      PEDAL_HI_HAT: 44,
      LOW_TOM: 45,
      OPEN_HI_HAT: 46,
      LOW_MID_TOM: 47,
      HI_MID_TOM: 48,
      CRASH_CYMBAL_1: 49,
      HIGH_TOM: 50,
      RIDE_CYMBAL_1: 51,
      CHINESE_CYMBAL: 52,
      RIDE_BELL: 53,
      TAMBOURINE: 54,
      SPLASH_CYMBAL: 55,
      COWBELL: 56,
      CRASH_CYMBAL_2: 57,
      VIBRA_SLAP: 58,
      RIDE_CYMBAL_2: 59,
      HI_BONGO: 60,
      LOW_BONGO: 61,
      MUTE_HI_CONGA: 62,
      OPEN_HI_CONGA: 63,
      LOW_CONGA: 64,
      HIGH_TIMBALE: 65,
      LOW_TIMBALE: 66,
      HIGH_AGOGO: 67,
      LOW_AGOGO: 68,
      CABASA: 69,
      MARACAS: 70,
      SHORT_WHISTLE: 71,
      LONG_WHISTLE: 72,
      SHORT_GUIRO: 73,
      LONG_GUIRO: 74,
      CLAVES: 75,
      HI_WOOD_BLOCK: 76,
      LOW_WOOD_BLOCK: 77,
      MUTE_CUICA: 78,
      OPEN_CUICA: 79,
      MUTE_TRIANGLE: 80,
      OPEN_TRIANGLE: 81
    };
  }
});

// node_modules/@julusian/midi/lib/notes.js
var require_notes = __commonJS({
  "node_modules/@julusian/midi/lib/notes.js"(exports, module) {
    module.exports = {
      /*
      ** The MIDI spec only indicates middle C to be
      ** 60. It doesn't indicate which octave this is.
      ** Some may consider 4, if they label octaves 
      ** from -1, instead of 0. I have adopted on octave
      ** number C here.
      */
      MIDDLE_C: 60,
      // Relative offsets
      C: 0,
      C_SHARP: 1,
      C_FLAT: -1,
      D: 2,
      D_SHARP: 3,
      D_FLAT: 1,
      E: 4,
      E_SHARP: 5,
      E_FLAT: 3,
      F: 5,
      F_SHARP: 6,
      F_FLAT: 4,
      G: 7,
      G_SHARP: 8,
      G_FLAT: 6,
      A: 9,
      A_SHARP: 10,
      A_FLAT: 8,
      B: 11,
      B_SHARP: 12,
      B_FLAT: 10,
      // For the octaves
      C0: 0,
      C1: 12,
      C2: 24,
      C3: 36,
      C4: 48,
      C5: 60,
      C6: 72,
      C7: 84,
      C8: 96,
      C9: 108,
      C10: 120
    };
  }
});

// node_modules/@julusian/midi/lib/messages.js
var require_messages = __commonJS({
  "node_modules/@julusian/midi/lib/messages.js"(exports, module) {
    module.exports = {
      // All basic messages are held in the root, because of how commonly they're
      // used. Luckily, there's no name clashes with sub-names
      NOTE_OFF: 128,
      /* [ pitch, volume ] */
      NOTE_ON: 144,
      /* [ pitch, volume ] */
      NOTE_KEY_PRESSURE: 160,
      /* [ pitch, pressure (after touch) ] */
      SET_PARAMETER: 176,
      /* [ param number (CC), setting ] */
      SET_PROGRAM: 192,
      /* [ program ] */
      CHANGE_PRESSURE: 208,
      /* [ pressure (after touch) ] */
      SET_PITCHWHEEL: 224,
      /* [ LSB,  MSB (two 7 bit values) ] */
      METAEVENT: 255,
      SYS_EX1: 240,
      SYS_EX2: 247,
      /* Alternative names */
      PATCH_CHANGE: 192,
      /* Equivalent to SET_PROGRAM */
      CONTROL_CHANGE: 176,
      /* Equivalent to SET_PARAMETER */
      SYSMASK: 240,
      // Control changes
      cc: {
        /* 0-31, where defined, all indicate the MSB */
        BANK_SELECT: 0,
        MODULATION: 1,
        BREATH_CONTROL: 2,
        UNDEFINED_3: 3,
        FOOT_CONTROL: 4,
        PORTAMENTO_TIME: 5,
        DATE_ENTRY: 6,
        VOLUME: 7,
        BALANCE: 8,
        UNDEFINED_9: 9,
        PAN: 10,
        EXPRESSION: 11,
        EFFECT_CONTROL_1: 12,
        EFFECT_CONTROL_2: 13,
        UNDEFINED_14: 14,
        UNDEFINED_15: 15,
        GENERAL_PURPOSE_1: 16,
        GENERAL_PURPOSE_2: 17,
        GENERAL_PURPOSE_3: 18,
        GENERAL_PURPOSE_4: 19,
        /* 20-31 are undefined */
        UNDEFINED_20: 20,
        UNDEFINED_21: 21,
        UNDEFINED_22: 22,
        UNDEFINED_23: 23,
        UNDEFINED_24: 24,
        UNDEFINED_25: 25,
        UNDEFINED_26: 26,
        UNDEFINED_27: 27,
        UNDEFINED_28: 28,
        UNDEFINED_29: 29,
        UNDEFINED_30: 30,
        UNDEFINED_31: 31,
        /* LSB for control changes 0-31		32-63 */
        BANK_SELECT_LSB: 32,
        MODULATION_LSB: 33,
        BREATH_CONTROL_LSB: 34,
        UNDEFINED_35: 35,
        FOOT_CONTROL_LSB: 36,
        PORTAMENTO_TIME_LSB: 37,
        DATA_ENTRY_LSB: 38,
        VOLUME_LSB: 39,
        BALANCE_LSB: 40,
        UNDEFINED_41: 41,
        PAN_LSB: 42,
        EXPRESSION_LSB: 43,
        EFFECT_CONTROL_1_LSB: 44,
        EFFECT_CONTROL_2_LSB: 45,
        UNDEFINED_46: 46,
        UNDEFINED_47: 47,
        GENERAL_PURPOSE_1_LSB: 48,
        GENERAL_PURPOSE_2_LSB: 49,
        GENERAL_PURPOSE_3_LSB: 50,
        GENERAL_PURPOSE_4_LSB: 51,
        /* 52-63 are undefined */
        UNDEFINED_52: 52,
        UNDEFINED_53: 53,
        UNDEFINED_54: 54,
        UNDEFINED_55: 55,
        UNDEFINED_56: 56,
        UNDEFINED_57: 57,
        UNDEFINED_58: 58,
        UNDEFINED_59: 59,
        UNDEFINED_60: 60,
        UNDEFINED_61: 61,
        UNDEFINED_62: 62,
        UNDEFINED_63: 63,
        SUSTAIN_PEDAL: 64,
        PORTAMENTO: 65,
        PEDAL_SUSTENUTO: 66,
        PEDAL_SOFT: 67,
        LEGATO_FOOT_SWITCH: 68,
        HOLD_2: 69,
        SOUND_VARIATION: 70,
        TIMBRE: 71,
        RELEASE_TIME: 72,
        ATTACKTIME: 73,
        BRIGHTNESS: 74,
        REVERB: 75,
        DELAY: 76,
        PITCH_TRANSPOSE: 77,
        FLANGE: 78,
        SPECIAL_FX: 79,
        GENERAL_PURPOSE_5_LSB: 80,
        GENERAL_PURPOSE_6_LSB: 81,
        GENERAL_PURPOSE_7_LSB: 82,
        GENERAL_PURPOSE_8_LSB: 83,
        PORTAMENTO_CONTROL: 84,
        /* 85-90 are undefined */
        UNDEFINED_85: 85,
        UNDEFINED_86: 86,
        UNDEFINED_87: 87,
        UNDEFINED_88: 88,
        UNDEFINED_89: 89,
        UNDEFINED_90: 90,
        /* Effects depth */
        FX_DEPTH: 91,
        TREMELO_DEPTH: 92,
        CHORUS_DEPTH: 93,
        CELESTA_DEPTH: 94,
        PHASER_DEPTH: 95,
        DATA_INC: 96,
        DATA_DEC: 97,
        NON_REG_PARAM_LSB: 98,
        NON_REG_PARAM_MSB: 99,
        REG_PARAM_LSB: 100,
        REG_PARAM_MSB: 101,
        /* 102-119 are undefined */
        UNDEFINED_102: 102,
        UNDEFINED_103: 103,
        UNDEFINED_104: 104,
        UNDEFINED_105: 105,
        UNDEFINED_106: 106,
        UNDEFINED_107: 107,
        UNDEFINED_108: 108,
        UNDEFINED_109: 109,
        UNDEFINED_110: 110,
        UNDEFINED_111: 111,
        UNDEFINED_112: 112,
        UNDEFINED_113: 113,
        UNDEFINED_114: 114,
        UNDEFINED_115: 115,
        UNDEFINED_116: 116,
        UNDEFINED_117: 117,
        UNDEFINED_118: 118,
        UNDEFINED_119: 119,
        // Modes
        ALL_SOUND_OFF: 120,
        RESET_ALL_CONTROLLERS: 121,
        LOCAL_CONTROL: 122,
        ALL_NOTES_OFF: 123,
        OMNI_MODE_OFF: 124,
        OMNI_MODE_ON: 125,
        MONO_MODE_ON: 126,
        POLY_MODE_ON: 127,
        /* Alternative names */
        MOD_WHEEL: 1,
        /* All sound controllers have only LSB */
        HARM_CONTENT: 71,
        SOUND_CONTROLLER_1: 70,
        SOUND_CONTROLLER_2: 71,
        SOUND_CONTROLLER_3: 72,
        SOUND_CONTROLLER_4: 73,
        SOUND_CONTROLLER_5: 74,
        SOUND_CONTROLLER_6: 75,
        SOUND_CONTROLLER_7: 76,
        SOUND_CONTROLLER_8: 77,
        SOUND_CONTROLLER_9: 78,
        SOUND_CONTROLLER_10: 79,
        EFFECT_1_DEPTH: 91,
        EFFECT_2_DEPTH: 92,
        EFFECT_3_DEPTH: 93,
        EFFECT_4_DEPTH: 94,
        EFFECT_5_DEPTH: 95,
        DETUNE_DEPTH: 94
      },
      /*
      ** System Common (Status byte: 1111 0ttt)
      */
      syscommon: {
        UNDEFINED_1: 241,
        SONG_POSITION: 242,
        /* [LSB, MSB] */
        SONG_SELECT: 243,
        UNDEFINED_4: 244,
        UNDEFINED_5: 245,
        TUNE_REQUEST: 246,
        EOX: 247
        /* End of Exclusive */
      },
      /*
      ** System Real Time (Status byte: 1111 1ttt)
      */
      realtime: {
        TIMING_CLOCK: 248,
        UNDEFINED_F9: 249,
        START: 250,
        CONTINUE: 251,
        STOP: 252,
        UNDEFINED_FD: 253,
        ACTIVE_SENSING: 254,
        SYSTEM_RESET: 255
      },
      /*
      ** System Exclusive (Status byte: 1111 0000)
      **
      ** The first byte of a sysex must be the identification number
      ** (7 bits, MSB=0). This is followed by an arbitary number of
      ** data bytes (all MSB=0), and ending in the sexEOX msg.
      ** Note: Any other status byte (where MSB=1) will also terminate
      ** a sysex message, with the exception of the System Real Time
      ** events above.
      */
      sysex: {
        EOX: 247
        /* End of Exclusive */
      }
    };
  }
});

// node_modules/@julusian/midi/midi.js
var require_midi = __commonJS({
  "node_modules/@julusian/midi/midi.js"(exports, module) {
    var midi = require_bindings()(
      __dirname,
      require_binding_options()
    );
    var Stream = __require("stream");
    var { EventEmitter: EventEmitter3 } = __require("events");
    var Instruments = require_instruments();
    var Drums = require_drums();
    var Notes = require_notes();
    var Messages = require_messages();
    var Input3 = class extends EventEmitter3 {
      constructor() {
        super();
        this.input = new midi.Input((deltaTime, message) => {
          this.emit("message", deltaTime, Array.from(message.values()));
        });
      }
      closePort() {
        return this.input.closePort();
      }
      destroy() {
        return this.input.destroy();
      }
      getPortCount() {
        return this.input.getPortCount();
      }
      getPortName(port) {
        return this.input.getPortName(port);
      }
      isPortOpen() {
        return this.input.isPortOpen();
      }
      ignoreTypes(sysex, timing, activeSensing) {
        return this.input.ignoreTypes(sysex, timing, activeSensing);
      }
      openPort(port) {
        return this.input.openPort(port);
      }
      openPortByName(name) {
        for (let port = 0; port < this.input.getPortCount(); ++port) {
          if (name === this.input.getPortName(port)) {
            return this.input.openPort(port);
          }
        }
        return void 0;
      }
      openVirtualPort(port) {
        return this.input.openVirtualPort(port);
      }
      setBufferSize(size, count = 4) {
        return this.input.setBufferSize(size, count);
      }
    };
    var Output3 = class {
      constructor() {
        this.output = new midi.Output();
      }
      closePort() {
        return this.output.closePort();
      }
      destroy() {
        return this.output.destroy();
      }
      getPortCount() {
        return this.output.getPortCount();
      }
      getPortName(port) {
        return this.output.getPortName(port);
      }
      isPortOpen() {
        return this.output.isPortOpen();
      }
      openPort(port) {
        return this.output.openPort(port);
      }
      openPortByName(name) {
        for (let port = 0; port < this.output.getPortCount(); ++port) {
          if (name === this.output.getPortName(port)) {
            return this.output.openPort(port);
          }
        }
        return void 0;
      }
      openVirtualPort(port) {
        return this.output.openVirtualPort(port);
      }
      send(message) {
        return this.sendMessage(message);
      }
      sendMessage(message) {
        if (Array.isArray(message)) {
          message = Buffer.from(message);
        }
        if (!Buffer.isBuffer(message)) {
          throw new Error("First argument must be an array or Buffer");
        }
        return this.output.sendMessage(message);
      }
    };
    function createReadStream(input) {
      input = input || new Input3();
      var stream = new Stream();
      stream.readable = true;
      stream.paused = false;
      stream.queue = [];
      input.on("message", function(deltaTime, message) {
        var packet = new Buffer.from(message);
        if (!stream.paused) {
          stream.emit("data", packet);
        } else {
          stream.queue.push(packet);
        }
      });
      stream.pause = function() {
        stream.paused = true;
      };
      stream.resume = function() {
        stream.paused = false;
        while (stream.queue.length && stream.emit("data", stream.queue.shift())) {
        }
      };
      return stream;
    }
    function createWriteStream(output) {
      output = output || new Output3();
      var stream = new Stream();
      stream.writable = true;
      stream.paused = false;
      stream.queue = [];
      stream.write = function(d) {
        if (Buffer.isBuffer(d)) {
          d = Array.prototype.slice.call(d, 0);
        }
        output.sendMessage(d);
        return !this.paused;
      };
      stream.end = function(buf) {
        buf && stream.write(buf);
        stream.writable = false;
      };
      stream.destroy = function() {
        stream.writable = false;
      };
      return stream;
    }
    module.exports = {
      Input: Input3,
      Output: Output3,
      createReadStream,
      createWriteStream,
      Constants: {
        Instruments,
        Drums,
        Notes,
        Messages
      },
      // Backwards compatibility.
      input: Input3,
      output: Output3
    };
  }
});

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables2) {
    if (Array.isArray(variables2))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables2);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path, args) {
    this.#context.oscSend(host, port, path, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// node_modules/@companion-module/base/dist/module-api/upgrade.js
function FixupNumericOrVariablesValueToExpressions(value) {
  if (!value || value.isExpression)
    return value;
  const oldValNum = Number(value.value);
  const oldValRaw = value.value;
  if (typeof value.value === "number" || typeof value.value === "string" && value.value.trim() !== "" && !isNaN(oldValNum)) {
    return {
      isExpression: false,
      value: oldValNum
    };
  } else if (typeof oldValRaw === "string") {
    const trimmedStr = oldValRaw.trim();
    if (trimmedStr.startsWith("$(") && trimmedStr.endsWith(")") && !trimmedStr.slice(2).includes("$(")) {
      return {
        isExpression: true,
        value: oldValRaw
      };
    } else {
      return {
        isExpression: true,
        value: `parseVariables("${oldValRaw.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}")`
      };
    }
  } else {
    return value;
  }
}

// dist/midi/midi.js
var node_midi = __toESM(require_midi(), 1);
import { EventEmitter as EventEmitter2 } from "events";

// dist/midi/msgtypes.js
var MAX_7_BIT = 127;
var MAX_14_BIT = 16383;
var MIDI_STATUS_TYPES = /* @__PURE__ */ new Map([
  ["noteoff", 128],
  ["noteon", 144],
  ["aftertouch", 160],
  ["cc", 176],
  ["program", 192],
  ["channelpressure", 208],
  ["pitch", 224],
  ["sysex", 240],
  ["mtc", 241],
  ["position", 242],
  ["select", 243],
  ["tune", 246],
  ["sysex end", 247],
  ["clock", 248],
  ["start", 250],
  ["continue", 251],
  ["stop", 252],
  ["activesense", 254],
  ["reset", 255]
]);
var hex = (val) => `${val} (0x${val.toString(16).padStart(2, "0")})`;
var MidiMessage = class _MidiMessage {
  id = "";
  bytes;
  static noMsg = {
    bytes: [],
    status: 0,
    channel: 0,
    type: 0,
    note: 0,
    velocity: 0,
    controller: 0,
    pressure: 0,
    value: 0,
    program: 0,
    song: 0
  };
  constructor(bytes = []) {
    this.bytes = bytes;
  }
  get status() {
    return this.bytes[0] > 239 ? this.bytes[0] : this.bytes[0] & 240;
  }
  set status(v) {
    this.bytes[0] = v > 239 ? v : this.bytes[0] & 15 | v & 240;
  }
  get channel() {
    return (this.bytes[0] & 15) + 1;
  }
  set channel(v) {
    v--;
    v = _MidiMessage.constrain(v, 15);
    this.bytes[0] = this.bytes[0] & 240 | v & 15;
  }
  get data1() {
    return this.bytes[1] & 127;
  }
  set data1(v) {
    this.bytes[1] = _MidiMessage.constrain(v, MAX_7_BIT);
  }
  get data2() {
    return this.bytes[2] & 127;
  }
  set data2(v) {
    this.bytes[2] = _MidiMessage.constrain(v, MAX_7_BIT);
  }
  get args() {
    return { bytes: this.bytes };
  }
  toString() {
    return `${this.id} Message`;
  }
  static constrain(num, max) {
    if (!Number.isFinite(num))
      return 0;
    return num > max ? max : num < 0 ? 0 : num;
  }
  static parseMessage(bytes = [], msg = this.noMsg) {
    let incoming = new _MidiMessage(bytes);
    let status = bytes.length > 0 ? incoming.status : msg.status || 0;
    if (status === 0 && typeof msg.id !== "undefined")
      status = MIDI_STATUS_TYPES.get(msg.id) || 0;
    switch (status) {
      case 128:
        incoming = new NoteOff(msg.channel, msg.note, msg.velocity);
        break;
      case 144:
        incoming = new NoteOn(msg.channel, msg.note, msg.velocity);
        break;
      case 160:
        incoming = new Aftertouch(msg.channel, msg.note, msg.pressure);
        break;
      case 176:
        incoming = new ControlChange(msg.channel, msg.controller, msg.value);
        break;
      case 192:
        incoming = new ProgramChange(msg.channel, msg.program);
        break;
      case 208:
        incoming = new ChannelPressure(msg.channel, msg.pressure);
        break;
      case 224:
        incoming = new PitchWheel(msg.channel, msg.value);
        break;
      case 240:
        incoming = new Sysex(msg.bytes);
        break;
      case 241:
        incoming = new Mtc(msg.type, msg.value);
        break;
      case 248:
        return;
      // ignore MIDI Clock messages
      default:
        console.log(`Unsupported MIDI message. Status = ${hex(status)}`);
        return;
    }
    if (bytes.length > 0)
      incoming.bytes = bytes;
    return incoming;
  }
};
var NoteOff = class extends MidiMessage {
  constructor(c, n, v) {
    super();
    this.id = "noteoff";
    this.status = 128;
    this.channel = c;
    this.note = n;
    this.velocity = v;
  }
  get note() {
    return this.data1;
  }
  set note(v) {
    this.data1 = v;
  }
  get velocity() {
    return this.data2;
  }
  set velocity(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, note: this.note, velocity: this.velocity };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, note: ${hex(this.note)}, velocity: ${hex(this.velocity)}`;
  }
};
var NoteOn = class extends NoteOff {
  constructor(c, n, v) {
    super(c, n, v);
    this.id = "noteon";
    this.status = 144;
  }
};
var Aftertouch = class extends MidiMessage {
  constructor(c, n, p) {
    super();
    this.id = "aftertouch";
    this.status = 160;
    this.channel = c;
    this.note = n;
    this.pressure = p;
  }
  get note() {
    return this.data1;
  }
  set note(v) {
    this.data1 = v;
  }
  get pressure() {
    return this.data2;
  }
  set pressure(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, note: this.note, pressure: this.pressure };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, note: ${hex(this.note)}, pressure: ${hex(this.pressure)}`;
  }
};
var ControlChange = class extends MidiMessage {
  constructor(c, cc, v) {
    super();
    this.id = "cc";
    this.status = 176;
    this.channel = c;
    this.controller = cc;
    this.value = v;
  }
  get controller() {
    return this.data1;
  }
  set controller(v) {
    this.data1 = v;
  }
  get value() {
    return this.data2;
  }
  set value(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, controller: this.controller, value: this.value };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, controller: ${hex(this.controller)}, value: ${hex(this.value)}`;
  }
};
var ProgramChange = class extends MidiMessage {
  constructor(c, n) {
    super();
    this.id = "program";
    this.status = 192;
    this.channel = c;
    this.program = n;
  }
  get program() {
    return this.data1 + 1;
  }
  set program(v) {
    v--;
    this.data1 = v;
  }
  get args() {
    return { channel: this.channel, program: this.program };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, program: ${hex(this.program)}`;
  }
};
var ChannelPressure = class extends MidiMessage {
  constructor(c, p) {
    super();
    this.id = "channelpressure";
    this.status = 208;
    this.channel = c;
    this.pressure = p;
  }
  get pressure() {
    return this.data1;
  }
  set pressure(v) {
    this.data1 = v;
  }
  get args() {
    return { channel: this.channel, pressure: this.pressure };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, pressure: ${hex(this.pressure)}`;
  }
};
var PitchWheel = class extends MidiMessage {
  constructor(c, v) {
    super();
    this.id = "pitch";
    this.status = 224;
    this.channel = c;
    this.value = v;
  }
  get value() {
    return (this.data2 << 7) + this.data1;
  }
  set value(v) {
    v = MidiMessage.constrain(v, MAX_14_BIT);
    this.data2 = v >> 7 & 127;
    this.data1 = v & 127;
  }
  get args() {
    return { channel: this.channel, value: this.value };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, value: ${hex(this.value)}`;
  }
};
var Sysex = class extends MidiMessage {
  constructor(b) {
    super();
    this.id = "sysex";
    this.bytes = b;
  }
  get args() {
    return { bytes: this.bytes };
  }
  toString() {
    return `${super.toString()}, bytes: ${this.bytes}`;
  }
};
var Mtc = class extends MidiMessage {
  constructor(t, v) {
    super();
    this.id = "mtc";
    this.status = 241;
    this.type = t;
    this.value = v;
  }
  get type() {
    return this.data1 >> 4 & 7;
  }
  set type(v) {
    this.data1 = this.data1 & 15 | v << 4;
  }
  get value() {
    return this.data1 & 15;
  }
  set value(v) {
    v = MidiMessage.constrain(v, 15);
    this.data1 = this.data1 & 240 | v;
  }
  get args() {
    return { channel: this.channel, type: this.type, value: this.value };
  }
  toString() {
    return `${super.toString()}, type: ${hex(this.type)}, value: ${hex(this.value)}`;
  }
};

// dist/midi/midi.js
var Input2 = class extends EventEmitter2 {
  _input;
  _smpte;
  name;
  constructor(name, virtual) {
    super();
    this._input = new node_midi.Input();
    this._input.ignoreTypes(false, false, false);
    this._smpte = [];
    this.name = name;
    const inputPortNumberedNames = getInputs();
    if (virtual) {
      this._input.openVirtualPort(name);
    } else {
      const numInputs = this._input.getPortCount();
      for (let i = 0; i < numInputs; i++) {
        if (name === inputPortNumberedNames[i]) {
          try {
            this._input.openPort(i);
          } catch (err) {
            console.log(`Error opening port ${name}.
Error: ${err}`);
          }
        }
      }
    }
    this._input.on("message", (deltaTime, bytes) => {
      const msg = MidiMessage.parseMessage(bytes);
      if (msg === void 0)
        return;
      this.emit("message", deltaTime, msg);
      if (msg.id == "mtc") {
        this.parseMtc(msg);
      }
    });
  }
  close() {
    this._input.closePort();
    this._input.destroy();
  }
  isPortOpen() {
    return this._input.isPortOpen();
  }
  parseMtc(data) {
    const FRAME_RATES = [24, 25, 29.97, 30];
    const byteNumber = data.type;
    let value = data.value;
    let smpteFrameRate;
    this._smpte[byteNumber] = value;
    if (byteNumber === 7 && typeof this._smpte[0] === "number") {
      const bits = [];
      for (let i = 3; i >= 0; i--) {
        const bit = value & 1 << i ? 1 : 0;
        bits.push(bit);
      }
      value = bits[3];
      smpteFrameRate = FRAME_RATES[(bits[1] << 1) + bits[2]];
      this._smpte[byteNumber] = value;
      const smpte = this._smpte;
      const smpteFormatted = ((smpte[7] << 4) + smpte[6]).toString().padStart(2, "0") + ":" + ((smpte[5] << 4) + smpte[4]).toString().padStart(2, "0") + ":" + ((smpte[3] << 4) + smpte[2]).toString().padStart(2, "0") + "." + ((smpte[1] << 4) + smpte[0]).toString().padStart(2, "0");
      this.emit("smpte", {
        smpte: smpteFormatted,
        smpteFR: smpteFrameRate
      });
    }
  }
};
var Output2 = class {
  _output;
  name;
  constructor(name, virtual) {
    this._output = new node_midi.Output();
    this.name = name;
    const outputPortNumberedNames = getOutputs();
    if (virtual) {
      this._output.openVirtualPort(name);
    } else {
      const numOutputs = this._output.getPortCount();
      for (let i = 0; i < numOutputs; i++) {
        if (name === outputPortNumberedNames[i]) {
          try {
            this._output.openPort(i);
          } catch (err) {
            console.log(`Error opening port ${name}.
Error: ${err}`);
          }
        }
      }
    }
  }
  close() {
    this._output.closePort();
    this._output.destroy();
  }
  isPortOpen() {
    return this._output.isPortOpen();
  }
  send(msg) {
    this._output.sendMessage(msg.bytes);
  }
};
function getInputs() {
  const input = new node_midi.Input();
  const inputs = [];
  for (let i = 0; i < input.getPortCount(); i++) {
    let counter = 0;
    const portName = input.getPortName(i);
    let numberedPortName = portName;
    while (inputs.includes(numberedPortName)) {
      counter++;
      numberedPortName += ` ${counter}`;
    }
    inputs.push(numberedPortName);
  }
  input.closePort();
  return inputs;
}
function getOutputs() {
  const output = new node_midi.Output();
  const outputs = [];
  for (let i = 0; i < output.getPortCount(); i++) {
    let counter = 0;
    const portName = output.getPortName(i);
    let numberedPortName = portName;
    while (outputs.includes(numberedPortName)) {
      counter++;
      numberedPortName += ` ${counter}`;
    }
    outputs.push(numberedPortName);
  }
  output.closePort();
  return outputs;
}

// dist/config.js
function GetConfigFields() {
  const inPortNames = [];
  const outPortNames = [];
  const inPorts = getInputs();
  const outPorts = getOutputs();
  inPorts.forEach((m) => {
    inPortNames.push({ id: m, label: m });
  });
  outPorts.forEach((m) => {
    outPortNames.push({ id: m, label: m });
  });
  return [
    {
      type: "dropdown",
      id: "inPortName",
      label: "MIDI In",
      width: 6,
      default: inPorts[0] || "NONE DETECTED",
      choices: inPortNames
      //	isVisible: (opts) => !opts.inPortIsVirtual,
    },
    /*
    {
        type: 'textinput',
        id: 'inPortVirtualName',
        label: 'MIDI In',
        width: 6,
        default: '',
        isVisible: (opts) => !!opts.inPortIsVirtual,
    },
    {
        type: 'checkbox',
        id: 'inPortIsVirtual',
        label: 'Virtual',
        width: 6,
        default: false,
    },
    */
    {
      type: "dropdown",
      id: "outPortName",
      label: "MIDI Out",
      width: 6,
      default: outPorts[0] || "NONE DETECTED",
      choices: outPortNames
      //	isVisible: (opts) => !opts.outPortIsVirtual,
    },
    /*
    {
        type: 'textinput',
        id: 'outPortVirtualName',
        label: 'MIDI Out',
        width: 6,
        default: '',
        isVisible: (opts) => !!opts.outPortIsVirtual,
    },
    {
        type: 'checkbox',
        id: 'outPortIsVirtual',
        label: 'Virtual',
        width: 6,
        default: false,
    },
    {
        type: 'static-text',
        id: 'customText',
        label: 'Choose existing ports, or type a custom name to create a Virtual Port',
        width: 12,
        value: '',
    },
    */
    {
      type: "checkbox",
      id: "useTimeStamp",
      label: "Use TimeStamp with Action Recorder",
      tooltip: "Enable this setting to include the delay time for actions created in Action Recorder",
      width: 6,
      default: false
    },
    {
      type: "checkbox",
      id: "autoCreateVars",
      label: 'Enable "Auto-Created Variables function"',
      tooltip: "Enable this setting ONLY if you need compatibility with existing Auto-Created variables",
      width: 6,
      default: false
    },
    {
      type: "static-text",
      id: "autoCreateVarNotice",
      label: '*** Support for the deprecated "Auto-Created Variable" function ***',
      value: 'The "Auto-Create Variable" function has now been superceded by the built-in Local Variables feature within Companion 4.2+.<br>If you still have auto-created variables, please change them to Value Feedbacks as support for Auto-Created Variables may disappear in the future!',
      tooltip: "Enable this setting ONLY if you need compatibility with existing Auto-Created variables",
      width: 12
    }
  ];
}

// dist/variables.js
var variables = {
  midiIn: { name: "Is a MIDI Message Incoming?" },
  midiOut: { name: "Is a MIDI Message Outgoing?" },
  lastMessage: { name: "Last Message Received" },
  smpte: { name: "SMPTE TC from MTC" },
  smpteFR: { name: "SMPTE Frame Rate from MTC" },
  noteStates: { name: "Current Note states" }
};
var midiTimers = /* @__PURE__ */ new Map();
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions(variables);
  self.setVariableValues({ midiIn: false, midiOut: false });
}
function HandleMidiIndicators(self, variable) {
  let t = midiTimers.get(variable) ?? null;
  if (t !== null)
    clearTimeout(t);
  t = setTimeout(() => {
    self.setVariableValues({ [variable]: false });
    self.checkFeedbacks(variable);
  }, 200);
  midiTimers.set(variable, t);
  self.setVariableValues({ [variable]: true });
  self.checkFeedbacks(variable);
}
function UpdateLastMsg(self, msg, data) {
  const msgInfo = CreateVarName(msg);
  const lastMsg = msgInfo.name + "_" + data;
  self.setVariableValues({ lastMessage: lastMsg });
  AddOrUpdateVar(self, "lastMsgType", "Last Message Type Received", msg.id);
  if (msg.id == "noteon" || msg.id == "noteoff") {
    const channelIndex = msg.channel - 1;
    self.noteStates[channelIndex] ??= [];
    self.noteStates[channelIndex][msg.args.note] = msg.id == "noteon" && data > 0;
    self.setVariableValues({ noteStates: structuredClone(self.noteStates) });
  }
  for (let i = 0; i < msgInfo.keys.length; i++) {
    const keyName = msgInfo.keys[i];
    const key = keyName;
    const CapKeyName = keyName[0].toUpperCase() + keyName.slice(1);
    AddOrUpdateVar(self, "last" + CapKeyName, "Last " + CapKeyName + " Received", Number(msg.args[key]));
  }
}
function FBCreatesVar(self, msg, data) {
  AddOrUpdateVar(self, "_" + CreateVarName(msg).name, "Auto-Created Variable", data);
}
function CreateVarName(msg) {
  let varName = msg.id;
  const msgKeys = Object.keys(msg.args);
  for (let i = 0; i < msgKeys.length - 1; i++) {
    const key = msgKeys[i];
    const val = Number(msg.args[key]);
    if (val !== void 0) {
      varName += `_${val}`;
    }
  }
  return { name: varName, keys: msgKeys };
}
function AddOrUpdateVar(self, varName, varDescr, data) {
  ;
  variables[varName] = { name: varDescr };
  self.setVariableDefinitions(variables);
  self.setVariableValues({ [varName]: data });
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  function(_context, props) {
    const changes = {
      updatedConfig: null,
      updatedActions: [],
      updatedFeedbacks: []
    };
    for (const a of props.actions) {
      let changed = false;
      if (a.actionId == "program" && a.options.number !== void 0) {
        const program = a.options.number;
        if (program !== void 0 && a.options.program === void 0)
          a.options.program = program;
        delete a.options.number;
        changed = true;
      }
      if (changed)
        changes.updatedActions.push(a);
    }
    for (const f of props.feedbacks) {
      if (f.feedbackId == "receive_message") {
        const msgType = f.options.msgType;
        const rawId = msgType && !msgType.isExpression ? msgType.value : void 0;
        const id = typeof rawId === "string" || typeof rawId === "number" ? String(rawId) : "";
        if (!id)
          continue;
        f.feedbackId = id;
        delete f.options.msgType;
        let key;
        switch (f.feedbackId) {
          case "program":
            key = "number";
            break;
          case "sysex":
            key = "message";
            break;
          case "pitch":
            key = "pitch";
            break;
        }
        if (key && f.options[key] !== void 0) {
          f.options[key === "number" ? "program" : key === "message" ? "bytes" : "value"] = f.options[key];
          delete f.options[key];
        }
        changes.updatedFeedbacks.push(f);
      }
    }
    return changes;
  },
  function(_context, props) {
    const changes = {
      updatedConfig: null,
      updatedActions: [],
      updatedFeedbacks: []
    };
    for (const a of props.actions) {
      if (a.actionId === "sysex")
        continue;
      let changed = false;
      if (!a.options.sendOverTime) {
        a.options.sendOverTime = { isExpression: false, value: false };
        changed = true;
      }
      if (!a.options.timeStartValue) {
        a.options.timeStartValue = { isExpression: false, value: 0 };
        changed = true;
      }
      if (!a.options.time) {
        a.options.time = { isExpression: false, value: 1 };
        changed = true;
      }
      if (!a.options.curve) {
        a.options.curve = { isExpression: false, value: "linear" };
        changed = true;
      }
      if (changed)
        changes.updatedActions.push(a);
    }
    return changes;
  },
  function(context, props) {
    const changes = {
      updatedConfig: null,
      updatedActions: [],
      updatedFeedbacks: []
    };
    let enableAutoCreateVars = false;
    for (const action of props.actions) {
      if (action.options.useVariables?.value !== true)
        continue;
      const valId = action.actionId === "program" ? "program" : action.actionId === "sysex" ? "bytes" : action.actionId === "noteon" || action.actionId === "noteoff" ? "velocity" : "value";
      for (const [oldKey, newKey] of [
        ["chValue", "channel"],
        ["noteValue", "note"],
        ["ccValue", "controller"],
        ["varValue", valId]
      ]) {
        const value = action.options[oldKey];
        if (value !== void 0)
          action.options[newKey] = FixupNumericOrVariablesValueToExpressions(value);
        delete action.options[oldKey];
      }
      delete action.options.useVariables;
      changes.updatedActions.push(action);
    }
    for (const feedback of props.feedbacks) {
      if (feedback.options.createVar?.value === true)
        enableAutoCreateVars = true;
      if (feedback.options.useVariables?.value !== true)
        continue;
      const valId = feedback.feedbackId === "program" ? "program" : feedback.feedbackId === "sysex" ? "bytes" : feedback.feedbackId === "noteon" || feedback.feedbackId === "noteoff" ? "velocity" : "value";
      for (const [oldKey, newKey] of [
        ["chValue", "channel"],
        ["noteValue", "note"],
        ["ccValue", "controller"],
        ["varValue", valId]
      ]) {
        const value = feedback.options[oldKey];
        if (value !== void 0)
          feedback.options[newKey] = FixupNumericOrVariablesValueToExpressions(value);
        delete feedback.options[oldKey];
      }
      delete feedback.options.useVariables;
      changes.updatedFeedbacks.push(feedback);
    }
    if (enableAutoCreateVars && !context.currentConfig.autoCreateVars) {
      changes.updatedConfig = { ...context.currentConfig, autoCreateVars: true };
    }
    return changes;
  }
];

// dist/operations.js
var midiMsgTypes = [
  {
    id: "noteoff",
    label: "Note Off",
    desc: "Note Off Messsage",
    valId: "velocity",
    valLabel: "Velocity",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  },
  {
    id: "noteon",
    label: "Note On",
    desc: "Note On Message",
    valId: "velocity",
    valLabel: "Velocity",
    valMin: 0,
    valMax: 127,
    valDefault: 127
  },
  //		{ id: 'aftertouch', name: 'Aftertouch' },
  {
    id: "cc",
    label: "CC",
    desc: "Control Change Message",
    valId: "value",
    valLabel: "Value",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  },
  {
    id: "program",
    label: "Program Change",
    desc: "Program Change Message",
    valId: "program",
    valLabel: "Program Number",
    valMin: 1,
    valMax: 128,
    valDefault: 1
  },
  //		{ id: 'channelpressure', 	name: 'Channel Pressure' },
  {
    id: "pitch",
    label: "Pitch Wheel",
    desc: "Pitch Wheel Message",
    valId: "value",
    valLabel: "Value",
    valMin: 0,
    valMax: 16383,
    valDefault: 8192
  },
  {
    id: "sysex",
    label: "SysEx",
    desc: "System Exclusive Message",
    valId: "bytes",
    valLabel: "SysEx Bytes",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  }
  //		{ id: 'mtc', 				name: 'MIDI Time Code' },
  //		{ id: 'position',			name: 'Song Position Pointer' },
  //		{ id: 'select',				name: 'Song Select' },
  //		{ id: 'tune',				name: 'Tune Request' },
  //		{ id: 'sysex end',			name: 'SysEx End' },
  //		{ id: 'clock',				name: 'Clock' },
  //		{ id: 'start',				name: 'Start' },
  //		{ id: 'continue',			name: 'Continue' },
  //		{ id: 'stop',				name: 'Stop' },
  //		{ id: 'activesense',		name: 'Active Sensing' },
  //		{ id: 'reset',				name: 'Reset' },
];
function createOptions(newOpts, midiOp) {
  if (["noteoff", "noteon", "cc", "program", "pitch"].includes(midiOp.id)) {
    newOpts.push({
      id: "channel",
      type: "number",
      label: "Channel",
      default: 1,
      min: 1,
      max: 16
    });
  }
  if (["noteoff", "noteon"].includes(midiOp.id)) {
    newOpts.push({
      id: "note",
      type: "number",
      label: "Note Number",
      default: 60,
      min: 0,
      max: 127
    });
  }
  if (midiOp.id == "cc") {
    newOpts.push({
      id: "controller",
      type: "number",
      label: "Controller",
      default: 127,
      min: 0,
      max: 127
    });
  }
  if (midiOp.id != "sysex") {
    newOpts.push({
      id: midiOp.valId,
      type: "number",
      label: midiOp.valLabel,
      default: midiOp.valDefault,
      min: midiOp.valMin,
      max: midiOp.valMax
    });
  } else {
    newOpts.push({
      id: "bytes",
      type: "textinput",
      label: midiOp.valLabel,
      tooltip: "Enter a string of decimal or hex digits, with spaces or commas between. MUST start with 0xF0 or 240 and end with 0xF7 or 247",
      default: "",
      useVariables: true
    });
  }
  return newOpts;
}

// dist/actions.js
function UpdateActions(self) {
  self.setVariableValues({ midiOut: false });
  const actions = {};
  for (const action of midiMsgTypes) {
    const newAction = {
      name: String(action.label),
      options: createOptions([], action),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        if (!self.config.outPortIsVirtual && !self.midiOutput.isPortOpen()) {
          self.log("error", `Output Port "${self.midiOutput.name}" not open!`);
          return;
        }
        if (action.id == "sysex") {
          const parsedSysex = String(opts[action.valId] ?? "");
          const bytes = parsedSysex.trim().split(/[\s,]+/).filter(Boolean).map((n) => /^0x/i.test(n) ? Number.parseInt(n.slice(2), 16) : Number(n));
          if (bytes.some((byte) => !Number.isInteger(byte) || byte < 0 || byte > 255) || bytes[0] !== 240 || bytes.at(-1) !== 247) {
            self.log("warn", "Invalid SysEx message. Bytes must be integers from 0 to 255 and start with F0 and end with F7.");
            return;
          }
          opts.bytes = bytes;
        }
        if (opts.relValue) {
          opts[action.valId] = Number(opts.varValue);
          if (!Number.isFinite(opts[action.valId])) {
            self.log("warn", "Invalid relative MIDI value");
            return;
          }
        }
        let msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
        if (!msg)
          return;
        if (opts.relValue) {
          const val = self.getFromDataStore(msg);
          if (val === void 0) {
            self.log("info", "Relative value not sent. Current value from device is needed!");
            return;
          }
          opts[action.valId] = val + Number(opts[action.valId] * 1);
        }
        if (opts.sendOverTime) {
          const durationMs = opts.time * 1e3;
          const curve = opts.curve;
          const tickMs = 15;
          let start = 0;
          if (opts.relValue) {
            start = self.getFromDataStore(msg) ?? 0;
          } else {
            start = Number(opts.timeStartValue);
          }
          let end = Number(opts[action.valId] * 1);
          if (end < 0) {
            end = 0;
          } else if (end > 127) {
            end = 127;
          }
          if (start > end) {
          }
          const t0 = Date.now();
          let last = -1;
          const easeFunctions = {
            linear: (x) => x,
            easeIn: (x) => x * x,
            easeOut: (x) => 1 - (1 - x) * (1 - x),
            easeInOut: (x) => x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2
          };
          const ease = easeFunctions[curve] || ((x) => x);
          const timer = setInterval(() => {
            const elapsed = Date.now() - t0;
            const u = Math.min(1, elapsed / durationMs);
            const val = Math.round(start + (end - start) * ease(u));
            if (val !== last) {
              opts[action.valId] = val;
              msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
              self.log("debug", `Sending:  ${msg} to "${self.midiOutput.name}"`);
              if (msg)
                self.midiOutput.send(msg);
              HandleMidiIndicators(self, "midiOut");
              last = val;
            }
            if (u >= 1)
              clearInterval(timer);
          }, tickMs);
        } else {
          msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
          if (!msg)
            return;
          self.log("debug", `Sending:  ${msg} to "${self.midiOutput.name}"`);
          self.midiOutput.send(msg);
          HandleMidiIndicators(self, "midiOut");
        }
      }
    };
    if (action.id != "sysex") {
      const valueOption = newAction.options.at(-1);
      if (valueOption)
        valueOption.isVisibleExpression = "!$(options:relValue)";
      newAction.options.push({
        id: "varValue",
        type: "number",
        label: action.valLabel,
        default: 0,
        min: -action.valMax,
        max: action.valMax,
        isVisibleExpression: "!!$(options:relValue)"
      }, {
        id: "relText",
        type: "static-text",
        label: "** NOTE **",
        value: "Relative will only work after a value has been sent from the device!",
        isVisibleExpression: "$(options:relValue)"
      }, {
        id: "relValue",
        type: "checkbox",
        label: "Relative",
        default: false,
        disableAutoExpression: true
      });
      newAction.options.push({
        id: "sendOverTime",
        type: "checkbox",
        label: "Send Over Time",
        default: false,
        disableAutoExpression: true
      }, {
        id: "timeStartValue",
        type: "number",
        label: "Start Value",
        default: 0,
        min: 0,
        max: 127,
        isVisibleExpression: "!!$(options:sendOverTime) && !$(options:relValue)"
      }, {
        id: "time",
        type: "number",
        label: "Time (seconds)",
        default: 1,
        min: 0,
        max: 600,
        isVisibleExpression: "$(options:sendOverTime)"
      }, {
        id: "curve",
        type: "dropdown",
        label: "Curve Type",
        default: "linear",
        choices: [
          { label: "Linear", id: "linear" },
          { label: "Ease In", id: "easeIn" },
          { label: "Ease Out", id: "easeOut" },
          { label: "Ease In/Out", id: "easeInOut" }
        ],
        isVisibleExpression: "$(options:sendOverTime)"
      });
    }
    actions[action.id] = newAction;
  }
  self.setActionDefinitions(actions);
}

// dist/feedbacks.js
function UpdateFeedbacks(self) {
  const feedbacks = {};
  for (const feedback of midiMsgTypes) {
    const newFeedback = {
      name: feedback.label,
      description: feedback.desc,
      type: "boolean",
      defaultStyle: {
        bgcolor: combineRgb(255, 0, 0),
        color: combineRgb(0, 0, 0)
      },
      options: createOptions([], feedback),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        if (event.feedbackId == "sysex") {
          const parsedSysex = String(opts[feedback.valId] ?? "");
          const bytes = parsedSysex.trim().split(/[\s,]+/).filter(Boolean).map((n) => /^0x/i.test(n) ? Number.parseInt(n.slice(2), 16) : Number(n));
          if (bytes.some((byte) => !Number.isInteger(byte) || byte < 0 || byte > 255) || bytes[0] !== 240 || bytes.at(-1) !== 247)
            return false;
          opts.bytes = bytes;
        }
        const msg = MidiMessage.parseMessage(void 0, { id: event.feedbackId, ...opts });
        if (!msg)
          return false;
        const dataStoreVal = self.getFromDataStore(msg);
        if (event.feedbackId !== "sysex" && opts.createVar && self.config.autoCreateVars && msg !== void 0)
          FBCreatesVar(self, msg, dataStoreVal);
        if (dataStoreVal == void 0)
          return false;
        if (dataStoreVal == self.getValFromMsg(msg).val) {
          return true;
        }
        return false;
      }
    };
    if (feedback.id != "sysex" && self.config.autoCreateVars) {
      const valueOption = newFeedback.options.at(-1);
      if (valueOption)
        valueOption.isVisibleExpression = "!$(options:createVar)";
      newFeedback.options.push({
        id: "createVar",
        type: "checkbox",
        label: "Auto-Create Variable",
        default: false,
        disableAutoExpression: true
      });
    }
    feedbacks[feedback.id] = newFeedback;
    if (feedback.id !== "sysex") {
      feedbacks[feedback.id + "_value"] = {
        name: feedback.label + " Value",
        description: feedback.desc,
        type: "value",
        options: newFeedback.options.filter((o) => o.id !== feedback.valId && o.id !== "createVar"),
        callback: async (event) => {
          const opts = JSON.parse(JSON.stringify(event.options));
          const msgId = event.feedbackId.replace("_value", "");
          const msg = MidiMessage.parseMessage(void 0, { id: msgId, ...opts });
          if (!msg)
            return void 0;
          const value = self.getFromDataStore(msg);
          if (value === void 0)
            return void 0;
          return msgId === "program" ? value + 1 : value;
        }
      };
    }
  }
  feedbacks["midiIn"] = {
    name: "MIDI Message Incoming?",
    description: "Fire whenever ANY MIDI message is received",
    type: "boolean",
    defaultStyle: {
      bgcolor: combineRgb(255, 0, 0),
      color: combineRgb(0, 0, 0)
    },
    options: [],
    callback: async () => {
      return !!self.getVariableValue("midiIn");
    }
  };
  feedbacks["midiOut"] = {
    name: "MIDI Message Outgoing?",
    description: "Fire whenever ANY MIDI message is sent",
    type: "boolean",
    defaultStyle: {
      bgcolor: combineRgb(255, 0, 0),
      color: combineRgb(0, 0, 0)
    },
    options: [],
    callback: async () => {
      return !!self.getVariableValue("midiOut");
    }
  };
  self.setFeedbackDefinitions(feedbacks);
}

// dist/presets.js
function UpdatePresets(self) {
  const presets = {
    midi_in: {
      type: "simple",
      name: `MIDI Message In Indicator`,
      style: {
        text: `MIDI IN`,
        size: "auto",
        color: combineRgb(255, 255, 255),
        bgcolor: combineRgb(0, 0, 0)
      },
      steps: [],
      feedbacks: [
        {
          feedbackId: "midiIn",
          options: {},
          style: {
            color: combineRgb(255, 255, 255),
            bgcolor: combineRgb(0, 255, 0)
          }
        }
      ]
    },
    midi_out: {
      type: "simple",
      name: `MIDI Message Out Indicator`,
      style: {
        text: `MIDI OUT`,
        size: "auto",
        color: combineRgb(255, 255, 255),
        bgcolor: combineRgb(0, 0, 0)
      },
      steps: [],
      feedbacks: [
        {
          feedbackId: "midiOut",
          options: {},
          style: {
            color: combineRgb(255, 255, 255),
            bgcolor: combineRgb(0, 255, 0)
          }
        }
      ]
    }
  };
  const structure = [
    {
      id: "indicators",
      name: "Indicators",
      definitions: [
        {
          id: "midi_indicators",
          type: "simple",
          name: "MIDI Indicators",
          presets: ["midi_in", "midi_out"]
        }
      ]
    }
  ];
  self.setPresetDefinitions(structure, presets);
}

// dist/main.js
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  midiInput;
  midiOutput;
  dataStore;
  isRecordingActions;
  noteStates = [];
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    this.dataStore = /* @__PURE__ */ new Map();
    this.updateActions();
    this.updateFeedbacks();
    this.updatePresets();
    this.updateVariableDefinitions();
    await this.configUpdated(config);
  }
  // When module gets deleted
  async destroy() {
    this.midiInput.close();
    this.midiOutput.close();
    this.log("debug", `${this.id} destroyed`);
  }
  async configUpdated(config) {
    const autoCreateVarsChanged = this.config?.autoCreateVars !== config.autoCreateVars;
    this.config = config;
    if (autoCreateVarsChanged)
      this.updateFeedbacks();
    this.config.inPortIsVirtual = false;
    this.config.outPortIsVirtual = false;
    const inPortName = this.config.inPortIsVirtual ? this.config.inPortVirtualName : this.config.inPortName;
    const outPortName = this.config.outPortIsVirtual ? this.config.outPortVirtualName : this.config.outPortName;
    this.log("debug", `Available MIDI Inputs: ${JSON.stringify(getInputs())}
	Selected MIDI Input:  ${inPortName}`);
    this.log("debug", `Available MIDI Outputs: ${JSON.stringify(getOutputs())}
	Selected MIDI Output: ${outPortName}`);
    this.log("debug", "");
    if (this.midiInput)
      this.midiInput.close();
    if (this.midiOutput)
      this.midiOutput.close();
    this.midiInput = new Input2(inPortName, this.config.inPortIsVirtual);
    this.midiOutput = new Output2(outPortName, this.config.outPortIsVirtual);
    const midiInStatus = this.config.inPortIsVirtual || this.midiInput.isPortOpen();
    const midiOutStatus = this.config.outPortIsVirtual || this.midiOutput.isPortOpen();
    this.log("info", `Selected In  Port "${this.midiInput.name}" is ${midiInStatus ? "" : "NOT "}Open.`);
    this.log("info", `Selected Out Port "${this.midiOutput.name}" is ${midiOutStatus ? "" : "NOT "}Open.`);
    this.updateStatus(InstanceStatus.Disconnected);
    if (!midiInStatus && midiOutStatus)
      this.updateStatus(InstanceStatus.BadConfig, "MIDI In Port not open");
    if (midiInStatus && !midiOutStatus)
      this.updateStatus(InstanceStatus.BadConfig, "MIDI Out Port not open");
    if (midiInStatus && midiOutStatus)
      this.updateStatus(InstanceStatus.Ok);
    this.start();
  }
  // Return config fields for web config
  getConfigFields() {
    return GetConfigFields();
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updatePresets() {
    UpdatePresets(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  // The main loop
  start() {
    this.log("debug", "\nEntering *main*\n");
    this.midiInput.on("smpte", (args) => {
      this.setVariableValues({
        smpte: args.smpte,
        smpteFR: args.smpteFR
      });
    });
    this.midiInput.on("message", (deltaTime, msg) => {
      if (msg.id !== "mtc") {
        this.log("debug", `[${deltaTime.toFixed(2).padStart(6, "0")}] Received: ${msg} from "${this.midiInput.name}"`);
        this.addToDataStore(msg);
        if (this.isRecordingActions)
          this.addToActionRecording(deltaTime, msg);
      }
      HandleMidiIndicators(this, "midiIn");
    });
  }
  addToDataStore(msg) {
    const data = this.getValFromMsg(msg);
    if (data.key > 0) {
      UpdateLastMsg(this, msg, data.val);
      this.dataStore.set(data.key, data.val);
      this.checkAllFeedbacks();
    }
  }
  getFromDataStore(msg) {
    const data = this.getValFromMsg(msg);
    if (data.key > 0) {
      return this.dataStore.get(data.key);
    }
    return void 0;
  }
  getValFromMsg(msg) {
    let lastIndex = msg.bytes.length - 1;
    let parsedKey = 0;
    let parsedVal = 0;
    if (lastIndex >= 0 && msg.status < 240) {
      if (msg.id == "pitch") {
        parsedVal = msg.args.value ?? 0;
        lastIndex--;
      } else {
        parsedVal = msg.bytes[lastIndex];
      }
      for (let i = 0; i < lastIndex; i++) {
        parsedKey += msg.bytes[i] << (lastIndex - i - 1 << 3);
      }
      if (parsedKey == 0)
        parsedKey = parsedVal;
    }
    return { key: parsedKey, val: parsedVal };
  }
  // Track whether actions are being recorded
  handleStartStopRecordActions(isRecording) {
    this.isRecordingActions = isRecording;
  }
  // Add a command to the Action Recorder
  addToActionRecording(deltaTime, msg) {
    const args = { ...msg.args };
    if (msg.id === "sysex" && args.bytes) {
      args.bytes = args.bytes.map((byte) => `0x${byte.toString(16).padStart(2, "0")}`);
    }
    let uniqueId = `${msg.id} ${this.getValFromMsg(msg).key}`;
    if (this.config.useTimeStamp) {
      deltaTime = Math.round(deltaTime * 1e3);
      uniqueId = "";
    } else {
      deltaTime = 0;
    }
    this.recordAction({
      actionId: msg.id,
      options: args,
      delay: deltaTime
    }, uniqueId);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL3BrZy1wcmVidWlsZHMvbGliL3ByZWJ1aWxkLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9wa2ctcHJlYnVpbGRzL2JpbmRpbmdzLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AanVsdXNpYW4vbWlkaS9iaW5kaW5nLW9wdGlvbnMuanMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0BqdWx1c2lhbi9taWRpL2xpYi9pbnN0cnVtZW50cy5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGp1bHVzaWFuL21pZGkvbGliL2RydW1zLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AanVsdXNpYW4vbWlkaS9saWIvbm90ZXMuanMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0BqdWx1c2lhbi9taWRpL2xpYi9tZXNzYWdlcy5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGp1bHVzaWFuL21pZGkvbWlkaS5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbG9nZ2luZy50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvdXRpbC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9zaGFyZWQtdWRwLXNvY2tldC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvaG9zdC1hcGkvY29udGV4dC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9iYXNlLnRzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AY29tcGFuaW9uLW1vZHVsZS9iYXNlL3NyYy9tb2R1bGUtYXBpL2VudW1zLnRzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AY29tcGFuaW9uLW1vZHVsZS9iYXNlL3NyYy9tb2R1bGUtYXBpL3VwZ3JhZGUudHMiLCAiLi4vLi4vc3JjL21pZGkvbWlkaS50cyIsICIuLi8uLi9zcmMvbWlkaS9tc2d0eXBlcy50cyIsICIuLi8uLi9zcmMvY29uZmlnLnRzIiwgIi4uLy4uL3NyYy92YXJpYWJsZXMudHMiLCAiLi4vLi4vc3JjL3VwZ3JhZGVzLnRzIiwgIi4uLy4uL3NyYy9vcGVyYXRpb25zLnRzIiwgIi4uLy4uL3NyYy9hY3Rpb25zLnRzIiwgIi4uLy4uL3NyYy9mZWVkYmFja3MudHMiLCAiLi4vLi4vc3JjL3ByZXNldHMudHMiLCAiLi4vLi4vc3JjL21haW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKVxuXG4vKipcbiAqIEdlbmVyYXRlIHRoZSBmaWxlbmFtZSBvZiB0aGUgcHJlYnVpbGQgZmlsZS5cbiAqIFRoZSBmb3JtYXQgb2YgdGhlIG5hbWUgaXMgcG9zc2libGUgdG8gY2FsY3VsYXRlIGJhc2VkIG9uIHNvbWUgb3B0aW9uc1xuICogQHBhcmFtIHtvYmplY3R9IG9wdGlvbnNcbiAqIEByZXR1cm5zXG4gKi9cbmZ1bmN0aW9uIGdldFByZWJ1aWxkTmFtZShvcHRpb25zKSB7XG5cdGlmICghb3B0aW9ucy5uYXBpX3ZlcnNpb24pIHRocm93IG5ldyBFcnJvcignTkFOIG5vdCBpbXBsZW1lbnRlZCcpIC8vIFRPRE9cblxuXHRjb25zdCB0b2tlbnMgPSBbXG5cdFx0b3B0aW9ucy5uYW1lLFxuXHRcdG9wdGlvbnMucGxhdGZvcm0sXG5cdFx0b3B0aW9ucy5hcmNoLFxuXHRcdC8vIG9wdGlvbnMuYXJtdiA/IChvcHRpb25zLmFyY2ggPT09ICdhcm02NCcgPyAnOCcgOiB2YXJzLmFybV92ZXJzaW9uKSA6IG51bGwsXG5cdFx0b3B0aW9ucy5saWJjICYmIG9wdGlvbnMucGxhdGZvcm0gPT09ICdsaW51eCcgPyBvcHRpb25zLmxpYmMgOiBudWxsLFxuXHRdXG5cdHJldHVybiBgJHt0b2tlbnMuZmlsdGVyKCh0KSA9PiAhIXQpLmpvaW4oJy0nKX0vJHtvcHRpb25zLnJ1bnRpbWV9LW5hcGktdiR7b3B0aW9ucy5uYXBpX3ZlcnNpb259Lm5vZGVgXG59XG5cbmZ1bmN0aW9uIGlzTndqcygpIHtcblx0cmV0dXJuICEhKHByb2Nlc3MudmVyc2lvbnMgJiYgcHJvY2Vzcy52ZXJzaW9ucy5udylcbn1cblxuZnVuY3Rpb24gaXNFbGVjdHJvbigpIHtcblx0aWYgKHByb2Nlc3MudmVyc2lvbnMgJiYgcHJvY2Vzcy52ZXJzaW9ucy5lbGVjdHJvbikgcmV0dXJuIHRydWVcblx0aWYgKHByb2Nlc3MuZW52LkVMRUNUUk9OX1JVTl9BU19OT0RFKSByZXR1cm4gdHJ1ZVxuXHRyZXR1cm4gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiYgd2luZG93LnByb2Nlc3MgJiYgd2luZG93LnByb2Nlc3MudHlwZSA9PT0gJ3JlbmRlcmVyJ1xufVxuXG5mdW5jdGlvbiBpc0FscGluZShwbGF0Zm9ybSkge1xuXHRyZXR1cm4gcGxhdGZvcm0gPT09ICdsaW51eCcgJiYgZnMuZXhpc3RzU3luYygnL2V0Yy9hbHBpbmUtcmVsZWFzZScpXG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXHRnZXRQcmVidWlsZE5hbWUsXG5cdGlzTndqcyxcblx0aXNFbGVjdHJvbixcblx0aXNBbHBpbmUsXG59XG4iLCAiY29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKVxuY29uc3Qgb3MgPSByZXF1aXJlKCdvcycpXG5jb25zdCB7IGdldFByZWJ1aWxkTmFtZSwgaXNOd2pzLCBpc0VsZWN0cm9uLCBpc0FscGluZSB9ID0gcmVxdWlyZSgnLi9saWIvcHJlYnVpbGQnKVxuXG4vLyBKZXN0IGNhbiBhbGxvdyB1c2VycyB0byBtb2NrICdmcycsIGJ1dCB3ZSBuZWVkIHRoZSByZWFsIGZzXG5jb25zdCBmcyA9IHR5cGVvZiBqZXN0ICE9PSAndW5kZWZpbmVkJyA/IGplc3QucmVxdWlyZUFjdHVhbCgnZnMnKSA6IHJlcXVpcmUoJ2ZzJylcblxuLy8gV29ya2Fyb3VuZCB0byBmaXggd2VicGFjaydzIGJ1aWxkIHdhcm5pbmdzOiAndGhlIHJlcXVlc3Qgb2YgYSBkZXBlbmRlbmN5IGlzIGFuIGV4cHJlc3Npb24nXG5jb25zdCBydW50aW1lUmVxdWlyZSA9IHR5cGVvZiBfX3dlYnBhY2tfcmVxdWlyZV9fID09PSAnZnVuY3Rpb24nID8gX19ub25fd2VicGFja19yZXF1aXJlX18gOiByZXF1aXJlIC8vIGVzbGludC1kaXNhYmxlLWxpbmVcblxuLyoqXG4gKiBGaW5kIHRoZSBiZXN0IHBhdGggdG8gdGhlIGJpbmRpbmcgZmlsZVxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VQYXRoIC0gQmFzZSBwYXRoIG9mIHRoZSBtb2R1bGUsIHdoZXJlIGJpbmFyaWVzIHdpbGwgYmUgbG9jYXRlZFxuICogQHBhcmFtIHtvYmplY3R9IG9wdGlvbnMgLSBEZXNjcmliZSBob3cgdGhlIHByZWJ1aWx0IGJpbmFyeSBpcyBuYW1lZFxuICogQHBhcmFtIHtib29sZWFufSB2ZXJpZnlQcmVidWlsZCAtIFRydWUgaWYgd2UgYXJlIHZlcmlmeWluZyB0aGF0IGEgcHJlYnVpbGQgZXhpc3RzXG4gKiBAcGFyYW0ge2Jvb2xlYW59IHRocm93T25NaXNzaW5nIC0gVHJ1ZSBpZiBhbiBlcnJvciBzaG91bGQgYmUgdGhyb3duIHdoZW4gdGhlIGJpbmFyeSBpcyBtaXNzaW5nXG4gKiBAcmV0dXJuc1xuICovXG5mdW5jdGlvbiByZXNvbHZlUGF0aChiYXNlUGF0aCwgb3B0aW9ucywgdmVyaWZ5UHJlYnVpbGQsIHRocm93T25NaXNzaW5nKSB7XG5cdGlmICh0eXBlb2YgYmFzZVBhdGggIT09ICdzdHJpbmcnIHx8ICFiYXNlUGF0aCkgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGJhc2VQYXRoIHRvIHBrZy1wcmVidWlsZHNgKVxuXG5cdGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gJ29iamVjdCcgfHwgIW9wdGlvbnMpIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBvcHRpb25zIHRvIHBrZy1wcmVidWlsZHNgKVxuXHRpZiAodHlwZW9mIG9wdGlvbnMubmFtZSAhPT0gJ3N0cmluZycgfHwgIW9wdGlvbnMubmFtZSkgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIG5hbWUgdG8gcGtnLXByZWJ1aWxkc2ApXG5cblx0bGV0IGlzTm9kZUFwaSA9IGZhbHNlXG5cdGlmIChvcHRpb25zLm5hcGlfdmVyc2lvbnMgJiYgQXJyYXkuaXNBcnJheShvcHRpb25zLm5hcGlfdmVyc2lvbnMpKSB7XG5cdFx0aXNOb2RlQXBpID0gdHJ1ZVxuXHR9XG5cblx0Y29uc3QgYXJjaCA9ICh2ZXJpZnlQcmVidWlsZCAmJiBwcm9jZXNzLmVudi5ucG1fY29uZmlnX2FyY2gpIHx8IG9zLmFyY2goKVxuXHRjb25zdCBwbGF0Zm9ybSA9ICh2ZXJpZnlQcmVidWlsZCAmJiBwcm9jZXNzLmVudi5ucG1fY29uZmlnX3BsYXRmb3JtKSB8fCBvcy5wbGF0Zm9ybSgpXG5cblx0bGV0IHJ1bnRpbWUgPSAnbm9kZSdcblx0Ly8gSWYgbm9kZS1hcGksIHRoZW4gZXZlcnl0aGluZyBjYW4gc2hhcmUgdGhlIHNhbWUgYmluYXJ5XG5cdGlmICghaXNOb2RlQXBpKSB7XG5cdFx0aWYgKHZlcmlmeVByZWJ1aWxkICYmIHByb2Nlc3MuZW52Lm5wbV9jb25maWdfcnVudGltZSkge1xuXHRcdFx0cnVudGltZSA9IHByb2Nlc3MuZW52Lm5wbV9jb25maWdfcnVudGltZVxuXHRcdH0gZWxzZSBpZiAoaXNFbGVjdHJvbigpKSB7XG5cdFx0XHRydW50aW1lID0gJ2VsZWN0cm9uJ1xuXHRcdH0gZWxzZSBpZiAoaXNOd2pzKCkpIHtcblx0XHRcdHJ1bnRpbWUgPSAnbm9kZS13ZWJraXQnXG5cdFx0fVxuXHR9XG5cblx0Y29uc3QgY2FuZGlkYXRlcyA9IFtdXG5cblx0aWYgKCF2ZXJpZnlQcmVidWlsZCkge1xuXHRcdC8vIFRyeSBmb3IgYSBsb2NhbGx5IGJ1aWx0IGJpbmRpbmdcblx0XHRjYW5kaWRhdGVzLnB1c2goXG5cdFx0XHRwYXRoLmpvaW4oYmFzZVBhdGgsICdidWlsZCcsICdEZWJ1ZycsIGAke29wdGlvbnMubmFtZX0ubm9kZWApLFxuXHRcdFx0cGF0aC5qb2luKGJhc2VQYXRoLCAnYnVpbGQnLCAnUmVsZWFzZScsIGAke29wdGlvbnMubmFtZX0ubm9kZWApXG5cdFx0KVxuXHR9XG5cblx0bGV0IGxpYmMgPSB1bmRlZmluZWRcblx0aWYgKGlzQWxwaW5lKHBsYXRmb3JtKSkgbGliYyA9ICdtdXNsJ1xuXG5cdC8vIExvb2sgZm9yIHByZWJ1aWxkc1xuXHRpZiAoaXNOb2RlQXBpKSB7XG5cdFx0Ly8gTG9vayBmb3Igbm9kZS1hcGkgdmVyc2lvbmVkIGJ1aWxkc1xuXHRcdGZvciAoY29uc3QgdmVyIG9mIG9wdGlvbnMubmFwaV92ZXJzaW9ucykge1xuXHRcdFx0Y29uc3QgcHJlYnVpbGROYW1lID0gZ2V0UHJlYnVpbGROYW1lKHtcblx0XHRcdFx0bmFtZTogb3B0aW9ucy5uYW1lLFxuXHRcdFx0XHRwbGF0Zm9ybSxcblx0XHRcdFx0YXJjaCxcblx0XHRcdFx0bGliYyxcblx0XHRcdFx0bmFwaV92ZXJzaW9uOiB2ZXIsXG5cdFx0XHRcdHJ1bnRpbWUsXG5cdFx0XHRcdC8vIGFybXY6IG9wdGlvbnMuYXJtdiA/IChhcmNoID09PSAnYXJtNjQnID8gJzgnIDogdmFycy5hcm1fdmVyc2lvbikgOiBudWxsLFxuXHRcdFx0fSlcblx0XHRcdGNhbmRpZGF0ZXMucHVzaChwYXRoLmpvaW4oYmFzZVBhdGgsICdwcmVidWlsZHMnLCBwcmVidWlsZE5hbWUpKVxuXHRcdH1cblx0fSBlbHNlIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ05vdCBpbXBsZW1lbnRlZCBmb3IgTkFOIScpXG5cdH1cblxuXHRsZXQgZm91bmRQYXRoID0gbnVsbFxuXG5cdGZvciAoY29uc3QgY2FuZGlkYXRlIG9mIGNhbmRpZGF0ZXMpIHtcblx0XHRpZiAoZnMuZXhpc3RzU3luYyhjYW5kaWRhdGUpKSB7XG5cdFx0XHRjb25zdCBzdGF0ID0gZnMuc3RhdFN5bmMoY2FuZGlkYXRlKVxuXHRcdFx0aWYgKHN0YXQuaXNGaWxlKCkpIHtcblx0XHRcdFx0Zm91bmRQYXRoID0gY2FuZGlkYXRlXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0aWYgKCFmb3VuZFBhdGggJiYgdGhyb3dPbk1pc3NpbmcpIHtcblx0XHRjb25zdCBjYW5kaWRhdGVzU3RyID0gY2FuZGlkYXRlcy5tYXAoKGNhbmQpID0+IGAgLSAke2NhbmR9YCkuam9pbignXFxuJylcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBmaW5kIGJpbmRpbmcgZm9yICR7b3B0aW9ucy5uYW1lfVxcblRyaWVkIHBhdGhzOlxcbiR7Y2FuZGlkYXRlc1N0cn1gKVxuXHR9XG5cblx0cmV0dXJuIGZvdW5kUGF0aFxufVxuXG5mdW5jdGlvbiBsb2FkQmluZGluZyhiYXNlUGF0aCwgb3B0aW9ucykge1xuXHRjb25zdCBmb3VuZFBhdGggPSByZXNvbHZlUGF0aChiYXNlUGF0aCwgb3B0aW9ucywgZmFsc2UsIHRydWUpXG5cblx0Ly8gTm90ZTogdGhpcyBlcnJvciBzaG91bGQgbm90IGJlIGhpdCwgYXMgcmVzb2x2ZVBhdGggd2lsbCB0aHJvdyBpZiB0aGUgYmluZGluZyBpcyBtaXNzaW5nXG5cdGlmICghZm91bmRQYXRoKSB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBmaW5kIGJpbmRpbmcgZm9yICR7b3B0aW9ucy5uYW1lfWApXG5cblx0cmV0dXJuIHJ1bnRpbWVSZXF1aXJlKGZvdW5kUGF0aClcbn1cbmxvYWRCaW5kaW5nLnJlc29sdmUgPSByZXNvbHZlUGF0aFxuXG5tb2R1bGUuZXhwb3J0cyA9IGxvYWRCaW5kaW5nXG4iLCAibW9kdWxlLmV4cG9ydHMgPSB7XG4gIG5hbWU6ICdtaWRpJyxcbiAgbmFwaV92ZXJzaW9uczogWzddLFxufVxuIiwgIi8vIEdlbmVyYWwgTUlESSBwYXRjaGVzXG5tb2R1bGUuZXhwb3J0cyA9IHtcblxuICAgIEFDT1VTVElDX0dSQU5EX1BJQU5PICAgICAgICA6IDAsIFxuICAgIEJSSUdIVF9BQ09VU1RJQ19QSUFOTyAgICAgICA6IDEsXG4gICAgRUxFQ1RSSUNfR1JBTkRfUElBTk8gICAgICAgIDogMixcbiAgICBIT05LWV9UT05LX1BJQU5PICAgICAgICAgICAgOiAzLFxuICAgIEVMRUNUUklDX1BJQU5PXzFcdFx0XHQ6IDQsXG4gICAgRUxFQ1RSSUNfUElBTk9fMiAgICAgICAgICAgIDogNSxcbiAgICBIQVJQU0lDSE9SRCAgICAgICAgICAgICAgICAgOiA2LFxuICAgIENMQVZJXHRcdFx0XHRcdCAgICA6IDcsXG4gICAgQ0VMRVNUQSAgIFx0XHRcdFx0ICAgIDogOCxcbiAgICBHTE9DS0VOU1BJRUxcdFx0XHRcdDogOSxcbiAgICBNVVNJQ19CT1hcdFx0XHRcdCAgICA6IDEwLFxuICAgIFZJQlJBUEhPTkVcdFx0XHRcdCAgICA6IDExLFxuICAgIE1BUklNQkFcdFx0XHRcdFx0ICAgIDogMTIsXG4gICAgWFlMT1BIT05FICAgICAgIFx0XHRcdDogMTMsXG4gICAgVFVCVUxBUl9CRUxMUyAgICAgICAgICAgICAgIDogMTQsXG4gICAgRFVMQ0lNRVJcdFx0XHRcdFx0OiAxNSxcbiAgICBEUkFXQkFSX09SR0FOICAgICAgICAgICAgICAgOiAxNixcbiAgICBQRVJDVVNTSVZFX09SR0FOICAgICAgICAgICAgOiAxNyxcbiAgICBST0NLX09SR0FOXHRcdFx0XHQgICAgOiAxOCxcbiAgICBDSFVSQ0hfT1JHQU5cdFx0XHRcdDogMTksXG4gICAgUkVFRF9PUkdBTlx0XHRcdFx0ICAgIDogMjAsXG4gICAgQUNDT1JESU9OXHRcdFx0XHQgICAgOiAyMSxcbiAgICBIQVJNT05JQ0FcdFx0XHRcdCAgICA6IDIyLFxuICAgIFRBTkdPX0FDQ09SRElPTiAgICAgICAgICAgICA6IDIzLFxuICAgIEFDT1VTVElDX0dVSVRBUl9OWUxPTiAgICAgICA6IDI0LFxuICAgIEFDT1VTVElDX0dVSVRBUl9TVEVFTCAgICAgICA6IDI1LFxuICAgIEVMRUNUUklDX0dVSVRBUl9KQVpaICAgICAgICA6IDI2LFxuICAgIEVMRUNUUklDX0dVSVRBUl9DTEVBTiAgICAgICA6IDI3LFxuICAgIEVMRUNUUklDX0dVSVRBUl9NVVRFRCAgICAgICA6IDI4LFxuICAgIE9WRVJEUklWRU5fR1VJVEFSXHRcdCAgICA6IDI5LFxuICAgIERJU1RPUlRJT05fR1VJVEFSXHRcdCAgICA6IDMwLFxuICAgIEdVSVRBUl9IQVJNT05JQ1NcdFx0XHQ6IDMxLFxuICAgIEFDT1VTVElDX0JBU1NcdFx0ICAgIFx0OiAzMixcbiAgICBFTEVDVFJJQ19CQVNTX0ZJTkdFUlx0XHQ6IDMzLFxuICAgIEVMRUNUUklDX0JBU1NfUElDS1x0ICAgIFx0OiAzNCxcbiAgICBGUkVUTEVTU19CQVNTICAgICAgICAgICAgICAgOiAzNSxcbiAgICBTTEFQX0JBU1NfMSAgICAgICAgICAgICAgICAgOiAzNixcbiAgICBTTEFQX0JBU1NfMiAgICAgICAgICAgICAgICAgOiAzNyxcbiAgICBTWU5USF9CQVNTXzEgICAgICAgICAgICAgICAgOiAzOCxcbiAgICBTWU5USF9CQVNTXzJcdFx0XHRcdDogMzksXG4gICAgVklPTElOXHRcdFx0XHQgICAgXHQ6IDQwLFxuICAgIFZJT0xBXHRcdFx0ICAgIFx0XHQ6IDQxLFxuICAgIENFTExPIFx0XHRcdCAgICBcdFx0OiA0MixcbiAgICBDT05UUkFCQVNTICAgICAgICAgICAgICBcdDogNDMsXG4gICAgVFJFTU9MT19TVFJJTkdTICAgICAgICAgXHQ6IDQ0LFxuICAgIFBJWlpJQ0FUT19TVFJJTkdTXHQgICAgXHQ6IDQ1LFxuICAgIE9SQ0hFU1RSQUxfSEFSUFx0XHRcdCAgICA6IDQ2LFxuICAgIFRJTVBBTkkgICAgICAgIFx0XHQgICAgXHQ6IDQ3LFxuICAgIFNUUklOR19FTlNFTUJMRV8xXHRcdCAgICA6IDQ4LFxuICAgIFNUUklOR19FTlNFTUJMRV8yICAgICAgICAgICA6IDQ5LFxuICAgIFNZTlRIU1RSSU5HU18xICAgICAgICAgICAgICA6IDUwLFxuICAgIFNZTlRIU1RSSU5HU18yICAgICAgICAgICAgICA6IDUxLFxuICAgIENIT0lSX0FBSFNcdFx0XHQgICAgXHQ6IDUyLFxuICAgIFZPSUNFX09PSFNcdFx0XHQgICAgXHQ6IDUzLFxuICAgIFNZTlRIX1ZPSUNFXHRcdFx0ICAgIFx0OiA1NCxcbiAgICBPUkNIRVNUUkFfSElUXHRcdCAgICBcdDogNTUsXG4gICAgVFJVTVBFVFx0XHRcdFx0ICAgIFx0OiA1NixcbiAgICBUUk9NQk9ORVx0XHRcdFx0XHQ6IDU3LFxuICAgIFRVQkFcdFx0XHRcdFx0XHQ6IDU4LFxuICAgIE1VVEVEX1RSVU1QRVRcdFx0ICAgIFx0OiA1OSxcbiAgICBGUkVOQ0hfSE9STlx0XHQgICAgXHRcdDogNjAsXG4gICAgQlJBU1NfU0VDVElPTlx0ICAgIFx0XHQ6IDYxLFxuICAgIFNZTlRIQlJBU1NfMVx0XHRcdFx0OiA2MixcbiAgICBTWU5USEJSQVNTXzJcdFx0XHRcdDogNjMsXG4gICAgU09QUkFOT19TQVhcdFx0XHQgICAgXHQ6IDY0LFxuICAgIEFMVE9fU0FYXHRcdFx0XHRcdDogNjUsXG4gICAgVEVOT1JfU0FYICAgICAgICAgICBcdFx0OiA2NixcbiAgICBCQVJJVE9ORV9TQVggICAgICAgIFx0XHQ6IDY3LFxuICAgIE9CT0UgICAgICAgICAgICBcdFx0XHQ6IDY4LFxuICAgIEVOR0xJU0hfSE9STiAgICBcdFx0ICBcdDogNjksXG4gICAgQkFTU09PTiAgICAgICAgICAgIFx0ICAgIFx0OiA3MCxcbiAgICBDTEFSSU5FVCAgICAgICAgICAgIFx0XHQ6IDcxLFxuICAgIFBJQ0NPTE8gICAgICAgICAgICAgIFx0ICAgIDogNzIsXG4gICAgRkxVVEUgICAgICAgICAgICAgIFx0ICAgIFx0OiA3MyxcbiAgICBSRUNPUkRFUiAgICAgICAgICAgXHRcdCAgICA6IDc0LFxuICAgIFBBTl9GTFVURVx0XHRcdCAgICBcdDogNzUsXG4gICAgQkxPV05fQk9UVExFXHRcdFx0XHQ6IDc2LFxuICAgIFNIQUtVSEFDSElcdFx0XHQgICAgXHQ6IDc3LFxuICAgIFdISVNUTEVcdFx0XHRcdCAgICBcdDogNzgsXG4gICAgT0NBUklOQVx0XHRcdFx0XHQgICAgOiA3OSxcbiAgICBMRUFEXzFfU1FVQVJFXHQgICAgICAgICAgICA6IDgwLFxuICAgIExFQURfMl9TQVdUT09USFx0XHRcdCAgICA6IDgxLFxuICAgIExFQURfM19DQUxMSU9QRVx0XHRcdCAgICA6IDgyLFxuICAgIExFQURfNF9DSElGRlx0XHRcdFx0OiA4MyxcbiAgICBMRUFEXzVfQ0hBUkFOR1x0XHQgICAgXHQ6IDg0LFxuICAgIExFQURfNl9WT0lDRSBcdFx0ICAgIFx0OiA4NSxcbiAgICBMRUFEXzdfRklGVEhTXHRcdFx0ICAgIDogODYsXG4gICAgTEVBRF84X0JBU1NfQU5EX0xFQURcdFx0OiA4NyxcbiAgICBQQURfMV9ORVdfQUdFXHRcdCAgICBcdDogODgsXG4gICAgUEFEXzJfV0FSTVx0XHRcdCAgICBcdDogODksXG4gICAgUEFEXzNfUE9MWVNZTlRIXHRcdCAgICBcdDogOTAsXG4gICAgUEFEXzRfQ0hPSVJcdFx0ICAgIFx0XHQ6IDkxLFxuICAgIFBBRF81X0JPV0VEXHRcdCAgICBcdFx0OiA5MixcbiAgICBQQURfNl9NRVRBTExJQ1x0ICAgIFx0XHQ6IDkzLFxuICAgIFBBRF83X0hBTE9cdFx0ICAgIFx0XHQ6IDk0LFxuICAgIFBBRF84X1NXRUVQXHRcdCAgICBcdFx0OiA5NSxcbiAgICBGWF8xX1JBSU5cdFx0ICAgIFx0XHQ6IDk2LFxuICAgIEZYXzJfU09VTkRUUkFDS1x0ICAgIFx0XHQ6IDk3LFxuICAgIEZYXzNfQ1JZU1RBTFx0XHRcdFx0OiA5OCxcbiAgICBGWF80X0FUTU9TUEhFUkVcdCAgICBcdFx0OiA5OSxcbiAgICBGWF81X0JSSUdIVE5FU1NcdCAgICBcdFx0OiAxMDAsXG4gICAgRlhfNl9HT0JMSU5TXHRcdFx0XHQ6IDEwMSxcbiAgICBGWF83X0VDSE9FU1x0XHQgICAgXHRcdDogMTAyLFxuICAgIEZYXzhfU0NJRklcdFx0ICAgIFx0XHQ6IDEwMyxcbiAgICBTSVRBUlx0XHRcdCAgICBcdFx0OiAxMDQsXG4gICAgQkFOSk9cdFx0XHQgICAgXHRcdDogMTA1LFxuICAgIFNIQU1JU0VOXHRcdFx0XHRcdDogMTA2LFxuICAgIEtPVE9cdFx0XHRcdFx0XHQ6IDEwNyxcbiAgICBLQUxJTUJBXHRcdFx0ICAgIFx0XHQ6IDEwOCxcbiAgICBCQUdfUElQRVx0XHRcdFx0XHQ6IDEwOSxcbiAgICBGSURETEVcdFx0XHQgICAgXHRcdDogMTEwLFxuICAgIFNIQU5BSVx0XHRcdFx0ICAgIFx0OiAxMTEsXG4gICAgVElOS0xFX0JFTExcdFx0XHQgICAgXHQ6IDExMixcbiAgICBBR09HT1x0XHRcdFx0ICAgIFx0OiAxMTMsXG4gICAgU1RFRUxfRFJVTVNcdFx0XHQgICAgXHQ6IDExNCxcbiAgICBXT09EQkxPQ0tcdFx0XHRcdCAgICA6IDExNSxcbiAgICBUQUlLT19EUlVNICBcdFx0XHRcdDogMTE2LFxuICAgIE1FTE9ESUNfVE9NXHQgICAgXHRcdFx0OiAxMTcsXG4gICAgU1lOVEhfRFJVTVx0XHQgICAgXHRcdDogMTE4LFxuICAgIFJFVkVSU0VfQ1lNQkFMXHRcdCAgICBcdDogMTE5LFxuICAgIEdVSVRBUl9GUkVUX05PSVNFXHRcdCAgICA6IDEyMCxcdFxuICAgIEJSRUFUSF9OT0lTRVx0XHRcdFx0OiAxMjEsXG4gICAgU0VBU0hPUkVcdFx0XHRcdFx0OiAxMjIsXG4gICAgQklSRF9UV0VFVFx0XHQgICAgXHRcdDogMTIzLFxuICAgIFRFTEVQSE9ORV9SSU5HXHRcdCAgICBcdDogMTI0LFxuICAgIEhFTElDT1BURVJcdFx0XHRcdCAgICA6IDEyNSxcbiAgICBBUFBMQVVTRVx0XHRcdFx0XHQ6IDEyNixcbiAgICBHVU5TSE9UICAgICAgICAgICAgICAgICAgICAgOiAxMjcsXG59O1xuIiwgIi8vIEdlbmVyYWwgTUlESSBkcnVtIHBhdGNoZXMsIHRyYWNrIDEwXG5tb2R1bGUuZXhwb3J0cyA9IHtcblxuICAgIEFDT1VTVElDX0JBU1NfRFJVTVx0ICAgIDogMzUsXG4gICAgQkFTU19EUlVNXHRcdFx0XHQ6IDM2LFxuICAgIFNJREVfU1RJQ0tcdFx0XHQgICAgOiAzNyxcbiAgICBBQ09VU1RJQ19TTkFSRVx0XHQgICAgOiAzOCxcbiAgICBIQU5EX0NMQVBcdFx0XHRcdDogMzksXG4gICAgRUxFQ1RSSUNfU05BUkVcdFx0ICAgIDogNDAsXG4gICAgTE9XX0ZMT09SX1RPTVx0XHRcdDogNDEsXG4gICAgQ0xPU0VEX0hJX0hBVFx0XHRcdDogNDIsXG4gICAgSElHSF9GTE9PUl9UT01cdFx0ICAgIDogNDMsXG4gICAgUEVEQUxfSElfSEFUXHRcdFx0OiA0NCxcbiAgICBMT1dfVE9NXHRcdFx0XHQgICAgOiA0NSxcbiAgICBPUEVOX0hJX0hBVFx0ICAgIFx0XHQ6IDQ2LFxuICAgIExPV19NSURfVE9NXHQgICAgXHRcdDogNDcsXG4gICAgSElfTUlEX1RPTVx0ICAgIFx0XHQ6IDQ4LFxuICAgIENSQVNIX0NZTUJBTF8xXHQgICAgXHQ6IDQ5LFxuICAgIEhJR0hfVE9NXHRcdFx0XHQ6IDUwLFxuICAgIFJJREVfQ1lNQkFMXzFcdFx0XHQ6IDUxLFxuICAgIENISU5FU0VfQ1lNQkFMXHQgICAgXHQ6IDUyLFxuICAgIFJJREVfQkVMTFx0XHRcdFx0OiA1MyxcbiAgICBUQU1CT1VSSU5FXHRcdCAgICBcdDogNTQsXG4gICAgU1BMQVNIX0NZTUJBTFx0XHRcdDogNTUsXG4gICAgQ09XQkVMTFx0XHRcdCAgICBcdDogNTYsXG4gICAgQ1JBU0hfQ1lNQkFMXzJcdCAgICBcdDogNTcsXG4gICAgVklCUkFfU0xBUFx0XHQgICAgXHQ6IDU4LFxuICAgIFJJREVfQ1lNQkFMXzJcdFx0XHQ6IDU5LFxuICAgIEhJX0JPTkdPXHRcdFx0XHQ6IDYwLFxuICAgIExPV19CT05HT1x0XHRcdFx0OiA2MSxcbiAgICBNVVRFX0hJX0NPTkdBXHRcdFx0OiA2MixcbiAgICBPUEVOX0hJX0NPTkdBXHRcdFx0OiA2MyxcbiAgICBMT1dfQ09OR0FcdFx0XHRcdDogNjQsXG4gICAgSElHSF9USU1CQUxFXHRcdFx0OiA2NSxcbiAgICBMT1dfVElNQkFMRVx0ICAgIFx0XHQ6IDY2LFxuICAgIEhJR0hfQUdPR09cdFx0ICAgIFx0OiA2NyxcbiAgICBMT1dfQUdPR09cdFx0XHRcdDogNjgsXG4gICAgQ0FCQVNBXHRcdFx0ICAgIFx0OiA2OSxcbiAgICBNQVJBQ0FTXHRcdFx0ICAgIFx0OiA3MCxcbiAgICBTSE9SVF9XSElTVExFXHRcdFx0OiA3MSxcbiAgICBMT05HX1dISVNUTEVcdFx0XHQ6IDcyLFxuICAgIFNIT1JUX0dVSVJPXHRcdCAgICBcdDogNzMsXG4gICAgTE9OR19HVUlST1x0XHQgICAgXHQ6IDc0LFxuICAgIENMQVZFU1x0XHRcdCAgICBcdDogNzUsXG4gICAgSElfV09PRF9CTE9DS1x0XHRcdDogNzYsXG4gICAgTE9XX1dPT0RfQkxPQ0tcdCAgICBcdDogNzcsXG4gICAgTVVURV9DVUlDQVx0XHQgICAgXHQ6IDc4LFxuICAgIE9QRU5fQ1VJQ0FcdFx0ICAgIFx0OiA3OSxcbiAgICBNVVRFX1RSSUFOR0xFXHRcdFx0OiA4MCxcbiAgICBPUEVOX1RSSUFOR0xFXHRcdFx0OiA4MSxcbn07XG4iLCAiLy8gTUlESSBub3Rlc1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICAvKlxuICAgICoqIFRoZSBNSURJIHNwZWMgb25seSBpbmRpY2F0ZXMgbWlkZGxlIEMgdG8gYmVcbiAgICAqKiA2MC4gSXQgZG9lc24ndCBpbmRpY2F0ZSB3aGljaCBvY3RhdmUgdGhpcyBpcy5cbiAgICAqKiBTb21lIG1heSBjb25zaWRlciA0LCBpZiB0aGV5IGxhYmVsIG9jdGF2ZXMgXG4gICAgKiogZnJvbSAtMSwgaW5zdGVhZCBvZiAwLiBJIGhhdmUgYWRvcHRlZCBvbiBvY3RhdmVcbiAgICAqKiBudW1iZXIgQyBoZXJlLlxuICAgICovXG4gICAgTUlERExFX0MgOiA2MCxcbiAgICBcbiAgICAvLyBSZWxhdGl2ZSBvZmZzZXRzXG4gICAgQ1x0XHQ6IDAsXG4gICAgQ19TSEFSUCA6IDEsXG4gICAgQ19GTEFUXHQ6IC0xLFxuICAgIERcdFx0OiAyLFxuICAgIERfU0hBUlAgOiAzLFxuICAgIERfRkxBVCAgOiAxLFxuICAgIEVcdFx0OiA0LFxuICAgIEVfU0hBUlAgOiA1LFxuICAgIEVfRkxBVCAgOiAzLFxuICAgIEZcdFx0OiA1LFxuICAgIEZfU0hBUlAgOiA2LFxuICAgIEZfRkxBVCAgOiA0LFxuICAgIEdcdFx0OiA3LFxuICAgIEdfU0hBUlAgOiA4LFxuICAgIEdfRkxBVCAgOiA2LFxuICAgIEFcdFx0OiA5LFxuICAgIEFfU0hBUlAgOiAxMCxcbiAgICBBX0ZMQVQgIDogOCxcbiAgICBCXHRcdDogMTEsXG4gICAgQl9TSEFSUCA6IDEyLFxuICAgIEJfRkxBVCAgOiAxMCxcblxuICAgIC8vIEZvciB0aGUgb2N0YXZlc1xuICAgIEMwXHQ6IDAsIFxuICAgIEMxXHQ6IDEyLFxuICAgIEMyXHQ6IDI0LFxuICAgIEMzXHQ6IDM2LFxuICAgIEM0XHQ6IDQ4LFxuICAgIEM1XHQ6IDYwLFxuICAgIEM2XHQ6IDcyLFxuICAgIEM3XHQ6IDg0LFxuICAgIEM4XHQ6IDk2LFxuICAgIEM5XHQ6IDEwOCxcbiAgICBDMTBcdDogMTIwLFxuXG59O1xuXG4iLCAiLy8gTUlESSBtZXNzYWdlc1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICAvLyBBbGwgYmFzaWMgbWVzc2FnZXMgYXJlIGhlbGQgaW4gdGhlIHJvb3QsIGJlY2F1c2Ugb2YgaG93IGNvbW1vbmx5IHRoZXkncmVcbiAgICAvLyB1c2VkLiBMdWNraWx5LCB0aGVyZSdzIG5vIG5hbWUgY2xhc2hlcyB3aXRoIHN1Yi1uYW1lc1xuICAgIE5PVEVfT0ZGOiAgICAgICAgICAgMHg4MCxcdFx0LyogWyBwaXRjaCwgdm9sdW1lIF0gKi9cbiAgICBOT1RFX09OOiAgICAgICAgICAgIDB4OTAsXHRcdC8qIFsgcGl0Y2gsIHZvbHVtZSBdICovXG4gICAgTk9URV9LRVlfUFJFU1NVUkU6ICAweGEwLFx0XHQvKiBbIHBpdGNoLCBwcmVzc3VyZSAoYWZ0ZXIgdG91Y2gpIF0gKi9cbiAgICBTRVRfUEFSQU1FVEVSOiAgICAgIDB4YjAsXHRcdC8qIFsgcGFyYW0gbnVtYmVyIChDQyksIHNldHRpbmcgXSAqL1xuICAgIFNFVF9QUk9HUkFNOiAgICAgICAgMHhjMCxcdFx0LyogWyBwcm9ncmFtIF0gKi9cbiAgICBDSEFOR0VfUFJFU1NVUkU6ICAgIDB4ZDAsXHRcdC8qIFsgcHJlc3N1cmUgKGFmdGVyIHRvdWNoKSBdICovXG4gICAgU0VUX1BJVENIV0hFRUw6ICAgICAweGUwLFx0XHQvKiBbIExTQiwgIE1TQiAodHdvIDcgYml0IHZhbHVlcykgXSAqL1xuICAgIFxuICAgIE1FVEFFVkVOVDogICAgICAgICAgMHhmZixcbiAgICBTWVNfRVgxOiAgICAgICAgICAgIDB4ZjAsXG4gICAgU1lTX0VYMjogICAgICAgICAgICAweGY3LFxuXG4gICAgLyogQWx0ZXJuYXRpdmUgbmFtZXMgKi9cbiAgICBQQVRDSF9DSEFOR0U6ICAgICAgIDB4YzAsICAgICAgIC8qIEVxdWl2YWxlbnQgdG8gU0VUX1BST0dSQU0gKi9cbiAgICBDT05UUk9MX0NIQU5HRTogICAgIDB4YjAsICAgICAgIC8qIEVxdWl2YWxlbnQgdG8gU0VUX1BBUkFNRVRFUiAqL1xuXG4gICAgU1lTTUFTSzogICAgICAgICAgICAweGYwLFxuXG5cbiAgICAvLyBDb250cm9sIGNoYW5nZXNcbiAgICBjYzoge1xuXHRcdC8qIDAtMzEsIHdoZXJlIGRlZmluZWQsIGFsbCBpbmRpY2F0ZSB0aGUgTVNCICovXG5cdFx0QkFOS19TRUxFQ1Q6XHRcdCAgICAwLFxuXHRcdE1PRFVMQVRJT046ICAgICAgICAgICAgIDEsXG5cdFx0QlJFQVRIX0NPTlRST0w6ICAgICAgICAgMixcblx0XHRVTkRFRklORURfMzogICAgICAgICAgICAzLFxuXHRcdEZPT1RfQ09OVFJPTDogICAgICAgICAgIDQsXG5cdFx0UE9SVEFNRU5UT19USU1FOiAgICAgICAgNSxcblx0XHREQVRFX0VOVFJZOiAgICAgICAgICAgICA2LFxuXHRcdFZPTFVNRTogICAgICAgICAgICAgICAgIDcsXG5cdFx0QkFMQU5DRTogICAgICAgICAgICAgICAgOCxcblx0XHRVTkRFRklORURfOTogICAgICAgICAgICA5LFxuXHRcdFBBTjogICAgICAgICAgICAgICAgICAgIDEwLFxuXHRcdEVYUFJFU1NJT046ICAgICAgICAgICAgIDExLFxuXHRcdEVGRkVDVF9DT05UUk9MXzE6ICAgICAgIDEyLFxuXHRcdEVGRkVDVF9DT05UUk9MXzI6ICAgICAgIDEzLFxuXHRcdFVOREVGSU5FRF8xNDogICAgICAgICAgIDE0LFxuXHRcdFVOREVGSU5FRF8xNTogICAgICAgICAgIDE1LFxuXHRcdEdFTkVSQUxfUFVSUE9TRV8xOiAgICAgIDE2LFxuXHRcdEdFTkVSQUxfUFVSUE9TRV8yOlx0XHQxNyxcblx0XHRHRU5FUkFMX1BVUlBPU0VfMzpcdFx0MTgsXG5cdFx0R0VORVJBTF9QVVJQT1NFXzQ6XHRcdDE5LFxuXG4gICAgICAgIC8qIDIwLTMxIGFyZSB1bmRlZmluZWQgKi9cblx0XHRVTkRFRklORURfMjA6ICAgICAgICAgICAyMCxcblx0XHRVTkRFRklORURfMjE6ICAgICAgICAgICAyMSxcblx0XHRVTkRFRklORURfMjI6ICAgICAgICAgICAyMixcblx0XHRVTkRFRklORURfMjM6ICAgICAgICAgICAyMyxcblx0XHRVTkRFRklORURfMjQ6ICAgICAgICAgICAyNCxcblx0XHRVTkRFRklORURfMjU6ICAgICAgICAgICAyNSxcblx0XHRVTkRFRklORURfMjY6ICAgICAgICAgICAyNixcblx0XHRVTkRFRklORURfMjc6ICAgICAgICAgICAyNyxcblx0XHRVTkRFRklORURfMjg6ICAgICAgICAgICAyOCxcblx0XHRVTkRFRklORURfMjk6ICAgICAgICAgICAyOSxcblx0XHRVTkRFRklORURfMzA6ICAgICAgICAgICAzMCxcblx0XHRVTkRFRklORURfMzE6ICAgICAgICAgICAzMSxcblxuICAgICAgICAvKiBMU0IgZm9yIGNvbnRyb2wgY2hhbmdlcyAwLTMxXHRcdDMyLTYzICovXG5cdFx0QkFOS19TRUxFQ1RfTFNCOlx0XHQzMixcbiAgICAgICAgTU9EVUxBVElPTl9MU0I6ICAgICAgICAgMzMsXG4gICAgICAgIEJSRUFUSF9DT05UUk9MX0xTQjogICAgIDM0LFxuXHRcdFVOREVGSU5FRF8zNTogICAgICAgICAgIDM1LFxuICAgICAgICBGT09UX0NPTlRST0xfTFNCOiAgICAgICAzNixcbiAgICAgICAgUE9SVEFNRU5UT19USU1FX0xTQjogICAgMzcsXG4gICAgICAgIERBVEFfRU5UUllfTFNCOiAgICAgICAgIDM4LFxuICAgICAgICBWT0xVTUVfTFNCOiAgICAgICAgICAgICAzOSxcbiAgICAgICAgQkFMQU5DRV9MU0I6ICAgICAgICAgICAgNDAsXG5cdFx0VU5ERUZJTkVEXzQxOiAgICAgICAgICAgNDEsXG4gICAgICAgIFBBTl9MU0I6ICAgICAgICAgICAgICAgIDQyLFxuICAgICAgICBFWFBSRVNTSU9OX0xTQjogICAgICAgICA0MyxcbiAgICAgICAgRUZGRUNUX0NPTlRST0xfMV9MU0I6ICAgNDQsXG4gICAgICAgIEVGRkVDVF9DT05UUk9MXzJfTFNCOiAgIDQ1LFxuXG4gICAgICAgIFVOREVGSU5FRF80NjogICAgICAgICAgIDQ2LFxuXHRcdFVOREVGSU5FRF80NzogICAgICAgICAgIDQ3LFxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfMV9MU0I6ICA0OCxcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzJfTFNCOiAgNDksXG4gICAgICAgIEdFTkVSQUxfUFVSUE9TRV8zX0xTQjogIDUwLFxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfNF9MU0I6ICA1MSxcblxuICAgICAgICAvKiA1Mi02MyBhcmUgdW5kZWZpbmVkICovXG5cdFx0VU5ERUZJTkVEXzUyOiAgICAgICAgICAgNTIsXG5cdFx0VU5ERUZJTkVEXzUzOiAgICAgICAgICAgNTMsXG5cdFx0VU5ERUZJTkVEXzU0OiAgICAgICAgICAgNTQsXG5cdFx0VU5ERUZJTkVEXzU1OiAgICAgICAgICAgNTUsXG5cdFx0VU5ERUZJTkVEXzU2OiAgICAgICAgICAgNTYsXG5cdFx0VU5ERUZJTkVEXzU3OiAgICAgICAgICAgNTcsXG5cdFx0VU5ERUZJTkVEXzU4OiAgICAgICAgICAgNTgsXG5cdFx0VU5ERUZJTkVEXzU5OiAgICAgICAgICAgNTksXG5cdFx0VU5ERUZJTkVEXzYwOiAgICAgICAgICAgNjAsXG5cdFx0VU5ERUZJTkVEXzYxOiAgICAgICAgICAgNjEsXG5cdFx0VU5ERUZJTkVEXzYyOiAgICAgICAgICAgNjIsXG5cdFx0VU5ERUZJTkVEXzYzOiAgICAgICAgICAgNjMsXG5cbiAgICAgICAgU1VTVEFJTl9QRURBTDogICAgICAgICAgNjQsXG5cdFx0UE9SVEFNRU5UTzogICAgICAgICAgICAgNjUsXG4gICAgICAgIFBFREFMX1NVU1RFTlVUTzogICAgICAgIDY2LFxuICAgICAgICBQRURBTF9TT0ZUOiAgICAgICAgICAgICA2NyxcbiAgICAgICAgTEVHQVRPX0ZPT1RfU1dJVENIOiAgICAgNjgsXG5cdFx0SE9MRF8yOiAgICAgICAgICAgICAgICAgNjksXG4gICAgICAgIFNPVU5EX1ZBUklBVElPTjogICAgICAgIDcwLFxuXHRcdFRJTUJSRTogICAgICAgICAgICAgICAgIDcxLFxuICAgICAgICBSRUxFQVNFX1RJTUU6ICAgICAgICAgICA3Mixcblx0XHRBVFRBQ0tUSU1FOiAgICAgICAgICAgICA3MyxcbiAgICAgICAgQlJJR0hUTkVTUzogICAgICAgICAgICAgNzQsXG5cdFx0UkVWRVJCOiAgICAgICAgICAgICAgICAgNzUsXG5cdFx0REVMQVk6ICAgICAgICAgICAgICAgICAgNzYsXG4gICAgICAgIFBJVENIX1RSQU5TUE9TRTogICAgICAgIDc3LFxuXHRcdEZMQU5HRTogICAgICAgICAgICAgICAgIDc4LFxuICAgICAgICBTUEVDSUFMX0ZYOiAgICAgICAgICAgICA3OSxcblxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfNV9MU0I6ICA4MCxcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzZfTFNCOiAgODEsXG4gICAgICAgIEdFTkVSQUxfUFVSUE9TRV83X0xTQjogIDgyLFxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfOF9MU0I6ICA4MyxcblxuICAgICAgICBQT1JUQU1FTlRPX0NPTlRST0w6ICAgICA4NCxcblxuICAgICAgICAvKiA4NS05MCBhcmUgdW5kZWZpbmVkICovXG5cdFx0VU5ERUZJTkVEXzg1OiAgICAgICAgICAgODUsXG5cdFx0VU5ERUZJTkVEXzg2OiAgICAgICAgICAgODYsXG5cdFx0VU5ERUZJTkVEXzg3OiAgICAgICAgICAgODcsXG5cdFx0VU5ERUZJTkVEXzg4OiAgICAgICAgICAgODgsXG5cdFx0VU5ERUZJTkVEXzg5OiAgICAgICAgICAgODksXG5cdFx0VU5ERUZJTkVEXzkwOiAgICAgICAgICAgOTAsXG5cbiAgICAgICAgLyogRWZmZWN0cyBkZXB0aCAqL1xuXHRcdEZYX0RFUFRIOiAgICAgICAgICAgICAgIDkxLFxuXHRcdFRSRU1FTE9fREVQVEg6ICAgICAgICAgIDkyLFxuICAgICAgICBDSE9SVVNfREVQVEg6ICAgICAgICAgICA5MyxcbiAgICAgICAgQ0VMRVNUQV9ERVBUSDogICAgICAgICAgOTQsXG4gICAgICAgIFBIQVNFUl9ERVBUSDogICAgICAgICAgIDk1LFxuXHRcdERBVEFfSU5DOiAgICAgICAgICAgICAgIDk2LFxuXHRcdERBVEFfREVDOiAgICAgICAgICAgICAgIDk3LFxuICAgICAgICBOT05fUkVHX1BBUkFNX0xTQjogICAgICA5OCxcbiAgICAgICAgTk9OX1JFR19QQVJBTV9NU0I6ICAgICAgOTksXG4gICAgICAgIFJFR19QQVJBTV9MU0I6ICAgICAgICAgIDEwMCxcbiAgICAgICAgUkVHX1BBUkFNX01TQjogICAgICAgICAgMTAxLFxuXG4gICAgICAgIC8qIDEwMi0xMTkgYXJlIHVuZGVmaW5lZCAqL1xuXHRcdFVOREVGSU5FRF8xMDI6ICAgICAgICAgIDEwMixcblx0XHRVTkRFRklORURfMTAzOiAgICAgICAgICAxMDMsXG5cdFx0VU5ERUZJTkVEXzEwNDogICAgICAgICAgMTA0LFxuXHRcdFVOREVGSU5FRF8xMDU6ICAgICAgICAgIDEwNSxcblx0XHRVTkRFRklORURfMTA2OiAgICAgICAgICAxMDYsXG5cdFx0VU5ERUZJTkVEXzEwNzogICAgICAgICAgMTA3LFxuXHRcdFVOREVGSU5FRF8xMDg6ICAgICAgICAgIDEwOCxcblx0XHRVTkRFRklORURfMTA5OiAgICAgICAgICAxMDksXG5cdFx0VU5ERUZJTkVEXzExMDogICAgICAgICAgMTEwLFxuXHRcdFVOREVGSU5FRF8xMTE6ICAgICAgICAgIDExMSxcblx0XHRVTkRFRklORURfMTEyOiAgICAgICAgICAxMTIsXG5cdFx0VU5ERUZJTkVEXzExMzogICAgICAgICAgMTEzLFxuXHRcdFVOREVGSU5FRF8xMTQ6ICAgICAgICAgIDExNCxcblx0XHRVTkRFRklORURfMTE1OiAgICAgICAgICAxMTUsXG5cdFx0VU5ERUZJTkVEXzExNjogICAgICAgICAgMTE2LFxuXHRcdFVOREVGSU5FRF8xMTc6ICAgICAgICAgIDExNyxcblx0XHRVTkRFRklORURfMTE4OiAgICAgICAgICAxMTgsXG5cdFx0VU5ERUZJTkVEXzExOTogICAgICAgICAgMTE5LFxuXG4gICAgICAgIC8vIE1vZGVzXG4gICAgICAgIEFMTF9TT1VORF9PRkY6ICAgICAgICAgIDEyMCxcbiAgICAgICAgUkVTRVRfQUxMX0NPTlRST0xMRVJTOiAgMTIxLFxuXHRcdExPQ0FMX0NPTlRST0w6ICAgICAgICAgIDEyMixcbiAgICAgICAgQUxMX05PVEVTX09GRjogICAgICAgICAgMTIzLFxuXHRcdE9NTklfTU9ERV9PRkY6ICAgICAgICAgIDEyNCxcblx0XHRPTU5JX01PREVfT046ICAgICAgICAgICAxMjUsXG5cdFx0TU9OT19NT0RFX09OOiAgICAgICAgICAgMTI2LFxuXHRcdFBPTFlfTU9ERV9PTjogICAgICAgICAgIDEyNyxcblxuXHRcdC8qIEFsdGVybmF0aXZlIG5hbWVzICovXG5cdFx0TU9EX1dIRUVMOiAgICAgICAgICAgICAgMSxcblxuXHRcdC8qIEFsbCBzb3VuZCBjb250cm9sbGVycyBoYXZlIG9ubHkgTFNCICovXG5cdFx0SEFSTV9DT05URU5UOiAgICAgICAgICAgNzEsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfMTogICAgIDcwLFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzI6ICAgICA3MSxcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl8zOiAgICAgNzIsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfNDogICAgIDczLFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzU6ICAgICA3NCxcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl82OiAgICAgNzUsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfNzogICAgIDc2LFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzg6ICAgICA3NyxcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl85OiAgICAgNzgsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfMTA6ICAgIDc5LFxuXG4gICAgICAgIEVGRkVDVF8xX0RFUFRIOiAgICAgICAgIDkxLFxuXHRcdEVGRkVDVF8yX0RFUFRIOiAgICAgICAgIDkyLFxuXHRcdEVGRkVDVF8zX0RFUFRIOiAgICAgICAgIDkzLFxuXHRcdEVGRkVDVF80X0RFUFRIOiAgICAgICAgIDk0LFxuXHRcdEVGRkVDVF81X0RFUFRIOiAgICAgICAgIDk1LFxuXG4gICAgICAgIERFVFVORV9ERVBUSDogICAgICAgICAgIDk0LFxuICAgIH0sXG5cblxuICAgIC8qXG4gICAgKiogU3lzdGVtIENvbW1vbiAoU3RhdHVzIGJ5dGU6IDExMTEgMHR0dClcbiAgICAqL1xuICAgIHN5c2NvbW1vbjoge1xuICAgICAgICBVTkRFRklORURfMTogICAgICAgICAgICAweGYxLFxuICAgICAgICBTT05HX1BPU0lUSU9OOiAgICAgICAgICAweGYyLCAvKiBbTFNCLCBNU0JdICovXG4gICAgICAgIFNPTkdfU0VMRUNUOiAgICAgICAgICAgIDB4ZjMsXG4gICAgICAgIFVOREVGSU5FRF80OiAgICAgICAgICAgIDB4ZjQsXG4gICAgICAgIFVOREVGSU5FRF81OiAgICAgICAgICAgIDB4ZjUsXG4gICAgICAgIFRVTkVfUkVRVUVTVDogICAgICAgICAgIDB4ZjYsXG4gICAgICAgIEVPWDogICAgICAgICAgICAgICAgICAgIDB4ZjcsIC8qIEVuZCBvZiBFeGNsdXNpdmUgKi9cbiAgICB9LFxuXG5cbiAgICAvKlxuICAgICoqIFN5c3RlbSBSZWFsIFRpbWUgKFN0YXR1cyBieXRlOiAxMTExIDF0dHQpXG4gICAgKi9cbiAgICByZWFsdGltZToge1xuICAgICAgICBUSU1JTkdfQ0xPQ0s6ICAgMHhmOCxcbiAgICAgICAgVU5ERUZJTkVEX0Y5OiAgIDB4ZjksXG4gICAgICAgIFNUQVJUOiAgICAgICAgICAweGZhLFxuICAgICAgICBDT05USU5VRTogICAgICAgMHhmYixcbiAgICAgICAgU1RPUDogICAgICAgICAgIDB4ZmMsXG4gICAgICAgIFVOREVGSU5FRF9GRDogICAweGZkLFxuICAgICAgICBBQ1RJVkVfU0VOU0lORzogMHhmZSxcbiAgICAgICAgU1lTVEVNX1JFU0VUOiAgIDB4ZmYsXG4gICAgfSxcblxuXG4gICAgLypcbiAgICAqKiBTeXN0ZW0gRXhjbHVzaXZlIChTdGF0dXMgYnl0ZTogMTExMSAwMDAwKVxuICAgICoqXG4gICAgKiogVGhlIGZpcnN0IGJ5dGUgb2YgYSBzeXNleCBtdXN0IGJlIHRoZSBpZGVudGlmaWNhdGlvbiBudW1iZXJcbiAgICAqKiAoNyBiaXRzLCBNU0I9MCkuIFRoaXMgaXMgZm9sbG93ZWQgYnkgYW4gYXJiaXRhcnkgbnVtYmVyIG9mXG4gICAgKiogZGF0YSBieXRlcyAoYWxsIE1TQj0wKSwgYW5kIGVuZGluZyBpbiB0aGUgc2V4RU9YIG1zZy5cbiAgICAqKiBOb3RlOiBBbnkgb3RoZXIgc3RhdHVzIGJ5dGUgKHdoZXJlIE1TQj0xKSB3aWxsIGFsc28gdGVybWluYXRlXG4gICAgKiogYSBzeXNleCBtZXNzYWdlLCB3aXRoIHRoZSBleGNlcHRpb24gb2YgdGhlIFN5c3RlbSBSZWFsIFRpbWVcbiAgICAqKiBldmVudHMgYWJvdmUuXG4gICAgKi9cbiAgICBzeXNleDoge1xuICAgICAgICBFT1g6ICAgICAgICAgICAgICAgICAgICAweGY3LCAvKiBFbmQgb2YgRXhjbHVzaXZlICovXG4gICAgfSxcblxufTtcbiIsICJjb25zdCBtaWRpID0gcmVxdWlyZShcInBrZy1wcmVidWlsZHMvYmluZGluZ3NcIikoXG4gIF9fZGlybmFtZSxcbiAgcmVxdWlyZShcIi4vYmluZGluZy1vcHRpb25zXCIpXG4pO1xuY29uc3QgU3RyZWFtID0gcmVxdWlyZSgnc3RyZWFtJyk7XG5cbi8vIE1JREkgaW5wdXQgaW5oZXJpdHMgZnJvbSBFdmVudEVtaXR0ZXJcbmNvbnN0IHsgRXZlbnRFbWl0dGVyIH0gPSByZXF1aXJlKCdldmVudHMnKTtcblxuLy8gQnJpbmcgaW4gdGhlIHNldCBvZiBjb25zdGFudHMgdG8gcmVmbGVjdCBNSURJIG1lc3NhZ2VzIGFuZCB0aGVpclxuLy8gcGFyYW1ldGVycywgdG8gZWxpbWluYXRlIHRoZSBuZWVkIGZvciBtYWdpYyBudW1iZXJzLlxuLyoqIEFuIGluc3RydW1lbnQgbGlzdCwgb25seSB2YWxpZCBpbiB0aGUgR2VuZXJhbCBNSURJIHN0YW5kYXJkICovXG5jb25zdCBJbnN0cnVtZW50cyA9IHJlcXVpcmUoJy4vbGliL2luc3RydW1lbnRzJyk7XG4vKiogQSBkcnVtIG1hcCwgb25seSB2YWxpZCBpbiB0aGUgR2VuZXJhbCBNSURJIHN0YW5kYXJkICovXG5jb25zdCBEcnVtcyA9IHJlcXVpcmUoJy4vbGliL2RydW1zJyk7XG4vKiogTm90ZSBkZXNjcmlwdGlvbnMsIHdpdGggTWlkZGxlIEMgPSBDNSA9IE1JREkgbm90ZSA2MCAqL1xuY29uc3QgTm90ZXMgPSByZXF1aXJlKCcuL2xpYi9ub3RlcycpO1xuLyoqIE1lc3NhZ2UgbmFtZXMsIGluY2x1ZGluZyBDQ3MgKi9cbmNvbnN0IE1lc3NhZ2VzID0gcmVxdWlyZSgnLi9saWIvbWVzc2FnZXMnKTtcblxuY2xhc3MgSW5wdXQgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpXG4gICAgXG4gICAgdGhpcy5pbnB1dCA9IG5ldyBtaWRpLklucHV0KChkZWx0YVRpbWUsIG1lc3NhZ2UpID0+IHtcbiAgICAgIHRoaXMuZW1pdCgnbWVzc2FnZScsIGRlbHRhVGltZSwgQXJyYXkuZnJvbShtZXNzYWdlLnZhbHVlcygpKSlcbiAgICB9KVxuICB9XG5cbiAgY2xvc2VQb3J0KCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0LmNsb3NlUG9ydCgpXG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5kZXN0cm95KClcbiAgfVxuICBnZXRQb3J0Q291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuZ2V0UG9ydENvdW50KClcbiAgfVxuICBnZXRQb3J0TmFtZShwb3J0KSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuZ2V0UG9ydE5hbWUocG9ydClcbiAgfVxuICBpc1BvcnRPcGVuKCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0LmlzUG9ydE9wZW4oKVxuICB9XG4gIGlnbm9yZVR5cGVzKHN5c2V4LCB0aW1pbmcsIGFjdGl2ZVNlbnNpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5pZ25vcmVUeXBlcyhzeXNleCwgdGltaW5nLCBhY3RpdmVTZW5zaW5nKVxuICB9XG4gIG9wZW5Qb3J0KHBvcnQpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5vcGVuUG9ydChwb3J0KVxuICB9XG4gIG9wZW5Qb3J0QnlOYW1lKG5hbWUpIHtcbiAgICBmb3IobGV0IHBvcnQ9MDsgcG9ydDx0aGlzLmlucHV0LmdldFBvcnRDb3VudCgpOyArK3BvcnQpIHtcbiAgICAgIGlmIChuYW1lID09PSB0aGlzLmlucHV0LmdldFBvcnROYW1lKHBvcnQpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmlucHV0Lm9wZW5Qb3J0KHBvcnQpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIG9wZW5WaXJ0dWFsUG9ydChwb3J0KSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQub3BlblZpcnR1YWxQb3J0KHBvcnQpXG4gIH1cbiAgc2V0QnVmZmVyU2l6ZShzaXplLCBjb3VudCA9IDQpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5zZXRCdWZmZXJTaXplKHNpemUsIGNvdW50KVxuICB9XG59XG5cbmNsYXNzIE91dHB1dCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMub3V0cHV0ID0gbmV3IG1pZGkuT3V0cHV0KClcbiAgfVxuXG4gIGNsb3NlUG9ydCgpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQuY2xvc2VQb3J0KClcbiAgfVxuICBkZXN0cm95KCkge1xuICAgIHJldHVybiB0aGlzLm91dHB1dC5kZXN0cm95KClcbiAgfVxuICBnZXRQb3J0Q291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMub3V0cHV0LmdldFBvcnRDb3VudCgpXG4gIH1cbiAgZ2V0UG9ydE5hbWUocG9ydCkge1xuICAgIHJldHVybiB0aGlzLm91dHB1dC5nZXRQb3J0TmFtZShwb3J0KVxuICB9XG4gIGlzUG9ydE9wZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMub3V0cHV0LmlzUG9ydE9wZW4oKVxuICB9XG4gIG9wZW5Qb3J0KHBvcnQpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQub3BlblBvcnQocG9ydClcbiAgfVxuICBvcGVuUG9ydEJ5TmFtZShuYW1lKSB7XG4gICAgZm9yKGxldCBwb3J0PTA7IHBvcnQ8dGhpcy5vdXRwdXQuZ2V0UG9ydENvdW50KCk7ICsrcG9ydCkge1xuICAgICAgaWYgKG5hbWUgPT09IHRoaXMub3V0cHV0LmdldFBvcnROYW1lKHBvcnQpKSB7XG4gICAgICAgIHJldHVybiB0aGlzLm91dHB1dC5vcGVuUG9ydChwb3J0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBvcGVuVmlydHVhbFBvcnQocG9ydCkge1xuICAgIHJldHVybiB0aGlzLm91dHB1dC5vcGVuVmlydHVhbFBvcnQocG9ydClcbiAgfVxuICBzZW5kKG1lc3NhZ2UpIHtcbiAgICByZXR1cm4gdGhpcy5zZW5kTWVzc2FnZShtZXNzYWdlKVxuICB9XG4gIHNlbmRNZXNzYWdlKG1lc3NhZ2UpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShtZXNzYWdlKSkge1xuICAgICAgbWVzc2FnZSA9IEJ1ZmZlci5mcm9tKG1lc3NhZ2UpXG4gICAgfVxuICAgIGlmICghQnVmZmVyLmlzQnVmZmVyKG1lc3NhZ2UpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZpcnN0IGFyZ3VtZW50IG11c3QgYmUgYW4gYXJyYXkgb3IgQnVmZmVyJylcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5vdXRwdXQuc2VuZE1lc3NhZ2UobWVzc2FnZSlcbiAgfVxufVxuXG5cbmZ1bmN0aW9uIGNyZWF0ZVJlYWRTdHJlYW0oaW5wdXQpIHtcbiAgaW5wdXQgPSBpbnB1dCB8fCBuZXcgSW5wdXQoKTtcbiAgdmFyIHN0cmVhbSA9IG5ldyBTdHJlYW0oKTtcbiAgc3RyZWFtLnJlYWRhYmxlID0gdHJ1ZTtcbiAgc3RyZWFtLnBhdXNlZCA9IGZhbHNlO1xuICBzdHJlYW0ucXVldWUgPSBbXTtcblxuICBpbnB1dC5vbignbWVzc2FnZScsIGZ1bmN0aW9uKGRlbHRhVGltZSwgbWVzc2FnZSkge1xuXG4gICAgdmFyIHBhY2tldCA9IG5ldyBCdWZmZXIuZnJvbShtZXNzYWdlKTtcblxuICAgIGlmICghc3RyZWFtLnBhdXNlZCkge1xuICAgICAgc3RyZWFtLmVtaXQoJ2RhdGEnLCBwYWNrZXQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdHJlYW0ucXVldWUucHVzaChwYWNrZXQpO1xuICAgIH1cbiAgfSk7XG5cbiAgc3RyZWFtLnBhdXNlID0gZnVuY3Rpb24oKSB7XG4gICAgc3RyZWFtLnBhdXNlZCA9IHRydWU7XG4gIH07XG5cbiAgc3RyZWFtLnJlc3VtZSA9IGZ1bmN0aW9uKCkge1xuICAgIHN0cmVhbS5wYXVzZWQgPSBmYWxzZTtcbiAgICB3aGlsZSAoc3RyZWFtLnF1ZXVlLmxlbmd0aCAmJiBzdHJlYW0uZW1pdCgnZGF0YScsIHN0cmVhbS5xdWV1ZS5zaGlmdCgpKSkge31cbiAgfTtcblxuICByZXR1cm4gc3RyZWFtO1xufTtcblxuZnVuY3Rpb24gY3JlYXRlV3JpdGVTdHJlYW0ob3V0cHV0KSB7XG4gIG91dHB1dCA9IG91dHB1dCB8fCBuZXcgT3V0cHV0KCk7XG4gIHZhciBzdHJlYW0gPSBuZXcgU3RyZWFtKCk7XG4gIHN0cmVhbS53cml0YWJsZSA9IHRydWU7XG4gIHN0cmVhbS5wYXVzZWQgPSBmYWxzZTtcbiAgc3RyZWFtLnF1ZXVlID0gW107XG5cbiAgc3RyZWFtLndyaXRlID0gZnVuY3Rpb24oZCkge1xuXG4gICAgaWYgKEJ1ZmZlci5pc0J1ZmZlcihkKSkge1xuICAgICAgZCA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGQsIDApO1xuICAgIH1cblxuICAgIG91dHB1dC5zZW5kTWVzc2FnZShkKTtcblxuICAgIHJldHVybiAhdGhpcy5wYXVzZWQ7XG4gIH1cblxuICBzdHJlYW0uZW5kID0gZnVuY3Rpb24oYnVmKSB7XG4gICAgYnVmICYmIHN0cmVhbS53cml0ZShidWYpO1xuICAgIHN0cmVhbS53cml0YWJsZSA9IGZhbHNlO1xuICB9O1xuXG4gIHN0cmVhbS5kZXN0cm95ID0gZnVuY3Rpb24oKSB7XG4gICAgc3RyZWFtLndyaXRhYmxlID0gZmFsc2U7XG4gIH1cblxuICByZXR1cm4gc3RyZWFtO1xufTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIElucHV0LFxuICBPdXRwdXQsXG5cbiAgY3JlYXRlUmVhZFN0cmVhbSxcbiAgY3JlYXRlV3JpdGVTdHJlYW0sXG5cbiAgQ29uc3RhbnRzOiB7XG4gICAgSW5zdHJ1bWVudHMsXG4gICAgRHJ1bXMsXG4gICAgTm90ZXMsXG4gICAgTWVzc2FnZXMsXG4gIH0sXG4gIFxuICAvLyBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eS5cbiAgaW5wdXQ6IElucHV0LFxuICBvdXRwdXQ6IE91dHB1dCxcbn07XG4iLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCBudWxsLCAiaW1wb3J0ICogYXMgbm9kZV9taWRpIGZyb20gJ0BqdWx1c2lhbi9taWRpJ1xuaW1wb3J0IHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnZXZlbnRzJ1xuaW1wb3J0IHsgTWlkaU1lc3NhZ2UsIE10YyB9IGZyb20gJy4vbXNndHlwZXMuanMnXG5cbmV4cG9ydCBjbGFzcyBJbnB1dCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG5cdHByaXZhdGUgX2lucHV0XG5cdHByaXZhdGUgX3NtcHRlOiBudW1iZXJbXVxuXHRwdWJsaWMgbmFtZTogc3RyaW5nXG5cblx0Y29uc3RydWN0b3IobmFtZTogc3RyaW5nLCB2aXJ0dWFsPzogYm9vbGVhbikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLl9pbnB1dCA9IG5ldyBub2RlX21pZGkuSW5wdXQoKVxuXHRcdHRoaXMuX2lucHV0Lmlnbm9yZVR5cGVzKGZhbHNlLCBmYWxzZSwgZmFsc2UpIC8vIEFsbG93IGFsbCBtZXNzYWdlIHR5cGVzXG5cdFx0dGhpcy5fc21wdGUgPSBbXVxuXHRcdHRoaXMubmFtZSA9IG5hbWVcblx0XHRjb25zdCBpbnB1dFBvcnROdW1iZXJlZE5hbWVzOiBzdHJpbmdbXSA9IGdldElucHV0cygpXG5cblx0XHRpZiAodmlydHVhbCkge1xuXHRcdFx0dGhpcy5faW5wdXQub3BlblZpcnR1YWxQb3J0KG5hbWUpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IG51bUlucHV0cyA9IHRoaXMuX2lucHV0LmdldFBvcnRDb3VudCgpXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG51bUlucHV0czsgaSsrKSB7XG5cdFx0XHRcdGlmIChuYW1lID09PSBpbnB1dFBvcnROdW1iZXJlZE5hbWVzW2ldKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuX2lucHV0Lm9wZW5Qb3J0KGkpXG5cdFx0XHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhgRXJyb3Igb3BlbmluZyBwb3J0ICR7bmFtZX0uXFxuRXJyb3I6ICR7ZXJyfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0dGhpcy5faW5wdXQub24oJ21lc3NhZ2UnLCAoZGVsdGFUaW1lOiBudW1iZXIsIGJ5dGVzOiBudW1iZXJbXSk6IHZvaWQgPT4ge1xuXHRcdFx0Ly8gbm90IGRlYWxpbmcgd2l0aCBzeXNleCBjaHVua3MgbG9uZ2VyIHRoYW4gdGhlIGJ1ZmZlciBBVE1cblxuXHRcdFx0Y29uc3QgbXNnID0gTWlkaU1lc3NhZ2UucGFyc2VNZXNzYWdlKGJ5dGVzKVxuXHRcdFx0aWYgKG1zZyA9PT0gdW5kZWZpbmVkKSByZXR1cm5cblx0XHRcdHRoaXMuZW1pdCgnbWVzc2FnZScsIGRlbHRhVGltZSwgbXNnKVxuXHRcdFx0aWYgKG1zZy5pZCA9PSAnbXRjJykge1xuXHRcdFx0XHR0aGlzLnBhcnNlTXRjKG1zZyBhcyBNdGMpXG5cdFx0XHR9XG5cdFx0fSlcblx0fVxuXG5cdGNsb3NlKCk6IHZvaWQge1xuXHRcdHRoaXMuX2lucHV0LmNsb3NlUG9ydCgpXG5cdFx0dGhpcy5faW5wdXQuZGVzdHJveSgpXG5cdH1cblxuXHRpc1BvcnRPcGVuKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9pbnB1dC5pc1BvcnRPcGVuKClcblx0fVxuXG5cdHBhcnNlTXRjKGRhdGE6IE10Yyk6IHZvaWQge1xuXHRcdGNvbnN0IEZSQU1FX1JBVEVTID0gWzI0LCAyNSwgMjkuOTcsIDMwXVxuXHRcdGNvbnN0IGJ5dGVOdW1iZXI6IG51bWJlciA9IGRhdGEudHlwZVxuXHRcdGxldCB2YWx1ZTogbnVtYmVyID0gZGF0YS52YWx1ZVxuXHRcdGxldCBzbXB0ZUZyYW1lUmF0ZTogbnVtYmVyXG5cblx0XHR0aGlzLl9zbXB0ZVtieXRlTnVtYmVyXSA9IHZhbHVlXG5cblx0XHQvLyBDaGVjayBpZiB3ZSBoYXZlIDggY29tcGxldGUgbWVzc2FnZXMuIElmIHRoaXMuX3NtcHRlWzBdIGlzIHVuZGVmaW5lZCwgdGhlbiB3ZSBzdGFydGVkIGluIHRoZSBtaWRkbGUhXG5cdFx0aWYgKGJ5dGVOdW1iZXIgPT09IDcgJiYgdHlwZW9mIHRoaXMuX3NtcHRlWzBdID09PSAnbnVtYmVyJykge1xuXHRcdFx0Y29uc3QgYml0czogbnVtYmVyW10gPSBbXVxuXHRcdFx0Zm9yIChsZXQgaSA9IDM7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdGNvbnN0IGJpdCA9IHZhbHVlICYgKDEgPDwgaSkgPyAxIDogMFxuXHRcdFx0XHRiaXRzLnB1c2goYml0KVxuXHRcdFx0fVxuXHRcdFx0dmFsdWUgPSBiaXRzWzNdXG5cdFx0XHRzbXB0ZUZyYW1lUmF0ZSA9IEZSQU1FX1JBVEVTWyhiaXRzWzFdIDw8IDEpICsgYml0c1syXV1cblx0XHRcdHRoaXMuX3NtcHRlW2J5dGVOdW1iZXJdID0gdmFsdWVcblxuXHRcdFx0Y29uc3Qgc21wdGUgPSB0aGlzLl9zbXB0ZVxuXHRcdFx0Y29uc3Qgc21wdGVGb3JtYXR0ZWQgPVxuXHRcdFx0XHQoKHNtcHRlWzddIDw8IDQpICsgc21wdGVbNl0pLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSArXG5cdFx0XHRcdCc6JyArXG5cdFx0XHRcdCgoc21wdGVbNV0gPDwgNCkgKyBzbXB0ZVs0XSkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpICtcblx0XHRcdFx0JzonICtcblx0XHRcdFx0KChzbXB0ZVszXSA8PCA0KSArIHNtcHRlWzJdKS50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgK1xuXHRcdFx0XHQnLicgK1xuXHRcdFx0XHQoKHNtcHRlWzFdIDw8IDQpICsgc21wdGVbMF0pLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKVxuXHRcdFx0dGhpcy5lbWl0KCdzbXB0ZScsIHtcblx0XHRcdFx0c21wdGU6IHNtcHRlRm9ybWF0dGVkLFxuXHRcdFx0XHRzbXB0ZUZSOiBzbXB0ZUZyYW1lUmF0ZSxcblx0XHRcdH0pXG5cdFx0fVxuXHR9XG59XG5cbmV4cG9ydCBjbGFzcyBPdXRwdXQge1xuXHRwcml2YXRlIF9vdXRwdXRcblx0cHVibGljIG5hbWU6IHN0cmluZ1xuXG5cdGNvbnN0cnVjdG9yKG5hbWU6IHN0cmluZywgdmlydHVhbD86IGJvb2xlYW4pIHtcblx0XHR0aGlzLl9vdXRwdXQgPSBuZXcgbm9kZV9taWRpLk91dHB1dCgpXG5cdFx0dGhpcy5uYW1lID0gbmFtZVxuXHRcdGNvbnN0IG91dHB1dFBvcnROdW1iZXJlZE5hbWVzOiBzdHJpbmdbXSA9IGdldE91dHB1dHMoKVxuXG5cdFx0aWYgKHZpcnR1YWwpIHtcblx0XHRcdHRoaXMuX291dHB1dC5vcGVuVmlydHVhbFBvcnQobmFtZSlcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgbnVtT3V0cHV0cyA9IHRoaXMuX291dHB1dC5nZXRQb3J0Q291bnQoKVxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBudW1PdXRwdXRzOyBpKyspIHtcblx0XHRcdFx0aWYgKG5hbWUgPT09IG91dHB1dFBvcnROdW1iZXJlZE5hbWVzW2ldKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuX291dHB1dC5vcGVuUG9ydChpKVxuXHRcdFx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coYEVycm9yIG9wZW5pbmcgcG9ydCAke25hbWV9LlxcbkVycm9yOiAke2Vycn1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGNsb3NlKCk6IHZvaWQge1xuXHRcdHRoaXMuX291dHB1dC5jbG9zZVBvcnQoKVxuXHRcdHRoaXMuX291dHB1dC5kZXN0cm95KClcblx0fVxuXG5cdGlzUG9ydE9wZW4oKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX291dHB1dC5pc1BvcnRPcGVuKClcblx0fVxuXG5cdHNlbmQobXNnOiBNaWRpTWVzc2FnZSk6IHZvaWQge1xuXHRcdHRoaXMuX291dHB1dC5zZW5kTWVzc2FnZShtc2cuYnl0ZXMpXG5cdH1cbn1cblxuLy8gdXRpbGl0aWVzXG5leHBvcnQgZnVuY3Rpb24gZ2V0SW5wdXRzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3QgaW5wdXQgPSBuZXcgbm9kZV9taWRpLklucHV0KClcblx0Y29uc3QgaW5wdXRzOiBzdHJpbmdbXSA9IFtdXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQuZ2V0UG9ydENvdW50KCk7IGkrKykge1xuXHRcdGxldCBjb3VudGVyID0gMFxuXHRcdGNvbnN0IHBvcnROYW1lID0gaW5wdXQuZ2V0UG9ydE5hbWUoaSlcblx0XHRsZXQgbnVtYmVyZWRQb3J0TmFtZSA9IHBvcnROYW1lXG5cdFx0d2hpbGUgKGlucHV0cy5pbmNsdWRlcyhudW1iZXJlZFBvcnROYW1lKSkge1xuXHRcdFx0Y291bnRlcisrXG5cdFx0XHRudW1iZXJlZFBvcnROYW1lICs9IGAgJHtjb3VudGVyfWBcblx0XHR9XG5cdFx0aW5wdXRzLnB1c2gobnVtYmVyZWRQb3J0TmFtZSlcblx0fVxuXHRpbnB1dC5jbG9zZVBvcnQoKVxuXHRyZXR1cm4gaW5wdXRzXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRPdXRwdXRzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgb3V0cHV0ID0gbmV3IG5vZGVfbWlkaS5PdXRwdXQoKVxuXHRjb25zdCBvdXRwdXRzOiBzdHJpbmdbXSA9IFtdXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgb3V0cHV0LmdldFBvcnRDb3VudCgpOyBpKyspIHtcblx0XHRsZXQgY291bnRlciA9IDBcblx0XHRjb25zdCBwb3J0TmFtZSA9IG91dHB1dC5nZXRQb3J0TmFtZShpKVxuXHRcdGxldCBudW1iZXJlZFBvcnROYW1lID0gcG9ydE5hbWVcblx0XHR3aGlsZSAob3V0cHV0cy5pbmNsdWRlcyhudW1iZXJlZFBvcnROYW1lKSkge1xuXHRcdFx0Y291bnRlcisrXG5cdFx0XHRudW1iZXJlZFBvcnROYW1lICs9IGAgJHtjb3VudGVyfWBcblx0XHR9XG5cdFx0b3V0cHV0cy5wdXNoKG51bWJlcmVkUG9ydE5hbWUpXG5cdH1cblx0b3V0cHV0LmNsb3NlUG9ydCgpXG5cdHJldHVybiBvdXRwdXRzXG59XG4iLCAiY29uc3QgTUFYXzdfQklUID0gMHg3ZlxuY29uc3QgTUFYXzE0X0JJVCA9IDB4M2ZmZlxuXG5jb25zdCBNSURJX1NUQVRVU19UWVBFUyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KFtcblx0Wydub3Rlb2ZmJywgMHg4MF0sXG5cdFsnbm90ZW9uJywgMHg5MF0sXG5cdFsnYWZ0ZXJ0b3VjaCcsIDB4YTBdLFxuXHRbJ2NjJywgMHhiMF0sXG5cdFsncHJvZ3JhbScsIDB4YzBdLFxuXHRbJ2NoYW5uZWxwcmVzc3VyZScsIDB4ZDBdLFxuXHRbJ3BpdGNoJywgMHhlMF0sXG5cdFsnc3lzZXgnLCAweGYwXSxcblx0WydtdGMnLCAweGYxXSxcblx0Wydwb3NpdGlvbicsIDB4ZjJdLFxuXHRbJ3NlbGVjdCcsIDB4ZjNdLFxuXHRbJ3R1bmUnLCAweGY2XSxcblx0WydzeXNleCBlbmQnLCAweGY3XSxcblx0WydjbG9jaycsIDB4ZjhdLFxuXHRbJ3N0YXJ0JywgMHhmYV0sXG5cdFsnY29udGludWUnLCAweGZiXSxcblx0WydzdG9wJywgMHhmY10sXG5cdFsnYWN0aXZlc2Vuc2UnLCAweGZlXSxcblx0WydyZXNldCcsIDB4ZmZdLFxuXSlcblxuY29uc3QgaGV4ID0gKHZhbDogbnVtYmVyKSA9PiBgJHt2YWx9ICgweCR7dmFsLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfSlgXG5cbmV4cG9ydCBpbnRlcmZhY2UgSU1zZ0FyZ3Mge1xuXHRpZD86IHN0cmluZ1xuXHRieXRlcz86IG51bWJlcltdXG5cdHN0YXR1cz86IG51bWJlclxuXHRjaGFubmVsPzogbnVtYmVyXG5cdHR5cGU/OiBudW1iZXJcblx0bm90ZT86IG51bWJlclxuXHR2ZWxvY2l0eT86IG51bWJlclxuXHRjb250cm9sbGVyPzogbnVtYmVyXG5cdHByZXNzdXJlPzogbnVtYmVyXG5cdHZhbHVlPzogbnVtYmVyXG5cdHByb2dyYW0/OiBudW1iZXJcblx0c29uZz86IG51bWJlclxufVxuXG5leHBvcnQgY2xhc3MgTWlkaU1lc3NhZ2Uge1xuXHRpZCA9ICcnXG5cdGJ5dGVzOiBudW1iZXJbXVxuXHRzdGF0aWMgbm9Nc2c6IElNc2dBcmdzID0ge1xuXHRcdGJ5dGVzOiBbXSxcblx0XHRzdGF0dXM6IDAsXG5cdFx0Y2hhbm5lbDogMCxcblx0XHR0eXBlOiAwLFxuXHRcdG5vdGU6IDAsXG5cdFx0dmVsb2NpdHk6IDAsXG5cdFx0Y29udHJvbGxlcjogMCxcblx0XHRwcmVzc3VyZTogMCxcblx0XHR2YWx1ZTogMCxcblx0XHRwcm9ncmFtOiAwLFxuXHRcdHNvbmc6IDAsXG5cdH1cblxuXHRjb25zdHJ1Y3RvcihieXRlczogbnVtYmVyW10gPSBbXSkge1xuXHRcdHRoaXMuYnl0ZXMgPSBieXRlc1xuXHR9XG5cblx0Z2V0IHN0YXR1cygpOiBudW1iZXIge1xuXHRcdHJldHVybiB0aGlzLmJ5dGVzWzBdID4gMHhlZiA/IHRoaXMuYnl0ZXNbMF0gOiB0aGlzLmJ5dGVzWzBdICYgMHhmMFxuXHR9XG5cdHNldCBzdGF0dXModjogbnVtYmVyKSB7XG5cdFx0dGhpcy5ieXRlc1swXSA9IHYgPiAweGVmID8gdiA6ICh0aGlzLmJ5dGVzWzBdICYgMHgwZikgfCAodiAmIDB4ZjApXG5cdH1cblxuXHRnZXQgY2hhbm5lbCgpOiBudW1iZXIge1xuXHRcdHJldHVybiAodGhpcy5ieXRlc1swXSAmIDB4MGYpICsgMVxuXHR9XG5cdHNldCBjaGFubmVsKHY6IG51bWJlcikge1xuXHRcdHYtLSAvLyBDaGFubmVscyBhcmUgbm9ybWFsbHkgc2hvd24gYXMgMS0xNiBidXQgaW50ZXJuYWxseSBhcmUgMC0xNVxuXHRcdHYgPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgMTUpXG5cdFx0dGhpcy5ieXRlc1swXSA9ICh0aGlzLmJ5dGVzWzBdICYgMHhmMCkgfCAodiAmIDB4MGYpXG5cdH1cblxuXHRwcm90ZWN0ZWQgZ2V0IGRhdGExKCk6IG51bWJlciB7XG5cdFx0cmV0dXJuIHRoaXMuYnl0ZXNbMV0gJiAweDdmXG5cdH1cblx0cHJvdGVjdGVkIHNldCBkYXRhMSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmJ5dGVzWzFdID0gTWlkaU1lc3NhZ2UuY29uc3RyYWluKHYsIE1BWF83X0JJVClcblx0fVxuXG5cdHByb3RlY3RlZCBnZXQgZGF0YTIoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gdGhpcy5ieXRlc1syXSAmIDB4N2Zcblx0fVxuXHRwcm90ZWN0ZWQgc2V0IGRhdGEyKHY6IG51bWJlcikge1xuXHRcdHRoaXMuYnl0ZXNbMl0gPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgTUFYXzdfQklUKVxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGJ5dGVzOiB0aGlzLmJ5dGVzIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3RoaXMuaWR9IE1lc3NhZ2VgXG5cdH1cblxuXHRzdGF0aWMgY29uc3RyYWluKG51bTogbnVtYmVyLCBtYXg6IG51bWJlcik6IG51bWJlciB7XG5cdFx0aWYgKCFOdW1iZXIuaXNGaW5pdGUobnVtKSkgcmV0dXJuIDBcblx0XHRyZXR1cm4gbnVtID4gbWF4ID8gbWF4IDogbnVtIDwgMCA/IDAgOiBudW1cblx0fVxuXG5cdHN0YXRpYyBwYXJzZU1lc3NhZ2UoYnl0ZXM6IG51bWJlcltdID0gW10sIG1zZzogSU1zZ0FyZ3MgPSB0aGlzLm5vTXNnKTogTWlkaU1lc3NhZ2UgfCB1bmRlZmluZWQge1xuXHRcdGxldCBpbmNvbWluZyA9IG5ldyBNaWRpTWVzc2FnZShieXRlcylcblx0XHRsZXQgc3RhdHVzID0gYnl0ZXMubGVuZ3RoID4gMCA/IGluY29taW5nLnN0YXR1cyA6IG1zZy5zdGF0dXMgfHwgMFxuXHRcdGlmIChzdGF0dXMgPT09IDAgJiYgdHlwZW9mIG1zZy5pZCAhPT0gJ3VuZGVmaW5lZCcpIHN0YXR1cyA9IE1JRElfU1RBVFVTX1RZUEVTLmdldChtc2cuaWQpIHx8IDBcblxuXHRcdHN3aXRjaCAoc3RhdHVzKSB7XG5cdFx0XHRjYXNlIDB4ODA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IE5vdGVPZmYobXNnLmNoYW5uZWwhLCBtc2cubm90ZSEsIG1zZy52ZWxvY2l0eSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4OTA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IE5vdGVPbihtc2cuY2hhbm5lbCEsIG1zZy5ub3RlISwgbXNnLnZlbG9jaXR5ISlcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgMHhhMDpcblx0XHRcdFx0aW5jb21pbmcgPSBuZXcgQWZ0ZXJ0b3VjaChtc2cuY2hhbm5lbCEsIG1zZy5ub3RlISwgbXNnLnByZXNzdXJlISlcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgMHhiMDpcblx0XHRcdFx0aW5jb21pbmcgPSBuZXcgQ29udHJvbENoYW5nZShtc2cuY2hhbm5lbCEsIG1zZy5jb250cm9sbGVyISwgbXNnLnZhbHVlISlcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgMHhjMDpcblx0XHRcdFx0aW5jb21pbmcgPSBuZXcgUHJvZ3JhbUNoYW5nZShtc2cuY2hhbm5lbCEsIG1zZy5wcm9ncmFtISlcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgMHhkMDpcblx0XHRcdFx0aW5jb21pbmcgPSBuZXcgQ2hhbm5lbFByZXNzdXJlKG1zZy5jaGFubmVsISwgbXNnLnByZXNzdXJlISlcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgMHhlMDpcblx0XHRcdFx0aW5jb21pbmcgPSBuZXcgUGl0Y2hXaGVlbChtc2cuY2hhbm5lbCEsIG1zZy52YWx1ZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4ZjA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IFN5c2V4KG1zZy5ieXRlcyEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4ZjE6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IE10Yyhtc2cudHlwZSEsIG1zZy52YWx1ZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4Zjg6XG5cdFx0XHRcdHJldHVybiAvLyBpZ25vcmUgTUlESSBDbG9jayBtZXNzYWdlc1xuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0Y29uc29sZS5sb2coYFVuc3VwcG9ydGVkIE1JREkgbWVzc2FnZS4gU3RhdHVzID0gJHtoZXgoc3RhdHVzKX1gKVxuXHRcdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAoYnl0ZXMubGVuZ3RoID4gMCkgaW5jb21pbmcuYnl0ZXMgPSBieXRlcyAvLyBwdXNoIHRoZSBkYXRhIHRvIHRoaXMgbWVzc2FnZVxuXHRcdHJldHVybiBpbmNvbWluZ1xuXHR9XG59XG5cbmNsYXNzIE5vdGVPZmYgZXh0ZW5kcyBNaWRpTWVzc2FnZSB7XG5cdGNvbnN0cnVjdG9yKGM6IG51bWJlciwgbjogbnVtYmVyLCB2OiBudW1iZXIpIHtcblx0XHRzdXBlcigpXG5cdFx0dGhpcy5pZCA9ICdub3Rlb2ZmJ1xuXHRcdHRoaXMuc3RhdHVzID0gMHg4MFxuXHRcdHRoaXMuY2hhbm5lbCA9IGNcblx0XHR0aGlzLm5vdGUgPSBuXG5cdFx0dGhpcy52ZWxvY2l0eSA9IHZcblx0fVxuXG5cdGdldCBub3RlKCkge1xuXHRcdHJldHVybiB0aGlzLmRhdGExXG5cdH1cblx0c2V0IG5vdGUodjogbnVtYmVyKSB7XG5cdFx0dGhpcy5kYXRhMSA9IHZcblx0fVxuXG5cdGdldCB2ZWxvY2l0eSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMlxuXHR9XG5cdHNldCB2ZWxvY2l0eSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGEyID0gdlxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGNoYW5uZWw6IHRoaXMuY2hhbm5lbCwgbm90ZTogdGhpcy5ub3RlLCB2ZWxvY2l0eTogdGhpcy52ZWxvY2l0eSB9XG5cdH1cblxuXHR0b1N0cmluZygpOiBzdHJpbmcge1xuXHRcdHJldHVybiBgJHtzdXBlci50b1N0cmluZygpfSwgY2hhbm5lbDogJHtoZXgodGhpcy5jaGFubmVsKX0sIG5vdGU6ICR7aGV4KHRoaXMubm90ZSl9LCB2ZWxvY2l0eTogJHtoZXgoXG5cdFx0XHR0aGlzLnZlbG9jaXR5LFxuXHRcdCl9YFxuXHR9XG59XG5cbmNsYXNzIE5vdGVPbiBleHRlbmRzIE5vdGVPZmYge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIG46IG51bWJlciwgdjogbnVtYmVyKSB7XG5cdFx0c3VwZXIoYywgbiwgdilcblx0XHR0aGlzLmlkID0gJ25vdGVvbidcblx0XHR0aGlzLnN0YXR1cyA9IDB4OTBcblx0fVxufVxuXG5jbGFzcyBBZnRlcnRvdWNoIGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIG46IG51bWJlciwgcDogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAnYWZ0ZXJ0b3VjaCdcblx0XHR0aGlzLnN0YXR1cyA9IDB4YTBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy5ub3RlID0gblxuXHRcdHRoaXMucHJlc3N1cmUgPSBwXG5cdH1cblxuXHRnZXQgbm90ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMVxuXHR9XG5cdHNldCBub3RlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTEgPSB2XG5cdH1cblxuXHRnZXQgcHJlc3N1cmUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTJcblx0fVxuXHRzZXQgcHJlc3N1cmUodjogbnVtYmVyKSB7XG5cdFx0dGhpcy5kYXRhMiA9IHZcblx0fVxuXG5cdGdldCBhcmdzKCk6IElNc2dBcmdzIHtcblx0XHRyZXR1cm4geyBjaGFubmVsOiB0aGlzLmNoYW5uZWwsIG5vdGU6IHRoaXMubm90ZSwgcHJlc3N1cmU6IHRoaXMucHJlc3N1cmUgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCBub3RlOiAke2hleCh0aGlzLm5vdGUpfSwgcHJlc3N1cmU6ICR7aGV4KFxuXHRcdFx0dGhpcy5wcmVzc3VyZSxcblx0XHQpfWBcblx0fVxufVxuXG5jbGFzcyBDb250cm9sQ2hhbmdlIGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIGNjOiBudW1iZXIsIHY6IG51bWJlcikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ2NjJ1xuXHRcdHRoaXMuc3RhdHVzID0gMHhiMFxuXHRcdHRoaXMuY2hhbm5lbCA9IGNcblx0XHR0aGlzLmNvbnRyb2xsZXIgPSBjY1xuXHRcdHRoaXMudmFsdWUgPSB2XG5cdH1cblxuXHRnZXQgY29udHJvbGxlcigpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMVxuXHR9XG5cdHNldCBjb250cm9sbGVyKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTEgPSB2XG5cdH1cblxuXHRnZXQgdmFsdWUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTJcblx0fVxuXHRzZXQgdmFsdWUodjogbnVtYmVyKSB7XG5cdFx0dGhpcy5kYXRhMiA9IHZcblx0fVxuXG5cdGdldCBhcmdzKCk6IElNc2dBcmdzIHtcblx0XHRyZXR1cm4geyBjaGFubmVsOiB0aGlzLmNoYW5uZWwsIGNvbnRyb2xsZXI6IHRoaXMuY29udHJvbGxlciwgdmFsdWU6IHRoaXMudmFsdWUgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCBjb250cm9sbGVyOiAke2hleCh0aGlzLmNvbnRyb2xsZXIpfSwgdmFsdWU6ICR7aGV4KFxuXHRcdFx0dGhpcy52YWx1ZSxcblx0XHQpfWBcblx0fVxufVxuXG5jbGFzcyBQcm9ncmFtQ2hhbmdlIGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIG46IG51bWJlcikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ3Byb2dyYW0nXG5cdFx0dGhpcy5zdGF0dXMgPSAweGMwXG5cdFx0dGhpcy5jaGFubmVsID0gY1xuXHRcdHRoaXMucHJvZ3JhbSA9IG5cblx0fVxuXG5cdGdldCBwcm9ncmFtKCkge1xuXHRcdHJldHVybiB0aGlzLmRhdGExICsgMSAvLyBQQyBpcyBub3JtYWxseSBzaG93biBhcyAxLTEyOCwgYnV0IGl0J3MgaW50ZXJuYWxseSAwLTEyN1xuXHR9XG5cdHNldCBwcm9ncmFtKHY6IG51bWJlcikge1xuXHRcdHYtLVxuXHRcdHRoaXMuZGF0YTEgPSB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCBwcm9ncmFtOiB0aGlzLnByb2dyYW0gfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCBwcm9ncmFtOiAke2hleCh0aGlzLnByb2dyYW0pfWBcblx0fVxufVxuXG5jbGFzcyBDaGFubmVsUHJlc3N1cmUgZXh0ZW5kcyBNaWRpTWVzc2FnZSB7XG5cdGNvbnN0cnVjdG9yKGM6IG51bWJlciwgcDogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAnY2hhbm5lbHByZXNzdXJlJ1xuXHRcdHRoaXMuc3RhdHVzID0gMHhkMFxuXHRcdHRoaXMuY2hhbm5lbCA9IGNcblx0XHR0aGlzLnByZXNzdXJlID0gcFxuXHR9XG5cblx0Z2V0IHByZXNzdXJlKCkge1xuXHRcdHJldHVybiB0aGlzLmRhdGExXG5cdH1cblx0c2V0IHByZXNzdXJlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTEgPSB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCBwcmVzc3VyZTogdGhpcy5wcmVzc3VyZSB9XG5cdH1cblxuXHR0b1N0cmluZygpOiBzdHJpbmcge1xuXHRcdHJldHVybiBgJHtzdXBlci50b1N0cmluZygpfSwgY2hhbm5lbDogJHtoZXgodGhpcy5jaGFubmVsKX0sIHByZXNzdXJlOiAke2hleCh0aGlzLnByZXNzdXJlKX1gXG5cdH1cbn1cblxuY2xhc3MgUGl0Y2hXaGVlbCBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCB2OiBudW1iZXIpIHtcblx0XHRzdXBlcigpXG5cdFx0dGhpcy5pZCA9ICdwaXRjaCdcblx0XHR0aGlzLnN0YXR1cyA9IDB4ZTBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy52YWx1ZSA9IHZcblx0fVxuXG5cdGdldCB2YWx1ZSgpIHtcblx0XHRyZXR1cm4gKHRoaXMuZGF0YTIgPDwgNykgKyB0aGlzLmRhdGExXG5cdH1cblx0c2V0IHZhbHVlKHY6IG51bWJlcikge1xuXHRcdHYgPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgTUFYXzE0X0JJVClcblx0XHR0aGlzLmRhdGEyID0gKHYgPj4gNykgJiAweDdmXG5cdFx0dGhpcy5kYXRhMSA9IHYgJiAweDdmXG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCB2YWx1ZTogdGhpcy52YWx1ZSB9XG5cdH1cblxuXHR0b1N0cmluZygpOiBzdHJpbmcge1xuXHRcdHJldHVybiBgJHtzdXBlci50b1N0cmluZygpfSwgY2hhbm5lbDogJHtoZXgodGhpcy5jaGFubmVsKX0sIHZhbHVlOiAke2hleCh0aGlzLnZhbHVlKX1gXG5cdH1cbn1cblxuY2xhc3MgU3lzZXggZXh0ZW5kcyBNaWRpTWVzc2FnZSB7XG5cdGNvbnN0cnVjdG9yKGI6IG51bWJlcltdKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAnc3lzZXgnXG5cdFx0dGhpcy5ieXRlcyA9IGJcblx0fVxuXG5cdGdldCBhcmdzKCk6IElNc2dBcmdzIHtcblx0XHRyZXR1cm4geyBieXRlczogdGhpcy5ieXRlcyB9XG5cdH1cblxuXHR0b1N0cmluZygpOiBzdHJpbmcge1xuXHRcdHJldHVybiBgJHtzdXBlci50b1N0cmluZygpfSwgYnl0ZXM6ICR7dGhpcy5ieXRlc31gXG5cdH1cbn1cblxuZXhwb3J0IGNsYXNzIE10YyBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IodDogbnVtYmVyLCB2OiBudW1iZXIpIHtcblx0XHRzdXBlcigpXG5cdFx0dGhpcy5pZCA9ICdtdGMnXG5cdFx0dGhpcy5zdGF0dXMgPSAweGYxXG5cdFx0dGhpcy50eXBlID0gdFxuXHRcdHRoaXMudmFsdWUgPSB2XG5cdH1cblxuXHRnZXQgdHlwZSgpOiBudW1iZXIge1xuXHRcdHJldHVybiAodGhpcy5kYXRhMSA+PiA0KSAmIDB4MDdcblx0fVxuXHRzZXQgdHlwZSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGExID0gKHRoaXMuZGF0YTEgJiAweDBmKSB8ICh2IDw8IDQpXG5cdH1cblxuXHRnZXQgdmFsdWUoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMSAmIDB4MGZcblx0fVxuXHRzZXQgdmFsdWUodjogbnVtYmVyKSB7XG5cdFx0diA9IE1pZGlNZXNzYWdlLmNvbnN0cmFpbih2LCAxNSlcblx0XHR0aGlzLmRhdGExID0gKHRoaXMuZGF0YTEgJiAweGYwKSB8IHZcblx0fVxuXG5cdGdldCBhcmdzKCk6IElNc2dBcmdzIHtcblx0XHRyZXR1cm4geyBjaGFubmVsOiB0aGlzLmNoYW5uZWwsIHR5cGU6IHRoaXMudHlwZSwgdmFsdWU6IHRoaXMudmFsdWUgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIHR5cGU6ICR7aGV4KHRoaXMudHlwZSl9LCB2YWx1ZTogJHtoZXgodGhpcy52YWx1ZSl9YFxuXHR9XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQsIEpzb25PYmplY3QsIERyb3Bkb3duQ2hvaWNlIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB7IGdldElucHV0cywgZ2V0T3V0cHV0cyB9IGZyb20gJy4vbWlkaS9taWRpLmpzJ1xuXG5leHBvcnQgaW50ZXJmYWNlIE1vZHVsZUNvbmZpZyBleHRlbmRzIEpzb25PYmplY3Qge1xuXHRpblBvcnROYW1lOiBzdHJpbmdcblx0aW5Qb3J0VmlydHVhbE5hbWU6IHN0cmluZ1xuXHRpblBvcnRJc1ZpcnR1YWw6IGJvb2xlYW5cblx0b3V0UG9ydE5hbWU6IHN0cmluZ1xuXHRvdXRQb3J0VmlydHVhbE5hbWU6IHN0cmluZ1xuXHRvdXRQb3J0SXNWaXJ0dWFsOiBib29sZWFuXG5cdHVzZVRpbWVTdGFtcDogYm9vbGVhblxuXHRhdXRvQ3JlYXRlVmFyczogYm9vbGVhblxufVxuXG5leHBvcnQgZnVuY3Rpb24gR2V0Q29uZmlnRmllbGRzKCk6IFNvbWVDb21wYW5pb25Db25maWdGaWVsZFtdIHtcblx0Y29uc3QgaW5Qb3J0TmFtZXM6IERyb3Bkb3duQ2hvaWNlW10gPSBbXVxuXHRjb25zdCBvdXRQb3J0TmFtZXM6IERyb3Bkb3duQ2hvaWNlW10gPSBbXVxuXHRjb25zdCBpblBvcnRzOiBzdHJpbmdbXSA9IGdldElucHV0cygpXG5cdGNvbnN0IG91dFBvcnRzOiBzdHJpbmdbXSA9IGdldE91dHB1dHMoKVxuXHRpblBvcnRzLmZvckVhY2goKG0pID0+IHtcblx0XHRpblBvcnROYW1lcy5wdXNoKHsgaWQ6IG0sIGxhYmVsOiBtIH0pXG5cdH0pXG5cdG91dFBvcnRzLmZvckVhY2goKG0pID0+IHtcblx0XHRvdXRQb3J0TmFtZXMucHVzaCh7IGlkOiBtLCBsYWJlbDogbSB9KVxuXHR9KVxuXG5cdHJldHVybiBbXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnaW5Qb3J0TmFtZScsXG5cdFx0XHRsYWJlbDogJ01JREkgSW4nLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiBpblBvcnRzWzBdIHx8ICdOT05FIERFVEVDVEVEJyxcblx0XHRcdGNob2ljZXM6IGluUG9ydE5hbWVzLFxuXHRcdFx0Ly9cdGlzVmlzaWJsZTogKG9wdHMpID0+ICFvcHRzLmluUG9ydElzVmlydHVhbCxcblx0XHR9LFxuXHRcdC8qXG5cdFx0e1xuXHRcdFx0dHlwZTogJ3RleHRpbnB1dCcsXG5cdFx0XHRpZDogJ2luUG9ydFZpcnR1YWxOYW1lJyxcblx0XHRcdGxhYmVsOiAnTUlESSBJbicsXG5cdFx0XHR3aWR0aDogNixcblx0XHRcdGRlZmF1bHQ6ICcnLFxuXHRcdFx0aXNWaXNpYmxlOiAob3B0cykgPT4gISFvcHRzLmluUG9ydElzVmlydHVhbCxcblx0XHR9LFxuXHRcdHtcblx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRpZDogJ2luUG9ydElzVmlydHVhbCcsXG5cdFx0XHRsYWJlbDogJ1ZpcnR1YWwnLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHR9LFxuXHRcdCovXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2Ryb3Bkb3duJyxcblx0XHRcdGlkOiAnb3V0UG9ydE5hbWUnLFxuXHRcdFx0bGFiZWw6ICdNSURJIE91dCcsXG5cdFx0XHR3aWR0aDogNixcblx0XHRcdGRlZmF1bHQ6IG91dFBvcnRzWzBdIHx8ICdOT05FIERFVEVDVEVEJyxcblx0XHRcdGNob2ljZXM6IG91dFBvcnROYW1lcyxcblx0XHRcdC8vXHRpc1Zpc2libGU6IChvcHRzKSA9PiAhb3B0cy5vdXRQb3J0SXNWaXJ0dWFsLFxuXHRcdH0sXG5cdFx0Lypcblx0XHR7XG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGlkOiAnb3V0UG9ydFZpcnR1YWxOYW1lJyxcblx0XHRcdGxhYmVsOiAnTUlESSBPdXQnLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdGlzVmlzaWJsZTogKG9wdHMpID0+ICEhb3B0cy5vdXRQb3J0SXNWaXJ0dWFsLFxuXHRcdH0sXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2NoZWNrYm94Jyxcblx0XHRcdGlkOiAnb3V0UG9ydElzVmlydHVhbCcsXG5cdFx0XHRsYWJlbDogJ1ZpcnR1YWwnLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHR9LFxuXHRcdHtcblx0XHRcdHR5cGU6ICdzdGF0aWMtdGV4dCcsXG5cdFx0XHRpZDogJ2N1c3RvbVRleHQnLFxuXHRcdFx0bGFiZWw6ICdDaG9vc2UgZXhpc3RpbmcgcG9ydHMsIG9yIHR5cGUgYSBjdXN0b20gbmFtZSB0byBjcmVhdGUgYSBWaXJ0dWFsIFBvcnQnLFxuXHRcdFx0d2lkdGg6IDEyLFxuXHRcdFx0dmFsdWU6ICcnLFxuXHRcdH0sXG5cdFx0Ki9cblx0XHR7XG5cdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0aWQ6ICd1c2VUaW1lU3RhbXAnLFxuXHRcdFx0bGFiZWw6ICdVc2UgVGltZVN0YW1wIHdpdGggQWN0aW9uIFJlY29yZGVyJyxcblx0XHRcdHRvb2x0aXA6ICdFbmFibGUgdGhpcyBzZXR0aW5nIHRvIGluY2x1ZGUgdGhlIGRlbGF5IHRpbWUgZm9yIGFjdGlvbnMgY3JlYXRlZCBpbiBBY3Rpb24gUmVjb3JkZXInLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHR9LFxuXHRcdHtcblx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRpZDogJ2F1dG9DcmVhdGVWYXJzJyxcblx0XHRcdGxhYmVsOiAnRW5hYmxlIFwiQXV0by1DcmVhdGVkIFZhcmlhYmxlcyBmdW5jdGlvblwiJyxcblx0XHRcdHRvb2x0aXA6ICdFbmFibGUgdGhpcyBzZXR0aW5nIE9OTFkgaWYgeW91IG5lZWQgY29tcGF0aWJpbGl0eSB3aXRoIGV4aXN0aW5nIEF1dG8tQ3JlYXRlZCB2YXJpYWJsZXMnLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiBmYWxzZSxcblx0XHR9LFxuXHRcdHtcblx0XHRcdHR5cGU6ICdzdGF0aWMtdGV4dCcsXG5cdFx0XHRpZDogJ2F1dG9DcmVhdGVWYXJOb3RpY2UnLFxuXHRcdFx0bGFiZWw6ICcqKiogU3VwcG9ydCBmb3IgdGhlIGRlcHJlY2F0ZWQgXCJBdXRvLUNyZWF0ZWQgVmFyaWFibGVcIiBmdW5jdGlvbiAqKionLFxuXHRcdFx0dmFsdWU6XG5cdFx0XHRcdCdUaGUgXCJBdXRvLUNyZWF0ZSBWYXJpYWJsZVwiIGZ1bmN0aW9uIGhhcyBub3cgYmVlbiBzdXBlcmNlZGVkIGJ5IHRoZSBidWlsdC1pbiBMb2NhbCBWYXJpYWJsZXMgZmVhdHVyZSB3aXRoaW4gQ29tcGFuaW9uIDQuMisuPGJyPklmIHlvdSBzdGlsbCBoYXZlIGF1dG8tY3JlYXRlZCB2YXJpYWJsZXMsIHBsZWFzZSBjaGFuZ2UgdGhlbSB0byBWYWx1ZSBGZWVkYmFja3MgYXMgc3VwcG9ydCBmb3IgQXV0by1DcmVhdGVkIFZhcmlhYmxlcyBtYXkgZGlzYXBwZWFyIGluIHRoZSBmdXR1cmUhJyxcblx0XHRcdHRvb2x0aXA6ICdFbmFibGUgdGhpcyBzZXR0aW5nIE9OTFkgaWYgeW91IG5lZWQgY29tcGF0aWJpbGl0eSB3aXRoIGV4aXN0aW5nIEF1dG8tQ3JlYXRlZCB2YXJpYWJsZXMnLFxuXHRcdFx0d2lkdGg6IDEyLFxuXHRcdH0sXG5cdF1cbn1cbiIsICJpbXBvcnQgdHlwZSB7IENvbXBhbmlvblZhcmlhYmxlRGVmaW5pdGlvbnMgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IHR5cGUgSU1zZ0FyZ3MsIE1pZGlNZXNzYWdlIH0gZnJvbSAnLi9taWRpL21zZ3R5cGVzLmpzJ1xuXG5leHBvcnQgdHlwZSBtaWRpVmFycyA9IHtcblx0bWlkaUluOiBib29sZWFuXG5cdG1pZGlPdXQ6IGJvb2xlYW5cblx0bGFzdE1lc3NhZ2U6IHN0cmluZ1xuXHRzbXB0ZTogc3RyaW5nXG5cdHNtcHRlRlI6IG51bWJlclxuXHRub3RlU3RhdGVzOiBib29sZWFuW11bXVxufVxuXG5jb25zdCB2YXJpYWJsZXM6IENvbXBhbmlvblZhcmlhYmxlRGVmaW5pdGlvbnM8bWlkaVZhcnM+ID0ge1xuXHRtaWRpSW46IHsgbmFtZTogJ0lzIGEgTUlESSBNZXNzYWdlIEluY29taW5nPycgfSxcblx0bWlkaU91dDogeyBuYW1lOiAnSXMgYSBNSURJIE1lc3NhZ2UgT3V0Z29pbmc/JyB9LFxuXHRsYXN0TWVzc2FnZTogeyBuYW1lOiAnTGFzdCBNZXNzYWdlIFJlY2VpdmVkJyB9LFxuXHRzbXB0ZTogeyBuYW1lOiAnU01QVEUgVEMgZnJvbSBNVEMnIH0sXG5cdHNtcHRlRlI6IHsgbmFtZTogJ1NNUFRFIEZyYW1lIFJhdGUgZnJvbSBNVEMnIH0sXG5cdG5vdGVTdGF0ZXM6IHsgbmFtZTogJ0N1cnJlbnQgTm90ZSBzdGF0ZXMnIH0sXG59XG5cbmNvbnN0IG1pZGlUaW1lcnM6IE1hcDxzdHJpbmcsIFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbD4gPSBuZXcgTWFwKClcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0c2VsZi5zZXRWYXJpYWJsZURlZmluaXRpb25zKHZhcmlhYmxlcylcblx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7IG1pZGlJbjogZmFsc2UsIG1pZGlPdXQ6IGZhbHNlIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBIYW5kbGVNaWRpSW5kaWNhdG9ycyhzZWxmOiBNb2R1bGVJbnN0YW5jZSwgdmFyaWFibGU6IHN0cmluZyk6IHZvaWQge1xuXHRsZXQgdCA9IG1pZGlUaW1lcnMuZ2V0KHZhcmlhYmxlKSA/PyBudWxsXG5cdGlmICh0ICE9PSBudWxsKSBjbGVhclRpbWVvdXQodClcblx0dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBbdmFyaWFibGVdOiBmYWxzZSB9KVxuXHRcdHNlbGYuY2hlY2tGZWVkYmFja3ModmFyaWFibGUpXG5cdH0sIDIwMClcblx0bWlkaVRpbWVycy5zZXQodmFyaWFibGUsIHQpXG5cdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBbdmFyaWFibGVdOiB0cnVlIH0pXG5cdHNlbGYuY2hlY2tGZWVkYmFja3ModmFyaWFibGUpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVMYXN0TXNnKHNlbGY6IE1vZHVsZUluc3RhbmNlLCBtc2c6IE1pZGlNZXNzYWdlLCBkYXRhOiBudW1iZXIgfCB1bmRlZmluZWQpOiB2b2lkIHtcblx0Y29uc3QgbXNnSW5mbyA9IENyZWF0ZVZhck5hbWUobXNnKVxuXHRjb25zdCBsYXN0TXNnID0gbXNnSW5mby5uYW1lICsgJ18nICsgZGF0YVxuXHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHsgbGFzdE1lc3NhZ2U6IGxhc3RNc2cgfSlcblxuXHRBZGRPclVwZGF0ZVZhcihzZWxmLCAnbGFzdE1zZ1R5cGUnLCAnTGFzdCBNZXNzYWdlIFR5cGUgUmVjZWl2ZWQnLCBtc2cuaWQpXG5cblx0aWYgKG1zZy5pZCA9PSAnbm90ZW9uJyB8fCBtc2cuaWQgPT0gJ25vdGVvZmYnKSB7XG5cdFx0Y29uc3QgY2hhbm5lbEluZGV4ID0gbXNnLmNoYW5uZWwgLSAxXG5cdFx0c2VsZi5ub3RlU3RhdGVzW2NoYW5uZWxJbmRleF0gPz89IFtdXG5cdFx0c2VsZi5ub3RlU3RhdGVzW2NoYW5uZWxJbmRleF1bbXNnLmFyZ3Mubm90ZSFdID0gbXNnLmlkID09ICdub3Rlb24nICYmIGRhdGEhID4gMFxuXHRcdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBub3RlU3RhdGVzOiBzdHJ1Y3R1cmVkQ2xvbmUoc2VsZi5ub3RlU3RhdGVzKSB9KVxuXHR9XG5cblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBtc2dJbmZvLmtleXMubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCBrZXlOYW1lID0gbXNnSW5mby5rZXlzW2ldXG5cdFx0Y29uc3Qga2V5ID0ga2V5TmFtZSBhcyBrZXlvZiBJTXNnQXJnc1xuXHRcdGNvbnN0IENhcEtleU5hbWUgPSBrZXlOYW1lWzBdLnRvVXBwZXJDYXNlKCkgKyBrZXlOYW1lLnNsaWNlKDEpXG5cdFx0QWRkT3JVcGRhdGVWYXIoc2VsZiwgJ2xhc3QnICsgQ2FwS2V5TmFtZSwgJ0xhc3QgJyArIENhcEtleU5hbWUgKyAnIFJlY2VpdmVkJywgTnVtYmVyKG1zZy5hcmdzW2tleV0pKVxuXHR9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBGQkNyZWF0ZXNWYXIoc2VsZjogTW9kdWxlSW5zdGFuY2UsIG1zZzogTWlkaU1lc3NhZ2UsIGRhdGE6IG51bWJlciB8IHVuZGVmaW5lZCk6IHZvaWQge1xuXHQvLyBBdXRvLWNyZWF0ZSBhIHZhcmlhYmxlXG5cdEFkZE9yVXBkYXRlVmFyKHNlbGYsICdfJyArIENyZWF0ZVZhck5hbWUobXNnKS5uYW1lLCAnQXV0by1DcmVhdGVkIFZhcmlhYmxlJywgZGF0YSlcbn1cblxuZnVuY3Rpb24gQ3JlYXRlVmFyTmFtZShtc2c6IE1pZGlNZXNzYWdlKTogeyBuYW1lOiBzdHJpbmc7IGtleXM6IHN0cmluZ1tdIH0ge1xuXHQvLyBBdXRvLWNyZWF0ZSBhIHZhcmlhYmxlIG5hbWVcblxuXHRsZXQgdmFyTmFtZSA9IG1zZy5pZFxuXHRjb25zdCBtc2dLZXlzID0gT2JqZWN0LmtleXMobXNnLmFyZ3MpXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbXNnS2V5cy5sZW5ndGggLSAxOyBpKyspIHtcblx0XHRjb25zdCBrZXkgPSBtc2dLZXlzW2ldIGFzIGtleW9mIElNc2dBcmdzXG5cdFx0Y29uc3QgdmFsOiBudW1iZXIgfCB1bmRlZmluZWQgPSBOdW1iZXIobXNnLmFyZ3Nba2V5XSlcblx0XHRpZiAodmFsICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdHZhck5hbWUgKz0gYF8ke3ZhbH1gXG5cdFx0fVxuXHR9XG5cdHJldHVybiB7IG5hbWU6IHZhck5hbWUsIGtleXM6IG1zZ0tleXMgfVxufVxuXG5mdW5jdGlvbiBBZGRPclVwZGF0ZVZhcihcblx0c2VsZjogTW9kdWxlSW5zdGFuY2UsXG5cdHZhck5hbWU6IHN0cmluZyxcblx0dmFyRGVzY3I6IHN0cmluZyxcblx0ZGF0YTogbnVtYmVyIHwgc3RyaW5nIHwgdW5kZWZpbmVkLFxuKTogdm9pZCB7XG5cdDsodmFyaWFibGVzIGFzIFJlY29yZDxzdHJpbmcsIHsgbmFtZTogc3RyaW5nIH0+KVt2YXJOYW1lXSA9IHsgbmFtZTogdmFyRGVzY3IgfSAvLyBpZiBWYXJpYWJsZSBkb2Vzbid0IGV4aXN0LCBhZGQgaXRcblx0c2VsZi5zZXRWYXJpYWJsZURlZmluaXRpb25zKHZhcmlhYmxlcylcblx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7IFt2YXJOYW1lXTogZGF0YSB9KVxufVxuIiwgImltcG9ydCB7IEZpeHVwTnVtZXJpY09yVmFyaWFibGVzVmFsdWVUb0V4cHJlc3Npb25zIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHtcblx0Q29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdCxcblx0Q29tcGFuaW9uU3RhdGljVXBncmFkZVJlc3VsdCxcblx0Q29tcGFuaW9uU3RhdGljVXBncmFkZVByb3BzLFxuXHRDb21wYW5pb25VcGdyYWRlQ29udGV4dCxcbn0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHsgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5cbmV4cG9ydCBjb25zdCBVcGdyYWRlU2NyaXB0czogQ29tcGFuaW9uU3RhdGljVXBncmFkZVNjcmlwdDxNb2R1bGVDb25maWc+W10gPSBbXG5cdC8qXG5cdCAqIFBsYWNlIHlvdXIgdXBncmFkZSBzY3JpcHRzIGhlcmVcblx0ICogUmVtZW1iZXIgdGhhdCBvbmNlIGl0IGhhcyBiZWVuIGFkZGVkIGl0IGNhbm5vdCBiZSByZW1vdmVkIVxuXHQgKi9cblx0ZnVuY3Rpb24gKFxuXHRcdF9jb250ZXh0OiBDb21wYW5pb25VcGdyYWRlQ29udGV4dDxNb2R1bGVDb25maWc+LFxuXHRcdHByb3BzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUHJvcHM8TW9kdWxlQ29uZmlnLCB1bmRlZmluZWQ+LFxuXHQpOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUmVzdWx0PE1vZHVsZUNvbmZpZywgdW5kZWZpbmVkPiB7XG5cdFx0Y29uc3QgY2hhbmdlczogQ29tcGFuaW9uU3RhdGljVXBncmFkZVJlc3VsdDxNb2R1bGVDb25maWcsIHVuZGVmaW5lZD4gPSB7XG5cdFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHRcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHRcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdFx0fVxuXG5cdFx0Zm9yIChjb25zdCBhIG9mIHByb3BzLmFjdGlvbnMpIHtcblx0XHRcdGxldCBjaGFuZ2VkID0gZmFsc2Vcblx0XHRcdGlmIChhLmFjdGlvbklkID09ICdwcm9ncmFtJyAmJiBhLm9wdGlvbnMubnVtYmVyICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0Y29uc3QgcHJvZ3JhbSA9IGEub3B0aW9ucy5udW1iZXJcblx0XHRcdFx0aWYgKHByb2dyYW0gIT09IHVuZGVmaW5lZCAmJiBhLm9wdGlvbnMucHJvZ3JhbSA9PT0gdW5kZWZpbmVkKSBhLm9wdGlvbnMucHJvZ3JhbSA9IHByb2dyYW1cblx0XHRcdFx0ZGVsZXRlIGEub3B0aW9ucy5udW1iZXJcblx0XHRcdFx0Y2hhbmdlZCA9IHRydWVcblx0XHRcdH1cblx0XHRcdGlmIChjaGFuZ2VkKSBjaGFuZ2VzLnVwZGF0ZWRBY3Rpb25zLnB1c2goYSlcblx0XHR9XG5cblx0XHRmb3IgKGNvbnN0IGYgb2YgcHJvcHMuZmVlZGJhY2tzKSB7XG5cdFx0XHRpZiAoZi5mZWVkYmFja0lkID09ICdyZWNlaXZlX21lc3NhZ2UnKSB7XG5cdFx0XHRcdGNvbnN0IG1zZ1R5cGUgPSBmLm9wdGlvbnMubXNnVHlwZVxuXHRcdFx0XHRjb25zdCByYXdJZCA9IG1zZ1R5cGUgJiYgIW1zZ1R5cGUuaXNFeHByZXNzaW9uID8gbXNnVHlwZS52YWx1ZSA6IHVuZGVmaW5lZFxuXHRcdFx0XHRjb25zdCBpZCA9IHR5cGVvZiByYXdJZCA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHJhd0lkID09PSAnbnVtYmVyJyA/IFN0cmluZyhyYXdJZCkgOiAnJ1xuXHRcdFx0XHRpZiAoIWlkKSBjb250aW51ZVxuXHRcdFx0XHRmLmZlZWRiYWNrSWQgPSBpZFxuXHRcdFx0XHRkZWxldGUgZi5vcHRpb25zLm1zZ1R5cGVcblx0XHRcdFx0bGV0IGtleTogc3RyaW5nIHwgdW5kZWZpbmVkXG5cdFx0XHRcdHN3aXRjaCAoZi5mZWVkYmFja0lkKSB7XG5cdFx0XHRcdFx0Y2FzZSAncHJvZ3JhbSc6XG5cdFx0XHRcdFx0XHRrZXkgPSAnbnVtYmVyJ1xuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHRjYXNlICdzeXNleCc6XG5cdFx0XHRcdFx0XHRrZXkgPSAnbWVzc2FnZSdcblx0XHRcdFx0XHRcdGJyZWFrXG5cdFx0XHRcdFx0Y2FzZSAncGl0Y2gnOlxuXHRcdFx0XHRcdFx0a2V5ID0gJ3BpdGNoJ1xuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoa2V5ICYmIGYub3B0aW9uc1trZXldICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRmLm9wdGlvbnNba2V5ID09PSAnbnVtYmVyJyA/ICdwcm9ncmFtJyA6IGtleSA9PT0gJ21lc3NhZ2UnID8gJ2J5dGVzJyA6ICd2YWx1ZSddID0gZi5vcHRpb25zW2tleV1cblx0XHRcdFx0XHRkZWxldGUgZi5vcHRpb25zW2tleV1cblx0XHRcdFx0fVxuXHRcdFx0XHRjaGFuZ2VzLnVwZGF0ZWRGZWVkYmFja3MucHVzaChmKVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHJldHVybiBjaGFuZ2VzXG5cdH0sXG5cblx0ZnVuY3Rpb24gKFxuXHRcdF9jb250ZXh0OiBDb21wYW5pb25VcGdyYWRlQ29udGV4dDxNb2R1bGVDb25maWc+LFxuXHRcdHByb3BzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUHJvcHM8TW9kdWxlQ29uZmlnLCB1bmRlZmluZWQ+LFxuXHQpOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUmVzdWx0PE1vZHVsZUNvbmZpZywgdW5kZWZpbmVkPiB7XG5cdFx0Y29uc3QgY2hhbmdlczogQ29tcGFuaW9uU3RhdGljVXBncmFkZVJlc3VsdDxNb2R1bGVDb25maWcsIHVuZGVmaW5lZD4gPSB7XG5cdFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHRcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHRcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdFx0fVxuXG5cdFx0Zm9yIChjb25zdCBhIG9mIHByb3BzLmFjdGlvbnMpIHtcblx0XHRcdGlmIChhLmFjdGlvbklkID09PSAnc3lzZXgnKSBjb250aW51ZVxuXHRcdFx0bGV0IGNoYW5nZWQgPSBmYWxzZVxuXG5cdFx0XHRpZiAoIWEub3B0aW9ucy5zZW5kT3ZlclRpbWUpIHtcblx0XHRcdFx0YS5vcHRpb25zLnNlbmRPdmVyVGltZSA9IHsgaXNFeHByZXNzaW9uOiBmYWxzZSwgdmFsdWU6IGZhbHNlIH1cblx0XHRcdFx0Y2hhbmdlZCA9IHRydWVcblx0XHRcdH1cblx0XHRcdGlmICghYS5vcHRpb25zLnRpbWVTdGFydFZhbHVlKSB7XG5cdFx0XHRcdGEub3B0aW9ucy50aW1lU3RhcnRWYWx1ZSA9IHsgaXNFeHByZXNzaW9uOiBmYWxzZSwgdmFsdWU6IDAgfVxuXHRcdFx0XHRjaGFuZ2VkID0gdHJ1ZVxuXHRcdFx0fVxuXHRcdFx0aWYgKCFhLm9wdGlvbnMudGltZSkge1xuXHRcdFx0XHRhLm9wdGlvbnMudGltZSA9IHsgaXNFeHByZXNzaW9uOiBmYWxzZSwgdmFsdWU6IDEgfVxuXHRcdFx0XHRjaGFuZ2VkID0gdHJ1ZVxuXHRcdFx0fVxuXHRcdFx0aWYgKCFhLm9wdGlvbnMuY3VydmUpIHtcblx0XHRcdFx0YS5vcHRpb25zLmN1cnZlID0geyBpc0V4cHJlc3Npb246IGZhbHNlLCB2YWx1ZTogJ2xpbmVhcicgfVxuXHRcdFx0XHRjaGFuZ2VkID0gdHJ1ZVxuXHRcdFx0fVxuXG5cdFx0XHRpZiAoY2hhbmdlZCkgY2hhbmdlcy51cGRhdGVkQWN0aW9ucy5wdXNoKGEpXG5cdFx0fVxuXG5cdFx0cmV0dXJuIGNoYW5nZXNcblx0fSxcblx0ZnVuY3Rpb24gKFxuXHRcdGNvbnRleHQ6IENvbXBhbmlvblVwZ3JhZGVDb250ZXh0PE1vZHVsZUNvbmZpZz4sXG5cdFx0cHJvcHM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVQcm9wczxNb2R1bGVDb25maWcsIHVuZGVmaW5lZD4sXG5cdCk6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVSZXN1bHQ8TW9kdWxlQ29uZmlnLCB1bmRlZmluZWQ+IHtcblx0XHRjb25zdCBjaGFuZ2VzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUmVzdWx0PE1vZHVsZUNvbmZpZywgdW5kZWZpbmVkPiA9IHtcblx0XHRcdHVwZGF0ZWRDb25maWc6IG51bGwsXG5cdFx0XHR1cGRhdGVkQWN0aW9uczogW10sXG5cdFx0XHR1cGRhdGVkRmVlZGJhY2tzOiBbXSxcblx0XHR9XG5cdFx0bGV0IGVuYWJsZUF1dG9DcmVhdGVWYXJzID0gZmFsc2VcblxuXHRcdGZvciAoY29uc3QgYWN0aW9uIG9mIHByb3BzLmFjdGlvbnMpIHtcblx0XHRcdGlmIChhY3Rpb24ub3B0aW9ucy51c2VWYXJpYWJsZXM/LnZhbHVlICE9PSB0cnVlKSBjb250aW51ZVxuXHRcdFx0Y29uc3QgdmFsSWQgPVxuXHRcdFx0XHRhY3Rpb24uYWN0aW9uSWQgPT09ICdwcm9ncmFtJ1xuXHRcdFx0XHRcdD8gJ3Byb2dyYW0nXG5cdFx0XHRcdFx0OiBhY3Rpb24uYWN0aW9uSWQgPT09ICdzeXNleCdcblx0XHRcdFx0XHRcdD8gJ2J5dGVzJ1xuXHRcdFx0XHRcdFx0OiBhY3Rpb24uYWN0aW9uSWQgPT09ICdub3Rlb24nIHx8IGFjdGlvbi5hY3Rpb25JZCA9PT0gJ25vdGVvZmYnXG5cdFx0XHRcdFx0XHRcdD8gJ3ZlbG9jaXR5J1xuXHRcdFx0XHRcdFx0XHQ6ICd2YWx1ZSdcblx0XHRcdGZvciAoY29uc3QgW29sZEtleSwgbmV3S2V5XSBvZiBbXG5cdFx0XHRcdFsnY2hWYWx1ZScsICdjaGFubmVsJ10sXG5cdFx0XHRcdFsnbm90ZVZhbHVlJywgJ25vdGUnXSxcblx0XHRcdFx0WydjY1ZhbHVlJywgJ2NvbnRyb2xsZXInXSxcblx0XHRcdFx0Wyd2YXJWYWx1ZScsIHZhbElkXSxcblx0XHRcdF0pIHtcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBhY3Rpb24ub3B0aW9uc1tvbGRLZXldXG5cdFx0XHRcdGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSBhY3Rpb24ub3B0aW9uc1tuZXdLZXldID0gRml4dXBOdW1lcmljT3JWYXJpYWJsZXNWYWx1ZVRvRXhwcmVzc2lvbnModmFsdWUpXG5cdFx0XHRcdGRlbGV0ZSBhY3Rpb24ub3B0aW9uc1tvbGRLZXldXG5cdFx0XHR9XG5cdFx0XHRkZWxldGUgYWN0aW9uLm9wdGlvbnMudXNlVmFyaWFibGVzXG5cdFx0XHRjaGFuZ2VzLnVwZGF0ZWRBY3Rpb25zLnB1c2goYWN0aW9uKVxuXHRcdH1cblxuXHRcdGZvciAoY29uc3QgZmVlZGJhY2sgb2YgcHJvcHMuZmVlZGJhY2tzKSB7XG5cdFx0XHRpZiAoZmVlZGJhY2sub3B0aW9ucy5jcmVhdGVWYXI/LnZhbHVlID09PSB0cnVlKSBlbmFibGVBdXRvQ3JlYXRlVmFycyA9IHRydWVcblx0XHRcdGlmIChmZWVkYmFjay5vcHRpb25zLnVzZVZhcmlhYmxlcz8udmFsdWUgIT09IHRydWUpIGNvbnRpbnVlXG5cdFx0XHRjb25zdCB2YWxJZCA9XG5cdFx0XHRcdGZlZWRiYWNrLmZlZWRiYWNrSWQgPT09ICdwcm9ncmFtJ1xuXHRcdFx0XHRcdD8gJ3Byb2dyYW0nXG5cdFx0XHRcdFx0OiBmZWVkYmFjay5mZWVkYmFja0lkID09PSAnc3lzZXgnXG5cdFx0XHRcdFx0XHQ/ICdieXRlcydcblx0XHRcdFx0XHRcdDogZmVlZGJhY2suZmVlZGJhY2tJZCA9PT0gJ25vdGVvbicgfHwgZmVlZGJhY2suZmVlZGJhY2tJZCA9PT0gJ25vdGVvZmYnXG5cdFx0XHRcdFx0XHRcdD8gJ3ZlbG9jaXR5J1xuXHRcdFx0XHRcdFx0XHQ6ICd2YWx1ZSdcblx0XHRcdGZvciAoY29uc3QgW29sZEtleSwgbmV3S2V5XSBvZiBbXG5cdFx0XHRcdFsnY2hWYWx1ZScsICdjaGFubmVsJ10sXG5cdFx0XHRcdFsnbm90ZVZhbHVlJywgJ25vdGUnXSxcblx0XHRcdFx0WydjY1ZhbHVlJywgJ2NvbnRyb2xsZXInXSxcblx0XHRcdFx0Wyd2YXJWYWx1ZScsIHZhbElkXSxcblx0XHRcdF0pIHtcblx0XHRcdFx0Y29uc3QgdmFsdWUgPSBmZWVkYmFjay5vcHRpb25zW29sZEtleV1cblx0XHRcdFx0aWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIGZlZWRiYWNrLm9wdGlvbnNbbmV3S2V5XSA9IEZpeHVwTnVtZXJpY09yVmFyaWFibGVzVmFsdWVUb0V4cHJlc3Npb25zKHZhbHVlKVxuXHRcdFx0XHRkZWxldGUgZmVlZGJhY2sub3B0aW9uc1tvbGRLZXldXG5cdFx0XHR9XG5cdFx0XHRkZWxldGUgZmVlZGJhY2sub3B0aW9ucy51c2VWYXJpYWJsZXNcblx0XHRcdGNoYW5nZXMudXBkYXRlZEZlZWRiYWNrcy5wdXNoKGZlZWRiYWNrKVxuXHRcdH1cblxuXHRcdGlmIChlbmFibGVBdXRvQ3JlYXRlVmFycyAmJiAhY29udGV4dC5jdXJyZW50Q29uZmlnLmF1dG9DcmVhdGVWYXJzKSB7XG5cdFx0XHRjaGFuZ2VzLnVwZGF0ZWRDb25maWcgPSB7IC4uLmNvbnRleHQuY3VycmVudENvbmZpZywgYXV0b0NyZWF0ZVZhcnM6IHRydWUgfVxuXHRcdH1cblx0XHRyZXR1cm4gY2hhbmdlc1xuXHR9LFxuXVxuIiwgImltcG9ydCB0eXBlIHsgU29tZUNvbXBhbmlvbkFjdGlvbklucHV0RmllbGQsIFNvbWVDb21wYW5pb25GZWVkYmFja0lucHV0RmllbGQgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuXG5pbnRlcmZhY2UgbWlkaU1zZ1R5cGUge1xuXHRpZDogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVzYzogc3RyaW5nXG5cdHZhbElkOiBzdHJpbmdcblx0dmFsTGFiZWw6IHN0cmluZ1xuXHR2YWxNaW46IG51bWJlclxuXHR2YWxNYXg6IG51bWJlclxuXHR2YWxEZWZhdWx0OiBudW1iZXJcbn1cblxuZXhwb3J0IGNvbnN0IG1pZGlNc2dUeXBlczogbWlkaU1zZ1R5cGVbXSA9IFtcblx0e1xuXHRcdGlkOiAnbm90ZW9mZicsXG5cdFx0bGFiZWw6ICdOb3RlIE9mZicsXG5cdFx0ZGVzYzogJ05vdGUgT2ZmIE1lc3NzYWdlJyxcblx0XHR2YWxJZDogJ3ZlbG9jaXR5Jyxcblx0XHR2YWxMYWJlbDogJ1ZlbG9jaXR5Jyxcblx0XHR2YWxNaW46IDAsXG5cdFx0dmFsTWF4OiAxMjcsXG5cdFx0dmFsRGVmYXVsdDogMCxcblx0fSxcblx0e1xuXHRcdGlkOiAnbm90ZW9uJyxcblx0XHRsYWJlbDogJ05vdGUgT24nLFxuXHRcdGRlc2M6ICdOb3RlIE9uIE1lc3NhZ2UnLFxuXHRcdHZhbElkOiAndmVsb2NpdHknLFxuXHRcdHZhbExhYmVsOiAnVmVsb2NpdHknLFxuXHRcdHZhbE1pbjogMCxcblx0XHR2YWxNYXg6IDEyNyxcblx0XHR2YWxEZWZhdWx0OiAxMjcsXG5cdH0sXG5cdC8vXHRcdHsgaWQ6ICdhZnRlcnRvdWNoJywgbmFtZTogJ0FmdGVydG91Y2gnIH0sXG5cdHtcblx0XHRpZDogJ2NjJyxcblx0XHRsYWJlbDogJ0NDJyxcblx0XHRkZXNjOiAnQ29udHJvbCBDaGFuZ2UgTWVzc2FnZScsXG5cdFx0dmFsSWQ6ICd2YWx1ZScsXG5cdFx0dmFsTGFiZWw6ICdWYWx1ZScsXG5cdFx0dmFsTWluOiAwLFxuXHRcdHZhbE1heDogMTI3LFxuXHRcdHZhbERlZmF1bHQ6IDAsXG5cdH0sXG5cdHtcblx0XHRpZDogJ3Byb2dyYW0nLFxuXHRcdGxhYmVsOiAnUHJvZ3JhbSBDaGFuZ2UnLFxuXHRcdGRlc2M6ICdQcm9ncmFtIENoYW5nZSBNZXNzYWdlJyxcblx0XHR2YWxJZDogJ3Byb2dyYW0nLFxuXHRcdHZhbExhYmVsOiAnUHJvZ3JhbSBOdW1iZXInLFxuXHRcdHZhbE1pbjogMSxcblx0XHR2YWxNYXg6IDEyOCxcblx0XHR2YWxEZWZhdWx0OiAxLFxuXHR9LFxuXHQvL1x0XHR7IGlkOiAnY2hhbm5lbHByZXNzdXJlJywgXHRuYW1lOiAnQ2hhbm5lbCBQcmVzc3VyZScgfSxcblx0e1xuXHRcdGlkOiAncGl0Y2gnLFxuXHRcdGxhYmVsOiAnUGl0Y2ggV2hlZWwnLFxuXHRcdGRlc2M6ICdQaXRjaCBXaGVlbCBNZXNzYWdlJyxcblx0XHR2YWxJZDogJ3ZhbHVlJyxcblx0XHR2YWxMYWJlbDogJ1ZhbHVlJyxcblx0XHR2YWxNaW46IDAsXG5cdFx0dmFsTWF4OiAxNjM4Myxcblx0XHR2YWxEZWZhdWx0OiA4MTkyLFxuXHR9LFxuXHR7XG5cdFx0aWQ6ICdzeXNleCcsXG5cdFx0bGFiZWw6ICdTeXNFeCcsXG5cdFx0ZGVzYzogJ1N5c3RlbSBFeGNsdXNpdmUgTWVzc2FnZScsXG5cdFx0dmFsSWQ6ICdieXRlcycsXG5cdFx0dmFsTGFiZWw6ICdTeXNFeCBCeXRlcycsXG5cdFx0dmFsTWluOiAwLFxuXHRcdHZhbE1heDogMTI3LFxuXHRcdHZhbERlZmF1bHQ6IDAsXG5cdH0sXG5cdC8vXHRcdHsgaWQ6ICdtdGMnLCBcdFx0XHRcdG5hbWU6ICdNSURJIFRpbWUgQ29kZScgfSxcblx0Ly9cdFx0eyBpZDogJ3Bvc2l0aW9uJyxcdFx0XHRuYW1lOiAnU29uZyBQb3NpdGlvbiBQb2ludGVyJyB9LFxuXHQvL1x0XHR7IGlkOiAnc2VsZWN0JyxcdFx0XHRcdG5hbWU6ICdTb25nIFNlbGVjdCcgfSxcblx0Ly9cdFx0eyBpZDogJ3R1bmUnLFx0XHRcdFx0bmFtZTogJ1R1bmUgUmVxdWVzdCcgfSxcblx0Ly9cdFx0eyBpZDogJ3N5c2V4IGVuZCcsXHRcdFx0bmFtZTogJ1N5c0V4IEVuZCcgfSxcblx0Ly9cdFx0eyBpZDogJ2Nsb2NrJyxcdFx0XHRcdG5hbWU6ICdDbG9jaycgfSxcblx0Ly9cdFx0eyBpZDogJ3N0YXJ0JyxcdFx0XHRcdG5hbWU6ICdTdGFydCcgfSxcblx0Ly9cdFx0eyBpZDogJ2NvbnRpbnVlJyxcdFx0XHRuYW1lOiAnQ29udGludWUnIH0sXG5cdC8vXHRcdHsgaWQ6ICdzdG9wJyxcdFx0XHRcdG5hbWU6ICdTdG9wJyB9LFxuXHQvL1x0XHR7IGlkOiAnYWN0aXZlc2Vuc2UnLFx0XHRuYW1lOiAnQWN0aXZlIFNlbnNpbmcnIH0sXG5cdC8vXHRcdHsgaWQ6ICdyZXNldCcsXHRcdFx0XHRuYW1lOiAnUmVzZXQnIH0sXG5dXG5cbnR5cGUgb3B0aW9uVHlwZXMgPSBTb21lQ29tcGFuaW9uQWN0aW9uSW5wdXRGaWVsZFtdIHwgU29tZUNvbXBhbmlvbkZlZWRiYWNrSW5wdXRGaWVsZFtdXG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVPcHRpb25zKG5ld09wdHM6IG9wdGlvblR5cGVzLCBtaWRpT3A6IG1pZGlNc2dUeXBlKTogb3B0aW9uVHlwZXMge1xuXHRpZiAoWydub3Rlb2ZmJywgJ25vdGVvbicsICdjYycsICdwcm9ncmFtJywgJ3BpdGNoJ10uaW5jbHVkZXMobWlkaU9wLmlkKSkge1xuXHRcdG5ld09wdHMucHVzaCh7XG5cdFx0XHRpZDogJ2NoYW5uZWwnLFxuXHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRsYWJlbDogJ0NoYW5uZWwnLFxuXHRcdFx0ZGVmYXVsdDogMSxcblx0XHRcdG1pbjogMSxcblx0XHRcdG1heDogMTYsXG5cdFx0fSlcblx0fVxuXHRpZiAoWydub3Rlb2ZmJywgJ25vdGVvbiddLmluY2x1ZGVzKG1pZGlPcC5pZCkpIHtcblx0XHRuZXdPcHRzLnB1c2goe1xuXHRcdFx0aWQ6ICdub3RlJyxcblx0XHRcdHR5cGU6ICdudW1iZXInLFxuXHRcdFx0bGFiZWw6ICdOb3RlIE51bWJlcicsXG5cdFx0XHRkZWZhdWx0OiA2MCxcblx0XHRcdG1pbjogMCxcblx0XHRcdG1heDogMTI3LFxuXHRcdH0pXG5cdH1cblx0aWYgKG1pZGlPcC5pZCA9PSAnY2MnKSB7XG5cdFx0bmV3T3B0cy5wdXNoKHtcblx0XHRcdGlkOiAnY29udHJvbGxlcicsXG5cdFx0XHR0eXBlOiAnbnVtYmVyJyxcblx0XHRcdGxhYmVsOiAnQ29udHJvbGxlcicsXG5cdFx0XHRkZWZhdWx0OiAxMjcsXG5cdFx0XHRtaW46IDAsXG5cdFx0XHRtYXg6IDEyNyxcblx0XHR9KVxuXHR9XG5cdGlmIChtaWRpT3AuaWQgIT0gJ3N5c2V4Jykge1xuXHRcdG5ld09wdHMucHVzaCh7XG5cdFx0XHRpZDogbWlkaU9wLnZhbElkLFxuXHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRsYWJlbDogbWlkaU9wLnZhbExhYmVsLFxuXHRcdFx0ZGVmYXVsdDogbWlkaU9wLnZhbERlZmF1bHQsXG5cdFx0XHRtaW46IG1pZGlPcC52YWxNaW4sXG5cdFx0XHRtYXg6IG1pZGlPcC52YWxNYXgsXG5cdFx0fSlcblx0fSBlbHNlIHtcblx0XHRuZXdPcHRzLnB1c2goe1xuXHRcdFx0aWQ6ICdieXRlcycsXG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGxhYmVsOiBtaWRpT3AudmFsTGFiZWwsXG5cdFx0XHR0b29sdGlwOlxuXHRcdFx0XHQnRW50ZXIgYSBzdHJpbmcgb2YgZGVjaW1hbCBvciBoZXggZGlnaXRzLCB3aXRoIHNwYWNlcyBvciBjb21tYXMgYmV0d2Vlbi4gTVVTVCBzdGFydCB3aXRoIDB4RjAgb3IgMjQwIGFuZCBlbmQgd2l0aCAweEY3IG9yIDI0NycsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdHVzZVZhcmlhYmxlczogdHJ1ZSxcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIG5ld09wdHNcbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHR5cGUgeyBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uLCBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9ucyB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBIYW5kbGVNaWRpSW5kaWNhdG9ycyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgTWlkaU1lc3NhZ2UgfSBmcm9tICcuL21pZGkvbXNndHlwZXMuanMnXG5pbXBvcnQgeyBtaWRpTXNnVHlwZXMsIGNyZWF0ZU9wdGlvbnMgfSBmcm9tICcuL29wZXJhdGlvbnMuanMnXG5cbmV4cG9ydCBmdW5jdGlvbiBVcGRhdGVBY3Rpb25zKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBtaWRpT3V0OiBmYWxzZSB9KVxuXG5cdGNvbnN0IGFjdGlvbnM6IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb25zID0ge31cblx0Zm9yIChjb25zdCBhY3Rpb24gb2YgbWlkaU1zZ1R5cGVzKSB7XG5cdFx0Y29uc3QgbmV3QWN0aW9uOiBDb21wYW5pb25BY3Rpb25EZWZpbml0aW9uID0ge1xuXHRcdFx0bmFtZTogU3RyaW5nKGFjdGlvbi5sYWJlbCksXG5cdFx0XHRvcHRpb25zOiBjcmVhdGVPcHRpb25zKFtdLCBhY3Rpb24pLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudCk6IFByb21pc2U8dm9pZD4gPT4ge1xuXHRcdFx0XHRjb25zdCBvcHRzID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShldmVudC5vcHRpb25zKSlcblxuXHRcdFx0XHRpZiAoIXNlbGYuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwgJiYgIXNlbGYubWlkaU91dHB1dC5pc1BvcnRPcGVuKCkpIHtcblx0XHRcdFx0XHRzZWxmLmxvZygnZXJyb3InLCBgT3V0cHV0IFBvcnQgXCIke3NlbGYubWlkaU91dHB1dC5uYW1lfVwiIG5vdCBvcGVuIWApXG5cdFx0XHRcdFx0cmV0dXJuXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRpZiAoYWN0aW9uLmlkID09ICdzeXNleCcpIHtcblx0XHRcdFx0XHRjb25zdCBwYXJzZWRTeXNleCA9IFN0cmluZyhvcHRzW2FjdGlvbi52YWxJZF0gPz8gJycpXG5cdFx0XHRcdFx0Y29uc3QgYnl0ZXMgPSBwYXJzZWRTeXNleFxuXHRcdFx0XHRcdFx0LnRyaW0oKVxuXHRcdFx0XHRcdFx0LnNwbGl0KC9bXFxzLF0rLylcblx0XHRcdFx0XHRcdC5maWx0ZXIoQm9vbGVhbilcblx0XHRcdFx0XHRcdC5tYXAoKG46IHN0cmluZykgPT4gKC9eMHgvaS50ZXN0KG4pID8gTnVtYmVyLnBhcnNlSW50KG4uc2xpY2UoMiksIDE2KSA6IE51bWJlcihuKSkpXG5cdFx0XHRcdFx0aWYgKFxuXHRcdFx0XHRcdFx0Ynl0ZXMuc29tZSgoYnl0ZTogbnVtYmVyKSA9PiAhTnVtYmVyLmlzSW50ZWdlcihieXRlKSB8fCBieXRlIDwgMCB8fCBieXRlID4gMjU1KSB8fFxuXHRcdFx0XHRcdFx0Ynl0ZXNbMF0gIT09IDB4ZjAgfHxcblx0XHRcdFx0XHRcdGJ5dGVzLmF0KC0xKSAhPT0gMHhmN1xuXHRcdFx0XHRcdCkge1xuXHRcdFx0XHRcdFx0c2VsZi5sb2coXG5cdFx0XHRcdFx0XHRcdCd3YXJuJyxcblx0XHRcdFx0XHRcdFx0J0ludmFsaWQgU3lzRXggbWVzc2FnZS4gQnl0ZXMgbXVzdCBiZSBpbnRlZ2VycyBmcm9tIDAgdG8gMjU1IGFuZCBzdGFydCB3aXRoIEYwIGFuZCBlbmQgd2l0aCBGNy4nLFxuXHRcdFx0XHRcdFx0KVxuXHRcdFx0XHRcdFx0cmV0dXJuXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdG9wdHMuYnl0ZXMgPSBieXRlc1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKG9wdHMucmVsVmFsdWUpIHtcblx0XHRcdFx0XHRvcHRzW2FjdGlvbi52YWxJZF0gPSBOdW1iZXIob3B0cy52YXJWYWx1ZSlcblx0XHRcdFx0XHRpZiAoIU51bWJlci5pc0Zpbml0ZShvcHRzW2FjdGlvbi52YWxJZF0pKSB7XG5cdFx0XHRcdFx0XHRzZWxmLmxvZygnd2FybicsICdJbnZhbGlkIHJlbGF0aXZlIE1JREkgdmFsdWUnKVxuXHRcdFx0XHRcdFx0cmV0dXJuXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0bGV0IG1zZyA9IE1pZGlNZXNzYWdlLnBhcnNlTWVzc2FnZSh1bmRlZmluZWQsIHsgaWQ6IGFjdGlvbi5pZCwgLi4ub3B0cyB9KVxuXHRcdFx0XHRpZiAoIW1zZykgcmV0dXJuXG5cdFx0XHRcdGlmIChvcHRzLnJlbFZhbHVlKSB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsID0gc2VsZi5nZXRGcm9tRGF0YVN0b3JlKG1zZylcblx0XHRcdFx0XHRpZiAodmFsID09PSB1bmRlZmluZWQpIHtcblx0XHRcdFx0XHRcdHNlbGYubG9nKCdpbmZvJywgJ1JlbGF0aXZlIHZhbHVlIG5vdCBzZW50LiBDdXJyZW50IHZhbHVlIGZyb20gZGV2aWNlIGlzIG5lZWRlZCEnKVxuXHRcdFx0XHRcdFx0cmV0dXJuXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdG9wdHNbYWN0aW9uLnZhbElkXSA9IHZhbCArIE51bWJlcihvcHRzW2FjdGlvbi52YWxJZF0gKiAxKVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKG9wdHMuc2VuZE92ZXJUaW1lKSB7XG5cdFx0XHRcdFx0Ly8gSGFuZGxlIHNlbmRpbmcgb3ZlciB0aW1lXG5cdFx0XHRcdFx0Y29uc3QgZHVyYXRpb25NcyA9IG9wdHMudGltZSAqIDEwMDBcblx0XHRcdFx0XHRjb25zdCBjdXJ2ZSA9IG9wdHMuY3VydmVcblx0XHRcdFx0XHRjb25zdCB0aWNrTXMgPSAxNVxuXG5cdFx0XHRcdFx0bGV0IHN0YXJ0ID0gMFxuXHRcdFx0XHRcdGlmIChvcHRzLnJlbFZhbHVlKSB7XG5cdFx0XHRcdFx0XHRzdGFydCA9IHNlbGYuZ2V0RnJvbURhdGFTdG9yZShtc2cpID8/IDBcblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0c3RhcnQgPSBOdW1iZXIob3B0cy50aW1lU3RhcnRWYWx1ZSlcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRsZXQgZW5kID0gTnVtYmVyKG9wdHNbYWN0aW9uLnZhbElkXSAqIDEpXG5cblx0XHRcdFx0XHQvL2Vuc3VyZSBlbmQgdmFsdWUgaXMgd2l0aGluIGJvdW5kc1xuXHRcdFx0XHRcdGlmIChlbmQgPCAwKSB7XG5cdFx0XHRcdFx0XHRlbmQgPSAwXG5cdFx0XHRcdFx0fSBlbHNlIGlmIChlbmQgPiAxMjcpIHtcblx0XHRcdFx0XHRcdGVuZCA9IDEyN1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdC8vaWYgc3RhcnQgPiBlbmQsIHN3YXAgdGhlbVxuXHRcdFx0XHRcdGlmIChzdGFydCA+IGVuZCkge1xuXHRcdFx0XHRcdFx0Ly87W3N0YXJ0LCBlbmRdID0gW2VuZCwgc3RhcnRdXG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Y29uc3QgdDAgPSBEYXRlLm5vdygpXG5cdFx0XHRcdFx0bGV0IGxhc3QgPSAtMVxuXG5cdFx0XHRcdFx0aW50ZXJmYWNlIEVhc2VGdW5jdGlvbnMge1xuXHRcdFx0XHRcdFx0W2tleTogc3RyaW5nXTogKHg6IG51bWJlcikgPT4gbnVtYmVyXG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Y29uc3QgZWFzZUZ1bmN0aW9uczogRWFzZUZ1bmN0aW9ucyA9IHtcblx0XHRcdFx0XHRcdGxpbmVhcjogKHg6IG51bWJlcik6IG51bWJlciA9PiB4LFxuXHRcdFx0XHRcdFx0ZWFzZUluOiAoeDogbnVtYmVyKTogbnVtYmVyID0+IHggKiB4LFxuXHRcdFx0XHRcdFx0ZWFzZU91dDogKHg6IG51bWJlcik6IG51bWJlciA9PiAxIC0gKDEgLSB4KSAqICgxIC0geCksXG5cdFx0XHRcdFx0XHRlYXNlSW5PdXQ6ICh4OiBudW1iZXIpOiBudW1iZXIgPT4gKHggPCAwLjUgPyAyICogeCAqIHggOiAxIC0gTWF0aC5wb3coLTIgKiB4ICsgMiwgMikgLyAyKSxcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0Y29uc3QgZWFzZTogKHg6IG51bWJlcikgPT4gbnVtYmVyID0gZWFzZUZ1bmN0aW9uc1tjdXJ2ZSBhcyBzdHJpbmddIHx8ICgoeDogbnVtYmVyKTogbnVtYmVyID0+IHgpXG5cblx0XHRcdFx0XHRjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcblx0XHRcdFx0XHRcdGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gdDBcblx0XHRcdFx0XHRcdGNvbnN0IHUgPSBNYXRoLm1pbigxLCBlbGFwc2VkIC8gZHVyYXRpb25Ncylcblx0XHRcdFx0XHRcdGNvbnN0IHZhbCA9IE1hdGgucm91bmQoc3RhcnQgKyAoZW5kIC0gc3RhcnQpICogZWFzZSh1KSlcblxuXHRcdFx0XHRcdFx0aWYgKHZhbCAhPT0gbGFzdCkge1xuXHRcdFx0XHRcdFx0XHRvcHRzW2FjdGlvbi52YWxJZF0gPSB2YWxcblx0XHRcdFx0XHRcdFx0bXNnID0gTWlkaU1lc3NhZ2UucGFyc2VNZXNzYWdlKHVuZGVmaW5lZCwgeyBpZDogYWN0aW9uLmlkLCAuLi5vcHRzIH0pXG5cdFx0XHRcdFx0XHRcdHNlbGYubG9nKCdkZWJ1ZycsIGBTZW5kaW5nOiAgJHttc2d9IHRvIFwiJHtzZWxmLm1pZGlPdXRwdXQubmFtZX1cImApXG5cdFx0XHRcdFx0XHRcdGlmIChtc2cpIHNlbGYubWlkaU91dHB1dC5zZW5kKG1zZylcblx0XHRcdFx0XHRcdFx0SGFuZGxlTWlkaUluZGljYXRvcnMoc2VsZiwgJ21pZGlPdXQnKVxuXHRcdFx0XHRcdFx0XHRsYXN0ID0gdmFsXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAodSA+PSAxKSBjbGVhckludGVydmFsKHRpbWVyKVxuXHRcdFx0XHRcdH0sIHRpY2tNcylcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRtc2cgPSBNaWRpTWVzc2FnZS5wYXJzZU1lc3NhZ2UodW5kZWZpbmVkLCB7IGlkOiBhY3Rpb24uaWQsIC4uLm9wdHMgfSlcblx0XHRcdFx0XHRpZiAoIW1zZykgcmV0dXJuXG5cdFx0XHRcdFx0c2VsZi5sb2coJ2RlYnVnJywgYFNlbmRpbmc6ICAke21zZ30gdG8gXCIke3NlbGYubWlkaU91dHB1dC5uYW1lfVwiYClcblx0XHRcdFx0XHRzZWxmLm1pZGlPdXRwdXQuc2VuZChtc2cpXG5cdFx0XHRcdFx0SGFuZGxlTWlkaUluZGljYXRvcnMoc2VsZiwgJ21pZGlPdXQnKVxuXHRcdFx0XHR9XG5cdFx0XHR9LFxuXHRcdH1cblxuXHRcdGlmIChhY3Rpb24uaWQgIT0gJ3N5c2V4Jykge1xuXHRcdFx0Y29uc3QgdmFsdWVPcHRpb24gPSBuZXdBY3Rpb24ub3B0aW9ucy5hdCgtMSlcblx0XHRcdGlmICh2YWx1ZU9wdGlvbikgdmFsdWVPcHRpb24uaXNWaXNpYmxlRXhwcmVzc2lvbiA9ICchJChvcHRpb25zOnJlbFZhbHVlKSdcblx0XHRcdG5ld0FjdGlvbi5vcHRpb25zLnB1c2goXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRpZDogJ3ZhclZhbHVlJyxcblx0XHRcdFx0XHR0eXBlOiAnbnVtYmVyJyxcblx0XHRcdFx0XHRsYWJlbDogYWN0aW9uLnZhbExhYmVsLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0bWluOiAtYWN0aW9uLnZhbE1heCxcblx0XHRcdFx0XHRtYXg6IGFjdGlvbi52YWxNYXgsXG5cdFx0XHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogJyEhJChvcHRpb25zOnJlbFZhbHVlKScsXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRpZDogJ3JlbFRleHQnLFxuXHRcdFx0XHRcdHR5cGU6ICdzdGF0aWMtdGV4dCcsXG5cdFx0XHRcdFx0bGFiZWw6ICcqKiBOT1RFICoqJyxcblx0XHRcdFx0XHR2YWx1ZTogJ1JlbGF0aXZlIHdpbGwgb25seSB3b3JrIGFmdGVyIGEgdmFsdWUgaGFzIGJlZW4gc2VudCBmcm9tIHRoZSBkZXZpY2UhJyxcblx0XHRcdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiAnJChvcHRpb25zOnJlbFZhbHVlKScsXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRpZDogJ3JlbFZhbHVlJyxcblx0XHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRcdGxhYmVsOiAnUmVsYXRpdmUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHRcdGRpc2FibGVBdXRvRXhwcmVzc2lvbjogdHJ1ZSxcblx0XHRcdFx0fSxcblx0XHRcdClcblxuXHRcdFx0Ly9vdmVyIHRpbWUgZmVhdHVyZXMgLSB0aW1lIGluIHNlY29uZHMsIGN1cnZlIHR5cGUgKGxpbmVhciwgZWFzZSBpbiwgZWFzZSBvdXQsIGVhc2UgaW4vb3V0KVxuXHRcdFx0bmV3QWN0aW9uLm9wdGlvbnMucHVzaChcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAnc2VuZE92ZXJUaW1lJyxcblx0XHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRcdGxhYmVsOiAnU2VuZCBPdmVyIFRpbWUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHRcdGRpc2FibGVBdXRvRXhwcmVzc2lvbjogdHJ1ZSxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAndGltZVN0YXJ0VmFsdWUnLFxuXHRcdFx0XHRcdHR5cGU6ICdudW1iZXInLFxuXHRcdFx0XHRcdGxhYmVsOiAnU3RhcnQgVmFsdWUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0bWluOiAwLFxuXHRcdFx0XHRcdG1heDogMTI3LFxuXHRcdFx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246ICchISQob3B0aW9uczpzZW5kT3ZlclRpbWUpICYmICEkKG9wdGlvbnM6cmVsVmFsdWUpJyxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAndGltZScsXG5cdFx0XHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRcdFx0bGFiZWw6ICdUaW1lIChzZWNvbmRzKScsXG5cdFx0XHRcdFx0ZGVmYXVsdDogMSxcblx0XHRcdFx0XHRtaW46IDAsXG5cdFx0XHRcdFx0bWF4OiA2MDAsXG5cdFx0XHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogJyQob3B0aW9uczpzZW5kT3ZlclRpbWUpJyxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAnY3VydmUnLFxuXHRcdFx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRcdFx0bGFiZWw6ICdDdXJ2ZSBUeXBlJyxcblx0XHRcdFx0XHRkZWZhdWx0OiAnbGluZWFyJyxcblx0XHRcdFx0XHRjaG9pY2VzOiBbXG5cdFx0XHRcdFx0XHR7IGxhYmVsOiAnTGluZWFyJywgaWQ6ICdsaW5lYXInIH0sXG5cdFx0XHRcdFx0XHR7IGxhYmVsOiAnRWFzZSBJbicsIGlkOiAnZWFzZUluJyB9LFxuXHRcdFx0XHRcdFx0eyBsYWJlbDogJ0Vhc2UgT3V0JywgaWQ6ICdlYXNlT3V0JyB9LFxuXHRcdFx0XHRcdFx0eyBsYWJlbDogJ0Vhc2UgSW4vT3V0JywgaWQ6ICdlYXNlSW5PdXQnIH0sXG5cdFx0XHRcdFx0XSxcblx0XHRcdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiAnJChvcHRpb25zOnNlbmRPdmVyVGltZSknLFxuXHRcdFx0XHR9LFxuXHRcdFx0KVxuXHRcdH1cblxuXHRcdGFjdGlvbnNbYWN0aW9uLmlkXSA9IG5ld0FjdGlvblxuXHR9XG5cblx0c2VsZi5zZXRBY3Rpb25EZWZpbml0aW9ucyhhY3Rpb25zKVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBjb21iaW5lUmdiIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcbmltcG9ydCB0eXBlIHtcblx0Q29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9uLFxuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb25zLFxuXHRTb21lQ29tcGFuaW9uRmVlZGJhY2tJbnB1dEZpZWxkLFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgRkJDcmVhdGVzVmFyIH0gZnJvbSAnLi92YXJpYWJsZXMuanMnXG5pbXBvcnQgeyBNaWRpTWVzc2FnZSB9IGZyb20gJy4vbWlkaS9tc2d0eXBlcy5qcydcbmltcG9ydCB7IG1pZGlNc2dUeXBlcywgY3JlYXRlT3B0aW9ucyB9IGZyb20gJy4vb3BlcmF0aW9ucy5qcydcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUZlZWRiYWNrcyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBmZWVkYmFja3M6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMgPSB7fVxuXHRmb3IgKGNvbnN0IGZlZWRiYWNrIG9mIG1pZGlNc2dUeXBlcykge1xuXHRcdGNvbnN0IG5ld0ZlZWRiYWNrOiBDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb24gPSB7XG5cdFx0XHRuYW1lOiBmZWVkYmFjay5sYWJlbCxcblx0XHRcdGRlc2NyaXB0aW9uOiBmZWVkYmFjay5kZXNjLFxuXHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0ZGVmYXVsdFN0eWxlOiB7XG5cdFx0XHRcdGJnY29sb3I6IGNvbWJpbmVSZ2IoMjU1LCAwLCAwKSxcblx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHR9LFxuXHRcdFx0b3B0aW9uczogY3JlYXRlT3B0aW9ucyhbXSwgZmVlZGJhY2spIGFzIFNvbWVDb21wYW5pb25GZWVkYmFja0lucHV0RmllbGRbXSxcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQpOiBQcm9taXNlPGJvb2xlYW4+ID0+IHtcblx0XHRcdFx0Y29uc3Qgb3B0cyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZXZlbnQub3B0aW9ucykpXG5cblx0XHRcdFx0aWYgKGV2ZW50LmZlZWRiYWNrSWQgPT0gJ3N5c2V4Jykge1xuXHRcdFx0XHRcdGNvbnN0IHBhcnNlZFN5c2V4ID0gU3RyaW5nKG9wdHNbZmVlZGJhY2sudmFsSWRdID8/ICcnKVxuXHRcdFx0XHRcdGNvbnN0IGJ5dGVzID0gcGFyc2VkU3lzZXhcblx0XHRcdFx0XHRcdC50cmltKClcblx0XHRcdFx0XHRcdC5zcGxpdCgvW1xccyxdKy8pXG5cdFx0XHRcdFx0XHQuZmlsdGVyKEJvb2xlYW4pXG5cdFx0XHRcdFx0XHQubWFwKChuOiBzdHJpbmcpID0+ICgvXjB4L2kudGVzdChuKSA/IE51bWJlci5wYXJzZUludChuLnNsaWNlKDIpLCAxNikgOiBOdW1iZXIobikpKVxuXHRcdFx0XHRcdGlmIChcblx0XHRcdFx0XHRcdGJ5dGVzLnNvbWUoKGJ5dGU6IG51bWJlcikgPT4gIU51bWJlci5pc0ludGVnZXIoYnl0ZSkgfHwgYnl0ZSA8IDAgfHwgYnl0ZSA+IDI1NSkgfHxcblx0XHRcdFx0XHRcdGJ5dGVzWzBdICE9PSAweGYwIHx8XG5cdFx0XHRcdFx0XHRieXRlcy5hdCgtMSkgIT09IDB4Zjdcblx0XHRcdFx0XHQpXG5cdFx0XHRcdFx0XHRyZXR1cm4gZmFsc2Vcblx0XHRcdFx0XHRvcHRzLmJ5dGVzID0gYnl0ZXNcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGNvbnN0IG1zZyA9IE1pZGlNZXNzYWdlLnBhcnNlTWVzc2FnZSh1bmRlZmluZWQsIHsgaWQ6IGV2ZW50LmZlZWRiYWNrSWQsIC4uLm9wdHMgfSlcblx0XHRcdFx0aWYgKCFtc2cpIHJldHVybiBmYWxzZVxuXG5cdFx0XHRcdGNvbnN0IGRhdGFTdG9yZVZhbCA9IHNlbGYuZ2V0RnJvbURhdGFTdG9yZShtc2cpXG5cdFx0XHRcdGlmIChldmVudC5mZWVkYmFja0lkICE9PSAnc3lzZXgnICYmIG9wdHMuY3JlYXRlVmFyICYmIHNlbGYuY29uZmlnLmF1dG9DcmVhdGVWYXJzICYmIG1zZyAhPT0gdW5kZWZpbmVkKVxuXHRcdFx0XHRcdEZCQ3JlYXRlc1ZhcihzZWxmLCBtc2csIGRhdGFTdG9yZVZhbClcblx0XHRcdFx0aWYgKGRhdGFTdG9yZVZhbCA9PSB1bmRlZmluZWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRpZiAoZGF0YVN0b3JlVmFsID09IHNlbGYuZ2V0VmFsRnJvbU1zZyhtc2cpLnZhbCkge1xuXHRcdFx0XHRcdHJldHVybiB0cnVlXG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGZhbHNlXG5cdFx0XHR9LFxuXHRcdH1cblxuXHRcdGlmIChmZWVkYmFjay5pZCAhPSAnc3lzZXgnICYmIHNlbGYuY29uZmlnLmF1dG9DcmVhdGVWYXJzKSB7XG5cdFx0XHRjb25zdCB2YWx1ZU9wdGlvbiA9IG5ld0ZlZWRiYWNrLm9wdGlvbnMuYXQoLTEpXG5cdFx0XHRpZiAodmFsdWVPcHRpb24pIHZhbHVlT3B0aW9uLmlzVmlzaWJsZUV4cHJlc3Npb24gPSAnISQob3B0aW9uczpjcmVhdGVWYXIpJ1xuXHRcdFx0bmV3RmVlZGJhY2sub3B0aW9ucy5wdXNoKHtcblx0XHRcdFx0aWQ6ICdjcmVhdGVWYXInLFxuXHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRsYWJlbDogJ0F1dG8tQ3JlYXRlIFZhcmlhYmxlJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdGRpc2FibGVBdXRvRXhwcmVzc2lvbjogdHJ1ZSxcblx0XHRcdH0pXG5cdFx0fVxuXG5cdFx0ZmVlZGJhY2tzW2ZlZWRiYWNrLmlkXSA9IG5ld0ZlZWRiYWNrXG5cblx0XHRpZiAoZmVlZGJhY2suaWQgIT09ICdzeXNleCcpIHtcblx0XHRcdGZlZWRiYWNrc1tmZWVkYmFjay5pZCArICdfdmFsdWUnXSA9IHtcblx0XHRcdFx0bmFtZTogZmVlZGJhY2subGFiZWwgKyAnIFZhbHVlJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246IGZlZWRiYWNrLmRlc2MsXG5cdFx0XHRcdHR5cGU6ICd2YWx1ZScsXG5cdFx0XHRcdG9wdGlvbnM6IG5ld0ZlZWRiYWNrLm9wdGlvbnMuZmlsdGVyKChvKSA9PiBvLmlkICE9PSBmZWVkYmFjay52YWxJZCAmJiBvLmlkICE9PSAnY3JlYXRlVmFyJyksXG5cdFx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQpOiBQcm9taXNlPG51bWJlcj4gPT4ge1xuXHRcdFx0XHRcdGNvbnN0IG9wdHMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGV2ZW50Lm9wdGlvbnMpKVxuXHRcdFx0XHRcdGNvbnN0IG1zZ0lkID0gZXZlbnQuZmVlZGJhY2tJZC5yZXBsYWNlKCdfdmFsdWUnLCAnJylcblx0XHRcdFx0XHRjb25zdCBtc2cgPSBNaWRpTWVzc2FnZS5wYXJzZU1lc3NhZ2UodW5kZWZpbmVkLCB7IGlkOiBtc2dJZCwgLi4ub3B0cyB9KVxuXHRcdFx0XHRcdGlmICghbXNnKSByZXR1cm4gdW5kZWZpbmVkIGFzIHVua25vd24gYXMgbnVtYmVyXG5cdFx0XHRcdFx0Y29uc3QgdmFsdWUgPSBzZWxmLmdldEZyb21EYXRhU3RvcmUobXNnKVxuXHRcdFx0XHRcdGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSByZXR1cm4gdW5kZWZpbmVkIGFzIHVua25vd24gYXMgbnVtYmVyXG5cdFx0XHRcdFx0cmV0dXJuIG1zZ0lkID09PSAncHJvZ3JhbScgPyB2YWx1ZSArIDEgOiB2YWx1ZVxuXHRcdFx0XHR9LFxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGZlZWRiYWNrc1snbWlkaUluJ10gPSB7XG5cdFx0bmFtZTogJ01JREkgTWVzc2FnZSBJbmNvbWluZz8nLFxuXHRcdGRlc2NyaXB0aW9uOiAnRmlyZSB3aGVuZXZlciBBTlkgTUlESSBtZXNzYWdlIGlzIHJlY2VpdmVkJyxcblx0XHR0eXBlOiAnYm9vbGVhbicsXG5cdFx0ZGVmYXVsdFN0eWxlOiB7XG5cdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDI1NSwgMCwgMCksXG5cdFx0XHRjb2xvcjogY29tYmluZVJnYigwLCAwLCAwKSxcblx0XHR9LFxuXHRcdG9wdGlvbnM6IFtdLFxuXHRcdGNhbGxiYWNrOiBhc3luYyAoKTogUHJvbWlzZTxib29sZWFuPiA9PiB7XG5cdFx0XHRyZXR1cm4gISFzZWxmLmdldFZhcmlhYmxlVmFsdWUoJ21pZGlJbicpXG5cdFx0fSxcblx0fVxuXG5cdGZlZWRiYWNrc1snbWlkaU91dCddID0ge1xuXHRcdG5hbWU6ICdNSURJIE1lc3NhZ2UgT3V0Z29pbmc/Jyxcblx0XHRkZXNjcmlwdGlvbjogJ0ZpcmUgd2hlbmV2ZXIgQU5ZIE1JREkgbWVzc2FnZSBpcyBzZW50Jyxcblx0XHR0eXBlOiAnYm9vbGVhbicsXG5cdFx0ZGVmYXVsdFN0eWxlOiB7XG5cdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDI1NSwgMCwgMCksXG5cdFx0XHRjb2xvcjogY29tYmluZVJnYigwLCAwLCAwKSxcblx0XHR9LFxuXHRcdG9wdGlvbnM6IFtdLFxuXHRcdGNhbGxiYWNrOiBhc3luYyAoKTogUHJvbWlzZTxib29sZWFuPiA9PiB7XG5cdFx0XHRyZXR1cm4gISFzZWxmLmdldFZhcmlhYmxlVmFsdWUoJ21pZGlPdXQnKVxuXHRcdH0sXG5cdH1cblxuXHRzZWxmLnNldEZlZWRiYWNrRGVmaW5pdGlvbnMoZmVlZGJhY2tzKVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQgeyBjb21iaW5lUmdiIH0gZnJvbSAnQGNvbXBhbmlvbi1tb2R1bGUvYmFzZSdcblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZVByZXNldHMoc2VsZjogTW9kdWxlSW5zdGFuY2UpOiB2b2lkIHtcblx0Y29uc3QgcHJlc2V0cyA9IHtcblx0XHRtaWRpX2luOiB7XG5cdFx0XHR0eXBlOiAnc2ltcGxlJyBhcyBjb25zdCxcblx0XHRcdG5hbWU6IGBNSURJIE1lc3NhZ2UgSW4gSW5kaWNhdG9yYCxcblx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdHRleHQ6IGBNSURJIElOYCxcblx0XHRcdFx0c2l6ZTogJ2F1dG8nIGFzIGNvbnN0LFxuXHRcdFx0XHRjb2xvcjogY29tYmluZVJnYigyNTUsIDI1NSwgMjU1KSxcblx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAwLCAwKSxcblx0XHRcdH0sXG5cdFx0XHRzdGVwczogW10sXG5cdFx0XHRmZWVkYmFja3M6IFtcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGZlZWRiYWNrSWQ6ICdtaWRpSW4nLFxuXHRcdFx0XHRcdG9wdGlvbnM6IHt9LFxuXHRcdFx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdFx0XHRjb2xvcjogY29tYmluZVJnYigyNTUsIDI1NSwgMjU1KSxcblx0XHRcdFx0XHRcdGJnY29sb3I6IGNvbWJpbmVSZ2IoMCwgMjU1LCAwKSxcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHR9LFxuXHRcdFx0XSxcblx0XHR9LFxuXHRcdG1pZGlfb3V0OiB7XG5cdFx0XHR0eXBlOiAnc2ltcGxlJyBhcyBjb25zdCxcblx0XHRcdG5hbWU6IGBNSURJIE1lc3NhZ2UgT3V0IEluZGljYXRvcmAsXG5cdFx0XHRzdHlsZToge1xuXHRcdFx0XHR0ZXh0OiBgTUlESSBPVVRgLFxuXHRcdFx0XHRzaXplOiAnYXV0bycgYXMgY29uc3QsXG5cdFx0XHRcdGNvbG9yOiBjb21iaW5lUmdiKDI1NSwgMjU1LCAyNTUpLFxuXHRcdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDAsIDAsIDApLFxuXHRcdFx0fSxcblx0XHRcdHN0ZXBzOiBbXSxcblx0XHRcdGZlZWRiYWNrczogW1xuXHRcdFx0XHR7XG5cdFx0XHRcdFx0ZmVlZGJhY2tJZDogJ21pZGlPdXQnLFxuXHRcdFx0XHRcdG9wdGlvbnM6IHt9LFxuXHRcdFx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdFx0XHRjb2xvcjogY29tYmluZVJnYigyNTUsIDI1NSwgMjU1KSxcblx0XHRcdFx0XHRcdGJnY29sb3I6IGNvbWJpbmVSZ2IoMCwgMjU1LCAwKSxcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHR9LFxuXHRcdFx0XSxcblx0XHR9LFxuXHR9XG5cblx0Y29uc3Qgc3RydWN0dXJlID0gW1xuXHRcdHtcblx0XHRcdGlkOiAnaW5kaWNhdG9ycycsXG5cdFx0XHRuYW1lOiAnSW5kaWNhdG9ycycsXG5cdFx0XHRkZWZpbml0aW9uczogW1xuXHRcdFx0XHR7XG5cdFx0XHRcdFx0aWQ6ICdtaWRpX2luZGljYXRvcnMnLFxuXHRcdFx0XHRcdHR5cGU6ICdzaW1wbGUnIGFzIGNvbnN0LFxuXHRcdFx0XHRcdG5hbWU6ICdNSURJIEluZGljYXRvcnMnLFxuXHRcdFx0XHRcdHByZXNldHM6IFsnbWlkaV9pbicsICdtaWRpX291dCddLFxuXHRcdFx0XHR9LFxuXHRcdFx0XSxcblx0XHR9LFxuXHRdXG5cblx0c2VsZi5zZXRQcmVzZXREZWZpbml0aW9ucyhzdHJ1Y3R1cmUsIHByZXNldHMpXG59XG4iLCAiaW1wb3J0IHsgSW5zdGFuY2VCYXNlLCBJbnN0YW5jZVN0YXR1cyB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgdHlwZSB7IEluc3RhbmNlVHlwZXMsIFNvbWVDb21wYW5pb25Db25maWdGaWVsZCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBHZXRDb25maWdGaWVsZHMsIHR5cGUgTW9kdWxlQ29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnXG5pbXBvcnQgeyBVcGRhdGVWYXJpYWJsZURlZmluaXRpb25zLCBIYW5kbGVNaWRpSW5kaWNhdG9ycywgVXBkYXRlTGFzdE1zZyB9IGZyb20gJy4vdmFyaWFibGVzLmpzJ1xuaW1wb3J0IHsgVXBncmFkZVNjcmlwdHMgfSBmcm9tICcuL3VwZ3JhZGVzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlQWN0aW9ucyB9IGZyb20gJy4vYWN0aW9ucy5qcydcbmltcG9ydCB7IFVwZGF0ZUZlZWRiYWNrcyB9IGZyb20gJy4vZmVlZGJhY2tzLmpzJ1xuaW1wb3J0IHsgVXBkYXRlUHJlc2V0cyB9IGZyb20gJy4vcHJlc2V0cy5qcydcbmltcG9ydCAqIGFzIG1pZGkgZnJvbSAnLi9taWRpL21pZGkuanMnXG5pbXBvcnQgeyBNaWRpTWVzc2FnZSB9IGZyb20gJy4vbWlkaS9tc2d0eXBlcy5qcydcbmltcG9ydCB0eXBlIHsgbWlkaVZhcnMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcblxuaW50ZXJmYWNlIE1vZHVsZVR5cGVzIGV4dGVuZHMgSW5zdGFuY2VUeXBlcyB7XG5cdGNvbmZpZzogTW9kdWxlQ29uZmlnXG5cdHNlY3JldHM6IHVuZGVmaW5lZFxuXHR2YXJpYWJsZXM6IG1pZGlWYXJzXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGF0YVN0b3JlRW50cnkge1xuXHRrZXk6IG51bWJlclxuXHR2YWw6IG51bWJlclxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb2R1bGVJbnN0YW5jZSBleHRlbmRzIEluc3RhbmNlQmFzZTxNb2R1bGVUeXBlcz4ge1xuXHRjb25maWchOiBNb2R1bGVDb25maWcgLy8gU2V0dXAgaW4gaW5pdCgpXG5cdG1pZGlJbnB1dCE6IG1pZGkuSW5wdXRcblx0bWlkaU91dHB1dCE6IG1pZGkuT3V0cHV0XG5cdGRhdGFTdG9yZSE6IE1hcDxudW1iZXIsIG51bWJlcj5cblx0aXNSZWNvcmRpbmdBY3Rpb25zITogYm9vbGVhblxuXHRub3RlU3RhdGVzOiBib29sZWFuW11bXSA9IFtdXG5cblx0Y29uc3RydWN0b3IoaW50ZXJuYWw6IHVua25vd24pIHtcblx0XHRzdXBlcihpbnRlcm5hbClcblx0fVxuXG5cdGFzeW5jIGluaXQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdHRoaXMuZGF0YVN0b3JlID0gbmV3IE1hcCgpXG5cblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVByZXNldHMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0YXdhaXQgdGhpcy5jb25maWdVcGRhdGVkKGNvbmZpZylcblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMubWlkaUlucHV0LmNsb3NlKClcblx0XHR0aGlzLm1pZGlPdXRwdXQuY2xvc2UoKVxuXHRcdHRoaXMubG9nKCdkZWJ1ZycsIGAke3RoaXMuaWR9IGRlc3Ryb3llZGApXG5cdH1cblxuXHRhc3luYyBjb25maWdVcGRhdGVkKGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0Y29uc3QgYXV0b0NyZWF0ZVZhcnNDaGFuZ2VkID0gdGhpcy5jb25maWc/LmF1dG9DcmVhdGVWYXJzICE9PSBjb25maWcuYXV0b0NyZWF0ZVZhcnNcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdGlmIChhdXRvQ3JlYXRlVmFyc0NoYW5nZWQpIHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLmNvbmZpZy5pblBvcnRJc1ZpcnR1YWwgPSBmYWxzZSAvLyBkZWxldGUgaWYgVmlydHVhbCBwb3J0cyBldmVyIGdldCBzdXBwb3J0ZWQgYnkgV2luZG93c1xuXHRcdHRoaXMuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwgPSBmYWxzZVxuXHRcdGNvbnN0IGluUG9ydE5hbWUgPSB0aGlzLmNvbmZpZy5pblBvcnRJc1ZpcnR1YWwgPyB0aGlzLmNvbmZpZy5pblBvcnRWaXJ0dWFsTmFtZSA6IHRoaXMuY29uZmlnLmluUG9ydE5hbWVcblx0XHRjb25zdCBvdXRQb3J0TmFtZSA9IHRoaXMuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwgPyB0aGlzLmNvbmZpZy5vdXRQb3J0VmlydHVhbE5hbWUgOiB0aGlzLmNvbmZpZy5vdXRQb3J0TmFtZVxuXHRcdHRoaXMubG9nKFxuXHRcdFx0J2RlYnVnJyxcblx0XHRcdGBBdmFpbGFibGUgTUlESSBJbnB1dHM6ICR7SlNPTi5zdHJpbmdpZnkobWlkaS5nZXRJbnB1dHMoKSl9XFxuXFx0U2VsZWN0ZWQgTUlESSBJbnB1dDogICR7aW5Qb3J0TmFtZX1gLFxuXHRcdClcblx0XHR0aGlzLmxvZyhcblx0XHRcdCdkZWJ1ZycsXG5cdFx0XHRgQXZhaWxhYmxlIE1JREkgT3V0cHV0czogJHtKU09OLnN0cmluZ2lmeShtaWRpLmdldE91dHB1dHMoKSl9XFxuXFx0U2VsZWN0ZWQgTUlESSBPdXRwdXQ6ICR7b3V0UG9ydE5hbWV9YCxcblx0XHQpXG5cdFx0dGhpcy5sb2coJ2RlYnVnJywgJycpXG5cdFx0aWYgKHRoaXMubWlkaUlucHV0KSB0aGlzLm1pZGlJbnB1dC5jbG9zZSgpXG5cdFx0aWYgKHRoaXMubWlkaU91dHB1dCkgdGhpcy5taWRpT3V0cHV0LmNsb3NlKClcblx0XHR0aGlzLm1pZGlJbnB1dCA9IG5ldyBtaWRpLklucHV0KGluUG9ydE5hbWUsIHRoaXMuY29uZmlnLmluUG9ydElzVmlydHVhbClcblx0XHR0aGlzLm1pZGlPdXRwdXQgPSBuZXcgbWlkaS5PdXRwdXQob3V0UG9ydE5hbWUsIHRoaXMuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwpXG5cdFx0Y29uc3QgbWlkaUluU3RhdHVzID0gdGhpcy5jb25maWcuaW5Qb3J0SXNWaXJ0dWFsIHx8IHRoaXMubWlkaUlucHV0LmlzUG9ydE9wZW4oKVxuXHRcdGNvbnN0IG1pZGlPdXRTdGF0dXMgPSB0aGlzLmNvbmZpZy5vdXRQb3J0SXNWaXJ0dWFsIHx8IHRoaXMubWlkaU91dHB1dC5pc1BvcnRPcGVuKClcblx0XHR0aGlzLmxvZygnaW5mbycsIGBTZWxlY3RlZCBJbiAgUG9ydCBcIiR7dGhpcy5taWRpSW5wdXQubmFtZX1cIiBpcyAke21pZGlJblN0YXR1cyA/ICcnIDogJ05PVCAnfU9wZW4uYClcblx0XHR0aGlzLmxvZygnaW5mbycsIGBTZWxlY3RlZCBPdXQgUG9ydCBcIiR7dGhpcy5taWRpT3V0cHV0Lm5hbWV9XCIgaXMgJHttaWRpT3V0U3RhdHVzID8gJycgOiAnTk9UICd9T3Blbi5gKVxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkRpc2Nvbm5lY3RlZClcblx0XHRpZiAoIW1pZGlJblN0YXR1cyAmJiBtaWRpT3V0U3RhdHVzKSB0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5CYWRDb25maWcsICdNSURJIEluIFBvcnQgbm90IG9wZW4nKVxuXHRcdGlmIChtaWRpSW5TdGF0dXMgJiYgIW1pZGlPdXRTdGF0dXMpIHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkJhZENvbmZpZywgJ01JREkgT3V0IFBvcnQgbm90IG9wZW4nKVxuXHRcdGlmIChtaWRpSW5TdGF0dXMgJiYgbWlkaU91dFN0YXR1cykgdGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cblx0XHR0aGlzLnN0YXJ0KClcblx0fVxuXG5cdC8vIFJldHVybiBjb25maWcgZmllbGRzIGZvciB3ZWIgY29uZmlnXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcygpXG5cdH1cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVQcmVzZXRzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVByZXNldHModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyh0aGlzKVxuXHR9XG5cblx0Ly8gVGhlIG1haW4gbG9vcFxuXHRzdGFydCgpOiB2b2lkIHtcblx0XHR0aGlzLmxvZygnZGVidWcnLCAnXFxuRW50ZXJpbmcgKm1haW4qXFxuJylcblxuXHRcdHRoaXMubWlkaUlucHV0Lm9uKCdzbXB0ZScsIChhcmdzOiB7IHNtcHRlOiBzdHJpbmc7IHNtcHRlRlI6IG51bWJlciB9KSA9PiB7XG5cdFx0XHR0aGlzLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdFx0c21wdGU6IGFyZ3Muc21wdGUsXG5cdFx0XHRcdHNtcHRlRlI6IGFyZ3Muc21wdGVGUixcblx0XHRcdH0pXG5cdFx0fSlcblx0XHR0aGlzLm1pZGlJbnB1dC5vbignbWVzc2FnZScsIChkZWx0YVRpbWU6IG51bWJlciwgbXNnOiBNaWRpTWVzc2FnZSkgPT4ge1xuXHRcdFx0aWYgKG1zZy5pZCAhPT0gJ210YycpIHtcblx0XHRcdFx0dGhpcy5sb2coJ2RlYnVnJywgYFske2RlbHRhVGltZS50b0ZpeGVkKDIpLnBhZFN0YXJ0KDYsICcwJyl9XSBSZWNlaXZlZDogJHttc2d9IGZyb20gXCIke3RoaXMubWlkaUlucHV0Lm5hbWV9XCJgKVxuXHRcdFx0XHR0aGlzLmFkZFRvRGF0YVN0b3JlKG1zZylcblx0XHRcdFx0aWYgKHRoaXMuaXNSZWNvcmRpbmdBY3Rpb25zKSB0aGlzLmFkZFRvQWN0aW9uUmVjb3JkaW5nKGRlbHRhVGltZSwgbXNnKVxuXHRcdFx0fVxuXHRcdFx0SGFuZGxlTWlkaUluZGljYXRvcnModGhpcywgJ21pZGlJbicpXG5cdFx0fSlcblx0fVxuXG5cdGFkZFRvRGF0YVN0b3JlKG1zZzogTWlkaU1lc3NhZ2UpOiB2b2lkIHtcblx0XHRjb25zdCBkYXRhOiBEYXRhU3RvcmVFbnRyeSA9IHRoaXMuZ2V0VmFsRnJvbU1zZyhtc2cpXG5cdFx0aWYgKGRhdGEua2V5ID4gMCkge1xuXHRcdFx0VXBkYXRlTGFzdE1zZyh0aGlzLCBtc2csIGRhdGEudmFsKVxuXHRcdFx0dGhpcy5kYXRhU3RvcmUuc2V0KGRhdGEua2V5LCBkYXRhLnZhbClcblx0XHRcdHRoaXMuY2hlY2tBbGxGZWVkYmFja3MoKVxuXHRcdH1cblx0fVxuXG5cdGdldEZyb21EYXRhU3RvcmUobXNnOiBNaWRpTWVzc2FnZSk6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3QgZGF0YTogRGF0YVN0b3JlRW50cnkgPSB0aGlzLmdldFZhbEZyb21Nc2cobXNnKVxuXHRcdGlmIChkYXRhLmtleSA+IDApIHtcblx0XHRcdHJldHVybiB0aGlzLmRhdGFTdG9yZS5nZXQoZGF0YS5rZXkpXG5cdFx0fVxuXHRcdHJldHVybiB1bmRlZmluZWRcblx0fVxuXG5cdGdldFZhbEZyb21Nc2cobXNnOiBNaWRpTWVzc2FnZSk6IERhdGFTdG9yZUVudHJ5IHtcblx0XHRsZXQgbGFzdEluZGV4OiBudW1iZXIgPSBtc2cuYnl0ZXMubGVuZ3RoIC0gMVxuXHRcdGxldCBwYXJzZWRLZXkgPSAwXG5cdFx0bGV0IHBhcnNlZFZhbCA9IDBcblx0XHQvLyB2YWwgaXMgbGFzdCBieXRlLCBrZXkgaXMgYWxsIGJ5dGVzIHVwIHRvIHRoZSBsYXN0XG5cdFx0Ly8gZS5nLiBbMHg5MCwgMHg2MCwgMHg3Rl06IGtleSA9IDB4OTA2MCwgdmFsID0gMHg3RlxuXHRcdGlmIChsYXN0SW5kZXggPj0gMCAmJiBtc2cuc3RhdHVzIDwgMHhmMCkge1xuXHRcdFx0aWYgKG1zZy5pZCA9PSAncGl0Y2gnKSB7XG5cdFx0XHRcdHBhcnNlZFZhbCA9IG1zZy5hcmdzLnZhbHVlID8/IDBcblx0XHRcdFx0bGFzdEluZGV4LS1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHBhcnNlZFZhbCA9IG1zZy5ieXRlc1tsYXN0SW5kZXhdXG5cdFx0XHR9XG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGxhc3RJbmRleDsgaSsrKSB7XG5cdFx0XHRcdHBhcnNlZEtleSArPSBtc2cuYnl0ZXNbaV0gPDwgKChsYXN0SW5kZXggLSBpIC0gMSkgPDwgMylcblx0XHRcdH1cblx0XHRcdGlmIChwYXJzZWRLZXkgPT0gMCkgcGFyc2VkS2V5ID0gcGFyc2VkVmFsXG5cdFx0fVxuXHRcdHJldHVybiB7IGtleTogcGFyc2VkS2V5LCB2YWw6IHBhcnNlZFZhbCB9XG5cdH1cblxuXHQvLyBUcmFjayB3aGV0aGVyIGFjdGlvbnMgYXJlIGJlaW5nIHJlY29yZGVkXG5cdGhhbmRsZVN0YXJ0U3RvcFJlY29yZEFjdGlvbnMoaXNSZWNvcmRpbmc6IGJvb2xlYW4pOiB2b2lkIHtcblx0XHR0aGlzLmlzUmVjb3JkaW5nQWN0aW9ucyA9IGlzUmVjb3JkaW5nXG5cdH1cblxuXHQvLyBBZGQgYSBjb21tYW5kIHRvIHRoZSBBY3Rpb24gUmVjb3JkZXJcblx0YWRkVG9BY3Rpb25SZWNvcmRpbmcoZGVsdGFUaW1lOiBudW1iZXIsIG1zZzogTWlkaU1lc3NhZ2UpOiB2b2lkIHtcblx0XHRjb25zdCBhcmdzID0geyAuLi5tc2cuYXJncyB9XG5cdFx0aWYgKG1zZy5pZCA9PT0gJ3N5c2V4JyAmJiBhcmdzLmJ5dGVzKSB7XG5cdFx0XHRhcmdzLmJ5dGVzID0gYXJncy5ieXRlcy5tYXAoKGJ5dGUpID0+IGAweCR7Ynl0ZS50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKX1gKSBhcyB1bmtub3duIGFzIG51bWJlcltdXG5cdFx0fVxuXHRcdGxldCB1bmlxdWVJZCA9IGAke21zZy5pZH0gJHt0aGlzLmdldFZhbEZyb21Nc2cobXNnKS5rZXl9YFxuXHRcdGlmICh0aGlzLmNvbmZpZy51c2VUaW1lU3RhbXApIHtcblx0XHRcdGRlbHRhVGltZSA9IE1hdGgucm91bmQoZGVsdGFUaW1lICogMTAwMClcblx0XHRcdHVuaXF1ZUlkID0gJydcblx0XHR9IGVsc2Uge1xuXHRcdFx0ZGVsdGFUaW1lID0gMFxuXHRcdH1cblx0XHR0aGlzLnJlY29yZEFjdGlvbihcblx0XHRcdHtcblx0XHRcdFx0YWN0aW9uSWQ6IG1zZy5pZCxcblx0XHRcdFx0b3B0aW9uczogYXJncyxcblx0XHRcdFx0ZGVsYXk6IGRlbHRhVGltZSxcblx0XHRcdH0sXG5cdFx0XHR1bmlxdWVJZCwgLy8gdW5pcXVlSWQgdG8gc3RvcCBkdXBsaWNhdGVzIHdoZW4gbm90IHVzaW5nIFRpbWVTdGFtcFxuXHRcdClcblx0fVxufVxuXG5leHBvcnQgeyBVcGdyYWRlU2NyaXB0cyB9XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUEsUUFBTSxLQUFLLFVBQVEsSUFBSTtBQVF2QixhQUFTLGdCQUFnQixTQUFTO0FBQ2pDLFVBQUksQ0FBQyxRQUFRLGFBQWMsT0FBTSxJQUFJLE1BQU0scUJBQXFCO0FBRWhFLFlBQU0sU0FBUztBQUFBLFFBQ2QsUUFBUTtBQUFBLFFBQ1IsUUFBUTtBQUFBLFFBQ1IsUUFBUTtBQUFBO0FBQUEsUUFFUixRQUFRLFFBQVEsUUFBUSxhQUFhLFVBQVUsUUFBUSxPQUFPO0FBQUEsTUFDL0Q7QUFDQSxhQUFPLEdBQUcsT0FBTyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRyxDQUFDLElBQUksUUFBUSxPQUFPLFVBQVUsUUFBUSxZQUFZO0FBQUEsSUFDL0Y7QUFFQSxhQUFTLFNBQVM7QUFDakIsYUFBTyxDQUFDLEVBQUUsUUFBUSxZQUFZLFFBQVEsU0FBUztBQUFBLElBQ2hEO0FBRUEsYUFBUyxhQUFhO0FBQ3JCLFVBQUksUUFBUSxZQUFZLFFBQVEsU0FBUyxTQUFVLFFBQU87QUFDMUQsVUFBSSxRQUFRLElBQUkscUJBQXNCLFFBQU87QUFDN0MsYUFBTyxPQUFPLFdBQVcsZUFBZSxPQUFPLFdBQVcsT0FBTyxRQUFRLFNBQVM7QUFBQSxJQUNuRjtBQUVBLGFBQVMsU0FBUyxVQUFVO0FBQzNCLGFBQU8sYUFBYSxXQUFXLEdBQUcsV0FBVyxxQkFBcUI7QUFBQSxJQUNuRTtBQUVBLFdBQU8sVUFBVTtBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRDtBQUFBO0FBQUE7OztBQ3hDQTtBQUFBO0FBQUEsUUFBTSxPQUFPLFVBQVEsTUFBTTtBQUMzQixRQUFNLEtBQUssVUFBUSxJQUFJO0FBQ3ZCLFFBQU0sRUFBRSxpQkFBaUIsUUFBUSxZQUFZLFNBQVMsSUFBSTtBQUcxRCxRQUFNLEtBQUssT0FBTyxTQUFTLGNBQWMsS0FBSyxjQUFjLElBQUksSUFBSSxVQUFRLElBQUk7QUFHaEYsUUFBTSxpQkFBaUIsT0FBTyx3QkFBd0IsYUFBYSwwQkFBMEI7QUFVN0YsYUFBUyxZQUFZLFVBQVUsU0FBUyxnQkFBZ0IsZ0JBQWdCO0FBQ3ZFLFVBQUksT0FBTyxhQUFhLFlBQVksQ0FBQyxTQUFVLE9BQU0sSUFBSSxNQUFNLG1DQUFtQztBQUVsRyxVQUFJLE9BQU8sWUFBWSxZQUFZLENBQUMsUUFBUyxPQUFNLElBQUksTUFBTSxrQ0FBa0M7QUFDL0YsVUFBSSxPQUFPLFFBQVEsU0FBUyxZQUFZLENBQUMsUUFBUSxLQUFNLE9BQU0sSUFBSSxNQUFNLCtCQUErQjtBQUV0RyxVQUFJLFlBQVk7QUFDaEIsVUFBSSxRQUFRLGlCQUFpQixNQUFNLFFBQVEsUUFBUSxhQUFhLEdBQUc7QUFDbEUsb0JBQVk7QUFBQSxNQUNiO0FBRUEsWUFBTSxPQUFRLGtCQUFrQixRQUFRLElBQUksbUJBQW9CLEdBQUcsS0FBSztBQUN4RSxZQUFNLFdBQVksa0JBQWtCLFFBQVEsSUFBSSx1QkFBd0IsR0FBRyxTQUFTO0FBRXBGLFVBQUksVUFBVTtBQUVkLFVBQUksQ0FBQyxXQUFXO0FBQ2YsWUFBSSxrQkFBa0IsUUFBUSxJQUFJLG9CQUFvQjtBQUNyRCxvQkFBVSxRQUFRLElBQUk7QUFBQSxRQUN2QixXQUFXLFdBQVcsR0FBRztBQUN4QixvQkFBVTtBQUFBLFFBQ1gsV0FBVyxPQUFPLEdBQUc7QUFDcEIsb0JBQVU7QUFBQSxRQUNYO0FBQUEsTUFDRDtBQUVBLFlBQU0sYUFBYSxDQUFDO0FBRXBCLFVBQUksQ0FBQyxnQkFBZ0I7QUFFcEIsbUJBQVc7QUFBQSxVQUNWLEtBQUssS0FBSyxVQUFVLFNBQVMsU0FBUyxHQUFHLFFBQVEsSUFBSSxPQUFPO0FBQUEsVUFDNUQsS0FBSyxLQUFLLFVBQVUsU0FBUyxXQUFXLEdBQUcsUUFBUSxJQUFJLE9BQU87QUFBQSxRQUMvRDtBQUFBLE1BQ0Q7QUFFQSxVQUFJLE9BQU87QUFDWCxVQUFJLFNBQVMsUUFBUSxFQUFHLFFBQU87QUFHL0IsVUFBSSxXQUFXO0FBRWQsbUJBQVcsT0FBTyxRQUFRLGVBQWU7QUFDeEMsZ0JBQU0sZUFBZSxnQkFBZ0I7QUFBQSxZQUNwQyxNQUFNLFFBQVE7QUFBQSxZQUNkO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLGNBQWM7QUFBQSxZQUNkO0FBQUE7QUFBQSxVQUVELENBQUM7QUFDRCxxQkFBVyxLQUFLLEtBQUssS0FBSyxVQUFVLGFBQWEsWUFBWSxDQUFDO0FBQUEsUUFDL0Q7QUFBQSxNQUNELE9BQU87QUFDTixjQUFNLElBQUksTUFBTSwwQkFBMEI7QUFBQSxNQUMzQztBQUVBLFVBQUksWUFBWTtBQUVoQixpQkFBVyxhQUFhLFlBQVk7QUFDbkMsWUFBSSxHQUFHLFdBQVcsU0FBUyxHQUFHO0FBQzdCLGdCQUFNLE9BQU8sR0FBRyxTQUFTLFNBQVM7QUFDbEMsY0FBSSxLQUFLLE9BQU8sR0FBRztBQUNsQix3QkFBWTtBQUNaO0FBQUEsVUFDRDtBQUFBLFFBQ0Q7QUFBQSxNQUNEO0FBRUEsVUFBSSxDQUFDLGFBQWEsZ0JBQWdCO0FBQ2pDLGNBQU0sZ0JBQWdCLFdBQVcsSUFBSSxDQUFDLFNBQVMsTUFBTSxJQUFJLEVBQUUsRUFBRSxLQUFLLElBQUk7QUFDdEUsY0FBTSxJQUFJLE1BQU0sOEJBQThCLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFBbUIsYUFBYSxFQUFFO0FBQUEsTUFDN0Y7QUFFQSxhQUFPO0FBQUEsSUFDUjtBQUVBLGFBQVMsWUFBWSxVQUFVLFNBQVM7QUFDdkMsWUFBTSxZQUFZLFlBQVksVUFBVSxTQUFTLE9BQU8sSUFBSTtBQUc1RCxVQUFJLENBQUMsVUFBVyxPQUFNLElBQUksTUFBTSw4QkFBOEIsUUFBUSxJQUFJLEVBQUU7QUFFNUUsYUFBTyxlQUFlLFNBQVM7QUFBQSxJQUNoQztBQUNBLGdCQUFZLFVBQVU7QUFFdEIsV0FBTyxVQUFVO0FBQUE7QUFBQTs7O0FDMUdqQjtBQUFBO0FBQUEsV0FBTyxVQUFVO0FBQUEsTUFDZixNQUFNO0FBQUEsTUFDTixlQUFlLENBQUMsQ0FBQztBQUFBLElBQ25CO0FBQUE7QUFBQTs7O0FDSEE7QUFBQTtBQUNBLFdBQU8sVUFBVTtBQUFBLE1BRWIsc0JBQThCO0FBQUEsTUFDOUIsdUJBQThCO0FBQUEsTUFDOUIsc0JBQThCO0FBQUEsTUFDOUIsa0JBQThCO0FBQUEsTUFDOUIsa0JBQXFCO0FBQUEsTUFDckIsa0JBQThCO0FBQUEsTUFDOUIsYUFBOEI7QUFBQSxNQUM5QixPQUFnQjtBQUFBLE1BQ2hCLFNBQW9CO0FBQUEsTUFDcEIsY0FBa0I7QUFBQSxNQUNsQixXQUFtQjtBQUFBLE1BQ25CLFlBQW9CO0FBQUEsTUFDcEIsU0FBa0I7QUFBQSxNQUNsQixXQUFxQjtBQUFBLE1BQ3JCLGVBQThCO0FBQUEsTUFDOUIsVUFBZTtBQUFBLE1BQ2YsZUFBOEI7QUFBQSxNQUM5QixrQkFBOEI7QUFBQSxNQUM5QixZQUFvQjtBQUFBLE1BQ3BCLGNBQWtCO0FBQUEsTUFDbEIsWUFBb0I7QUFBQSxNQUNwQixXQUFtQjtBQUFBLE1BQ25CLFdBQW1CO0FBQUEsTUFDbkIsaUJBQThCO0FBQUEsTUFDOUIsdUJBQThCO0FBQUEsTUFDOUIsdUJBQThCO0FBQUEsTUFDOUIsc0JBQThCO0FBQUEsTUFDOUIsdUJBQThCO0FBQUEsTUFDOUIsdUJBQThCO0FBQUEsTUFDOUIsbUJBQXlCO0FBQUEsTUFDekIsbUJBQXlCO0FBQUEsTUFDekIsa0JBQXFCO0FBQUEsTUFDckIsZUFBc0I7QUFBQSxNQUN0QixzQkFBd0I7QUFBQSxNQUN4QixvQkFBMEI7QUFBQSxNQUMxQixlQUE4QjtBQUFBLE1BQzlCLGFBQThCO0FBQUEsTUFDOUIsYUFBOEI7QUFBQSxNQUM5QixjQUE4QjtBQUFBLE1BQzlCLGNBQWtCO0FBQUEsTUFDbEIsUUFBaUI7QUFBQSxNQUNqQixPQUFnQjtBQUFBLE1BQ2hCLE9BQWlCO0FBQUEsTUFDakIsWUFBMkI7QUFBQSxNQUMzQixpQkFBMkI7QUFBQSxNQUMzQixtQkFBeUI7QUFBQSxNQUN6QixpQkFBd0I7QUFBQSxNQUN4QixTQUF3QjtBQUFBLE1BQ3hCLG1CQUF5QjtBQUFBLE1BQ3pCLG1CQUE4QjtBQUFBLE1BQzlCLGdCQUE4QjtBQUFBLE1BQzlCLGdCQUE4QjtBQUFBLE1BQzlCLFlBQW9CO0FBQUEsTUFDcEIsWUFBb0I7QUFBQSxNQUNwQixhQUFxQjtBQUFBLE1BQ3JCLGVBQXNCO0FBQUEsTUFDdEIsU0FBa0I7QUFBQSxNQUNsQixVQUFlO0FBQUEsTUFDZixNQUFZO0FBQUEsTUFDWixlQUFzQjtBQUFBLE1BQ3RCLGFBQXFCO0FBQUEsTUFDckIsZUFBc0I7QUFBQSxNQUN0QixjQUFrQjtBQUFBLE1BQ2xCLGNBQWtCO0FBQUEsTUFDbEIsYUFBcUI7QUFBQSxNQUNyQixVQUFlO0FBQUEsTUFDZixXQUF3QjtBQUFBLE1BQ3hCLGNBQXdCO0FBQUEsTUFDeEIsTUFBcUI7QUFBQSxNQUNyQixjQUF1QjtBQUFBLE1BQ3ZCLFNBQTJCO0FBQUEsTUFDM0IsVUFBd0I7QUFBQSxNQUN4QixTQUE0QjtBQUFBLE1BQzVCLE9BQTJCO0FBQUEsTUFDM0IsVUFBMkI7QUFBQSxNQUMzQixXQUFtQjtBQUFBLE1BQ25CLGNBQWtCO0FBQUEsTUFDbEIsWUFBb0I7QUFBQSxNQUNwQixTQUFrQjtBQUFBLE1BQ2xCLFNBQWtCO0FBQUEsTUFDbEIsZUFBNEI7QUFBQSxNQUM1QixpQkFBd0I7QUFBQSxNQUN4QixpQkFBd0I7QUFBQSxNQUN4QixjQUFrQjtBQUFBLE1BQ2xCLGdCQUF1QjtBQUFBLE1BQ3ZCLGNBQXNCO0FBQUEsTUFDdEIsZUFBc0I7QUFBQSxNQUN0QixzQkFBd0I7QUFBQSxNQUN4QixlQUFzQjtBQUFBLE1BQ3RCLFlBQW9CO0FBQUEsTUFDcEIsaUJBQXdCO0FBQUEsTUFDeEIsYUFBcUI7QUFBQSxNQUNyQixhQUFxQjtBQUFBLE1BQ3JCLGdCQUF1QjtBQUFBLE1BQ3ZCLFlBQW9CO0FBQUEsTUFDcEIsYUFBcUI7QUFBQSxNQUNyQixXQUFtQjtBQUFBLE1BQ25CLGlCQUF3QjtBQUFBLE1BQ3hCLGNBQWtCO0FBQUEsTUFDbEIsaUJBQXdCO0FBQUEsTUFDeEIsaUJBQXdCO0FBQUEsTUFDeEIsY0FBa0I7QUFBQSxNQUNsQixhQUFxQjtBQUFBLE1BQ3JCLFlBQW9CO0FBQUEsTUFDcEIsT0FBZ0I7QUFBQSxNQUNoQixPQUFnQjtBQUFBLE1BQ2hCLFVBQWU7QUFBQSxNQUNmLE1BQVk7QUFBQSxNQUNaLFNBQWtCO0FBQUEsTUFDbEIsVUFBZTtBQUFBLE1BQ2YsUUFBaUI7QUFBQSxNQUNqQixRQUFpQjtBQUFBLE1BQ2pCLGFBQXFCO0FBQUEsTUFDckIsT0FBZ0I7QUFBQSxNQUNoQixhQUFxQjtBQUFBLE1BQ3JCLFdBQW1CO0FBQUEsTUFDbkIsWUFBa0I7QUFBQSxNQUNsQixhQUFxQjtBQUFBLE1BQ3JCLFlBQW9CO0FBQUEsTUFDcEIsZ0JBQXVCO0FBQUEsTUFDdkIsbUJBQXlCO0FBQUEsTUFDekIsY0FBa0I7QUFBQSxNQUNsQixVQUFlO0FBQUEsTUFDZixZQUFvQjtBQUFBLE1BQ3BCLGdCQUF1QjtBQUFBLE1BQ3ZCLFlBQW9CO0FBQUEsTUFDcEIsVUFBZTtBQUFBLE1BQ2YsU0FBOEI7QUFBQSxJQUNsQztBQUFBO0FBQUE7OztBQ25JQTtBQUFBO0FBQ0EsV0FBTyxVQUFVO0FBQUEsTUFFYixvQkFBeUI7QUFBQSxNQUN6QixXQUFlO0FBQUEsTUFDZixZQUFtQjtBQUFBLE1BQ25CLGdCQUFzQjtBQUFBLE1BQ3RCLFdBQWU7QUFBQSxNQUNmLGdCQUFzQjtBQUFBLE1BQ3RCLGVBQWtCO0FBQUEsTUFDbEIsZUFBa0I7QUFBQSxNQUNsQixnQkFBc0I7QUFBQSxNQUN0QixjQUFpQjtBQUFBLE1BQ2pCLFNBQWlCO0FBQUEsTUFDakIsYUFBb0I7QUFBQSxNQUNwQixhQUFvQjtBQUFBLE1BQ3BCLFlBQW1CO0FBQUEsTUFDbkIsZ0JBQXNCO0FBQUEsTUFDdEIsVUFBYztBQUFBLE1BQ2QsZUFBa0I7QUFBQSxNQUNsQixnQkFBc0I7QUFBQSxNQUN0QixXQUFlO0FBQUEsTUFDZixZQUFtQjtBQUFBLE1BQ25CLGVBQWtCO0FBQUEsTUFDbEIsU0FBaUI7QUFBQSxNQUNqQixnQkFBc0I7QUFBQSxNQUN0QixZQUFtQjtBQUFBLE1BQ25CLGVBQWtCO0FBQUEsTUFDbEIsVUFBYztBQUFBLE1BQ2QsV0FBZTtBQUFBLE1BQ2YsZUFBa0I7QUFBQSxNQUNsQixlQUFrQjtBQUFBLE1BQ2xCLFdBQWU7QUFBQSxNQUNmLGNBQWlCO0FBQUEsTUFDakIsYUFBb0I7QUFBQSxNQUNwQixZQUFtQjtBQUFBLE1BQ25CLFdBQWU7QUFBQSxNQUNmLFFBQWdCO0FBQUEsTUFDaEIsU0FBaUI7QUFBQSxNQUNqQixlQUFrQjtBQUFBLE1BQ2xCLGNBQWlCO0FBQUEsTUFDakIsYUFBb0I7QUFBQSxNQUNwQixZQUFtQjtBQUFBLE1BQ25CLFFBQWdCO0FBQUEsTUFDaEIsZUFBa0I7QUFBQSxNQUNsQixnQkFBc0I7QUFBQSxNQUN0QixZQUFtQjtBQUFBLE1BQ25CLFlBQW1CO0FBQUEsTUFDbkIsZUFBa0I7QUFBQSxNQUNsQixlQUFrQjtBQUFBLElBQ3RCO0FBQUE7QUFBQTs7O0FDbERBO0FBQUE7QUFDQSxXQUFPLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU2IsVUFBVztBQUFBO0FBQUEsTUFHWCxHQUFLO0FBQUEsTUFDTCxTQUFVO0FBQUEsTUFDVixRQUFTO0FBQUEsTUFDVCxHQUFLO0FBQUEsTUFDTCxTQUFVO0FBQUEsTUFDVixRQUFVO0FBQUEsTUFDVixHQUFLO0FBQUEsTUFDTCxTQUFVO0FBQUEsTUFDVixRQUFVO0FBQUEsTUFDVixHQUFLO0FBQUEsTUFDTCxTQUFVO0FBQUEsTUFDVixRQUFVO0FBQUEsTUFDVixHQUFLO0FBQUEsTUFDTCxTQUFVO0FBQUEsTUFDVixRQUFVO0FBQUEsTUFDVixHQUFLO0FBQUEsTUFDTCxTQUFVO0FBQUEsTUFDVixRQUFVO0FBQUEsTUFDVixHQUFLO0FBQUEsTUFDTCxTQUFVO0FBQUEsTUFDVixRQUFVO0FBQUE7QUFBQSxNQUdWLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLElBQUs7QUFBQSxNQUNMLEtBQU07QUFBQSxJQUVWO0FBQUE7QUFBQTs7O0FDaERBO0FBQUE7QUFDQSxXQUFPLFVBQVU7QUFBQTtBQUFBO0FBQUEsTUFJYixVQUFvQjtBQUFBO0FBQUEsTUFDcEIsU0FBb0I7QUFBQTtBQUFBLE1BQ3BCLG1CQUFvQjtBQUFBO0FBQUEsTUFDcEIsZUFBb0I7QUFBQTtBQUFBLE1BQ3BCLGFBQW9CO0FBQUE7QUFBQSxNQUNwQixpQkFBb0I7QUFBQTtBQUFBLE1BQ3BCLGdCQUFvQjtBQUFBO0FBQUEsTUFFcEIsV0FBb0I7QUFBQSxNQUNwQixTQUFvQjtBQUFBLE1BQ3BCLFNBQW9CO0FBQUE7QUFBQSxNQUdwQixjQUFvQjtBQUFBO0FBQUEsTUFDcEIsZ0JBQW9CO0FBQUE7QUFBQSxNQUVwQixTQUFvQjtBQUFBO0FBQUEsTUFJcEIsSUFBSTtBQUFBO0FBQUEsUUFFTixhQUFrQjtBQUFBLFFBQ2xCLFlBQXdCO0FBQUEsUUFDeEIsZ0JBQXdCO0FBQUEsUUFDeEIsYUFBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGlCQUF3QjtBQUFBLFFBQ3hCLFlBQXdCO0FBQUEsUUFDeEIsUUFBd0I7QUFBQSxRQUN4QixTQUF3QjtBQUFBLFFBQ3hCLGFBQXdCO0FBQUEsUUFDeEIsS0FBd0I7QUFBQSxRQUN4QixZQUF3QjtBQUFBLFFBQ3hCLGtCQUF3QjtBQUFBLFFBQ3hCLGtCQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixtQkFBd0I7QUFBQSxRQUN4QixtQkFBb0I7QUFBQSxRQUNwQixtQkFBb0I7QUFBQSxRQUNwQixtQkFBb0I7QUFBQTtBQUFBLFFBR3BCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBO0FBQUEsUUFHeEIsaUJBQWtCO0FBQUEsUUFDWixnQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUM5QixjQUF3QjtBQUFBLFFBQ2xCLGtCQUF3QjtBQUFBLFFBQ3hCLHFCQUF3QjtBQUFBLFFBQ3hCLGdCQUF3QjtBQUFBLFFBQ3hCLFlBQXdCO0FBQUEsUUFDeEIsYUFBd0I7QUFBQSxRQUM5QixjQUF3QjtBQUFBLFFBQ2xCLFNBQXdCO0FBQUEsUUFDeEIsZ0JBQXdCO0FBQUEsUUFDeEIsc0JBQXdCO0FBQUEsUUFDeEIsc0JBQXdCO0FBQUEsUUFFeEIsY0FBd0I7QUFBQSxRQUM5QixjQUF3QjtBQUFBLFFBQ2xCLHVCQUF3QjtBQUFBLFFBQ3hCLHVCQUF3QjtBQUFBLFFBQ3hCLHVCQUF3QjtBQUFBLFFBQ3hCLHVCQUF3QjtBQUFBO0FBQUEsUUFHOUIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFFbEIsZUFBd0I7QUFBQSxRQUM5QixZQUF3QjtBQUFBLFFBQ2xCLGlCQUF3QjtBQUFBLFFBQ3hCLFlBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDOUIsUUFBd0I7QUFBQSxRQUNsQixpQkFBd0I7QUFBQSxRQUM5QixRQUF3QjtBQUFBLFFBQ2xCLGNBQXdCO0FBQUEsUUFDOUIsWUFBd0I7QUFBQSxRQUNsQixZQUF3QjtBQUFBLFFBQzlCLFFBQXdCO0FBQUEsUUFDeEIsT0FBd0I7QUFBQSxRQUNsQixpQkFBd0I7QUFBQSxRQUM5QixRQUF3QjtBQUFBLFFBQ2xCLFlBQXdCO0FBQUEsUUFFeEIsdUJBQXdCO0FBQUEsUUFDeEIsdUJBQXdCO0FBQUEsUUFDeEIsdUJBQXdCO0FBQUEsUUFDeEIsdUJBQXdCO0FBQUEsUUFFeEIsb0JBQXdCO0FBQUE7QUFBQSxRQUc5QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQTtBQUFBLFFBR3hCLFVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUNsQixjQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUM5QixVQUF3QjtBQUFBLFFBQ3hCLFVBQXdCO0FBQUEsUUFDbEIsbUJBQXdCO0FBQUEsUUFDeEIsbUJBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBO0FBQUEsUUFHOUIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUE7QUFBQSxRQUdsQixlQUF3QjtBQUFBLFFBQ3hCLHVCQUF3QjtBQUFBLFFBQzlCLGVBQXdCO0FBQUEsUUFDbEIsZUFBd0I7QUFBQSxRQUM5QixlQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBO0FBQUEsUUFHeEIsV0FBd0I7QUFBQTtBQUFBLFFBR3hCLGNBQXdCO0FBQUEsUUFDbEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIsb0JBQXdCO0FBQUEsUUFDeEIscUJBQXdCO0FBQUEsUUFFeEIsZ0JBQXdCO0FBQUEsUUFDOUIsZ0JBQXdCO0FBQUEsUUFDeEIsZ0JBQXdCO0FBQUEsUUFDeEIsZ0JBQXdCO0FBQUEsUUFDeEIsZ0JBQXdCO0FBQUEsUUFFbEIsY0FBd0I7QUFBQSxNQUM1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUEsV0FBVztBQUFBLFFBQ1AsYUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBO0FBQUEsUUFDeEIsYUFBd0I7QUFBQSxRQUN4QixhQUF3QjtBQUFBLFFBQ3hCLGFBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixLQUF3QjtBQUFBO0FBQUEsTUFDNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1BLFVBQVU7QUFBQSxRQUNOLGNBQWdCO0FBQUEsUUFDaEIsY0FBZ0I7QUFBQSxRQUNoQixPQUFnQjtBQUFBLFFBQ2hCLFVBQWdCO0FBQUEsUUFDaEIsTUFBZ0I7QUFBQSxRQUNoQixjQUFnQjtBQUFBLFFBQ2hCLGdCQUFnQjtBQUFBLFFBQ2hCLGNBQWdCO0FBQUEsTUFDcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BYUEsT0FBTztBQUFBLFFBQ0gsS0FBd0I7QUFBQTtBQUFBLE1BQzVCO0FBQUEsSUFFSjtBQUFBO0FBQUE7OztBQ25QQTtBQUFBO0FBQUEsUUFBTSxPQUFPO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBTSxTQUFTLFVBQVEsUUFBUTtBQUcvQixRQUFNLEVBQUUsY0FBQUEsY0FBYSxJQUFJLFVBQVEsUUFBUTtBQUt6QyxRQUFNLGNBQWM7QUFFcEIsUUFBTSxRQUFRO0FBRWQsUUFBTSxRQUFRO0FBRWQsUUFBTSxXQUFXO0FBRWpCLFFBQU1DLFNBQU4sY0FBb0JELGNBQWE7QUFBQSxNQUMvQixjQUFjO0FBQ1osY0FBTTtBQUVOLGFBQUssUUFBUSxJQUFJLEtBQUssTUFBTSxDQUFDLFdBQVcsWUFBWTtBQUNsRCxlQUFLLEtBQUssV0FBVyxXQUFXLE1BQU0sS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDO0FBQUEsUUFDOUQsQ0FBQztBQUFBLE1BQ0g7QUFBQSxNQUVBLFlBQVk7QUFDVixlQUFPLEtBQUssTUFBTSxVQUFVO0FBQUEsTUFDOUI7QUFBQSxNQUNBLFVBQVU7QUFDUixlQUFPLEtBQUssTUFBTSxRQUFRO0FBQUEsTUFDNUI7QUFBQSxNQUNBLGVBQWU7QUFDYixlQUFPLEtBQUssTUFBTSxhQUFhO0FBQUEsTUFDakM7QUFBQSxNQUNBLFlBQVksTUFBTTtBQUNoQixlQUFPLEtBQUssTUFBTSxZQUFZLElBQUk7QUFBQSxNQUNwQztBQUFBLE1BQ0EsYUFBYTtBQUNYLGVBQU8sS0FBSyxNQUFNLFdBQVc7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsWUFBWSxPQUFPLFFBQVEsZUFBZTtBQUN4QyxlQUFPLEtBQUssTUFBTSxZQUFZLE9BQU8sUUFBUSxhQUFhO0FBQUEsTUFDNUQ7QUFBQSxNQUNBLFNBQVMsTUFBTTtBQUNiLGVBQU8sS0FBSyxNQUFNLFNBQVMsSUFBSTtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxlQUFlLE1BQU07QUFDbkIsaUJBQVEsT0FBSyxHQUFHLE9BQUssS0FBSyxNQUFNLGFBQWEsR0FBRyxFQUFFLE1BQU07QUFDdEQsY0FBSSxTQUFTLEtBQUssTUFBTSxZQUFZLElBQUksR0FBRztBQUN6QyxtQkFBTyxLQUFLLE1BQU0sU0FBUyxJQUFJO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBLGdCQUFnQixNQUFNO0FBQ3BCLGVBQU8sS0FBSyxNQUFNLGdCQUFnQixJQUFJO0FBQUEsTUFDeEM7QUFBQSxNQUNBLGNBQWMsTUFBTSxRQUFRLEdBQUc7QUFDN0IsZUFBTyxLQUFLLE1BQU0sY0FBYyxNQUFNLEtBQUs7QUFBQSxNQUM3QztBQUFBLElBQ0Y7QUFFQSxRQUFNRSxVQUFOLE1BQWE7QUFBQSxNQUNYLGNBQWM7QUFDWixhQUFLLFNBQVMsSUFBSSxLQUFLLE9BQU87QUFBQSxNQUNoQztBQUFBLE1BRUEsWUFBWTtBQUNWLGVBQU8sS0FBSyxPQUFPLFVBQVU7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsVUFBVTtBQUNSLGVBQU8sS0FBSyxPQUFPLFFBQVE7QUFBQSxNQUM3QjtBQUFBLE1BQ0EsZUFBZTtBQUNiLGVBQU8sS0FBSyxPQUFPLGFBQWE7QUFBQSxNQUNsQztBQUFBLE1BQ0EsWUFBWSxNQUFNO0FBQ2hCLGVBQU8sS0FBSyxPQUFPLFlBQVksSUFBSTtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxhQUFhO0FBQ1gsZUFBTyxLQUFLLE9BQU8sV0FBVztBQUFBLE1BQ2hDO0FBQUEsTUFDQSxTQUFTLE1BQU07QUFDYixlQUFPLEtBQUssT0FBTyxTQUFTLElBQUk7QUFBQSxNQUNsQztBQUFBLE1BQ0EsZUFBZSxNQUFNO0FBQ25CLGlCQUFRLE9BQUssR0FBRyxPQUFLLEtBQUssT0FBTyxhQUFhLEdBQUcsRUFBRSxNQUFNO0FBQ3ZELGNBQUksU0FBUyxLQUFLLE9BQU8sWUFBWSxJQUFJLEdBQUc7QUFDMUMsbUJBQU8sS0FBSyxPQUFPLFNBQVMsSUFBSTtBQUFBLFVBQ2xDO0FBQUEsUUFDRjtBQUNBLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFDQSxnQkFBZ0IsTUFBTTtBQUNwQixlQUFPLEtBQUssT0FBTyxnQkFBZ0IsSUFBSTtBQUFBLE1BQ3pDO0FBQUEsTUFDQSxLQUFLLFNBQVM7QUFDWixlQUFPLEtBQUssWUFBWSxPQUFPO0FBQUEsTUFDakM7QUFBQSxNQUNBLFlBQVksU0FBUztBQUNuQixZQUFJLE1BQU0sUUFBUSxPQUFPLEdBQUc7QUFDMUIsb0JBQVUsT0FBTyxLQUFLLE9BQU87QUFBQSxRQUMvQjtBQUNBLFlBQUksQ0FBQyxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzdCLGdCQUFNLElBQUksTUFBTSwyQ0FBMkM7QUFBQSxRQUM3RDtBQUVBLGVBQU8sS0FBSyxPQUFPLFlBQVksT0FBTztBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUdBLGFBQVMsaUJBQWlCLE9BQU87QUFDL0IsY0FBUSxTQUFTLElBQUlELE9BQU07QUFDM0IsVUFBSSxTQUFTLElBQUksT0FBTztBQUN4QixhQUFPLFdBQVc7QUFDbEIsYUFBTyxTQUFTO0FBQ2hCLGFBQU8sUUFBUSxDQUFDO0FBRWhCLFlBQU0sR0FBRyxXQUFXLFNBQVMsV0FBVyxTQUFTO0FBRS9DLFlBQUksU0FBUyxJQUFJLE9BQU8sS0FBSyxPQUFPO0FBRXBDLFlBQUksQ0FBQyxPQUFPLFFBQVE7QUFDbEIsaUJBQU8sS0FBSyxRQUFRLE1BQU07QUFBQSxRQUM1QixPQUFPO0FBQ0wsaUJBQU8sTUFBTSxLQUFLLE1BQU07QUFBQSxRQUMxQjtBQUFBLE1BQ0YsQ0FBQztBQUVELGFBQU8sUUFBUSxXQUFXO0FBQ3hCLGVBQU8sU0FBUztBQUFBLE1BQ2xCO0FBRUEsYUFBTyxTQUFTLFdBQVc7QUFDekIsZUFBTyxTQUFTO0FBQ2hCLGVBQU8sT0FBTyxNQUFNLFVBQVUsT0FBTyxLQUFLLFFBQVEsT0FBTyxNQUFNLE1BQU0sQ0FBQyxHQUFHO0FBQUEsUUFBQztBQUFBLE1BQzVFO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLGtCQUFrQixRQUFRO0FBQ2pDLGVBQVMsVUFBVSxJQUFJQyxRQUFPO0FBQzlCLFVBQUksU0FBUyxJQUFJLE9BQU87QUFDeEIsYUFBTyxXQUFXO0FBQ2xCLGFBQU8sU0FBUztBQUNoQixhQUFPLFFBQVEsQ0FBQztBQUVoQixhQUFPLFFBQVEsU0FBUyxHQUFHO0FBRXpCLFlBQUksT0FBTyxTQUFTLENBQUMsR0FBRztBQUN0QixjQUFJLE1BQU0sVUFBVSxNQUFNLEtBQUssR0FBRyxDQUFDO0FBQUEsUUFDckM7QUFFQSxlQUFPLFlBQVksQ0FBQztBQUVwQixlQUFPLENBQUMsS0FBSztBQUFBLE1BQ2Y7QUFFQSxhQUFPLE1BQU0sU0FBUyxLQUFLO0FBQ3pCLGVBQU8sT0FBTyxNQUFNLEdBQUc7QUFDdkIsZUFBTyxXQUFXO0FBQUEsTUFDcEI7QUFFQSxhQUFPLFVBQVUsV0FBVztBQUMxQixlQUFPLFdBQVc7QUFBQSxNQUNwQjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTyxVQUFVO0FBQUEsTUFDZixPQUFBRDtBQUFBLE1BQ0EsUUFBQUM7QUFBQSxNQUVBO0FBQUEsTUFDQTtBQUFBLE1BRUEsV0FBVztBQUFBLFFBQ1Q7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUE7QUFBQSxNQUdBLE9BQU9EO0FBQUEsTUFDUCxRQUFRQztBQUFBLElBQ1Y7QUFBQTtBQUFBOzs7QUMvS0EsSUFBTSxxQkFBa0MsQ0FBQyxRQUFRLE9BQU8sWUFBVztBQUVsRSxVQUFRLElBQUksSUFBSSxNQUFNLFlBQVcsQ0FBRSxJQUFJLFNBQVMsS0FBSyxNQUFNLE1BQU0sRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUNqRjtBQUVBLFNBQVMsVUFBVSxRQUE0QixPQUFpQixTQUFlO0FBQzlFLFFBQU0sT0FBTyxPQUFPLE9BQU8scUJBQXFCLGFBQWEsT0FBTyxtQkFBbUI7QUFDdkYsT0FBSyxRQUFRLE9BQU8sT0FBTztBQUM1QjtBQU9NLFNBQVUsbUJBQW1CLFFBQWU7QUFDakQsU0FBTztJQUNOLE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPO0lBQzlELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE1BQU0sQ0FBQyxZQUFvQixVQUFVLFFBQVEsUUFBUSxPQUFPO0lBQzVELE9BQU8sQ0FBQyxZQUFvQixVQUFVLFFBQVEsU0FBUyxPQUFPOztBQUVoRTs7O0FDVE0sU0FBVSxZQUFZLE1BQVc7QUFFdkM7QUF5Qk0sU0FBVSxXQUFXLEdBQVcsR0FBVyxHQUFXLEdBQVU7QUFDckUsTUFBSSxlQUF3QixJQUFJLFFBQVMsTUFBUSxJQUFJLFFBQVMsSUFBTSxJQUFJO0FBQ3hFLE1BQUksS0FBSyxLQUFLLEtBQUssSUFBSSxHQUFHO0FBQ3pCLG1CQUFlLFdBQVksS0FBSyxNQUFNLE9BQU8sSUFBSSxFQUFFO0VBQ3BEO0FBQ0EsU0FBTztBQUNSOzs7QUMvREEsU0FBUyxvQkFBb0I7QUEyRXZCLElBQU8sc0JBQVAsY0FBbUMsYUFBbUM7RUFDbEU7RUFDQTtFQUVULElBQVcsV0FBUTtBQUNsQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUNBLElBQVcsYUFBVTtBQUNwQixXQUFPLEtBQUssWUFBWTtFQUN6QjtFQUVBLElBQVksYUFBVTtBQUNyQixRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVyxVQUFVO0FBQ25ELGFBQU8sS0FBSztJQUNiLE9BQU87QUFDTixhQUFPO0lBQ1I7RUFDRDtFQUVBLFNBQXVFO0VBRXZFLFlBQVksU0FBeUMsU0FBK0I7QUFDbkYsVUFBSztBQUVMLFNBQUssV0FBVztBQUNoQixTQUFLLFdBQVcsRUFBRSxHQUFHLFFBQU87RUFDN0I7RUFFQSxLQUFLLE1BQWMsVUFBbUIsVUFBcUI7QUFDMUQsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7QUFBVSxZQUFNLElBQUksTUFBTSx5QkFBeUI7QUFDN0YsWUFBUSxLQUFLLFFBQVE7TUFDcEIsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG9DQUFvQztNQUNyRCxLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0seUJBQXlCO01BQzFDLEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSxtQkFBbUI7TUFDcEMsS0FBSztBQUNKO01BQ0Q7QUFDQyxvQkFBWSxLQUFLLE1BQU07QUFDdkIsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0lBQ3hDO0FBRUEsU0FBSyxTQUFTO0FBRWQsUUFBSTtBQUFVLFdBQUssR0FBRyxhQUFhLFFBQVE7QUFFM0MsU0FBSyxTQUNILG9CQUFvQjtNQUNwQixRQUFRLEtBQUssU0FBUztNQUN0QixZQUFZOztLQUVaLEVBQ0EsS0FDQSxDQUFDLGFBQVk7QUFDWixXQUFLLFNBQVMsRUFBRSxZQUFZLE1BQU0sU0FBUTtBQUMxQyxXQUFLLFNBQVMsd0JBQXdCLElBQUksVUFBVSxJQUFJO0FBQ3hELFdBQUssS0FBSyxXQUFXO0lBQ3RCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTO0FBQ2QsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxNQUFNLFVBQXFCO0FBQzFCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7SUFFcEQsT0FBTztBQUNOLGNBQVEsS0FBSyxRQUFRO1FBQ3BCLEtBQUs7QUFDSixnQkFBTSxJQUFJLE1BQU0sb0NBQW9DO1FBQ3JELEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQkFBb0I7UUFDckM7QUFDQyxzQkFBWSxLQUFLLE1BQU07QUFDdkIsZ0JBQU0sSUFBSSxNQUFNLHNCQUFzQjtNQUN4QztJQUNEO0FBRUEsVUFBTSxXQUFXLEtBQUssT0FBTztBQUM3QixTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLFNBQVMsUUFBUTtBQUV2QyxTQUFLLFNBQ0gscUJBQXFCO01BQ3JCO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixXQUFLLFNBQVMsd0JBQXdCLE9BQU8sUUFBUTtBQUNyRCxXQUFLLEtBQUssT0FBTztJQUNsQixHQUNBLENBQUMsUUFBTztBQUNQLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxTQUFTLGVBQWUsUUFBUSxNQUFNLElBQUksTUFBTSxHQUFHLENBQUM7SUFDL0QsQ0FBQyxFQUVELE1BQU0sTUFBTSxJQUFJO0VBQ25CO0VBV0EsS0FDQyxjQUNBLGNBQ0EsaUJBQ0EsZ0JBQ0EsU0FDQSxVQUFxQjtBQUVyQixRQUFJLE9BQU8saUJBQWlCO0FBQVUsWUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ3pFLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN4QyxVQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxZQUFZO0FBQVUsY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQzFHLFVBQUksYUFBYSxVQUFhLE9BQU8sYUFBYTtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUVqRyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsY0FBYyxlQUFlO0FBQzlFLFdBQUssV0FBVyxRQUFRLGdCQUFnQixTQUFTLFFBQVE7SUFDMUQsV0FBVyxPQUFPLG9CQUFvQixVQUFVO0FBQy9DLFVBQUksbUJBQW1CLFVBQWEsT0FBTyxtQkFBbUI7QUFBWSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFFN0csWUFBTSxTQUFTLEtBQUssZUFBZSxjQUFjLEdBQUcsTUFBUztBQUM3RCxXQUFLLFdBQVcsUUFBUSxjQUFjLGlCQUFpQixjQUFjO0lBQ3RFLE9BQU87QUFDTixZQUFNLElBQUksTUFBTSxtQkFBbUI7SUFDcEM7RUFDRDtFQUVBLGVBQ0MsY0FDQSxRQUNBLFFBQTBCO0FBRTFCLFFBQUk7QUFDSixRQUFJLE9BQU8saUJBQWlCLFVBQVU7QUFDckMsZUFBUyxPQUFPLEtBQUssY0FBYyxPQUFPO0lBQzNDLFdBQVcsT0FBTyxTQUFTLFlBQVksR0FBRztBQUN6QyxlQUFTO0lBQ1YsV0FBVyxNQUFNLFFBQVEsWUFBWSxHQUFHO0FBRXZDLGFBQU8sT0FBTyxLQUFLLFlBQVk7SUFDaEMsT0FBTztBQUNOLGVBQVMsT0FBTyxLQUFLLGFBQWEsUUFBUSxhQUFhLFlBQVksYUFBYSxVQUFVO0lBQzNGO0FBRUEsV0FBTyxPQUFPLFNBQVMsUUFBUSxXQUFXLFNBQVksU0FBUyxTQUFTLE1BQVM7RUFDbEY7RUFFQSxXQUFXLFFBQWdCLE1BQWMsU0FBaUIsVUFBcUI7QUFDOUUsUUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUV6RixTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFVBQVUsS0FBSyxPQUFPO01BQ3RCLFNBQVM7TUFFVDtNQUNBO0tBQ0EsRUFDQSxLQUNBLE1BQUs7QUFDSixpQkFBVTtJQUNYLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFFQSxxQkFBcUIsU0FBK0I7QUFDbkQsUUFBSTtBQUNILFdBQUssS0FBSyxXQUFXLFFBQVEsU0FBUyxRQUFRLE1BQU07SUFDckQsU0FBUyxJQUFJO0lBRWI7RUFDRDtFQUNBLG1CQUFtQixPQUFZO0FBQzlCLFNBQUssU0FBUztBQUVkLFVBQU0sYUFBYSxLQUFLO0FBQ3hCLFFBQUk7QUFBWSxXQUFLLFNBQVMsd0JBQXdCLE9BQU8sV0FBVyxRQUFRO0FBRWhGLFFBQUk7QUFDSCxXQUFLLEtBQUssU0FBUyxLQUFLO0lBQ3pCLFNBQVMsSUFBSTtJQUViO0VBQ0Q7Ozs7QUM5UEssU0FBVSxrQkFBbUQsS0FBWTtBQUM5RSxRQUFNLE9BQU87QUFDYixTQUFPLENBQUMsQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxPQUFPLFlBQVksS0FBSyx1QkFBdUI7QUFDekc7OztBQzZCTSxJQUFnQixlQUFoQixNQUE0QjtFQUN4QjtFQUNBO0VBRUE7RUFFVCxJQUFXLEtBQUU7QUFDWixXQUFPLEtBQUssU0FBUztFQUN0QjtFQUVBLElBQVcsa0JBQWU7QUFDekIsV0FBTyxLQUFLO0VBQ2I7Ozs7O0VBTUEsSUFBVyxRQUFLO0FBQ2YsV0FBTyxLQUFLLFNBQVM7RUFDdEI7Ozs7RUFLQSxZQUFZLFVBQWlCO0FBQzVCLFFBQUksQ0FBQyxrQkFBNkIsUUFBUSxLQUFLLENBQUMsU0FBUztBQUN4RCxZQUFNLElBQUksTUFDVCxtR0FBbUc7QUFHckcsU0FBSyxXQUFXO0FBRWhCLFNBQUssVUFBVSxtQkFBa0I7QUFFakMsU0FBSyx3QkFBd0IsS0FBSyxzQkFBc0IsS0FBSyxJQUFJO0FBRWpFLFNBQUssV0FBVztNQUNmLDJCQUEyQjtNQUMzQix3QkFBd0I7O0FBR3pCLFNBQUssSUFBSSxTQUFTLGNBQWM7RUFDakM7RUErQkEsV0FBVyxXQUE0QyxZQUFpQztBQUN2RixTQUFLLFNBQVMsV0FBVyxXQUFXLFVBQVU7RUFDL0M7Ozs7O0VBdUJBLHFCQUFxQixTQUF5RDtBQUM3RSxTQUFLLFNBQVMscUJBQXFCLE9BQU87RUFDM0M7Ozs7O0VBTUEsdUJBQXVCLFdBQStEO0FBQ3JGLFNBQUssU0FBUyx1QkFBdUIsU0FBUztFQUMvQzs7Ozs7O0VBT0EscUJBQ0MsV0FDQSxTQUE4QztBQUU5QyxTQUFLLFNBQVMscUJBQXFCLFdBQVcsT0FBTztFQUN0RDs7Ozs7RUFNQSx1QkFBdUJDLFlBQStEO0FBQ3JGLFFBQUksTUFBTSxRQUFRQSxVQUFTO0FBQUcsWUFBTSxJQUFJLE1BQU0sd0RBQXdEO0FBRXRHLFNBQUssU0FBUyx1QkFBdUJBLFVBQVM7RUFDL0M7Ozs7O0VBTUEsa0JBQWtCLFFBQXVDO0FBQ3hELFNBQUssU0FBUyxrQkFBa0IsTUFBTTtFQUN2Qzs7Ozs7O0VBT0EsaUJBQW1DLFlBQWE7QUFDL0MsV0FBTyxLQUFLLFNBQVMsaUJBQWlCLFVBQVU7RUFDakQ7Ozs7RUFLQSxvQkFBaUI7QUFDaEIsU0FBSyxTQUFTLGtCQUFpQjtFQUNoQzs7Ozs7OztFQVFBLGVBQ0MsaUJBQ0csZUFBbUQ7QUFFdEQsU0FBSyxTQUFTLGVBQWUsQ0FBQyxjQUFjLEdBQUcsYUFBYSxDQUFDO0VBQzlEOzs7OztFQU1BLHNCQUFzQixhQUFxQjtBQUMxQyxTQUFLLFNBQVMsbUJBQW1CLFdBQVc7RUFDN0M7Ozs7OztFQU9BLG9CQUFvQixXQUFtQjtBQUN0QyxTQUFLLFNBQVMsaUJBQWlCLFNBQVM7RUFDekM7Ozs7OztFQU1BLHNCQUFzQixXQUFtQjtBQUN4QyxTQUFLLFNBQVMsbUJBQW1CLFNBQVM7RUFDM0M7Ozs7OztFQU9BLHdCQUF3QixhQUFxQjtBQUM1QyxTQUFLLFNBQVMscUJBQXFCLFdBQVc7RUFDL0M7Ozs7OztFQU9BLGFBQWEsUUFBaUMsY0FBcUI7QUFDbEUsU0FBSyxTQUFTLGFBQWEsUUFBUSxZQUFZO0VBQ2hEOzs7Ozs7OztFQVNBLFFBQVEsTUFBYyxNQUFjLE1BQWMsTUFBc0I7QUFDdkUsU0FBSyxTQUFTLFFBQVEsTUFBTSxNQUFNLE1BQU0sSUFBSTtFQUM3Qzs7Ozs7Ozs7Ozs7RUFZQSxhQUFhLFFBQXdCLFNBQXVCO0FBQzNELFNBQUssU0FBUyxhQUFhLFFBQVEsV0FBVyxJQUFJO0VBQ25EOzs7Ozs7RUFPQSxJQUFJLE9BQWlCLFNBQWU7QUFDbkMsWUFBUSxPQUFPO01BQ2QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxNQUFNLE9BQU87QUFDMUI7TUFDRDtBQUNDLG9CQUFZLEtBQUs7QUFDakIsYUFBSyxRQUFRLEtBQUssT0FBTztBQUN6QjtJQUNGO0VBQ0Q7RUFZQSxzQkFDQyxlQUNBLFVBQXlDO0FBRXpDLFVBQU0sVUFBa0MsT0FBTyxrQkFBa0IsV0FBVyxFQUFFLE1BQU0sY0FBYSxJQUFLO0FBRXRHLFVBQU0sU0FBUyxJQUFJLG9CQUFvQixLQUFLLFVBQVUsT0FBTztBQUM3RCxRQUFJO0FBQVUsYUFBTyxHQUFHLFdBQVcsUUFBUTtBQUUzQyxXQUFPO0VBQ1I7Ozs7QUMvVUQsSUFBWTtDQUFaLFNBQVlDLGlCQUFjO0FBQ3pCLEVBQUFBLGdCQUFBLElBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFlBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLG1CQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxXQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxjQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSxnQkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsdUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLHlCQUFBLElBQUE7QUFDRCxHQVZZLG1CQUFBLGlCQUFjLENBQUEsRUFBQTtBQWFwQixJQUFXO0NBQWpCLFNBQWlCQyxRQUFLO0FBRVIsRUFBQUEsT0FBQSxLQUFLO0FBQ0wsRUFBQUEsT0FBQSxXQUNaO0FBQ1ksRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxPQUNaO0FBQ1ksRUFBQUEsT0FBQSxjQUFjO0FBQ2QsRUFBQUEsT0FBQSxVQUFVO0FBQ1YsRUFBQUEsT0FBQSxRQUFRO0FBQ1IsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxlQUFlO0FBQ2YsRUFBQUEsT0FBQSxTQUFTO0FBQ1QsRUFBQUEsT0FBQSxnQkFBZ0I7QUFDaEIsRUFBQUEsT0FBQSxZQUFZO0FBQ1osRUFBQUEsT0FBQSxXQUNaO0FBQ0YsR0FsQmlCLFVBQUEsUUFBSyxDQUFBLEVBQUE7OztBQzZOaEIsU0FBVSwwQ0FDZixPQUEyRDtBQUczRCxNQUFJLENBQUMsU0FBUyxNQUFNO0FBQWMsV0FBTztBQUV6QyxRQUFNLFlBQVksT0FBTyxNQUFNLEtBQUs7QUFDcEMsUUFBTSxZQUFZLE1BQU07QUFDeEIsTUFDQyxPQUFPLE1BQU0sVUFBVSxZQUN0QixPQUFPLE1BQU0sVUFBVSxZQUFZLE1BQU0sTUFBTSxLQUFJLE1BQU8sTUFBTSxDQUFDLE1BQU0sU0FBUyxHQUNoRjtBQUVELFdBQU87TUFDTixjQUFjO01BQ2QsT0FBTzs7RUFFVCxXQUFXLE9BQU8sY0FBYyxVQUFVO0FBQ3pDLFVBQU0sYUFBYSxVQUFVLEtBQUk7QUFFakMsUUFBSSxXQUFXLFdBQVcsSUFBSSxLQUFLLFdBQVcsU0FBUyxHQUFHLEtBQUssQ0FBQyxXQUFXLE1BQU0sQ0FBQyxFQUFFLFNBQVMsSUFBSSxHQUFHO0FBRW5HLGFBQU87UUFDTixjQUFjO1FBQ2QsT0FBTzs7SUFFVCxPQUFPO0FBRU4sYUFBTztRQUNOLGNBQWM7UUFDZCxPQUFPLG1CQUFtQixVQUFVLFFBQVEsT0FBTyxNQUFNLEVBQUUsUUFBUSxNQUFNLEtBQUssQ0FBQzs7SUFFakY7RUFDRCxPQUFPO0FBR04sV0FBTztFQUNSO0FBQ0Q7OztBQ3BSQSxnQkFBMkI7QUFDM0IsU0FBUyxnQkFBQUMscUJBQW9COzs7QUNEN0IsSUFBTSxZQUFZO0FBQ2xCLElBQU0sYUFBYTtBQUVuQixJQUFNLG9CQUFvQixvQkFBSSxJQUFvQjtFQUNqRCxDQUFDLFdBQVcsR0FBSTtFQUNoQixDQUFDLFVBQVUsR0FBSTtFQUNmLENBQUMsY0FBYyxHQUFJO0VBQ25CLENBQUMsTUFBTSxHQUFJO0VBQ1gsQ0FBQyxXQUFXLEdBQUk7RUFDaEIsQ0FBQyxtQkFBbUIsR0FBSTtFQUN4QixDQUFDLFNBQVMsR0FBSTtFQUNkLENBQUMsU0FBUyxHQUFJO0VBQ2QsQ0FBQyxPQUFPLEdBQUk7RUFDWixDQUFDLFlBQVksR0FBSTtFQUNqQixDQUFDLFVBQVUsR0FBSTtFQUNmLENBQUMsUUFBUSxHQUFJO0VBQ2IsQ0FBQyxhQUFhLEdBQUk7RUFDbEIsQ0FBQyxTQUFTLEdBQUk7RUFDZCxDQUFDLFNBQVMsR0FBSTtFQUNkLENBQUMsWUFBWSxHQUFJO0VBQ2pCLENBQUMsUUFBUSxHQUFJO0VBQ2IsQ0FBQyxlQUFlLEdBQUk7RUFDcEIsQ0FBQyxTQUFTLEdBQUk7Q0FDZDtBQUVELElBQU0sTUFBTSxDQUFDLFFBQWdCLEdBQUcsR0FBRyxPQUFPLElBQUksU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQWlCckUsSUFBTyxjQUFQLE1BQU8sYUFBVztFQUN2QixLQUFLO0VBQ0w7RUFDQSxPQUFPLFFBQWtCO0lBQ3hCLE9BQU8sQ0FBQTtJQUNQLFFBQVE7SUFDUixTQUFTO0lBQ1QsTUFBTTtJQUNOLE1BQU07SUFDTixVQUFVO0lBQ1YsWUFBWTtJQUNaLFVBQVU7SUFDVixPQUFPO0lBQ1AsU0FBUztJQUNULE1BQU07O0VBR1AsWUFBWSxRQUFrQixDQUFBLEdBQUU7QUFDL0IsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLFNBQU07QUFDVCxXQUFPLEtBQUssTUFBTSxDQUFDLElBQUksTUFBTyxLQUFLLE1BQU0sQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLElBQUk7RUFDL0Q7RUFDQSxJQUFJLE9BQU8sR0FBUztBQUNuQixTQUFLLE1BQU0sQ0FBQyxJQUFJLElBQUksTUFBTyxJQUFLLEtBQUssTUFBTSxDQUFDLElBQUksS0FBUyxJQUFJO0VBQzlEO0VBRUEsSUFBSSxVQUFPO0FBQ1YsWUFBUSxLQUFLLE1BQU0sQ0FBQyxJQUFJLE1BQVE7RUFDakM7RUFDQSxJQUFJLFFBQVEsR0FBUztBQUNwQjtBQUNBLFFBQUksYUFBWSxVQUFVLEdBQUcsRUFBRTtBQUMvQixTQUFLLE1BQU0sQ0FBQyxJQUFLLEtBQUssTUFBTSxDQUFDLElBQUksTUFBUyxJQUFJO0VBQy9DO0VBRUEsSUFBYyxRQUFLO0FBQ2xCLFdBQU8sS0FBSyxNQUFNLENBQUMsSUFBSTtFQUN4QjtFQUNBLElBQWMsTUFBTSxHQUFTO0FBQzVCLFNBQUssTUFBTSxDQUFDLElBQUksYUFBWSxVQUFVLEdBQUcsU0FBUztFQUNuRDtFQUVBLElBQWMsUUFBSztBQUNsQixXQUFPLEtBQUssTUFBTSxDQUFDLElBQUk7RUFDeEI7RUFDQSxJQUFjLE1BQU0sR0FBUztBQUM1QixTQUFLLE1BQU0sQ0FBQyxJQUFJLGFBQVksVUFBVSxHQUFHLFNBQVM7RUFDbkQ7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsT0FBTyxLQUFLLE1BQUs7RUFDM0I7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLEtBQUssRUFBRTtFQUNsQjtFQUVBLE9BQU8sVUFBVSxLQUFhLEtBQVc7QUFDeEMsUUFBSSxDQUFDLE9BQU8sU0FBUyxHQUFHO0FBQUcsYUFBTztBQUNsQyxXQUFPLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSSxJQUFJO0VBQ3hDO0VBRUEsT0FBTyxhQUFhLFFBQWtCLENBQUEsR0FBSSxNQUFnQixLQUFLLE9BQUs7QUFDbkUsUUFBSSxXQUFXLElBQUksYUFBWSxLQUFLO0FBQ3BDLFFBQUksU0FBUyxNQUFNLFNBQVMsSUFBSSxTQUFTLFNBQVMsSUFBSSxVQUFVO0FBQ2hFLFFBQUksV0FBVyxLQUFLLE9BQU8sSUFBSSxPQUFPO0FBQWEsZUFBUyxrQkFBa0IsSUFBSSxJQUFJLEVBQUUsS0FBSztBQUU3RixZQUFRLFFBQVE7TUFDZixLQUFLO0FBQ0osbUJBQVcsSUFBSSxRQUFRLElBQUksU0FBVSxJQUFJLE1BQU8sSUFBSSxRQUFTO0FBQzdEO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksT0FBTyxJQUFJLFNBQVUsSUFBSSxNQUFPLElBQUksUUFBUztBQUM1RDtNQUNELEtBQUs7QUFDSixtQkFBVyxJQUFJLFdBQVcsSUFBSSxTQUFVLElBQUksTUFBTyxJQUFJLFFBQVM7QUFDaEU7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxjQUFjLElBQUksU0FBVSxJQUFJLFlBQWEsSUFBSSxLQUFNO0FBQ3RFO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksY0FBYyxJQUFJLFNBQVUsSUFBSSxPQUFRO0FBQ3ZEO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksZ0JBQWdCLElBQUksU0FBVSxJQUFJLFFBQVM7QUFDMUQ7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxXQUFXLElBQUksU0FBVSxJQUFJLEtBQU07QUFDbEQ7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxNQUFNLElBQUksS0FBTTtBQUMvQjtNQUNELEtBQUs7QUFDSixtQkFBVyxJQUFJLElBQUksSUFBSSxNQUFPLElBQUksS0FBTTtBQUN4QztNQUNELEtBQUs7QUFDSjs7TUFDRDtBQUNDLGdCQUFRLElBQUksc0NBQXNDLElBQUksTUFBTSxDQUFDLEVBQUU7QUFDL0Q7SUFDRjtBQUVBLFFBQUksTUFBTSxTQUFTO0FBQUcsZUFBUyxRQUFRO0FBQ3ZDLFdBQU87RUFDUjs7QUFHRCxJQUFNLFVBQU4sY0FBc0IsWUFBVztFQUNoQyxZQUFZLEdBQVcsR0FBVyxHQUFTO0FBQzFDLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLE9BQU87QUFDWixTQUFLLFdBQVc7RUFDakI7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEtBQUs7RUFDYjtFQUNBLElBQUksS0FBSyxHQUFTO0FBQ2pCLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxXQUFRO0FBQ1gsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLFNBQVMsR0FBUztBQUNyQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxTQUFTLEtBQUssU0FBUyxNQUFNLEtBQUssTUFBTSxVQUFVLEtBQUssU0FBUTtFQUN6RTtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsY0FBYyxJQUFJLEtBQUssT0FBTyxDQUFDLFdBQVcsSUFBSSxLQUFLLElBQUksQ0FBQyxlQUFlLElBQ2hHLEtBQUssUUFBUSxDQUNiO0VBQ0Y7O0FBR0QsSUFBTSxTQUFOLGNBQXFCLFFBQU87RUFDM0IsWUFBWSxHQUFXLEdBQVcsR0FBUztBQUMxQyxVQUFNLEdBQUcsR0FBRyxDQUFDO0FBQ2IsU0FBSyxLQUFLO0FBQ1YsU0FBSyxTQUFTO0VBQ2Y7O0FBR0QsSUFBTSxhQUFOLGNBQXlCLFlBQVc7RUFDbkMsWUFBWSxHQUFXLEdBQVcsR0FBUztBQUMxQyxVQUFLO0FBQ0wsU0FBSyxLQUFLO0FBQ1YsU0FBSyxTQUFTO0FBQ2QsU0FBSyxVQUFVO0FBQ2YsU0FBSyxPQUFPO0FBQ1osU0FBSyxXQUFXO0VBQ2pCO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLEtBQUssR0FBUztBQUNqQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksV0FBUTtBQUNYLFdBQU8sS0FBSztFQUNiO0VBQ0EsSUFBSSxTQUFTLEdBQVM7QUFDckIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsTUFBTSxLQUFLLE1BQU0sVUFBVSxLQUFLLFNBQVE7RUFDekU7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxXQUFXLElBQUksS0FBSyxJQUFJLENBQUMsZUFBZSxJQUNoRyxLQUFLLFFBQVEsQ0FDYjtFQUNGOztBQUdELElBQU0sZ0JBQU4sY0FBNEIsWUFBVztFQUN0QyxZQUFZLEdBQVcsSUFBWSxHQUFTO0FBQzNDLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLGFBQWE7QUFDbEIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLGFBQVU7QUFDYixXQUFPLEtBQUs7RUFDYjtFQUNBLElBQUksV0FBVyxHQUFTO0FBQ3ZCLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxRQUFLO0FBQ1IsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLE1BQU0sR0FBUztBQUNsQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxTQUFTLEtBQUssU0FBUyxZQUFZLEtBQUssWUFBWSxPQUFPLEtBQUssTUFBSztFQUMvRTtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsY0FBYyxJQUFJLEtBQUssT0FBTyxDQUFDLGlCQUFpQixJQUFJLEtBQUssVUFBVSxDQUFDLFlBQVksSUFDekcsS0FBSyxLQUFLLENBQ1Y7RUFDRjs7QUFHRCxJQUFNLGdCQUFOLGNBQTRCLFlBQVc7RUFDdEMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssVUFBVTtFQUNoQjtFQUVBLElBQUksVUFBTztBQUNWLFdBQU8sS0FBSyxRQUFRO0VBQ3JCO0VBQ0EsSUFBSSxRQUFRLEdBQVM7QUFDcEI7QUFDQSxTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxTQUFTLEtBQUssU0FBUyxTQUFTLEtBQUssUUFBTztFQUN0RDtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsY0FBYyxJQUFJLEtBQUssT0FBTyxDQUFDLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQztFQUN6Rjs7QUFHRCxJQUFNLGtCQUFOLGNBQThCLFlBQVc7RUFDeEMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssV0FBVztFQUNqQjtFQUVBLElBQUksV0FBUTtBQUNYLFdBQU8sS0FBSztFQUNiO0VBQ0EsSUFBSSxTQUFTLEdBQVM7QUFDckIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsVUFBVSxLQUFLLFNBQVE7RUFDeEQ7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxlQUFlLElBQUksS0FBSyxRQUFRLENBQUM7RUFDM0Y7O0FBR0QsSUFBTSxhQUFOLGNBQXlCLFlBQVc7RUFDbkMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxRQUFLO0FBQ1IsWUFBUSxLQUFLLFNBQVMsS0FBSyxLQUFLO0VBQ2pDO0VBQ0EsSUFBSSxNQUFNLEdBQVM7QUFDbEIsUUFBSSxZQUFZLFVBQVUsR0FBRyxVQUFVO0FBQ3ZDLFNBQUssUUFBUyxLQUFLLElBQUs7QUFDeEIsU0FBSyxRQUFRLElBQUk7RUFDbEI7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsT0FBTyxLQUFLLE1BQUs7RUFDbEQ7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxZQUFZLElBQUksS0FBSyxLQUFLLENBQUM7RUFDckY7O0FBR0QsSUFBTSxRQUFOLGNBQW9CLFlBQVc7RUFDOUIsWUFBWSxHQUFXO0FBQ3RCLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxPQUFPLEtBQUssTUFBSztFQUMzQjtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsWUFBWSxLQUFLLEtBQUs7RUFDakQ7O0FBR0ssSUFBTyxNQUFQLGNBQW1CLFlBQVc7RUFDbkMsWUFBWSxHQUFXLEdBQVM7QUFDL0IsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssT0FBTztBQUNaLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBUSxLQUFLLFNBQVMsSUFBSztFQUM1QjtFQUNBLElBQUksS0FBSyxHQUFTO0FBQ2pCLFNBQUssUUFBUyxLQUFLLFFBQVEsS0FBUyxLQUFLO0VBQzFDO0VBRUEsSUFBSSxRQUFLO0FBQ1IsV0FBTyxLQUFLLFFBQVE7RUFDckI7RUFDQSxJQUFJLE1BQU0sR0FBUztBQUNsQixRQUFJLFlBQVksVUFBVSxHQUFHLEVBQUU7QUFDL0IsU0FBSyxRQUFTLEtBQUssUUFBUSxNQUFRO0VBQ3BDO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLE1BQU0sS0FBSyxNQUFNLE9BQU8sS0FBSyxNQUFLO0VBQ25FO0VBRUEsV0FBUTtBQUNQLFdBQU8sR0FBRyxNQUFNLFNBQVEsQ0FBRSxXQUFXLElBQUksS0FBSyxJQUFJLENBQUMsWUFBWSxJQUFJLEtBQUssS0FBSyxDQUFDO0VBQy9FOzs7O0FEaFlLLElBQU9DLFNBQVAsY0FBcUJDLGNBQVk7RUFDOUI7RUFDQTtFQUNEO0VBRVAsWUFBWSxNQUFjLFNBQWlCO0FBQzFDLFVBQUs7QUFDTCxTQUFLLFNBQVMsSUFBYyxnQkFBSztBQUNqQyxTQUFLLE9BQU8sWUFBWSxPQUFPLE9BQU8sS0FBSztBQUMzQyxTQUFLLFNBQVMsQ0FBQTtBQUNkLFNBQUssT0FBTztBQUNaLFVBQU0seUJBQW1DLFVBQVM7QUFFbEQsUUFBSSxTQUFTO0FBQ1osV0FBSyxPQUFPLGdCQUFnQixJQUFJO0lBQ2pDLE9BQU87QUFDTixZQUFNLFlBQVksS0FBSyxPQUFPLGFBQVk7QUFDMUMsZUFBUyxJQUFJLEdBQUcsSUFBSSxXQUFXLEtBQUs7QUFDbkMsWUFBSSxTQUFTLHVCQUF1QixDQUFDLEdBQUc7QUFDdkMsY0FBSTtBQUNILGlCQUFLLE9BQU8sU0FBUyxDQUFDO1VBQ3ZCLFNBQVMsS0FBSztBQUNiLG9CQUFRLElBQUksc0JBQXNCLElBQUk7U0FBYSxHQUFHLEVBQUU7VUFDekQ7UUFDRDtNQUNEO0lBQ0Q7QUFFQSxTQUFLLE9BQU8sR0FBRyxXQUFXLENBQUMsV0FBbUIsVUFBeUI7QUFHdEUsWUFBTSxNQUFNLFlBQVksYUFBYSxLQUFLO0FBQzFDLFVBQUksUUFBUTtBQUFXO0FBQ3ZCLFdBQUssS0FBSyxXQUFXLFdBQVcsR0FBRztBQUNuQyxVQUFJLElBQUksTUFBTSxPQUFPO0FBQ3BCLGFBQUssU0FBUyxHQUFVO01BQ3pCO0lBQ0QsQ0FBQztFQUNGO0VBRUEsUUFBSztBQUNKLFNBQUssT0FBTyxVQUFTO0FBQ3JCLFNBQUssT0FBTyxRQUFPO0VBQ3BCO0VBRUEsYUFBVTtBQUNULFdBQU8sS0FBSyxPQUFPLFdBQVU7RUFDOUI7RUFFQSxTQUFTLE1BQVM7QUFDakIsVUFBTSxjQUFjLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRTtBQUN0QyxVQUFNLGFBQXFCLEtBQUs7QUFDaEMsUUFBSSxRQUFnQixLQUFLO0FBQ3pCLFFBQUk7QUFFSixTQUFLLE9BQU8sVUFBVSxJQUFJO0FBRzFCLFFBQUksZUFBZSxLQUFLLE9BQU8sS0FBSyxPQUFPLENBQUMsTUFBTSxVQUFVO0FBQzNELFlBQU0sT0FBaUIsQ0FBQTtBQUN2QixlQUFTLElBQUksR0FBRyxLQUFLLEdBQUcsS0FBSztBQUM1QixjQUFNLE1BQU0sUUFBUyxLQUFLLElBQUssSUFBSTtBQUNuQyxhQUFLLEtBQUssR0FBRztNQUNkO0FBQ0EsY0FBUSxLQUFLLENBQUM7QUFDZCx1QkFBaUIsYUFBYSxLQUFLLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQ3JELFdBQUssT0FBTyxVQUFVLElBQUk7QUFFMUIsWUFBTSxRQUFRLEtBQUs7QUFDbkIsWUFBTSxtQkFDSCxNQUFNLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxHQUFHLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRyxJQUN2RCxRQUNFLE1BQU0sQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDLEdBQUcsU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHLElBQ3ZELFFBQ0UsTUFBTSxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsR0FBRyxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUcsSUFDdkQsUUFDRSxNQUFNLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxHQUFHLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRztBQUN4RCxXQUFLLEtBQUssU0FBUztRQUNsQixPQUFPO1FBQ1AsU0FBUztPQUNUO0lBQ0Y7RUFDRDs7QUFHSyxJQUFPQyxVQUFQLE1BQWE7RUFDVjtFQUNEO0VBRVAsWUFBWSxNQUFjLFNBQWlCO0FBQzFDLFNBQUssVUFBVSxJQUFjLGlCQUFNO0FBQ25DLFNBQUssT0FBTztBQUNaLFVBQU0sMEJBQW9DLFdBQVU7QUFFcEQsUUFBSSxTQUFTO0FBQ1osV0FBSyxRQUFRLGdCQUFnQixJQUFJO0lBQ2xDLE9BQU87QUFDTixZQUFNLGFBQWEsS0FBSyxRQUFRLGFBQVk7QUFDNUMsZUFBUyxJQUFJLEdBQUcsSUFBSSxZQUFZLEtBQUs7QUFDcEMsWUFBSSxTQUFTLHdCQUF3QixDQUFDLEdBQUc7QUFDeEMsY0FBSTtBQUNILGlCQUFLLFFBQVEsU0FBUyxDQUFDO1VBQ3hCLFNBQVMsS0FBSztBQUNiLG9CQUFRLElBQUksc0JBQXNCLElBQUk7U0FBYSxHQUFHLEVBQUU7VUFDekQ7UUFDRDtNQUNEO0lBQ0Q7RUFDRDtFQUVBLFFBQUs7QUFDSixTQUFLLFFBQVEsVUFBUztBQUN0QixTQUFLLFFBQVEsUUFBTztFQUNyQjtFQUVBLGFBQVU7QUFDVCxXQUFPLEtBQUssUUFBUSxXQUFVO0VBQy9CO0VBRUEsS0FBSyxLQUFnQjtBQUNwQixTQUFLLFFBQVEsWUFBWSxJQUFJLEtBQUs7RUFDbkM7O0FBSUssU0FBVSxZQUFTO0FBQ3hCLFFBQU0sUUFBUSxJQUFjLGdCQUFLO0FBQ2pDLFFBQU0sU0FBbUIsQ0FBQTtBQUN6QixXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sYUFBWSxHQUFJLEtBQUs7QUFDOUMsUUFBSSxVQUFVO0FBQ2QsVUFBTSxXQUFXLE1BQU0sWUFBWSxDQUFDO0FBQ3BDLFFBQUksbUJBQW1CO0FBQ3ZCLFdBQU8sT0FBTyxTQUFTLGdCQUFnQixHQUFHO0FBQ3pDO0FBQ0EsMEJBQW9CLElBQUksT0FBTztJQUNoQztBQUNBLFdBQU8sS0FBSyxnQkFBZ0I7RUFDN0I7QUFDQSxRQUFNLFVBQVM7QUFDZixTQUFPO0FBQ1I7QUFFTSxTQUFVLGFBQVU7QUFDekIsUUFBTSxTQUFTLElBQWMsaUJBQU07QUFDbkMsUUFBTSxVQUFvQixDQUFBO0FBQzFCLFdBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxhQUFZLEdBQUksS0FBSztBQUMvQyxRQUFJLFVBQVU7QUFDZCxVQUFNLFdBQVcsT0FBTyxZQUFZLENBQUM7QUFDckMsUUFBSSxtQkFBbUI7QUFDdkIsV0FBTyxRQUFRLFNBQVMsZ0JBQWdCLEdBQUc7QUFDMUM7QUFDQSwwQkFBb0IsSUFBSSxPQUFPO0lBQ2hDO0FBQ0EsWUFBUSxLQUFLLGdCQUFnQjtFQUM5QjtBQUNBLFNBQU8sVUFBUztBQUNoQixTQUFPO0FBQ1I7OztBRW5KTSxTQUFVLGtCQUFlO0FBQzlCLFFBQU0sY0FBZ0MsQ0FBQTtBQUN0QyxRQUFNLGVBQWlDLENBQUE7QUFDdkMsUUFBTSxVQUFvQixVQUFTO0FBQ25DLFFBQU0sV0FBcUIsV0FBVTtBQUNyQyxVQUFRLFFBQVEsQ0FBQyxNQUFLO0FBQ3JCLGdCQUFZLEtBQUssRUFBRSxJQUFJLEdBQUcsT0FBTyxFQUFDLENBQUU7RUFDckMsQ0FBQztBQUNELFdBQVMsUUFBUSxDQUFDLE1BQUs7QUFDdEIsaUJBQWEsS0FBSyxFQUFFLElBQUksR0FBRyxPQUFPLEVBQUMsQ0FBRTtFQUN0QyxDQUFDO0FBRUQsU0FBTztJQUNOO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsUUFBUSxDQUFDLEtBQUs7TUFDdkIsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFvQlY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUFPO01BQ1AsU0FBUyxTQUFTLENBQUMsS0FBSztNQUN4QixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUEyQlY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTztNQUNQLFNBQVM7O0lBRVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxTQUFTO01BQ1QsT0FBTztNQUNQLFNBQVM7O0lBRVY7TUFDQyxNQUFNO01BQ04sSUFBSTtNQUNKLE9BQU87TUFDUCxPQUNDO01BQ0QsU0FBUztNQUNULE9BQU87OztBQUdWOzs7QUNuR0EsSUFBTSxZQUFvRDtFQUN6RCxRQUFRLEVBQUUsTUFBTSw4QkFBNkI7RUFDN0MsU0FBUyxFQUFFLE1BQU0sOEJBQTZCO0VBQzlDLGFBQWEsRUFBRSxNQUFNLHdCQUF1QjtFQUM1QyxPQUFPLEVBQUUsTUFBTSxvQkFBbUI7RUFDbEMsU0FBUyxFQUFFLE1BQU0sNEJBQTJCO0VBQzVDLFlBQVksRUFBRSxNQUFNLHNCQUFxQjs7QUFHMUMsSUFBTSxhQUFnRSxvQkFBSSxJQUFHO0FBRXZFLFNBQVUsMEJBQTBCLE1BQW9CO0FBQzdELE9BQUssdUJBQXVCLFNBQVM7QUFDckMsT0FBSyxrQkFBa0IsRUFBRSxRQUFRLE9BQU8sU0FBUyxNQUFLLENBQUU7QUFDekQ7QUFFTSxTQUFVLHFCQUFxQixNQUFzQixVQUFnQjtBQUMxRSxNQUFJLElBQUksV0FBVyxJQUFJLFFBQVEsS0FBSztBQUNwQyxNQUFJLE1BQU07QUFBTSxpQkFBYSxDQUFDO0FBQzlCLE1BQUksV0FBVyxNQUFLO0FBQ25CLFNBQUssa0JBQWtCLEVBQUUsQ0FBQyxRQUFRLEdBQUcsTUFBSyxDQUFFO0FBQzVDLFNBQUssZUFBZSxRQUFRO0VBQzdCLEdBQUcsR0FBRztBQUNOLGFBQVcsSUFBSSxVQUFVLENBQUM7QUFDMUIsT0FBSyxrQkFBa0IsRUFBRSxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUU7QUFDM0MsT0FBSyxlQUFlLFFBQVE7QUFDN0I7QUFFTSxTQUFVLGNBQWMsTUFBc0IsS0FBa0IsTUFBd0I7QUFDN0YsUUFBTSxVQUFVLGNBQWMsR0FBRztBQUNqQyxRQUFNLFVBQVUsUUFBUSxPQUFPLE1BQU07QUFDckMsT0FBSyxrQkFBa0IsRUFBRSxhQUFhLFFBQU8sQ0FBRTtBQUUvQyxpQkFBZSxNQUFNLGVBQWUsOEJBQThCLElBQUksRUFBRTtBQUV4RSxNQUFJLElBQUksTUFBTSxZQUFZLElBQUksTUFBTSxXQUFXO0FBQzlDLFVBQU0sZUFBZSxJQUFJLFVBQVU7QUFDbkMsU0FBSyxXQUFXLFlBQVksTUFBTSxDQUFBO0FBQ2xDLFNBQUssV0FBVyxZQUFZLEVBQUUsSUFBSSxLQUFLLElBQUssSUFBSSxJQUFJLE1BQU0sWUFBWSxPQUFRO0FBQzlFLFNBQUssa0JBQWtCLEVBQUUsWUFBWSxnQkFBZ0IsS0FBSyxVQUFVLEVBQUMsQ0FBRTtFQUN4RTtBQUVBLFdBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLLFFBQVEsS0FBSztBQUM3QyxVQUFNLFVBQVUsUUFBUSxLQUFLLENBQUM7QUFDOUIsVUFBTSxNQUFNO0FBQ1osVUFBTSxhQUFhLFFBQVEsQ0FBQyxFQUFFLFlBQVcsSUFBSyxRQUFRLE1BQU0sQ0FBQztBQUM3RCxtQkFBZSxNQUFNLFNBQVMsWUFBWSxVQUFVLGFBQWEsYUFBYSxPQUFPLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztFQUNwRztBQUNEO0FBRU0sU0FBVSxhQUFhLE1BQXNCLEtBQWtCLE1BQXdCO0FBRTVGLGlCQUFlLE1BQU0sTUFBTSxjQUFjLEdBQUcsRUFBRSxNQUFNLHlCQUF5QixJQUFJO0FBQ2xGO0FBRUEsU0FBUyxjQUFjLEtBQWdCO0FBR3RDLE1BQUksVUFBVSxJQUFJO0FBQ2xCLFFBQU0sVUFBVSxPQUFPLEtBQUssSUFBSSxJQUFJO0FBQ3BDLFdBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxTQUFTLEdBQUcsS0FBSztBQUM1QyxVQUFNLE1BQU0sUUFBUSxDQUFDO0FBQ3JCLFVBQU0sTUFBMEIsT0FBTyxJQUFJLEtBQUssR0FBRyxDQUFDO0FBQ3BELFFBQUksUUFBUSxRQUFXO0FBQ3RCLGlCQUFXLElBQUksR0FBRztJQUNuQjtFQUNEO0FBQ0EsU0FBTyxFQUFFLE1BQU0sU0FBUyxNQUFNLFFBQU87QUFDdEM7QUFFQSxTQUFTLGVBQ1IsTUFDQSxTQUNBLFVBQ0EsTUFBaUM7QUFFakM7QUFBRSxZQUErQyxPQUFPLElBQUksRUFBRSxNQUFNLFNBQVE7QUFDNUUsT0FBSyx1QkFBdUIsU0FBUztBQUNyQyxPQUFLLGtCQUFrQixFQUFFLENBQUMsT0FBTyxHQUFHLEtBQUksQ0FBRTtBQUMzQzs7O0FDbkZPLElBQU0saUJBQStEOzs7OztFQUszRSxTQUNDLFVBQ0EsT0FBMkQ7QUFFM0QsVUFBTSxVQUFpRTtNQUN0RSxlQUFlO01BQ2YsZ0JBQWdCLENBQUE7TUFDaEIsa0JBQWtCLENBQUE7O0FBR25CLGVBQVcsS0FBSyxNQUFNLFNBQVM7QUFDOUIsVUFBSSxVQUFVO0FBQ2QsVUFBSSxFQUFFLFlBQVksYUFBYSxFQUFFLFFBQVEsV0FBVyxRQUFXO0FBQzlELGNBQU0sVUFBVSxFQUFFLFFBQVE7QUFDMUIsWUFBSSxZQUFZLFVBQWEsRUFBRSxRQUFRLFlBQVk7QUFBVyxZQUFFLFFBQVEsVUFBVTtBQUNsRixlQUFPLEVBQUUsUUFBUTtBQUNqQixrQkFBVTtNQUNYO0FBQ0EsVUFBSTtBQUFTLGdCQUFRLGVBQWUsS0FBSyxDQUFDO0lBQzNDO0FBRUEsZUFBVyxLQUFLLE1BQU0sV0FBVztBQUNoQyxVQUFJLEVBQUUsY0FBYyxtQkFBbUI7QUFDdEMsY0FBTSxVQUFVLEVBQUUsUUFBUTtBQUMxQixjQUFNLFFBQVEsV0FBVyxDQUFDLFFBQVEsZUFBZSxRQUFRLFFBQVE7QUFDakUsY0FBTSxLQUFLLE9BQU8sVUFBVSxZQUFZLE9BQU8sVUFBVSxXQUFXLE9BQU8sS0FBSyxJQUFJO0FBQ3BGLFlBQUksQ0FBQztBQUFJO0FBQ1QsVUFBRSxhQUFhO0FBQ2YsZUFBTyxFQUFFLFFBQVE7QUFDakIsWUFBSTtBQUNKLGdCQUFRLEVBQUUsWUFBWTtVQUNyQixLQUFLO0FBQ0osa0JBQU07QUFDTjtVQUNELEtBQUs7QUFDSixrQkFBTTtBQUNOO1VBQ0QsS0FBSztBQUNKLGtCQUFNO0FBQ047UUFDRjtBQUNBLFlBQUksT0FBTyxFQUFFLFFBQVEsR0FBRyxNQUFNLFFBQVc7QUFDeEMsWUFBRSxRQUFRLFFBQVEsV0FBVyxZQUFZLFFBQVEsWUFBWSxVQUFVLE9BQU8sSUFBSSxFQUFFLFFBQVEsR0FBRztBQUMvRixpQkFBTyxFQUFFLFFBQVEsR0FBRztRQUNyQjtBQUNBLGdCQUFRLGlCQUFpQixLQUFLLENBQUM7TUFDaEM7SUFDRDtBQUVBLFdBQU87RUFDUjtFQUVBLFNBQ0MsVUFDQSxPQUEyRDtBQUUzRCxVQUFNLFVBQWlFO01BQ3RFLGVBQWU7TUFDZixnQkFBZ0IsQ0FBQTtNQUNoQixrQkFBa0IsQ0FBQTs7QUFHbkIsZUFBVyxLQUFLLE1BQU0sU0FBUztBQUM5QixVQUFJLEVBQUUsYUFBYTtBQUFTO0FBQzVCLFVBQUksVUFBVTtBQUVkLFVBQUksQ0FBQyxFQUFFLFFBQVEsY0FBYztBQUM1QixVQUFFLFFBQVEsZUFBZSxFQUFFLGNBQWMsT0FBTyxPQUFPLE1BQUs7QUFDNUQsa0JBQVU7TUFDWDtBQUNBLFVBQUksQ0FBQyxFQUFFLFFBQVEsZ0JBQWdCO0FBQzlCLFVBQUUsUUFBUSxpQkFBaUIsRUFBRSxjQUFjLE9BQU8sT0FBTyxFQUFDO0FBQzFELGtCQUFVO01BQ1g7QUFDQSxVQUFJLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDcEIsVUFBRSxRQUFRLE9BQU8sRUFBRSxjQUFjLE9BQU8sT0FBTyxFQUFDO0FBQ2hELGtCQUFVO01BQ1g7QUFDQSxVQUFJLENBQUMsRUFBRSxRQUFRLE9BQU87QUFDckIsVUFBRSxRQUFRLFFBQVEsRUFBRSxjQUFjLE9BQU8sT0FBTyxTQUFRO0FBQ3hELGtCQUFVO01BQ1g7QUFFQSxVQUFJO0FBQVMsZ0JBQVEsZUFBZSxLQUFLLENBQUM7SUFDM0M7QUFFQSxXQUFPO0VBQ1I7RUFDQSxTQUNDLFNBQ0EsT0FBMkQ7QUFFM0QsVUFBTSxVQUFpRTtNQUN0RSxlQUFlO01BQ2YsZ0JBQWdCLENBQUE7TUFDaEIsa0JBQWtCLENBQUE7O0FBRW5CLFFBQUksdUJBQXVCO0FBRTNCLGVBQVcsVUFBVSxNQUFNLFNBQVM7QUFDbkMsVUFBSSxPQUFPLFFBQVEsY0FBYyxVQUFVO0FBQU07QUFDakQsWUFBTSxRQUNMLE9BQU8sYUFBYSxZQUNqQixZQUNBLE9BQU8sYUFBYSxVQUNuQixVQUNBLE9BQU8sYUFBYSxZQUFZLE9BQU8sYUFBYSxZQUNuRCxhQUNBO0FBQ04saUJBQVcsQ0FBQyxRQUFRLE1BQU0sS0FBSztRQUM5QixDQUFDLFdBQVcsU0FBUztRQUNyQixDQUFDLGFBQWEsTUFBTTtRQUNwQixDQUFDLFdBQVcsWUFBWTtRQUN4QixDQUFDLFlBQVksS0FBSztTQUNoQjtBQUNGLGNBQU0sUUFBUSxPQUFPLFFBQVEsTUFBTTtBQUNuQyxZQUFJLFVBQVU7QUFBVyxpQkFBTyxRQUFRLE1BQU0sSUFBSSwwQ0FBMEMsS0FBSztBQUNqRyxlQUFPLE9BQU8sUUFBUSxNQUFNO01BQzdCO0FBQ0EsYUFBTyxPQUFPLFFBQVE7QUFDdEIsY0FBUSxlQUFlLEtBQUssTUFBTTtJQUNuQztBQUVBLGVBQVcsWUFBWSxNQUFNLFdBQVc7QUFDdkMsVUFBSSxTQUFTLFFBQVEsV0FBVyxVQUFVO0FBQU0sK0JBQXVCO0FBQ3ZFLFVBQUksU0FBUyxRQUFRLGNBQWMsVUFBVTtBQUFNO0FBQ25ELFlBQU0sUUFDTCxTQUFTLGVBQWUsWUFDckIsWUFDQSxTQUFTLGVBQWUsVUFDdkIsVUFDQSxTQUFTLGVBQWUsWUFBWSxTQUFTLGVBQWUsWUFDM0QsYUFDQTtBQUNOLGlCQUFXLENBQUMsUUFBUSxNQUFNLEtBQUs7UUFDOUIsQ0FBQyxXQUFXLFNBQVM7UUFDckIsQ0FBQyxhQUFhLE1BQU07UUFDcEIsQ0FBQyxXQUFXLFlBQVk7UUFDeEIsQ0FBQyxZQUFZLEtBQUs7U0FDaEI7QUFDRixjQUFNLFFBQVEsU0FBUyxRQUFRLE1BQU07QUFDckMsWUFBSSxVQUFVO0FBQVcsbUJBQVMsUUFBUSxNQUFNLElBQUksMENBQTBDLEtBQUs7QUFDbkcsZUFBTyxTQUFTLFFBQVEsTUFBTTtNQUMvQjtBQUNBLGFBQU8sU0FBUyxRQUFRO0FBQ3hCLGNBQVEsaUJBQWlCLEtBQUssUUFBUTtJQUN2QztBQUVBLFFBQUksd0JBQXdCLENBQUMsUUFBUSxjQUFjLGdCQUFnQjtBQUNsRSxjQUFRLGdCQUFnQixFQUFFLEdBQUcsUUFBUSxlQUFlLGdCQUFnQixLQUFJO0lBQ3pFO0FBQ0EsV0FBTztFQUNSOzs7O0FDekpNLElBQU0sZUFBOEI7RUFDMUM7SUFDQyxJQUFJO0lBQ0osT0FBTztJQUNQLE1BQU07SUFDTixPQUFPO0lBQ1AsVUFBVTtJQUNWLFFBQVE7SUFDUixRQUFRO0lBQ1IsWUFBWTs7RUFFYjtJQUNDLElBQUk7SUFDSixPQUFPO0lBQ1AsTUFBTTtJQUNOLE9BQU87SUFDUCxVQUFVO0lBQ1YsUUFBUTtJQUNSLFFBQVE7SUFDUixZQUFZOzs7RUFHYjtJQUNDLElBQUk7SUFDSixPQUFPO0lBQ1AsTUFBTTtJQUNOLE9BQU87SUFDUCxVQUFVO0lBQ1YsUUFBUTtJQUNSLFFBQVE7SUFDUixZQUFZOztFQUViO0lBQ0MsSUFBSTtJQUNKLE9BQU87SUFDUCxNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVU7SUFDVixRQUFRO0lBQ1IsUUFBUTtJQUNSLFlBQVk7OztFQUdiO0lBQ0MsSUFBSTtJQUNKLE9BQU87SUFDUCxNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVU7SUFDVixRQUFRO0lBQ1IsUUFBUTtJQUNSLFlBQVk7O0VBRWI7SUFDQyxJQUFJO0lBQ0osT0FBTztJQUNQLE1BQU07SUFDTixPQUFPO0lBQ1AsVUFBVTtJQUNWLFFBQVE7SUFDUixRQUFRO0lBQ1IsWUFBWTs7Ozs7Ozs7Ozs7Ozs7QUFpQlIsU0FBVSxjQUFjLFNBQXNCLFFBQW1CO0FBQ3RFLE1BQUksQ0FBQyxXQUFXLFVBQVUsTUFBTSxXQUFXLE9BQU8sRUFBRSxTQUFTLE9BQU8sRUFBRSxHQUFHO0FBQ3hFLFlBQVEsS0FBSztNQUNaLElBQUk7TUFDSixNQUFNO01BQ04sT0FBTztNQUNQLFNBQVM7TUFDVCxLQUFLO01BQ0wsS0FBSztLQUNMO0VBQ0Y7QUFDQSxNQUFJLENBQUMsV0FBVyxRQUFRLEVBQUUsU0FBUyxPQUFPLEVBQUUsR0FBRztBQUM5QyxZQUFRLEtBQUs7TUFDWixJQUFJO01BQ0osTUFBTTtNQUNOLE9BQU87TUFDUCxTQUFTO01BQ1QsS0FBSztNQUNMLEtBQUs7S0FDTDtFQUNGO0FBQ0EsTUFBSSxPQUFPLE1BQU0sTUFBTTtBQUN0QixZQUFRLEtBQUs7TUFDWixJQUFJO01BQ0osTUFBTTtNQUNOLE9BQU87TUFDUCxTQUFTO01BQ1QsS0FBSztNQUNMLEtBQUs7S0FDTDtFQUNGO0FBQ0EsTUFBSSxPQUFPLE1BQU0sU0FBUztBQUN6QixZQUFRLEtBQUs7TUFDWixJQUFJLE9BQU87TUFDWCxNQUFNO01BQ04sT0FBTyxPQUFPO01BQ2QsU0FBUyxPQUFPO01BQ2hCLEtBQUssT0FBTztNQUNaLEtBQUssT0FBTztLQUNaO0VBQ0YsT0FBTztBQUNOLFlBQVEsS0FBSztNQUNaLElBQUk7TUFDSixNQUFNO01BQ04sT0FBTyxPQUFPO01BQ2QsU0FDQztNQUNELFNBQVM7TUFDVCxjQUFjO0tBQ2Q7RUFDRjtBQUVBLFNBQU87QUFDUjs7O0FDMUlNLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxPQUFLLGtCQUFrQixFQUFFLFNBQVMsTUFBSyxDQUFFO0FBRXpDLFFBQU0sVUFBc0MsQ0FBQTtBQUM1QyxhQUFXLFVBQVUsY0FBYztBQUNsQyxVQUFNLFlBQXVDO01BQzVDLE1BQU0sT0FBTyxPQUFPLEtBQUs7TUFDekIsU0FBUyxjQUFjLENBQUEsR0FBSSxNQUFNO01BQ2pDLFVBQVUsT0FBTyxVQUF3QjtBQUN4QyxjQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU8sQ0FBQztBQUVyRCxZQUFJLENBQUMsS0FBSyxPQUFPLG9CQUFvQixDQUFDLEtBQUssV0FBVyxXQUFVLEdBQUk7QUFDbkUsZUFBSyxJQUFJLFNBQVMsZ0JBQWdCLEtBQUssV0FBVyxJQUFJLGFBQWE7QUFDbkU7UUFDRDtBQUVBLFlBQUksT0FBTyxNQUFNLFNBQVM7QUFDekIsZ0JBQU0sY0FBYyxPQUFPLEtBQUssT0FBTyxLQUFLLEtBQUssRUFBRTtBQUNuRCxnQkFBTSxRQUFRLFlBQ1osS0FBSSxFQUNKLE1BQU0sUUFBUSxFQUNkLE9BQU8sT0FBTyxFQUNkLElBQUksQ0FBQyxNQUFlLE9BQU8sS0FBSyxDQUFDLElBQUksT0FBTyxTQUFTLEVBQUUsTUFBTSxDQUFDLEdBQUcsRUFBRSxJQUFJLE9BQU8sQ0FBQyxDQUFFO0FBQ25GLGNBQ0MsTUFBTSxLQUFLLENBQUMsU0FBaUIsQ0FBQyxPQUFPLFVBQVUsSUFBSSxLQUFLLE9BQU8sS0FBSyxPQUFPLEdBQUcsS0FDOUUsTUFBTSxDQUFDLE1BQU0sT0FDYixNQUFNLEdBQUcsRUFBRSxNQUFNLEtBQ2hCO0FBQ0QsaUJBQUssSUFDSixRQUNBLGdHQUFnRztBQUVqRztVQUNEO0FBQ0EsZUFBSyxRQUFRO1FBQ2Q7QUFFQSxZQUFJLEtBQUssVUFBVTtBQUNsQixlQUFLLE9BQU8sS0FBSyxJQUFJLE9BQU8sS0FBSyxRQUFRO0FBQ3pDLGNBQUksQ0FBQyxPQUFPLFNBQVMsS0FBSyxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ3pDLGlCQUFLLElBQUksUUFBUSw2QkFBNkI7QUFDOUM7VUFDRDtRQUNEO0FBRUEsWUFBSSxNQUFNLFlBQVksYUFBYSxRQUFXLEVBQUUsSUFBSSxPQUFPLElBQUksR0FBRyxLQUFJLENBQUU7QUFDeEUsWUFBSSxDQUFDO0FBQUs7QUFDVixZQUFJLEtBQUssVUFBVTtBQUNsQixnQkFBTSxNQUFNLEtBQUssaUJBQWlCLEdBQUc7QUFDckMsY0FBSSxRQUFRLFFBQVc7QUFDdEIsaUJBQUssSUFBSSxRQUFRLCtEQUErRDtBQUNoRjtVQUNEO0FBQ0EsZUFBSyxPQUFPLEtBQUssSUFBSSxNQUFNLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDO1FBQ3pEO0FBRUEsWUFBSSxLQUFLLGNBQWM7QUFFdEIsZ0JBQU0sYUFBYSxLQUFLLE9BQU87QUFDL0IsZ0JBQU0sUUFBUSxLQUFLO0FBQ25CLGdCQUFNLFNBQVM7QUFFZixjQUFJLFFBQVE7QUFDWixjQUFJLEtBQUssVUFBVTtBQUNsQixvQkFBUSxLQUFLLGlCQUFpQixHQUFHLEtBQUs7VUFDdkMsT0FBTztBQUNOLG9CQUFRLE9BQU8sS0FBSyxjQUFjO1VBQ25DO0FBRUEsY0FBSSxNQUFNLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDO0FBR3ZDLGNBQUksTUFBTSxHQUFHO0FBQ1osa0JBQU07VUFDUCxXQUFXLE1BQU0sS0FBSztBQUNyQixrQkFBTTtVQUNQO0FBR0EsY0FBSSxRQUFRLEtBQUs7VUFFakI7QUFFQSxnQkFBTSxLQUFLLEtBQUssSUFBRztBQUNuQixjQUFJLE9BQU87QUFNWCxnQkFBTSxnQkFBK0I7WUFDcEMsUUFBUSxDQUFDLE1BQXNCO1lBQy9CLFFBQVEsQ0FBQyxNQUFzQixJQUFJO1lBQ25DLFNBQVMsQ0FBQyxNQUFzQixLQUFLLElBQUksTUFBTSxJQUFJO1lBQ25ELFdBQVcsQ0FBQyxNQUF1QixJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsQ0FBQyxJQUFJOztBQUV4RixnQkFBTSxPQUE4QixjQUFjLEtBQWUsTUFBTSxDQUFDLE1BQXNCO0FBRTlGLGdCQUFNLFFBQVEsWUFBWSxNQUFLO0FBQzlCLGtCQUFNLFVBQVUsS0FBSyxJQUFHLElBQUs7QUFDN0Isa0JBQU0sSUFBSSxLQUFLLElBQUksR0FBRyxVQUFVLFVBQVU7QUFDMUMsa0JBQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFFdEQsZ0JBQUksUUFBUSxNQUFNO0FBQ2pCLG1CQUFLLE9BQU8sS0FBSyxJQUFJO0FBQ3JCLG9CQUFNLFlBQVksYUFBYSxRQUFXLEVBQUUsSUFBSSxPQUFPLElBQUksR0FBRyxLQUFJLENBQUU7QUFDcEUsbUJBQUssSUFBSSxTQUFTLGFBQWEsR0FBRyxRQUFRLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFDakUsa0JBQUk7QUFBSyxxQkFBSyxXQUFXLEtBQUssR0FBRztBQUNqQyxtQ0FBcUIsTUFBTSxTQUFTO0FBQ3BDLHFCQUFPO1lBQ1I7QUFDQSxnQkFBSSxLQUFLO0FBQUcsNEJBQWMsS0FBSztVQUNoQyxHQUFHLE1BQU07UUFDVixPQUFPO0FBQ04sZ0JBQU0sWUFBWSxhQUFhLFFBQVcsRUFBRSxJQUFJLE9BQU8sSUFBSSxHQUFHLEtBQUksQ0FBRTtBQUNwRSxjQUFJLENBQUM7QUFBSztBQUNWLGVBQUssSUFBSSxTQUFTLGFBQWEsR0FBRyxRQUFRLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFDakUsZUFBSyxXQUFXLEtBQUssR0FBRztBQUN4QiwrQkFBcUIsTUFBTSxTQUFTO1FBQ3JDO01BQ0Q7O0FBR0QsUUFBSSxPQUFPLE1BQU0sU0FBUztBQUN6QixZQUFNLGNBQWMsVUFBVSxRQUFRLEdBQUcsRUFBRTtBQUMzQyxVQUFJO0FBQWEsb0JBQVksc0JBQXNCO0FBQ25ELGdCQUFVLFFBQVEsS0FDakI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU8sT0FBTztRQUNkLFNBQVM7UUFDVCxLQUFLLENBQUMsT0FBTztRQUNiLEtBQUssT0FBTztRQUNaLHFCQUFxQjtTQUV0QjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLE9BQU87UUFDUCxxQkFBcUI7U0FFdEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsdUJBQXVCO09BQ3ZCO0FBSUYsZ0JBQVUsUUFBUSxLQUNqQjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCx1QkFBdUI7U0FFeEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsS0FBSztRQUNMLEtBQUs7UUFDTCxxQkFBcUI7U0FFdEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsS0FBSztRQUNMLEtBQUs7UUFDTCxxQkFBcUI7U0FFdEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsU0FBUztVQUNSLEVBQUUsT0FBTyxVQUFVLElBQUksU0FBUTtVQUMvQixFQUFFLE9BQU8sV0FBVyxJQUFJLFNBQVE7VUFDaEMsRUFBRSxPQUFPLFlBQVksSUFBSSxVQUFTO1VBQ2xDLEVBQUUsT0FBTyxlQUFlLElBQUksWUFBVzs7UUFFeEMscUJBQXFCO09BQ3JCO0lBRUg7QUFFQSxZQUFRLE9BQU8sRUFBRSxJQUFJO0VBQ3RCO0FBRUEsT0FBSyxxQkFBcUIsT0FBTztBQUNsQzs7O0FDbE1NLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sWUFBMEMsQ0FBQTtBQUNoRCxhQUFXLFlBQVksY0FBYztBQUNwQyxVQUFNLGNBQTJDO01BQ2hELE1BQU0sU0FBUztNQUNmLGFBQWEsU0FBUztNQUN0QixNQUFNO01BQ04sY0FBYztRQUNiLFNBQVMsV0FBVyxLQUFLLEdBQUcsQ0FBQztRQUM3QixPQUFPLFdBQVcsR0FBRyxHQUFHLENBQUM7O01BRTFCLFNBQVMsY0FBYyxDQUFBLEdBQUksUUFBUTtNQUNuQyxVQUFVLE9BQU8sVUFBMkI7QUFDM0MsY0FBTSxPQUFPLEtBQUssTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPLENBQUM7QUFFckQsWUFBSSxNQUFNLGNBQWMsU0FBUztBQUNoQyxnQkFBTSxjQUFjLE9BQU8sS0FBSyxTQUFTLEtBQUssS0FBSyxFQUFFO0FBQ3JELGdCQUFNLFFBQVEsWUFDWixLQUFJLEVBQ0osTUFBTSxRQUFRLEVBQ2QsT0FBTyxPQUFPLEVBQ2QsSUFBSSxDQUFDLE1BQWUsT0FBTyxLQUFLLENBQUMsSUFBSSxPQUFPLFNBQVMsRUFBRSxNQUFNLENBQUMsR0FBRyxFQUFFLElBQUksT0FBTyxDQUFDLENBQUU7QUFDbkYsY0FDQyxNQUFNLEtBQUssQ0FBQyxTQUFpQixDQUFDLE9BQU8sVUFBVSxJQUFJLEtBQUssT0FBTyxLQUFLLE9BQU8sR0FBRyxLQUM5RSxNQUFNLENBQUMsTUFBTSxPQUNiLE1BQU0sR0FBRyxFQUFFLE1BQU07QUFFakIsbUJBQU87QUFDUixlQUFLLFFBQVE7UUFDZDtBQUVBLGNBQU0sTUFBTSxZQUFZLGFBQWEsUUFBVyxFQUFFLElBQUksTUFBTSxZQUFZLEdBQUcsS0FBSSxDQUFFO0FBQ2pGLFlBQUksQ0FBQztBQUFLLGlCQUFPO0FBRWpCLGNBQU0sZUFBZSxLQUFLLGlCQUFpQixHQUFHO0FBQzlDLFlBQUksTUFBTSxlQUFlLFdBQVcsS0FBSyxhQUFhLEtBQUssT0FBTyxrQkFBa0IsUUFBUTtBQUMzRix1QkFBYSxNQUFNLEtBQUssWUFBWTtBQUNyQyxZQUFJLGdCQUFnQjtBQUFXLGlCQUFPO0FBQ3RDLFlBQUksZ0JBQWdCLEtBQUssY0FBYyxHQUFHLEVBQUUsS0FBSztBQUNoRCxpQkFBTztRQUNSO0FBQ0EsZUFBTztNQUNSOztBQUdELFFBQUksU0FBUyxNQUFNLFdBQVcsS0FBSyxPQUFPLGdCQUFnQjtBQUN6RCxZQUFNLGNBQWMsWUFBWSxRQUFRLEdBQUcsRUFBRTtBQUM3QyxVQUFJO0FBQWEsb0JBQVksc0JBQXNCO0FBQ25ELGtCQUFZLFFBQVEsS0FBSztRQUN4QixJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsdUJBQXVCO09BQ3ZCO0lBQ0Y7QUFFQSxjQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXpCLFFBQUksU0FBUyxPQUFPLFNBQVM7QUFDNUIsZ0JBQVUsU0FBUyxLQUFLLFFBQVEsSUFBSTtRQUNuQyxNQUFNLFNBQVMsUUFBUTtRQUN2QixhQUFhLFNBQVM7UUFDdEIsTUFBTTtRQUNOLFNBQVMsWUFBWSxRQUFRLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTLFNBQVMsRUFBRSxPQUFPLFdBQVc7UUFDMUYsVUFBVSxPQUFPLFVBQTBCO0FBQzFDLGdCQUFNLE9BQU8sS0FBSyxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU8sQ0FBQztBQUNyRCxnQkFBTSxRQUFRLE1BQU0sV0FBVyxRQUFRLFVBQVUsRUFBRTtBQUNuRCxnQkFBTSxNQUFNLFlBQVksYUFBYSxRQUFXLEVBQUUsSUFBSSxPQUFPLEdBQUcsS0FBSSxDQUFFO0FBQ3RFLGNBQUksQ0FBQztBQUFLLG1CQUFPO0FBQ2pCLGdCQUFNLFFBQVEsS0FBSyxpQkFBaUIsR0FBRztBQUN2QyxjQUFJLFVBQVU7QUFBVyxtQkFBTztBQUNoQyxpQkFBTyxVQUFVLFlBQVksUUFBUSxJQUFJO1FBQzFDOztJQUVGO0VBQ0Q7QUFFQSxZQUFVLFFBQVEsSUFBSTtJQUNyQixNQUFNO0lBQ04sYUFBYTtJQUNiLE1BQU07SUFDTixjQUFjO01BQ2IsU0FBUyxXQUFXLEtBQUssR0FBRyxDQUFDO01BQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7SUFFMUIsU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUE2QjtBQUN0QyxhQUFPLENBQUMsQ0FBQyxLQUFLLGlCQUFpQixRQUFRO0lBQ3hDOztBQUdELFlBQVUsU0FBUyxJQUFJO0lBQ3RCLE1BQU07SUFDTixhQUFhO0lBQ2IsTUFBTTtJQUNOLGNBQWM7TUFDYixTQUFTLFdBQVcsS0FBSyxHQUFHLENBQUM7TUFDN0IsT0FBTyxXQUFXLEdBQUcsR0FBRyxDQUFDOztJQUUxQixTQUFTLENBQUE7SUFDVCxVQUFVLFlBQTZCO0FBQ3RDLGFBQU8sQ0FBQyxDQUFDLEtBQUssaUJBQWlCLFNBQVM7SUFDekM7O0FBR0QsT0FBSyx1QkFBdUIsU0FBUztBQUN0Qzs7O0FDbkhNLFNBQVUsY0FBYyxNQUFvQjtBQUNqRCxRQUFNLFVBQVU7SUFDZixTQUFTO01BQ1IsTUFBTTtNQUNOLE1BQU07TUFDTixPQUFPO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixPQUFPLFdBQVcsS0FBSyxLQUFLLEdBQUc7UUFDL0IsU0FBUyxXQUFXLEdBQUcsR0FBRyxDQUFDOztNQUU1QixPQUFPLENBQUE7TUFDUCxXQUFXO1FBQ1Y7VUFDQyxZQUFZO1VBQ1osU0FBUyxDQUFBO1VBQ1QsT0FBTztZQUNOLE9BQU8sV0FBVyxLQUFLLEtBQUssR0FBRztZQUMvQixTQUFTLFdBQVcsR0FBRyxLQUFLLENBQUM7Ozs7O0lBS2pDLFVBQVU7TUFDVCxNQUFNO01BQ04sTUFBTTtNQUNOLE9BQU87UUFDTixNQUFNO1FBQ04sTUFBTTtRQUNOLE9BQU8sV0FBVyxLQUFLLEtBQUssR0FBRztRQUMvQixTQUFTLFdBQVcsR0FBRyxHQUFHLENBQUM7O01BRTVCLE9BQU8sQ0FBQTtNQUNQLFdBQVc7UUFDVjtVQUNDLFlBQVk7VUFDWixTQUFTLENBQUE7VUFDVCxPQUFPO1lBQ04sT0FBTyxXQUFXLEtBQUssS0FBSyxHQUFHO1lBQy9CLFNBQVMsV0FBVyxHQUFHLEtBQUssQ0FBQzs7Ozs7O0FBT2xDLFFBQU0sWUFBWTtJQUNqQjtNQUNDLElBQUk7TUFDSixNQUFNO01BQ04sYUFBYTtRQUNaO1VBQ0MsSUFBSTtVQUNKLE1BQU07VUFDTixNQUFNO1VBQ04sU0FBUyxDQUFDLFdBQVcsVUFBVTs7Ozs7QUFNbkMsT0FBSyxxQkFBcUIsV0FBVyxPQUFPO0FBQzdDOzs7QUMxQ0EsSUFBcUIsaUJBQXJCLGNBQTRDLGFBQXlCO0VBQ3BFOztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsYUFBMEIsQ0FBQTtFQUUxQixZQUFZLFVBQWlCO0FBQzVCLFVBQU0sUUFBUTtFQUNmO0VBRUEsTUFBTSxLQUFLLFFBQW9CO0FBQzlCLFNBQUssU0FBUztBQUNkLFNBQUssWUFBWSxvQkFBSSxJQUFHO0FBRXhCLFNBQUssY0FBYTtBQUNsQixTQUFLLGdCQUFlO0FBQ3BCLFNBQUssY0FBYTtBQUNsQixTQUFLLDBCQUF5QjtBQUM5QixVQUFNLEtBQUssY0FBYyxNQUFNO0VBQ2hDOztFQUdBLE1BQU0sVUFBTztBQUNaLFNBQUssVUFBVSxNQUFLO0FBQ3BCLFNBQUssV0FBVyxNQUFLO0FBQ3JCLFNBQUssSUFBSSxTQUFTLEdBQUcsS0FBSyxFQUFFLFlBQVk7RUFDekM7RUFFQSxNQUFNLGNBQWMsUUFBb0I7QUFDdkMsVUFBTSx3QkFBd0IsS0FBSyxRQUFRLG1CQUFtQixPQUFPO0FBQ3JFLFNBQUssU0FBUztBQUNkLFFBQUk7QUFBdUIsV0FBSyxnQkFBZTtBQUMvQyxTQUFLLE9BQU8sa0JBQWtCO0FBQzlCLFNBQUssT0FBTyxtQkFBbUI7QUFDL0IsVUFBTSxhQUFhLEtBQUssT0FBTyxrQkFBa0IsS0FBSyxPQUFPLG9CQUFvQixLQUFLLE9BQU87QUFDN0YsVUFBTSxjQUFjLEtBQUssT0FBTyxtQkFBbUIsS0FBSyxPQUFPLHFCQUFxQixLQUFLLE9BQU87QUFDaEcsU0FBSyxJQUNKLFNBQ0EsMEJBQTBCLEtBQUssVUFBZSxVQUFTLENBQUUsQ0FBQzt5QkFBNkIsVUFBVSxFQUFFO0FBRXBHLFNBQUssSUFDSixTQUNBLDJCQUEyQixLQUFLLFVBQWUsV0FBVSxDQUFFLENBQUM7eUJBQTZCLFdBQVcsRUFBRTtBQUV2RyxTQUFLLElBQUksU0FBUyxFQUFFO0FBQ3BCLFFBQUksS0FBSztBQUFXLFdBQUssVUFBVSxNQUFLO0FBQ3hDLFFBQUksS0FBSztBQUFZLFdBQUssV0FBVyxNQUFLO0FBQzFDLFNBQUssWUFBWSxJQUFTQyxPQUFNLFlBQVksS0FBSyxPQUFPLGVBQWU7QUFDdkUsU0FBSyxhQUFhLElBQVNDLFFBQU8sYUFBYSxLQUFLLE9BQU8sZ0JBQWdCO0FBQzNFLFVBQU0sZUFBZSxLQUFLLE9BQU8sbUJBQW1CLEtBQUssVUFBVSxXQUFVO0FBQzdFLFVBQU0sZ0JBQWdCLEtBQUssT0FBTyxvQkFBb0IsS0FBSyxXQUFXLFdBQVU7QUFDaEYsU0FBSyxJQUFJLFFBQVEsc0JBQXNCLEtBQUssVUFBVSxJQUFJLFFBQVEsZUFBZSxLQUFLLE1BQU0sT0FBTztBQUNuRyxTQUFLLElBQUksUUFBUSxzQkFBc0IsS0FBSyxXQUFXLElBQUksUUFBUSxnQkFBZ0IsS0FBSyxNQUFNLE9BQU87QUFDckcsU0FBSyxhQUFhLGVBQWUsWUFBWTtBQUM3QyxRQUFJLENBQUMsZ0JBQWdCO0FBQWUsV0FBSyxhQUFhLGVBQWUsV0FBVyx1QkFBdUI7QUFDdkcsUUFBSSxnQkFBZ0IsQ0FBQztBQUFlLFdBQUssYUFBYSxlQUFlLFdBQVcsd0JBQXdCO0FBQ3hHLFFBQUksZ0JBQWdCO0FBQWUsV0FBSyxhQUFhLGVBQWUsRUFBRTtBQUV0RSxTQUFLLE1BQUs7RUFDWDs7RUFHQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWU7RUFDdkI7RUFDQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsZ0JBQWE7QUFDWixrQkFBYyxJQUFJO0VBQ25CO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9COztFQUdBLFFBQUs7QUFDSixTQUFLLElBQUksU0FBUyxxQkFBcUI7QUFFdkMsU0FBSyxVQUFVLEdBQUcsU0FBUyxDQUFDLFNBQTRDO0FBQ3ZFLFdBQUssa0JBQWtCO1FBQ3RCLE9BQU8sS0FBSztRQUNaLFNBQVMsS0FBSztPQUNkO0lBQ0YsQ0FBQztBQUNELFNBQUssVUFBVSxHQUFHLFdBQVcsQ0FBQyxXQUFtQixRQUFvQjtBQUNwRSxVQUFJLElBQUksT0FBTyxPQUFPO0FBQ3JCLGFBQUssSUFBSSxTQUFTLElBQUksVUFBVSxRQUFRLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLGVBQWUsR0FBRyxVQUFVLEtBQUssVUFBVSxJQUFJLEdBQUc7QUFDN0csYUFBSyxlQUFlLEdBQUc7QUFDdkIsWUFBSSxLQUFLO0FBQW9CLGVBQUsscUJBQXFCLFdBQVcsR0FBRztNQUN0RTtBQUNBLDJCQUFxQixNQUFNLFFBQVE7SUFDcEMsQ0FBQztFQUNGO0VBRUEsZUFBZSxLQUFnQjtBQUM5QixVQUFNLE9BQXVCLEtBQUssY0FBYyxHQUFHO0FBQ25ELFFBQUksS0FBSyxNQUFNLEdBQUc7QUFDakIsb0JBQWMsTUFBTSxLQUFLLEtBQUssR0FBRztBQUNqQyxXQUFLLFVBQVUsSUFBSSxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQ3JDLFdBQUssa0JBQWlCO0lBQ3ZCO0VBQ0Q7RUFFQSxpQkFBaUIsS0FBZ0I7QUFDaEMsVUFBTSxPQUF1QixLQUFLLGNBQWMsR0FBRztBQUNuRCxRQUFJLEtBQUssTUFBTSxHQUFHO0FBQ2pCLGFBQU8sS0FBSyxVQUFVLElBQUksS0FBSyxHQUFHO0lBQ25DO0FBQ0EsV0FBTztFQUNSO0VBRUEsY0FBYyxLQUFnQjtBQUM3QixRQUFJLFlBQW9CLElBQUksTUFBTSxTQUFTO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLFlBQVk7QUFHaEIsUUFBSSxhQUFhLEtBQUssSUFBSSxTQUFTLEtBQU07QUFDeEMsVUFBSSxJQUFJLE1BQU0sU0FBUztBQUN0QixvQkFBWSxJQUFJLEtBQUssU0FBUztBQUM5QjtNQUNELE9BQU87QUFDTixvQkFBWSxJQUFJLE1BQU0sU0FBUztNQUNoQztBQUNBLGVBQVMsSUFBSSxHQUFHLElBQUksV0FBVyxLQUFLO0FBQ25DLHFCQUFhLElBQUksTUFBTSxDQUFDLE1BQU8sWUFBWSxJQUFJLEtBQU07TUFDdEQ7QUFDQSxVQUFJLGFBQWE7QUFBRyxvQkFBWTtJQUNqQztBQUNBLFdBQU8sRUFBRSxLQUFLLFdBQVcsS0FBSyxVQUFTO0VBQ3hDOztFQUdBLDZCQUE2QixhQUFvQjtBQUNoRCxTQUFLLHFCQUFxQjtFQUMzQjs7RUFHQSxxQkFBcUIsV0FBbUIsS0FBZ0I7QUFDdkQsVUFBTSxPQUFPLEVBQUUsR0FBRyxJQUFJLEtBQUk7QUFDMUIsUUFBSSxJQUFJLE9BQU8sV0FBVyxLQUFLLE9BQU87QUFDckMsV0FBSyxRQUFRLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLEtBQUssU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQ2hGO0FBQ0EsUUFBSSxXQUFXLEdBQUcsSUFBSSxFQUFFLElBQUksS0FBSyxjQUFjLEdBQUcsRUFBRSxHQUFHO0FBQ3ZELFFBQUksS0FBSyxPQUFPLGNBQWM7QUFDN0Isa0JBQVksS0FBSyxNQUFNLFlBQVksR0FBSTtBQUN2QyxpQkFBVztJQUNaLE9BQU87QUFDTixrQkFBWTtJQUNiO0FBQ0EsU0FBSyxhQUNKO01BQ0MsVUFBVSxJQUFJO01BQ2QsU0FBUztNQUNULE9BQU87T0FFUixRQUFRO0VBRVY7OyIsCiAgIm5hbWVzIjogWyJFdmVudEVtaXR0ZXIiLCAiSW5wdXQiLCAiT3V0cHV0IiwgInZhcmlhYmxlcyIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJFdmVudEVtaXR0ZXIiLCAiSW5wdXQiLCAiRXZlbnRFbWl0dGVyIiwgIk91dHB1dCIsICJJbnB1dCIsICJPdXRwdXQiXQp9Cg==
