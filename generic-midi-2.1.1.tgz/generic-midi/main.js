import { createRequire as __esbuild_createRequire } from 'module';
import { fileURLToPath as __esbuild_fileURLToPath } from 'url';
import { dirname as __esbuild_dirname } from 'path';
const require = __esbuild_createRequire(import.meta.url);
const __filename = __esbuild_fileURLToPath(import.meta.url);
const __dirname = __esbuild_dirname(__filename);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/pkg-prebuilds/lib/prebuild.js
var require_prebuild = __commonJS({
  "node_modules/pkg-prebuilds/lib/prebuild.js"(exports, module) {
    var fs = __require("fs");
    function getPrebuildName(options) {
      if (!options.napi_version) throw new Error("NAN not implemented");
      const tokens = [
        options.name,
        options.platform,
        options.arch,
        // options.armv ? (options.arch === 'arm64' ? '8' : vars.arm_version) : null,
        options.libc && options.platform === "linux" ? options.libc : null
      ];
      return `${tokens.filter((t) => !!t).join("-")}/${options.runtime}-napi-v${options.napi_version}.node`;
    }
    function isNwjs() {
      return !!(process.versions && process.versions.nw);
    }
    function isElectron() {
      if (process.versions && process.versions.electron) return true;
      if (process.env.ELECTRON_RUN_AS_NODE) return true;
      return typeof window !== "undefined" && window.process && window.process.type === "renderer";
    }
    function isAlpine(platform) {
      return platform === "linux" && fs.existsSync("/etc/alpine-release");
    }
    module.exports = {
      getPrebuildName,
      isNwjs,
      isElectron,
      isAlpine
    };
  }
});

// node_modules/pkg-prebuilds/bindings.js
var require_bindings = __commonJS({
  "node_modules/pkg-prebuilds/bindings.js"(exports, module) {
    var path = __require("path");
    var os = __require("os");
    var { getPrebuildName, isNwjs, isElectron, isAlpine } = require_prebuild();
    var fs = typeof jest !== "undefined" ? jest.requireActual("fs") : __require("fs");
    var runtimeRequire = typeof __webpack_require__ === "function" ? __non_webpack_require__ : __require;
    function resolvePath(basePath, options, verifyPrebuild, throwOnMissing) {
      if (typeof basePath !== "string" || !basePath) throw new Error(`Invalid basePath to pkg-prebuilds`);
      if (typeof options !== "object" || !options) throw new Error(`Invalid options to pkg-prebuilds`);
      if (typeof options.name !== "string" || !options.name) throw new Error(`Invalid name to pkg-prebuilds`);
      let isNodeApi = false;
      if (options.napi_versions && Array.isArray(options.napi_versions)) {
        isNodeApi = true;
      }
      const arch = verifyPrebuild && process.env.npm_config_arch || os.arch();
      const platform = verifyPrebuild && process.env.npm_config_platform || os.platform();
      let runtime = "node";
      if (!isNodeApi) {
        if (verifyPrebuild && process.env.npm_config_runtime) {
          runtime = process.env.npm_config_runtime;
        } else if (isElectron()) {
          runtime = "electron";
        } else if (isNwjs()) {
          runtime = "node-webkit";
        }
      }
      const candidates = [];
      if (!verifyPrebuild) {
        candidates.push(
          path.join(basePath, "build", "Debug", `${options.name}.node`),
          path.join(basePath, "build", "Release", `${options.name}.node`)
        );
      }
      let libc = void 0;
      if (isAlpine(platform)) libc = "musl";
      if (isNodeApi) {
        for (const ver of options.napi_versions) {
          const prebuildName = getPrebuildName({
            name: options.name,
            platform,
            arch,
            libc,
            napi_version: ver,
            runtime
            // armv: options.armv ? (arch === 'arm64' ? '8' : vars.arm_version) : null,
          });
          candidates.push(path.join(basePath, "prebuilds", prebuildName));
        }
      } else {
        throw new Error("Not implemented for NAN!");
      }
      let foundPath = null;
      for (const candidate of candidates) {
        if (fs.existsSync(candidate)) {
          const stat = fs.statSync(candidate);
          if (stat.isFile()) {
            foundPath = candidate;
            break;
          }
        }
      }
      if (!foundPath && throwOnMissing) {
        const candidatesStr = candidates.map((cand) => ` - ${cand}`).join("\n");
        throw new Error(`Failed to find binding for ${options.name}
Tried paths:
${candidatesStr}`);
      }
      return foundPath;
    }
    function loadBinding(basePath, options) {
      const foundPath = resolvePath(basePath, options, false, true);
      if (!foundPath) throw new Error(`Failed to find binding for ${options.name}`);
      return runtimeRequire(foundPath);
    }
    loadBinding.resolve = resolvePath;
    module.exports = loadBinding;
  }
});

// node_modules/@julusian/midi/binding-options.js
var require_binding_options = __commonJS({
  "node_modules/@julusian/midi/binding-options.js"(exports, module) {
    module.exports = {
      name: "midi",
      napi_versions: [7]
    };
  }
});

// node_modules/@julusian/midi/lib/instruments.js
var require_instruments = __commonJS({
  "node_modules/@julusian/midi/lib/instruments.js"(exports, module) {
    module.exports = {
      ACOUSTIC_GRAND_PIANO: 0,
      BRIGHT_ACOUSTIC_PIANO: 1,
      ELECTRIC_GRAND_PIANO: 2,
      HONKY_TONK_PIANO: 3,
      ELECTRIC_PIANO_1: 4,
      ELECTRIC_PIANO_2: 5,
      HARPSICHORD: 6,
      CLAVI: 7,
      CELESTA: 8,
      GLOCKENSPIEL: 9,
      MUSIC_BOX: 10,
      VIBRAPHONE: 11,
      MARIMBA: 12,
      XYLOPHONE: 13,
      TUBULAR_BELLS: 14,
      DULCIMER: 15,
      DRAWBAR_ORGAN: 16,
      PERCUSSIVE_ORGAN: 17,
      ROCK_ORGAN: 18,
      CHURCH_ORGAN: 19,
      REED_ORGAN: 20,
      ACCORDION: 21,
      HARMONICA: 22,
      TANGO_ACCORDION: 23,
      ACOUSTIC_GUITAR_NYLON: 24,
      ACOUSTIC_GUITAR_STEEL: 25,
      ELECTRIC_GUITAR_JAZZ: 26,
      ELECTRIC_GUITAR_CLEAN: 27,
      ELECTRIC_GUITAR_MUTED: 28,
      OVERDRIVEN_GUITAR: 29,
      DISTORTION_GUITAR: 30,
      GUITAR_HARMONICS: 31,
      ACOUSTIC_BASS: 32,
      ELECTRIC_BASS_FINGER: 33,
      ELECTRIC_BASS_PICK: 34,
      FRETLESS_BASS: 35,
      SLAP_BASS_1: 36,
      SLAP_BASS_2: 37,
      SYNTH_BASS_1: 38,
      SYNTH_BASS_2: 39,
      VIOLIN: 40,
      VIOLA: 41,
      CELLO: 42,
      CONTRABASS: 43,
      TREMOLO_STRINGS: 44,
      PIZZICATO_STRINGS: 45,
      ORCHESTRAL_HARP: 46,
      TIMPANI: 47,
      STRING_ENSEMBLE_1: 48,
      STRING_ENSEMBLE_2: 49,
      SYNTHSTRINGS_1: 50,
      SYNTHSTRINGS_2: 51,
      CHOIR_AAHS: 52,
      VOICE_OOHS: 53,
      SYNTH_VOICE: 54,
      ORCHESTRA_HIT: 55,
      TRUMPET: 56,
      TROMBONE: 57,
      TUBA: 58,
      MUTED_TRUMPET: 59,
      FRENCH_HORN: 60,
      BRASS_SECTION: 61,
      SYNTHBRASS_1: 62,
      SYNTHBRASS_2: 63,
      SOPRANO_SAX: 64,
      ALTO_SAX: 65,
      TENOR_SAX: 66,
      BARITONE_SAX: 67,
      OBOE: 68,
      ENGLISH_HORN: 69,
      BASSOON: 70,
      CLARINET: 71,
      PICCOLO: 72,
      FLUTE: 73,
      RECORDER: 74,
      PAN_FLUTE: 75,
      BLOWN_BOTTLE: 76,
      SHAKUHACHI: 77,
      WHISTLE: 78,
      OCARINA: 79,
      LEAD_1_SQUARE: 80,
      LEAD_2_SAWTOOTH: 81,
      LEAD_3_CALLIOPE: 82,
      LEAD_4_CHIFF: 83,
      LEAD_5_CHARANG: 84,
      LEAD_6_VOICE: 85,
      LEAD_7_FIFTHS: 86,
      LEAD_8_BASS_AND_LEAD: 87,
      PAD_1_NEW_AGE: 88,
      PAD_2_WARM: 89,
      PAD_3_POLYSYNTH: 90,
      PAD_4_CHOIR: 91,
      PAD_5_BOWED: 92,
      PAD_6_METALLIC: 93,
      PAD_7_HALO: 94,
      PAD_8_SWEEP: 95,
      FX_1_RAIN: 96,
      FX_2_SOUNDTRACK: 97,
      FX_3_CRYSTAL: 98,
      FX_4_ATMOSPHERE: 99,
      FX_5_BRIGHTNESS: 100,
      FX_6_GOBLINS: 101,
      FX_7_ECHOES: 102,
      FX_8_SCIFI: 103,
      SITAR: 104,
      BANJO: 105,
      SHAMISEN: 106,
      KOTO: 107,
      KALIMBA: 108,
      BAG_PIPE: 109,
      FIDDLE: 110,
      SHANAI: 111,
      TINKLE_BELL: 112,
      AGOGO: 113,
      STEEL_DRUMS: 114,
      WOODBLOCK: 115,
      TAIKO_DRUM: 116,
      MELODIC_TOM: 117,
      SYNTH_DRUM: 118,
      REVERSE_CYMBAL: 119,
      GUITAR_FRET_NOISE: 120,
      BREATH_NOISE: 121,
      SEASHORE: 122,
      BIRD_TWEET: 123,
      TELEPHONE_RING: 124,
      HELICOPTER: 125,
      APPLAUSE: 126,
      GUNSHOT: 127
    };
  }
});

// node_modules/@julusian/midi/lib/drums.js
var require_drums = __commonJS({
  "node_modules/@julusian/midi/lib/drums.js"(exports, module) {
    module.exports = {
      ACOUSTIC_BASS_DRUM: 35,
      BASS_DRUM: 36,
      SIDE_STICK: 37,
      ACOUSTIC_SNARE: 38,
      HAND_CLAP: 39,
      ELECTRIC_SNARE: 40,
      LOW_FLOOR_TOM: 41,
      CLOSED_HI_HAT: 42,
      HIGH_FLOOR_TOM: 43,
      PEDAL_HI_HAT: 44,
      LOW_TOM: 45,
      OPEN_HI_HAT: 46,
      LOW_MID_TOM: 47,
      HI_MID_TOM: 48,
      CRASH_CYMBAL_1: 49,
      HIGH_TOM: 50,
      RIDE_CYMBAL_1: 51,
      CHINESE_CYMBAL: 52,
      RIDE_BELL: 53,
      TAMBOURINE: 54,
      SPLASH_CYMBAL: 55,
      COWBELL: 56,
      CRASH_CYMBAL_2: 57,
      VIBRA_SLAP: 58,
      RIDE_CYMBAL_2: 59,
      HI_BONGO: 60,
      LOW_BONGO: 61,
      MUTE_HI_CONGA: 62,
      OPEN_HI_CONGA: 63,
      LOW_CONGA: 64,
      HIGH_TIMBALE: 65,
      LOW_TIMBALE: 66,
      HIGH_AGOGO: 67,
      LOW_AGOGO: 68,
      CABASA: 69,
      MARACAS: 70,
      SHORT_WHISTLE: 71,
      LONG_WHISTLE: 72,
      SHORT_GUIRO: 73,
      LONG_GUIRO: 74,
      CLAVES: 75,
      HI_WOOD_BLOCK: 76,
      LOW_WOOD_BLOCK: 77,
      MUTE_CUICA: 78,
      OPEN_CUICA: 79,
      MUTE_TRIANGLE: 80,
      OPEN_TRIANGLE: 81
    };
  }
});

// node_modules/@julusian/midi/lib/notes.js
var require_notes = __commonJS({
  "node_modules/@julusian/midi/lib/notes.js"(exports, module) {
    module.exports = {
      /*
      ** The MIDI spec only indicates middle C to be
      ** 60. It doesn't indicate which octave this is.
      ** Some may consider 4, if they label octaves 
      ** from -1, instead of 0. I have adopted on octave
      ** number C here.
      */
      MIDDLE_C: 60,
      // Relative offsets
      C: 0,
      C_SHARP: 1,
      C_FLAT: -1,
      D: 2,
      D_SHARP: 3,
      D_FLAT: 1,
      E: 4,
      E_SHARP: 5,
      E_FLAT: 3,
      F: 5,
      F_SHARP: 6,
      F_FLAT: 4,
      G: 7,
      G_SHARP: 8,
      G_FLAT: 6,
      A: 9,
      A_SHARP: 10,
      A_FLAT: 8,
      B: 11,
      B_SHARP: 12,
      B_FLAT: 10,
      // For the octaves
      C0: 0,
      C1: 12,
      C2: 24,
      C3: 36,
      C4: 48,
      C5: 60,
      C6: 72,
      C7: 84,
      C8: 96,
      C9: 108,
      C10: 120
    };
  }
});

// node_modules/@julusian/midi/lib/messages.js
var require_messages = __commonJS({
  "node_modules/@julusian/midi/lib/messages.js"(exports, module) {
    module.exports = {
      // All basic messages are held in the root, because of how commonly they're
      // used. Luckily, there's no name clashes with sub-names
      NOTE_OFF: 128,
      /* [ pitch, volume ] */
      NOTE_ON: 144,
      /* [ pitch, volume ] */
      NOTE_KEY_PRESSURE: 160,
      /* [ pitch, pressure (after touch) ] */
      SET_PARAMETER: 176,
      /* [ param number (CC), setting ] */
      SET_PROGRAM: 192,
      /* [ program ] */
      CHANGE_PRESSURE: 208,
      /* [ pressure (after touch) ] */
      SET_PITCHWHEEL: 224,
      /* [ LSB,  MSB (two 7 bit values) ] */
      METAEVENT: 255,
      SYS_EX1: 240,
      SYS_EX2: 247,
      /* Alternative names */
      PATCH_CHANGE: 192,
      /* Equivalent to SET_PROGRAM */
      CONTROL_CHANGE: 176,
      /* Equivalent to SET_PARAMETER */
      SYSMASK: 240,
      // Control changes
      cc: {
        /* 0-31, where defined, all indicate the MSB */
        BANK_SELECT: 0,
        MODULATION: 1,
        BREATH_CONTROL: 2,
        UNDEFINED_3: 3,
        FOOT_CONTROL: 4,
        PORTAMENTO_TIME: 5,
        DATE_ENTRY: 6,
        VOLUME: 7,
        BALANCE: 8,
        UNDEFINED_9: 9,
        PAN: 10,
        EXPRESSION: 11,
        EFFECT_CONTROL_1: 12,
        EFFECT_CONTROL_2: 13,
        UNDEFINED_14: 14,
        UNDEFINED_15: 15,
        GENERAL_PURPOSE_1: 16,
        GENERAL_PURPOSE_2: 17,
        GENERAL_PURPOSE_3: 18,
        GENERAL_PURPOSE_4: 19,
        /* 20-31 are undefined */
        UNDEFINED_20: 20,
        UNDEFINED_21: 21,
        UNDEFINED_22: 22,
        UNDEFINED_23: 23,
        UNDEFINED_24: 24,
        UNDEFINED_25: 25,
        UNDEFINED_26: 26,
        UNDEFINED_27: 27,
        UNDEFINED_28: 28,
        UNDEFINED_29: 29,
        UNDEFINED_30: 30,
        UNDEFINED_31: 31,
        /* LSB for control changes 0-31		32-63 */
        BANK_SELECT_LSB: 32,
        MODULATION_LSB: 33,
        BREATH_CONTROL_LSB: 34,
        UNDEFINED_35: 35,
        FOOT_CONTROL_LSB: 36,
        PORTAMENTO_TIME_LSB: 37,
        DATA_ENTRY_LSB: 38,
        VOLUME_LSB: 39,
        BALANCE_LSB: 40,
        UNDEFINED_41: 41,
        PAN_LSB: 42,
        EXPRESSION_LSB: 43,
        EFFECT_CONTROL_1_LSB: 44,
        EFFECT_CONTROL_2_LSB: 45,
        UNDEFINED_46: 46,
        UNDEFINED_47: 47,
        GENERAL_PURPOSE_1_LSB: 48,
        GENERAL_PURPOSE_2_LSB: 49,
        GENERAL_PURPOSE_3_LSB: 50,
        GENERAL_PURPOSE_4_LSB: 51,
        /* 52-63 are undefined */
        UNDEFINED_52: 52,
        UNDEFINED_53: 53,
        UNDEFINED_54: 54,
        UNDEFINED_55: 55,
        UNDEFINED_56: 56,
        UNDEFINED_57: 57,
        UNDEFINED_58: 58,
        UNDEFINED_59: 59,
        UNDEFINED_60: 60,
        UNDEFINED_61: 61,
        UNDEFINED_62: 62,
        UNDEFINED_63: 63,
        SUSTAIN_PEDAL: 64,
        PORTAMENTO: 65,
        PEDAL_SUSTENUTO: 66,
        PEDAL_SOFT: 67,
        LEGATO_FOOT_SWITCH: 68,
        HOLD_2: 69,
        SOUND_VARIATION: 70,
        TIMBRE: 71,
        RELEASE_TIME: 72,
        ATTACKTIME: 73,
        BRIGHTNESS: 74,
        REVERB: 75,
        DELAY: 76,
        PITCH_TRANSPOSE: 77,
        FLANGE: 78,
        SPECIAL_FX: 79,
        GENERAL_PURPOSE_5_LSB: 80,
        GENERAL_PURPOSE_6_LSB: 81,
        GENERAL_PURPOSE_7_LSB: 82,
        GENERAL_PURPOSE_8_LSB: 83,
        PORTAMENTO_CONTROL: 84,
        /* 85-90 are undefined */
        UNDEFINED_85: 85,
        UNDEFINED_86: 86,
        UNDEFINED_87: 87,
        UNDEFINED_88: 88,
        UNDEFINED_89: 89,
        UNDEFINED_90: 90,
        /* Effects depth */
        FX_DEPTH: 91,
        TREMELO_DEPTH: 92,
        CHORUS_DEPTH: 93,
        CELESTA_DEPTH: 94,
        PHASER_DEPTH: 95,
        DATA_INC: 96,
        DATA_DEC: 97,
        NON_REG_PARAM_LSB: 98,
        NON_REG_PARAM_MSB: 99,
        REG_PARAM_LSB: 100,
        REG_PARAM_MSB: 101,
        /* 102-119 are undefined */
        UNDEFINED_102: 102,
        UNDEFINED_103: 103,
        UNDEFINED_104: 104,
        UNDEFINED_105: 105,
        UNDEFINED_106: 106,
        UNDEFINED_107: 107,
        UNDEFINED_108: 108,
        UNDEFINED_109: 109,
        UNDEFINED_110: 110,
        UNDEFINED_111: 111,
        UNDEFINED_112: 112,
        UNDEFINED_113: 113,
        UNDEFINED_114: 114,
        UNDEFINED_115: 115,
        UNDEFINED_116: 116,
        UNDEFINED_117: 117,
        UNDEFINED_118: 118,
        UNDEFINED_119: 119,
        // Modes
        ALL_SOUND_OFF: 120,
        RESET_ALL_CONTROLLERS: 121,
        LOCAL_CONTROL: 122,
        ALL_NOTES_OFF: 123,
        OMNI_MODE_OFF: 124,
        OMNI_MODE_ON: 125,
        MONO_MODE_ON: 126,
        POLY_MODE_ON: 127,
        /* Alternative names */
        MOD_WHEEL: 1,
        /* All sound controllers have only LSB */
        HARM_CONTENT: 71,
        SOUND_CONTROLLER_1: 70,
        SOUND_CONTROLLER_2: 71,
        SOUND_CONTROLLER_3: 72,
        SOUND_CONTROLLER_4: 73,
        SOUND_CONTROLLER_5: 74,
        SOUND_CONTROLLER_6: 75,
        SOUND_CONTROLLER_7: 76,
        SOUND_CONTROLLER_8: 77,
        SOUND_CONTROLLER_9: 78,
        SOUND_CONTROLLER_10: 79,
        EFFECT_1_DEPTH: 91,
        EFFECT_2_DEPTH: 92,
        EFFECT_3_DEPTH: 93,
        EFFECT_4_DEPTH: 94,
        EFFECT_5_DEPTH: 95,
        DETUNE_DEPTH: 94
      },
      /*
      ** System Common (Status byte: 1111 0ttt)
      */
      syscommon: {
        UNDEFINED_1: 241,
        SONG_POSITION: 242,
        /* [LSB, MSB] */
        SONG_SELECT: 243,
        UNDEFINED_4: 244,
        UNDEFINED_5: 245,
        TUNE_REQUEST: 246,
        EOX: 247
        /* End of Exclusive */
      },
      /*
      ** System Real Time (Status byte: 1111 1ttt)
      */
      realtime: {
        TIMING_CLOCK: 248,
        UNDEFINED_F9: 249,
        START: 250,
        CONTINUE: 251,
        STOP: 252,
        UNDEFINED_FD: 253,
        ACTIVE_SENSING: 254,
        SYSTEM_RESET: 255
      },
      /*
      ** System Exclusive (Status byte: 1111 0000)
      **
      ** The first byte of a sysex must be the identification number
      ** (7 bits, MSB=0). This is followed by an arbitary number of
      ** data bytes (all MSB=0), and ending in the sexEOX msg.
      ** Note: Any other status byte (where MSB=1) will also terminate
      ** a sysex message, with the exception of the System Real Time
      ** events above.
      */
      sysex: {
        EOX: 247
        /* End of Exclusive */
      }
    };
  }
});

// node_modules/@julusian/midi/midi.js
var require_midi = __commonJS({
  "node_modules/@julusian/midi/midi.js"(exports, module) {
    var midi = require_bindings()(
      __dirname,
      require_binding_options()
    );
    var Stream = __require("stream");
    var { EventEmitter: EventEmitter3 } = __require("events");
    var Instruments = require_instruments();
    var Drums = require_drums();
    var Notes = require_notes();
    var Messages = require_messages();
    var Input3 = class extends EventEmitter3 {
      constructor() {
        super();
        this.input = new midi.Input((deltaTime, message) => {
          this.emit("message", deltaTime, Array.from(message.values()));
        });
      }
      closePort() {
        return this.input.closePort();
      }
      destroy() {
        return this.input.destroy();
      }
      getPortCount() {
        return this.input.getPortCount();
      }
      getPortName(port) {
        return this.input.getPortName(port);
      }
      isPortOpen() {
        return this.input.isPortOpen();
      }
      ignoreTypes(sysex, timing, activeSensing) {
        return this.input.ignoreTypes(sysex, timing, activeSensing);
      }
      openPort(port) {
        return this.input.openPort(port);
      }
      openPortByName(name) {
        for (let port = 0; port < this.input.getPortCount(); ++port) {
          if (name === this.input.getPortName(port)) {
            return this.input.openPort(port);
          }
        }
        return void 0;
      }
      openVirtualPort(port) {
        return this.input.openVirtualPort(port);
      }
      setBufferSize(size, count = 4) {
        return this.input.setBufferSize(size, count);
      }
    };
    var Output3 = class {
      constructor() {
        this.output = new midi.Output();
      }
      closePort() {
        return this.output.closePort();
      }
      destroy() {
        return this.output.destroy();
      }
      getPortCount() {
        return this.output.getPortCount();
      }
      getPortName(port) {
        return this.output.getPortName(port);
      }
      isPortOpen() {
        return this.output.isPortOpen();
      }
      openPort(port) {
        return this.output.openPort(port);
      }
      openPortByName(name) {
        for (let port = 0; port < this.output.getPortCount(); ++port) {
          if (name === this.output.getPortName(port)) {
            return this.output.openPort(port);
          }
        }
        return void 0;
      }
      openVirtualPort(port) {
        return this.output.openVirtualPort(port);
      }
      send(message) {
        return this.sendMessage(message);
      }
      sendMessage(message) {
        if (Array.isArray(message)) {
          message = Buffer.from(message);
        }
        if (!Buffer.isBuffer(message)) {
          throw new Error("First argument must be an array or Buffer");
        }
        return this.output.sendMessage(message);
      }
    };
    function createReadStream(input) {
      input = input || new Input3();
      var stream = new Stream();
      stream.readable = true;
      stream.paused = false;
      stream.queue = [];
      input.on("message", function(deltaTime, message) {
        var packet = new Buffer.from(message);
        if (!stream.paused) {
          stream.emit("data", packet);
        } else {
          stream.queue.push(packet);
        }
      });
      stream.pause = function() {
        stream.paused = true;
      };
      stream.resume = function() {
        stream.paused = false;
        while (stream.queue.length && stream.emit("data", stream.queue.shift())) {
        }
      };
      return stream;
    }
    function createWriteStream(output) {
      output = output || new Output3();
      var stream = new Stream();
      stream.writable = true;
      stream.paused = false;
      stream.queue = [];
      stream.write = function(d) {
        if (Buffer.isBuffer(d)) {
          d = Array.prototype.slice.call(d, 0);
        }
        output.sendMessage(d);
        return !this.paused;
      };
      stream.end = function(buf) {
        buf && stream.write(buf);
        stream.writable = false;
      };
      stream.destroy = function() {
        stream.writable = false;
      };
      return stream;
    }
    module.exports = {
      Input: Input3,
      Output: Output3,
      createReadStream,
      createWriteStream,
      Constants: {
        Instruments,
        Drums,
        Notes,
        Messages
      },
      // Backwards compatibility.
      input: Input3,
      output: Output3
    };
  }
});

// node_modules/@companion-module/base/dist/logging.js
var defaultLoggingSink = (source, level, message) => {
  console.log(`[${level.toUpperCase()}]${source ? ` [${source}]` : ""} ${message}`);
};
function logToSink(source, level, message) {
  const sink = typeof global.COMPANION_LOGGER === "function" ? global.COMPANION_LOGGER : defaultLoggingSink;
  sink(source, level, message);
}
function createModuleLogger(source) {
  return {
    debug: (message) => logToSink(source, "debug", message),
    info: (message) => logToSink(source, "info", message),
    warn: (message) => logToSink(source, "warn", message),
    error: (message) => logToSink(source, "error", message)
  };
}

// node_modules/@companion-module/base/dist/util.js
function assertNever(_val) {
}
function combineRgb(r, g, b, a) {
  let colorNumber = (r & 255) << 16 | (g & 255) << 8 | b & 255;
  if (a && a >= 0 && a < 1) {
    colorNumber += 16777216 * Math.round(255 * (1 - a));
  }
  return colorNumber;
}

// node_modules/@companion-module/base/dist/module-api/shared-udp-socket.js
import { EventEmitter } from "events";
var SharedUdpSocketImpl = class extends EventEmitter {
  #context;
  #options;
  get handleId() {
    return this.boundState?.handleId;
  }
  get portNumber() {
    return this.boundState?.portNumber;
  }
  get boundState() {
    if (this.#state && typeof this.#state === "object") {
      return this.#state;
    } else {
      return void 0;
    }
  }
  #state = "pending";
  constructor(context, options) {
    super();
    this.#context = context;
    this.#options = { ...options };
  }
  bind(port, _address, callback) {
    if (this.#state && typeof this.#state === "object")
      throw new Error("Socket is already bound");
    switch (this.#state) {
      case "fatalError":
        throw new Error("Socket has encountered fatal error");
      case "binding":
        throw new Error("Socket is already bound");
      case "closed":
        throw new Error("Socket is closing");
      case "pending":
        break;
      default:
        assertNever(this.#state);
        throw new Error("Invalid socket state");
    }
    this.#state = "binding";
    if (callback)
      this.on("listening", callback);
    this.#context.sharedUdpSocketJoin({
      family: this.#options.type,
      portNumber: port
      // Future: use address?
    }).then((handleId) => {
      this.#state = { portNumber: port, handleId };
      this.#context.sharedUdpSocketHandlers.set(handleId, this);
      this.emit("listening");
    }, (err) => {
      this.#state = "closed";
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  close(callback) {
    if (this.#state && typeof this.#state === "object") {
    } else {
      switch (this.#state) {
        case "fatalError":
          throw new Error("Socket has encountered fatal error");
        case "pending":
        case "closed":
        case "binding":
          throw new Error("Socket is not open");
        default:
          assertNever(this.#state);
          throw new Error("Invalid socket state");
      }
    }
    const handleId = this.#state.handleId;
    this.#state = "closed";
    if (callback)
      this.on("close", callback);
    this.#context.sharedUdpSocketLeave({
      handleId
    }).then(() => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("close");
    }, (err) => {
      this.#context.sharedUdpSocketHandlers.delete(handleId);
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  send(bufferOrList, offsetOrPort, lengthOrAddress, portOrCallback, address, callback) {
    if (typeof offsetOrPort !== "number")
      throw new Error("Invalid arguments");
    if (typeof lengthOrAddress === "number") {
      if (typeof portOrCallback !== "number" || typeof address !== "string")
        throw new Error("Invalid arguments");
      if (callback !== void 0 && typeof callback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, offsetOrPort, lengthOrAddress);
      this.#sendInner(buffer, portOrCallback, address, callback);
    } else if (typeof lengthOrAddress === "string") {
      if (portOrCallback !== void 0 && typeof portOrCallback !== "function")
        throw new Error("Invalid arguments");
      const buffer = this.#processBuffer(bufferOrList, 0, void 0);
      this.#sendInner(buffer, offsetOrPort, lengthOrAddress, portOrCallback);
    } else {
      throw new Error("Invalid arguments");
    }
  }
  #processBuffer(bufferOrList, offset, length) {
    let buffer;
    if (typeof bufferOrList === "string") {
      buffer = Buffer.from(bufferOrList, "utf-8");
    } else if (Buffer.isBuffer(bufferOrList)) {
      buffer = bufferOrList;
    } else if (Array.isArray(bufferOrList)) {
      return Buffer.from(bufferOrList);
    } else {
      buffer = Buffer.from(bufferOrList.buffer, bufferOrList.byteOffset, bufferOrList.byteLength);
    }
    return buffer.subarray(offset, length !== void 0 ? length + offset : void 0);
  }
  #sendInner(buffer, port, address, callback) {
    if (!this.#state || typeof this.#state !== "object")
      throw new Error("Socket is not open");
    this.#context.sharedUdpSocketSend({
      handleId: this.#state.handleId,
      message: buffer,
      address,
      port
    }).then(() => {
      callback?.();
    }, (err) => {
      this.emit("error", err instanceof Error ? err : new Error(err));
    }).catch(() => null);
  }
  receiveSocketMessage(message) {
    try {
      this.emit("message", message.message, message.source);
    } catch (_e) {
    }
  }
  receiveSocketError(error) {
    this.#state = "fatalError";
    const boundState = this.boundState;
    if (boundState)
      this.#context.sharedUdpSocketHandlers.delete(boundState.handleId);
    try {
      this.emit("error", error);
    } catch (_e) {
    }
  }
};

// node_modules/@companion-module/base/dist/host-api/context.js
function isInstanceContext(obj) {
  const obj2 = obj;
  return !!obj2 && typeof obj2 === "object" && typeof obj2.id === "string" && obj2._isInstanceContext === true;
}

// node_modules/@companion-module/base/dist/module-api/base.js
var InstanceBase = class {
  #context;
  #logger;
  #options;
  get id() {
    return this.#context.id;
  }
  get instanceOptions() {
    return this.#options;
  }
  /**
   * The user chosen name for this instance.
   * This can be changed just before `configUpdated` is called
   */
  get label() {
    return this.#context.label;
  }
  /**
   * Create an instance of the module
   */
  constructor(internal) {
    if (!isInstanceContext(internal) || !internal._isInstanceContext)
      throw new Error(`Module instance is being constructed incorrectly. Make sure you aren't trying to do this manually`);
    this.#context = internal;
    this.#logger = createModuleLogger();
    this.createSharedUdpSocket = this.createSharedUdpSocket.bind(this);
    this.#options = {
      disableVariableValidation: false,
      disableNewConfigLayout: false
    };
    this.log("debug", "Initializing");
  }
  saveConfig(newConfig, newSecrets) {
    this.#context.saveConfig(newConfig, newSecrets);
  }
  /**
   * Set the action definitions for this instance
   * @param actions The action definitions
   */
  setActionDefinitions(actions) {
    this.#context.setActionDefinitions(actions);
  }
  /**
   * Set the feedback definitions for this instance
   * @param feedbacks The feedback definitions
   */
  setFeedbackDefinitions(feedbacks) {
    this.#context.setFeedbackDefinitions(feedbacks);
  }
  /**
   * Set the preset definitions for this instance
   * @param structure The structure of the preset sections
   * @param presets The unstructured preset definitions
   */
  setPresetDefinitions(structure, presets) {
    this.#context.setPresetDefinitions(structure, presets);
  }
  /**
   * Set the variable definitions for this instance
   * @param variables The variable definitions
   */
  setVariableDefinitions(variables2) {
    if (Array.isArray(variables2))
      throw new Error("Variable definitions should be an object, not an array");
    this.#context.setVariableDefinitions(variables2);
  }
  /**
   * Set the values of some variables
   * @param values The new values for the variables
   */
  setVariableValues(values) {
    this.#context.setVariableValues(values);
  }
  /**
   * Get the last set value of a variable from this connection
   * @param variableId id of the variable
   * @returns The value
   */
  getVariableValue(variableId) {
    return this.#context.getVariableValue(variableId);
  }
  /**
   * Request all feedbacks of all types to be re-executed
   */
  checkAllFeedbacks() {
    this.#context.checkAllFeedbacks();
  }
  /**
   * Request all feedbacks of the specified types to be re-executed.
   * At least one feedback type must be provided.
   * @param feedbackType The first feedback type to check
   * @param feedbackTypes Additional feedback types to check
   */
  checkFeedbacks(feedbackType, ...feedbackTypes) {
    this.#context.checkFeedbacks([feedbackType, ...feedbackTypes]);
  }
  /**
   * Request the specified feedback instances to be be re-executed
   * @param feedbackIds The ids of the feedback instances to check
   */
  checkFeedbacksById(...feedbackIds) {
    this.#context.checkFeedbacksById(feedbackIds);
  }
  /**
   * Call subscribe on all currently known placed actions.
   * It can be useful to trigger this upon establishing a connection, to ensure all data is loaded.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  subscribeActions(...actionIds) {
    this.#context.subscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed actions.
   * It can be useful to do some cleanup upon a connection closing.
   * @param actionIds The actionIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeActions(...actionIds) {
    this.#context.unsubscribeActions(actionIds);
  }
  /**
   * Call unsubscribe on all currently known placed feedbacks.
   * It can be useful to do some cleanup upon a connection closing.
   * @param feedbackIds The feedbackIds to call subscribe for. If no values are provided, then all are called.
   */
  unsubscribeFeedbacks(...feedbackIds) {
    this.#context.unsubscribeFeedbacks(feedbackIds);
  }
  /**
   * Add an action to the current recording session
   * @param action The action to be added to the recording session
   * @param uniquenessId A unique id for the action being recorded. This should be different for each action, but by passing the same as a previous call will replace the previous value.
   */
  recordAction(action, uniquenessId) {
    this.#context.recordAction(action, uniquenessId);
  }
  /**
   * Send an osc message from the system osc sender
   * @param host destination ip address
   * @param port destination port number
   * @param path message path
   * @param args message arguments
   */
  oscSend(host, port, path, args) {
    this.#context.oscSend(host, port, path, args);
  }
  /**
   * Update the status of this connection
   * @param status The status level
   * @param message Additional information about the status
   *
   * ### Example
   * ```js
   * this.updateStatus(InstanceStatus.Ok)
   * ```
   */
  updateStatus(status, message) {
    this.#context.updateStatus(status, message ?? null);
  }
  /**
   * Write a line to the log
   * @param level The level of the message
   * @param message The message text to write
   */
  log(level, message) {
    switch (level) {
      case "debug":
        this.#logger.debug(message);
        break;
      case "info":
        this.#logger.info(message);
        break;
      case "warn":
        this.#logger.warn(message);
        break;
      case "error":
        this.#logger.error(message);
        break;
      default:
        assertNever(level);
        this.#logger.info(message);
        break;
    }
  }
  createSharedUdpSocket(typeOrOptions, callback) {
    const options = typeof typeOrOptions === "string" ? { type: typeOrOptions } : typeOrOptions;
    const socket = new SharedUdpSocketImpl(this.#context, options);
    if (callback)
      socket.on("message", callback);
    return socket;
  }
};

// node_modules/@companion-module/base/dist/module-api/enums.js
var InstanceStatus;
(function(InstanceStatus2) {
  InstanceStatus2["Ok"] = "ok";
  InstanceStatus2["Connecting"] = "connecting";
  InstanceStatus2["Disconnected"] = "disconnected";
  InstanceStatus2["ConnectionFailure"] = "connection_failure";
  InstanceStatus2["BadConfig"] = "bad_config";
  InstanceStatus2["UnknownError"] = "unknown_error";
  InstanceStatus2["UnknownWarning"] = "unknown_warning";
  InstanceStatus2["AuthenticationFailure"] = "authentication_failure";
  InstanceStatus2["InsufficientPermissions"] = "insufficient_permissions";
})(InstanceStatus || (InstanceStatus = {}));
var Regex;
(function(Regex2) {
  Regex2.IP = "/^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/";
  Regex2.HOSTNAME = "/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9-]*[A-Za-z0-9])$/";
  Regex2.BOOLEAN = "/^(true|false|0|1)$/i";
  Regex2.PORT = "/^([1-9]|[1-8][0-9]|9[0-9]|[1-8][0-9]{2}|9[0-8][0-9]|99[0-9]|[1-8][0-9]{3}|9[0-8][0-9]{2}|99[0-8][0-9]|999[0-9]|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-4])$/";
  Regex2.MAC_ADDRESS = "/^(?:[a-fA-F0-9]{2}:){5}([a-fA-F0-9]{2})$/";
  Regex2.PERCENT = "/^(100|[0-9]|[0-9][0-9])$/";
  Regex2.FLOAT = "/^([0-9]*\\.)?[0-9]+$/";
  Regex2.SIGNED_FLOAT = "/^[+-]?([0-9]*\\.)?[0-9]+$/";
  Regex2.FLOAT_OR_INT = "/^([0-9]+)(\\.[0-9]+)?$/";
  Regex2.NUMBER = "/^\\d+$/";
  Regex2.SIGNED_NUMBER = "/^[+-]?\\d+$/";
  Regex2.SOMETHING = "/^.+$/";
  Regex2.TIMECODE = "/^(0*[0-9]|1[0-9]|2[0-4]):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[1-5][0-9]|60):(0*[0-9]|[12][0-9]|30)$/";
})(Regex || (Regex = {}));

// dist/midi/midi.js
var node_midi = __toESM(require_midi(), 1);
import { EventEmitter as EventEmitter2 } from "events";

// dist/midi/msgtypes.js
var MAX_7_BIT = 127;
var MAX_14_BIT = 16383;
var MIDI_STATUS_TYPES = /* @__PURE__ */ new Map([
  ["noteoff", 128],
  ["noteon", 144],
  ["aftertouch", 160],
  ["cc", 176],
  ["program", 192],
  ["channelpressure", 208],
  ["pitch", 224],
  ["sysex", 240],
  ["mtc", 241],
  ["position", 242],
  ["select", 243],
  ["tune", 246],
  ["sysex end", 247],
  ["clock", 248],
  ["start", 250],
  ["continue", 251],
  ["stop", 252],
  ["activesense", 254],
  ["reset", 255]
]);
var hex = (val) => `${val} (0x${val.toString(16).padStart(2, "0")})`;
var MidiMessage = class _MidiMessage {
  id = "";
  bytes;
  static noMsg = {
    bytes: [],
    status: 0,
    channel: 0,
    type: 0,
    note: 0,
    velocity: 0,
    controller: 0,
    pressure: 0,
    value: 0,
    program: 0,
    song: 0
  };
  constructor(bytes = []) {
    this.bytes = bytes;
  }
  get status() {
    return this.bytes[0] > 239 ? this.bytes[0] : this.bytes[0] & 240;
  }
  set status(v) {
    this.bytes[0] = v > 239 ? v : this.bytes[0] & 15 | v & 240;
  }
  get channel() {
    return (this.bytes[0] & 15) + 1;
  }
  set channel(v) {
    v--;
    v = _MidiMessage.constrain(v, 15);
    this.bytes[0] = this.bytes[0] & 240 | v & 15;
  }
  get data1() {
    return this.bytes[1] & 127;
  }
  set data1(v) {
    this.bytes[1] = _MidiMessage.constrain(v, MAX_7_BIT);
  }
  get data2() {
    return this.bytes[2] & 127;
  }
  set data2(v) {
    this.bytes[2] = _MidiMessage.constrain(v, MAX_7_BIT);
  }
  get args() {
    return { bytes: this.bytes };
  }
  toString() {
    return `${this.id} Message`;
  }
  static constrain(num, max) {
    return num > max ? max : num < 0 ? 0 : num;
  }
  static parseMessage(bytes = [], msg = this.noMsg) {
    let incoming = new _MidiMessage(bytes);
    let status = bytes.length > 0 ? incoming.status : msg.status || 0;
    if (status === 0 && typeof msg.id !== "undefined")
      status = MIDI_STATUS_TYPES.get(msg.id) || 0;
    switch (status) {
      case 128:
        incoming = new NoteOff(msg.channel, msg.note, msg.velocity);
        break;
      case 144:
        incoming = new NoteOn(msg.channel, msg.note, msg.velocity);
        break;
      case 160:
        incoming = new Aftertouch(msg.channel, msg.note, msg.pressure);
        break;
      case 176:
        incoming = new ControlChange(msg.channel, msg.controller, msg.value);
        break;
      case 192:
        incoming = new ProgramChange(msg.channel, msg.program);
        break;
      case 208:
        incoming = new ChannelPressure(msg.channel, msg.pressure);
        break;
      case 224:
        incoming = new PitchWheel(msg.channel, msg.value);
        break;
      case 240:
        incoming = new Sysex(msg.bytes);
        break;
      case 241:
        incoming = new Mtc(msg.type, msg.value);
        break;
      case 248:
        return;
      // ignore MIDI Clock messages
      default:
        console.log(`Unsupported MIDI message. Status = ${hex(status)}`);
        return;
    }
    if (bytes.length > 0)
      incoming.bytes = bytes;
    return incoming;
  }
};
var NoteOff = class extends MidiMessage {
  constructor(c, n, v) {
    super();
    this.id = "noteoff";
    this.status = 128;
    this.channel = c;
    this.note = n;
    this.velocity = v;
  }
  get note() {
    return this.data1;
  }
  set note(v) {
    this.data1 = v;
  }
  get velocity() {
    return this.data2;
  }
  set velocity(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, note: this.note, velocity: this.velocity };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, note: ${hex(this.note)}, velocity: ${hex(this.velocity)}`;
  }
};
var NoteOn = class extends NoteOff {
  constructor(c, n, v) {
    super(c, n, v);
    this.id = "noteon";
    this.status = 144;
  }
};
var Aftertouch = class extends MidiMessage {
  constructor(c, n, p) {
    super();
    this.id = "aftertouch";
    this.status = 160;
    this.channel = c;
    this.note = n;
    this.pressure = p;
  }
  get note() {
    return this.data1;
  }
  set note(v) {
    this.data1 = v;
  }
  get pressure() {
    return this.data2;
  }
  set pressure(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, note: this.note, pressure: this.pressure };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, note: ${hex(this.note)}, pressure: ${hex(this.pressure)}`;
  }
};
var ControlChange = class extends MidiMessage {
  constructor(c, cc, v) {
    super();
    this.id = "cc";
    this.status = 176;
    this.channel = c;
    this.controller = cc;
    this.value = v;
  }
  get controller() {
    return this.data1;
  }
  set controller(v) {
    this.data1 = v;
  }
  get value() {
    return this.data2;
  }
  set value(v) {
    this.data2 = v;
  }
  get args() {
    return { channel: this.channel, controller: this.controller, value: this.value };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, controller: ${hex(this.controller)}, value: ${hex(this.value)}`;
  }
};
var ProgramChange = class extends MidiMessage {
  constructor(c, n) {
    super();
    this.id = "program";
    this.status = 192;
    this.channel = c;
    this.program = n;
  }
  get program() {
    return this.data1 + 1;
  }
  set program(v) {
    v--;
    this.data1 = v;
  }
  get args() {
    return { channel: this.channel, program: this.program };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, program: ${hex(this.program)}`;
  }
};
var ChannelPressure = class extends MidiMessage {
  constructor(c, p) {
    super();
    this.id = "channelpressure";
    this.status = 208;
    this.channel = c;
    this.pressure = p;
  }
  get pressure() {
    return this.data1;
  }
  set pressure(v) {
    this.data1 = v;
  }
  get args() {
    return { channel: this.channel, pressure: this.pressure };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, pressure: ${hex(this.pressure)}`;
  }
};
var PitchWheel = class extends MidiMessage {
  constructor(c, v) {
    super();
    this.id = "pitch";
    this.status = 224;
    this.channel = c;
    this.value = v;
  }
  get value() {
    return (this.data2 << 7) + this.data1;
  }
  set value(v) {
    v = MidiMessage.constrain(v, MAX_14_BIT);
    this.data2 = v >> 7 & 127;
    this.data1 = v & 127;
  }
  get args() {
    return { channel: this.channel, value: this.value };
  }
  toString() {
    return `${super.toString()}, channel: ${hex(this.channel)}, value: ${hex(this.value)}`;
  }
};
var Sysex = class extends MidiMessage {
  constructor(b) {
    super();
    this.id = "sysex";
    this.bytes = b;
  }
  get args() {
    return { bytes: this.bytes };
  }
  toString() {
    return `${super.toString()}, bytes: ${this.bytes}`;
  }
};
var Mtc = class extends MidiMessage {
  constructor(t, v) {
    super();
    this.id = "mtc";
    this.status = 241;
    this.type = t;
    this.value = v;
  }
  get type() {
    return this.data1 >> 4 & 7;
  }
  set type(v) {
    this.data1 = this.data1 & 15 | v << 4;
  }
  get value() {
    return this.data1 & 15;
  }
  set value(v) {
    v = MidiMessage.constrain(v, 15);
    this.data1 = this.data1 & 240 | v;
  }
  get args() {
    return { channel: this.channel, type: this.type, value: this.value };
  }
  toString() {
    return `${super.toString()}, type: ${hex(this.type)}, value: ${hex(this.value)}`;
  }
};

// dist/midi/midi.js
var Input2 = class extends EventEmitter2 {
  _input;
  _smpte;
  _pendingSysex;
  _sysex;
  name;
  constructor(name, virtual) {
    super();
    this._input = new node_midi.Input();
    this._input.ignoreTypes(false, false, false);
    this._pendingSysex = false;
    this._sysex = [];
    this._smpte = [];
    this.name = name;
    const inputPortNumberedNames = getInputs();
    if (virtual) {
      this._input.openVirtualPort(name);
    } else {
      const numInputs = this._input.getPortCount();
      for (let i = 0; i < numInputs; i++) {
        if (name === inputPortNumberedNames[i]) {
          try {
            this._input.openPort(i);
          } catch (err) {
            console.log(`Error opening port ${name}.
Error: ${err}`);
          }
        }
      }
    }
    this._input.on("message", (deltaTime, bytes) => {
      const msg = MidiMessage.parseMessage(bytes);
      if (msg === void 0)
        return;
      this.emit("message", deltaTime, msg);
      if (msg.id == "mtc") {
        this.parseMtc(msg);
      }
    });
  }
  close() {
    this._input.closePort();
    this._input.destroy();
  }
  isPortOpen() {
    return this._input.isPortOpen();
  }
  parseMtc(data) {
    const FRAME_RATES = [24, 25, 29.97, 30];
    const byteNumber = data.type;
    let value = data.value;
    let smpteFrameRate;
    this._smpte[byteNumber] = value;
    if (byteNumber === 7 && typeof this._smpte[0] === "number") {
      const bits = [];
      for (let i = 3; i >= 0; i--) {
        const bit = value & 1 << i ? 1 : 0;
        bits.push(bit);
      }
      value = bits[3];
      smpteFrameRate = FRAME_RATES[(bits[1] << 1) + bits[2]];
      this._smpte[byteNumber] = value;
      const smpte = this._smpte;
      const smpteFormatted = ((smpte[7] << 4) + smpte[6]).toString().padStart(2, "0") + ":" + ((smpte[5] << 4) + smpte[4]).toString().padStart(2, "0") + ":" + ((smpte[3] << 4) + smpte[2]).toString().padStart(2, "0") + "." + ((smpte[1] << 4) + smpte[0]).toString().padStart(2, "0");
      this.emit("smpte", {
        smpte: smpteFormatted,
        smpteFR: smpteFrameRate
      });
    }
  }
};
var Output2 = class {
  _output;
  name;
  constructor(name, virtual) {
    this._output = new node_midi.Output();
    this.name = name;
    const outputPortNumberedNames = getOutputs();
    if (virtual) {
      this._output.openVirtualPort(name);
    } else {
      const numOutputs = this._output.getPortCount();
      for (let i = 0; i < numOutputs; i++) {
        if (name === outputPortNumberedNames[i]) {
          try {
            this._output.openPort(i);
          } catch (err) {
            console.log(`Error opening port ${name}.
Error: ${err}`);
          }
        }
      }
    }
  }
  close() {
    this._output.closePort();
    this._output.destroy();
  }
  isPortOpen() {
    return this._output.isPortOpen();
  }
  send(msg) {
    this._output.sendMessage(msg.bytes);
  }
};
function getInputs() {
  const input = new node_midi.Input();
  const inputs = [];
  for (let i = 0; i < input.getPortCount(); i++) {
    let counter = 0;
    const portName = input.getPortName(i);
    let numberedPortName = portName;
    while (inputs.includes(numberedPortName)) {
      counter++;
      numberedPortName += ` ${counter}`;
    }
    inputs.push(numberedPortName);
  }
  input.closePort();
  return inputs;
}
function getOutputs() {
  const output = new node_midi.Output();
  const outputs = [];
  for (let i = 0; i < output.getPortCount(); i++) {
    let counter = 0;
    const portName = output.getPortName(i);
    let numberedPortName = portName;
    while (outputs.includes(numberedPortName)) {
      counter++;
      numberedPortName += ` ${counter}`;
    }
    outputs.push(numberedPortName);
  }
  output.closePort();
  return outputs;
}

// dist/config.js
function GetConfigFields() {
  const inPortNames = [];
  const outPortNames = [];
  const inPorts = getInputs();
  const outPorts = getOutputs();
  inPorts.forEach((m) => {
    inPortNames.push({ id: m, label: m });
  });
  outPorts.forEach((m) => {
    outPortNames.push({ id: m, label: m });
  });
  return [
    {
      type: "dropdown",
      id: "inPortName",
      label: "MIDI In",
      width: 6,
      default: inPorts[0] || "NONE DETECTED",
      choices: inPortNames
      //	isVisible: (opts) => !opts.inPortIsVirtual,
    },
    /*
    {
        type: 'textinput',
        id: 'inPortVirtualName',
        label: 'MIDI In',
        width: 6,
        default: '',
        isVisible: (opts) => !!opts.inPortIsVirtual,
    },
    {
        type: 'checkbox',
        id: 'inPortIsVirtual',
        label: 'Virtual',
        width: 6,
        default: false,
    },
    */
    {
      type: "dropdown",
      id: "outPortName",
      label: "MIDI Out",
      width: 6,
      default: outPorts[0] || "NONE DETECTED",
      choices: outPortNames
      //	isVisible: (opts) => !opts.outPortIsVirtual,
    },
    /*
    {
        type: 'textinput',
        id: 'outPortVirtualName',
        label: 'MIDI Out',
        width: 6,
        default: '',
        isVisible: (opts) => !!opts.outPortIsVirtual,
    },
    {
        type: 'checkbox',
        id: 'outPortIsVirtual',
        label: 'Virtual',
        width: 6,
        default: false,
    },
    {
        type: 'static-text',
        id: 'customText',
        label: 'Choose existing ports, or type a custom name to create a Virtual Port',
        width: 12,
        value: '',
    },
    */
    {
      type: "checkbox",
      id: "useTimeStamp",
      label: "Use TimeStamp with Action Recorder",
      tooltip: "Enable this setting to include the delay time for actions created in Action Recorder",
      width: 6,
      default: false
    },
    {
      type: "checkbox",
      id: "autoCreateVars",
      label: 'Enable "Auto-Created Variables function"',
      tooltip: "Enable this setting ONLY if you need compatibility with existing Auto-Created variables",
      width: 6,
      default: false
    },
    {
      type: "static-text",
      id: "autoCreateVarNotice",
      label: '*** Support for the deprecated "Auto-Created Variable" function ***',
      value: 'The "Auto-Create Variable" function has now been superceded by the built-in Local Variables feature within Companion 4.2+.<br>If you still have auto-created variables, please change them to Value Feedbacks as support for Auto-Created Variables may disappear in the future!',
      tooltip: "Enable this setting ONLY if you need compatibility with existing Auto-Created variables",
      width: 12
    }
  ];
}

// dist/variables.js
var variables = {
  midiIn: { name: "Is a MIDI Message Incoming?" },
  midiOut: { name: "Is a MIDI Message Outgoing?" },
  lastMessage: { name: "Last Message Received" },
  smpte: { name: "SMPTE TC from MTC" },
  smpteFR: { name: "SMPTE Frame Rate from MTC" },
  noteStates: { name: "Current Note states" }
};
var midiTimers = /* @__PURE__ */ new Map();
function UpdateVariableDefinitions(self) {
  self.setVariableDefinitions(variables);
  self.setVariableValues({ midiIn: false, midiOut: false });
}
function HandleMidiIndicators(self, variable) {
  let t = midiTimers.get(variable) ?? null;
  if (t !== null)
    clearTimeout(t);
  t = setTimeout(() => {
    self.setVariableValues({ [variable]: false });
    self.checkFeedbacks(variable);
  }, 200);
  midiTimers.set(variable, t);
  self.setVariableValues({ [variable]: true });
  self.checkFeedbacks(variable);
}
function UpdateLastMsg(self, msg, data) {
  const msgInfo = CreateVarName(msg);
  const lastMsg = msgInfo.name + "_" + data;
  self.setVariableValues({ lastMessage: lastMsg });
  AddOrUpdateVar(self, "lastMsgType", "Last Message Type Received", msg.id);
  if (msg.id == "noteon" || msg.id == "noteoff") {
    const noteStates = self.getVariableValue("noteStates") || [];
    noteStates[msg.channel] ??= [];
    noteStates[msg.channel][msg.args.note] = msg.id == "noteon" && data > 0;
    self.setVariableValues({ noteStates });
  }
  for (let i = 0; i < msgInfo.keys.length; i++) {
    const keyName = msgInfo.keys[i];
    const key = keyName;
    const CapKeyName = keyName[0].toUpperCase() + keyName.slice(1);
    AddOrUpdateVar(self, "last" + CapKeyName, "Last " + CapKeyName + " Received", Number(msg.args[key]));
  }
}
function FBCreatesVar(self, msg, data) {
  AddOrUpdateVar(self, "_" + CreateVarName(msg).name, "Auto-Created Variable", data);
}
function CreateVarName(msg) {
  let varName = msg.id;
  const msgKeys = Object.keys(msg.args);
  for (let i = 0; i < msgKeys.length - 1; i++) {
    const key = msgKeys[i];
    const val = Number(msg.args[key]);
    if (val !== void 0) {
      varName += `_${val}`;
    }
  }
  return { name: varName, keys: msgKeys };
}
function AddOrUpdateVar(self, varName, varDescr, data) {
  variables[varName] = { name: varDescr };
  self.setVariableDefinitions(variables);
  self.setVariableValues({ [varName]: data });
}

// dist/upgrades.js
var UpgradeScripts = [
  /*
   * Place your upgrade scripts here
   * Remember that once it has been added it cannot be removed!
   */
  function(context, props) {
    const changes = {
      updatedConfig: null,
      updatedActions: [],
      updatedFeedbacks: []
    };
    console.log("\nRunning Update Scripts...\n");
    for (const a of props.actions) {
      if (a.actionId == "program") {
        console.log("Updating action\n", a);
        a.options.program = a.options.number || a.options.program;
        delete a.options.number;
      }
      if (!a.options.chValue)
        a.options.chValue = a.options.channel;
      if (!a.options.noteValue)
        a.options.noteValue = a.options.note;
      if (!a.options.ccValue)
        a.options.ccValue = a.options.controller;
      changes.updatedActions.push(a);
      console.log("to\n", a);
    }
    for (const f of props.feedbacks) {
      if (f.feedbackId == "receive_message") {
        console.log("Updating feedback\n", f);
        f.feedbackId = String(f.options.msgType);
        delete f.options.msgType;
        switch (f.feedbackId) {
          case "program":
            f.options.program = f.options.number;
            delete f.options.number;
            break;
          case "sysex":
            f.options.bytes = f.options.message;
            delete f.options.message;
            break;
          case "pitch":
            f.options.value = f.options.pitch;
            delete f.options.pitch;
        }
      }
      if (!f.options.chValue)
        f.options.chValue = f.options.channel;
      if (!f.options.noteValue)
        f.options.noteValue = f.options.note;
      if (!f.options.ccValue)
        f.options.ccValue = f.options.controller;
      changes.updatedFeedbacks.push(f);
      console.log("to\n", f);
    }
    return changes;
  },
  function(context, props) {
    const changes = {
      updatedConfig: null,
      updatedActions: [],
      updatedFeedbacks: []
    };
    console.log("\nRunning Update Scripts...\n");
    for (const a of props.actions) {
      console.log("\nUpdating action\n", a);
      if (!a.options.sendOverTime)
        a.options.sendOverTime = { isExpression: false, value: false };
      if (!a.options.timeStartValue)
        a.options.timeStartValue = { isExpression: false, value: 0 };
      if (!a.options.time)
        a.options.time = { isExpression: false, value: 0 };
      if (!a.options.curve)
        a.options.curve = { isExpression: false, value: "linear" };
      changes.updatedActions.push(a);
      console.log("\nto\n", a);
    }
    return changes;
  }
];

// dist/operations.js
var midiMsgTypes = [
  {
    id: "noteoff",
    label: "Note Off",
    desc: "Note Off Messsage",
    valId: "velocity",
    valLabel: "Velocity",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  },
  {
    id: "noteon",
    label: "Note On",
    desc: "Note On Message",
    valId: "velocity",
    valLabel: "Velocity",
    valMin: 0,
    valMax: 127,
    valDefault: 127
  },
  //		{ id: 'aftertouch', name: 'Aftertouch' },
  {
    id: "cc",
    label: "CC",
    desc: "Control Change Message",
    valId: "value",
    valLabel: "Value",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  },
  {
    id: "program",
    label: "Program Change",
    desc: "Program Change Message",
    valId: "program",
    valLabel: "Program Number",
    valMin: 1,
    valMax: 128,
    valDefault: 1
  },
  //		{ id: 'channelpressure', 	name: 'Channel Pressure' },
  {
    id: "pitch",
    label: "Pitch Wheel",
    desc: "Pitch Wheel Message",
    valId: "value",
    valLabel: "Value",
    valMin: 0,
    valMax: 16383,
    valDefault: 8192
  },
  {
    id: "sysex",
    label: "SysEx",
    desc: "System Exclusive Message",
    valId: "bytes",
    valLabel: "SysEx Bytes",
    valMin: 0,
    valMax: 127,
    valDefault: 0
  }
  //		{ id: 'mtc', 				name: 'MIDI Time Code' },
  //		{ id: 'position',			name: 'Song Position Pointer' },
  //		{ id: 'select',				name: 'Song Select' },
  //		{ id: 'tune',				name: 'Tune Request' },
  //		{ id: 'sysex end',			name: 'SysEx End' },
  //		{ id: 'clock',				name: 'Clock' },
  //		{ id: 'start',				name: 'Start' },
  //		{ id: 'continue',			name: 'Continue' },
  //		{ id: 'stop',				name: 'Stop' },
  //		{ id: 'activesense',		name: 'Active Sensing' },
  //		{ id: 'reset',				name: 'Reset' },
];
function createOptions(newOpts, midiOp) {
  if (["noteoff", "noteon", "cc", "program", "pitch"].includes(midiOp.id)) {
    newOpts.push({
      id: "channel",
      type: "number",
      label: "Channel",
      default: 1,
      min: 1,
      max: 16
    });
  }
  if (["noteoff", "noteon"].includes(midiOp.id)) {
    newOpts.push({
      id: "note",
      type: "number",
      label: "Note Number",
      default: 60,
      min: 0,
      max: 127
    });
  }
  if (midiOp.id == "cc") {
    newOpts.push({
      id: "controller",
      type: "number",
      label: "Controller",
      default: 127,
      min: 0,
      max: 127
    });
  }
  if (midiOp.id != "sysex") {
    newOpts.push({
      id: midiOp.valId,
      type: "number",
      label: midiOp.valLabel,
      default: midiOp.valDefault,
      min: midiOp.valMin,
      max: midiOp.valMax
    });
  } else {
    newOpts.push({
      id: "bytes",
      type: "textinput",
      label: midiOp.valLabel,
      tooltip: "Enter a string of decimal or hex digits, with spaces or commas between. MUST start with 0xF0 or 240 and end with 0xF7 or 247",
      default: ""
    });
  }
  return newOpts;
}

// dist/actions.js
function UpdateActions(self) {
  self.setVariableValues({ midiOutData: false });
  const actions = {};
  for (const action of midiMsgTypes) {
    const newAction = {
      name: String(action.label),
      options: createOptions([], action),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        if (!self.config.outPortIsVirtual && !self.midiOutput.isPortOpen()) {
          self.log("error", `Output Port "${self.midiOutput.name}" not open!`);
          return;
        }
        if (action.id == "sysex") {
          const parsedSysex = await opts[action.valId];
          opts.bytes = parsedSysex.split(/[ ,]+/).map((n) => parseInt(n));
        }
        if (opts.relValue) {
          opts[action.valId] = Number(await opts.varValue);
          if (opts.chValue)
            opts.channel = Number(await opts.chValue);
          if (opts.noteValue)
            opts.note = Number(await opts.noteValue);
          if (opts.ccValue)
            opts.controller = Number(await opts.ccValue);
        }
        let msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
        if (opts.relValue) {
          const val = self.getFromDataStore(msg);
          if (val === void 0) {
            self.log("info", "Relative value not sent. Current value from device is needed!");
            return;
          }
          opts[action.valId] = val + Number(opts[action.valId] * 1);
        }
        if (opts.sendOverTime) {
          const durationMs = opts.time * 1e3;
          const curve = opts.curve;
          const tickMs = 15;
          let start = 0;
          if (opts.relValue) {
            start = self.getFromDataStore(msg) || 0;
          } else {
            start = Number(opts.timeStartValue);
          }
          let end = Number(opts[action.valId] * 1);
          if (end < 0) {
            end = 0;
          } else if (end > 127) {
            end = 127;
          }
          if (start > end) {
          }
          const t0 = Date.now();
          let last = -1;
          const easeFunctions = {
            linear: (x) => x,
            easeIn: (x) => x * x,
            easeOut: (x) => 1 - (1 - x) * (1 - x),
            easeInOut: (x) => x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2
          };
          const ease = easeFunctions[curve] || ((x) => x);
          const timer = setInterval(() => {
            const elapsed = Date.now() - t0;
            const u = Math.min(1, elapsed / durationMs);
            const val = Math.round(start + (end - start) * ease(u));
            if (val !== last) {
              opts[action.valId] = val;
              msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
              self.log("debug", `Sending:  ${msg} to "${self.midiOutput.name}"`);
              self.midiOutput.send(msg);
              HandleMidiIndicators(self, "midiOut");
              last = val;
            }
            if (u >= 1)
              clearInterval(timer);
          }, tickMs);
        } else {
          msg = MidiMessage.parseMessage(void 0, { id: action.id, ...opts });
          self.log("debug", `Sending:  ${msg} to "${self.midiOutput.name}"`);
          self.midiOutput.send(msg);
          HandleMidiIndicators(self, "midiOut");
        }
      }
    };
    if (action.id != "sysex") {
      newAction.options.at(-1).isVisibleExpression = "!$(options:relValue)";
      newAction.options.push({
        id: "varValue",
        type: "number",
        label: action.valLabel,
        default: action.valDefault,
        min: -action.valMax,
        max: action.valMax,
        isVisibleExpression: "!!$(options:relValue)"
      }, {
        id: "relText",
        type: "static-text",
        label: "** NOTE **",
        value: "Relative will only work after a value has been sent from the device!",
        isVisibleExpression: "$(options:relValue)"
      }, {
        id: "relValue",
        type: "checkbox",
        label: "Relative",
        default: false,
        disableAutoExpression: true
      });
      newAction.options.push({
        id: "sendOverTime",
        type: "checkbox",
        label: "Send Over Time",
        default: false,
        disableAutoExpression: true
      }, {
        id: "timeStartValue",
        type: "number",
        label: "Start Value",
        default: 0,
        min: 0,
        max: 127,
        isVisibleExpression: "!!$(options:sendOverTime) && !$(options:relValue)"
      }, {
        id: "time",
        type: "number",
        label: "Time (seconds)",
        default: 1,
        min: 0,
        max: 600,
        isVisibleExpression: "$(options:sendOverTime)"
      }, {
        id: "curve",
        type: "dropdown",
        label: "Curve Type",
        default: "linear",
        choices: [
          { label: "Linear", id: "linear" },
          { label: "Ease In", id: "easeIn" },
          { label: "Ease Out", id: "easeOut" },
          { label: "Ease In/Out", id: "easeInOut" }
        ],
        isVisibleExpression: "$(options:sendOverTime)"
      });
    }
    actions[action.id] = newAction;
  }
  self.setActionDefinitions(actions);
}

// dist/feedbacks.js
function UpdateFeedbacks(self) {
  const feedbacks = {};
  for (const feedback of midiMsgTypes) {
    const newFeedback = {
      name: feedback.label,
      description: feedback.desc,
      type: "boolean",
      defaultStyle: {
        bgcolor: combineRgb(255, 0, 0),
        color: combineRgb(0, 0, 0)
      },
      options: createOptions([], feedback),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        if (event.feedbackId == "sysex") {
          const parsedSysex = await opts[feedback.valId];
          opts.bytes = parsedSysex.split(/[ ,]+/).map((n) => parseInt(n));
        }
        if (opts.relValue) {
          opts[feedback.valId] = Number(await opts.varValue);
          if (opts.chValue)
            opts.channel = Number(await opts.chValue);
          if (opts.noteValue)
            opts.note = Number(await opts.noteValue);
          if (opts.ccValue)
            opts.controller = Number(await opts.ccValue);
        }
        const msg = MidiMessage.parseMessage(void 0, { id: event.feedbackId, ...opts });
        const dataStoreVal = self.getFromDataStore(msg);
        if (event.feedbackId !== "sysex" && opts.createVar && self.config.autoCreateVars && msg !== void 0)
          FBCreatesVar(self, msg, dataStoreVal);
        if (dataStoreVal == void 0)
          return false;
        if (dataStoreVal == self.getValFromMsg(msg).val) {
          return true;
        }
        return false;
      }
    };
    if (feedback.id != "sysex" && self.config.autoCreateVars) {
      newFeedback.options.at(-1).isVisibleExpression = "!$(options:createVar)";
      newFeedback.options.push({
        id: "createVar",
        type: "checkbox",
        label: "Auto-Create Variable",
        default: false,
        disableAutoExpression: true
      });
    }
    feedbacks[feedback.id] = newFeedback;
    feedbacks[feedback.id + "_value"] = {
      ...newFeedback,
      name: feedback.label + " Value",
      type: "value",
      options: newFeedback.options.filter((o) => o.id !== feedback.valId && o.id !== "createVar"),
      callback: async (event) => {
        const opts = JSON.parse(JSON.stringify(event.options));
        const msgId = event.feedbackId.replace("_value", "");
        const msg = MidiMessage.parseMessage(void 0, { id: msgId, ...opts });
        return self.getFromDataStore(msg) ?? 0;
      }
    };
  }
  feedbacks["midiIn"] = {
    name: "MIDI Message Incoming?",
    description: "Fire whenever ANY MIDI message is received",
    type: "boolean",
    defaultStyle: {
      bgcolor: combineRgb(255, 0, 0),
      color: combineRgb(0, 0, 0)
    },
    options: [],
    callback: async () => {
      return !!self.getVariableValue("midiIn");
    }
  };
  feedbacks["midiOut"] = {
    name: "MIDI Message Outgoing?",
    description: "Fire whenever ANY MIDI message is sent",
    type: "boolean",
    defaultStyle: {
      bgcolor: combineRgb(255, 0, 0),
      color: combineRgb(0, 0, 0)
    },
    options: [],
    callback: async () => {
      return !!self.getVariableValue("midiOut");
    }
  };
  self.setFeedbackDefinitions(feedbacks);
}

// dist/presets.js
function UpdatePresets(self) {
  const presets = {
    midi_in: {
      type: "simple",
      name: `MIDI Message In Indicator`,
      style: {
        text: `MIDI IN`,
        size: "auto",
        color: combineRgb(255, 255, 255),
        bgcolor: combineRgb(0, 0, 0)
      },
      steps: [],
      feedbacks: [
        {
          feedbackId: "midiIn",
          options: {},
          style: {
            color: combineRgb(255, 255, 255),
            bgcolor: combineRgb(0, 255, 0)
          }
        }
      ]
    },
    midi_out: {
      type: "simple",
      name: `MIDI Message Out Indicator`,
      style: {
        text: `MIDI OUT`,
        size: "auto",
        color: combineRgb(255, 255, 255),
        bgcolor: combineRgb(0, 0, 0)
      },
      steps: [],
      feedbacks: [
        {
          feedbackId: "midiOut",
          options: {},
          style: {
            color: combineRgb(255, 255, 255),
            bgcolor: combineRgb(0, 255, 0)
          }
        }
      ]
    }
  };
  const structure = [
    {
      id: "indicators",
      name: "Indicators",
      definitions: [
        {
          id: "midi_indicators",
          type: "simple",
          name: "MIDI Indicators",
          presets: ["midi_in", "midi_out"]
        }
      ]
    }
  ];
  self.setPresetDefinitions(structure, presets);
}

// dist/main.js
var ModuleInstance = class extends InstanceBase {
  config;
  // Setup in init()
  midiInput;
  midiOutput;
  dataStore;
  isRecordingActions;
  constructor(internal) {
    super(internal);
  }
  async init(config) {
    this.config = config;
    this.dataStore = /* @__PURE__ */ new Map();
    this.updateActions();
    this.updateFeedbacks();
    this.updatePresets();
    this.updateVariableDefinitions();
    await this.configUpdated(config);
  }
  // When module gets deleted
  async destroy() {
    this.midiInput.close();
    this.midiOutput.close();
    this.log("debug", `${this.id} destroyed`);
  }
  async configUpdated(config) {
    this.config = config;
    this.config.inPortIsVirtual = false;
    this.config.outPortIsVirtual = false;
    const inPortName = this.config.inPortIsVirtual ? this.config.inPortVirtualName : this.config.inPortName;
    const outPortName = this.config.outPortIsVirtual ? this.config.outPortVirtualName : this.config.outPortName;
    this.log("debug", `Available MIDI Inputs: ${JSON.stringify(getInputs())}
	Selected MIDI Input:  ${inPortName}`);
    this.log("debug", `Available MIDI Outputs: ${JSON.stringify(getOutputs())}
	Selected MIDI Output: ${outPortName}`);
    this.log("debug", "");
    if (this.midiInput)
      this.midiInput.close();
    if (this.midiOutput)
      this.midiOutput.close();
    this.midiInput = new Input2(inPortName, this.config.inPortIsVirtual);
    this.midiOutput = new Output2(outPortName, this.config.outPortIsVirtual);
    const midiInStatus = this.config.inPortIsVirtual || this.midiInput.isPortOpen();
    const midiOutStatus = this.config.outPortIsVirtual || this.midiOutput.isPortOpen();
    this.log("info", `Selected In  Port "${this.midiInput.name}" is ${midiInStatus ? "" : "NOT "}Open.`);
    this.log("info", `Selected Out Port "${this.midiOutput.name}" is ${midiOutStatus ? "" : "NOT "}Open.`);
    this.updateStatus(InstanceStatus.Disconnected);
    if (!midiInStatus && midiOutStatus)
      this.updateStatus(InstanceStatus.BadConfig, "MIDI In Port not open");
    if (midiInStatus && !midiOutStatus)
      this.updateStatus(InstanceStatus.BadConfig, "MIDI Out Port not open");
    if (midiInStatus && midiOutStatus)
      this.updateStatus(InstanceStatus.Ok);
    this.start();
  }
  // Return config fields for web config
  getConfigFields() {
    return GetConfigFields();
  }
  updateActions() {
    UpdateActions(this);
  }
  updateFeedbacks() {
    UpdateFeedbacks(this);
  }
  updatePresets() {
    UpdatePresets(this);
  }
  updateVariableDefinitions() {
    UpdateVariableDefinitions(this);
  }
  // The main loop
  start() {
    this.log("debug", "\nEntering *main*\n");
    this.midiInput.on("smpte", (args) => {
      this.setVariableValues({
        smpte: args.smpte,
        smpteFR: args.smpteFR
      });
    });
    this.midiInput.on("message", (deltaTime, msg) => {
      if (msg.id !== "mtc") {
        this.log("debug", `[${deltaTime.toFixed(2).padStart(6, "0")}] Received: ${msg} from "${this.midiInput.name}"`);
        this.addToDataStore(msg);
        if (this.isRecordingActions)
          this.addToActionRecording(deltaTime, msg);
      }
      HandleMidiIndicators(this, "midiIn");
    });
  }
  addToDataStore(msg) {
    const data = this.getValFromMsg(msg);
    if (data.key > 0) {
      UpdateLastMsg(this, msg, data.val);
      this.dataStore.set(data.key, data.val);
      this.checkAllFeedbacks();
    }
  }
  getFromDataStore(msg) {
    const data = this.getValFromMsg(msg);
    if (data.key > 0) {
      return this.dataStore.get(data.key);
    }
    return void 0;
  }
  getValFromMsg(msg) {
    let lastIndex = msg.bytes.length - 1;
    let parsedKey = 0;
    let parsedVal = 0;
    if (lastIndex >= 0 && msg.status < 240) {
      if (msg.id == "pitch") {
        parsedVal = msg.args.value ?? 0;
        lastIndex--;
      } else {
        parsedVal = msg.bytes[lastIndex];
      }
      for (let i = 0; i < lastIndex; i++) {
        parsedKey += msg.bytes[i] << (lastIndex - i - 1 << 3);
      }
      if (parsedKey == 0)
        parsedKey = parsedVal;
    }
    return { key: parsedKey, val: parsedVal };
  }
  // Track whether actions are being recorded
  handleStartStopRecordActions(isRecording) {
    this.isRecordingActions = isRecording;
  }
  // Add a command to the Action Recorder
  addToActionRecording(deltaTime, msg) {
    const args = { ...msg.args };
    let uniqueId = `${msg.id} ${this.getValFromMsg(msg).key}`;
    if (this.config.useTimeStamp) {
      deltaTime = Math.round(deltaTime * 1e3);
      uniqueId = "";
    } else {
      deltaTime = 0;
    }
    this.recordAction({
      actionId: msg.id,
      options: args,
      delay: deltaTime
    }, uniqueId);
  }
};
export {
  UpgradeScripts,
  ModuleInstance as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vbm9kZV9tb2R1bGVzL3BrZy1wcmVidWlsZHMvbGliL3ByZWJ1aWxkLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9wa2ctcHJlYnVpbGRzL2JpbmRpbmdzLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AanVsdXNpYW4vbWlkaS9iaW5kaW5nLW9wdGlvbnMuanMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0BqdWx1c2lhbi9taWRpL2xpYi9pbnN0cnVtZW50cy5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGp1bHVzaWFuL21pZGkvbGliL2RydW1zLmpzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AanVsdXNpYW4vbWlkaS9saWIvbm90ZXMuanMiLCAiLi4vLi4vbm9kZV9tb2R1bGVzL0BqdWx1c2lhbi9taWRpL2xpYi9tZXNzYWdlcy5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGp1bHVzaWFuL21pZGkvbWlkaS5qcyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbG9nZ2luZy50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvdXRpbC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9zaGFyZWQtdWRwLXNvY2tldC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvaG9zdC1hcGkvY29udGV4dC50cyIsICIuLi8uLi9ub2RlX21vZHVsZXMvQGNvbXBhbmlvbi1tb2R1bGUvYmFzZS9zcmMvbW9kdWxlLWFwaS9iYXNlLnRzIiwgIi4uLy4uL25vZGVfbW9kdWxlcy9AY29tcGFuaW9uLW1vZHVsZS9iYXNlL3NyYy9tb2R1bGUtYXBpL2VudW1zLnRzIiwgIi4uLy4uL3NyYy9taWRpL21pZGkudHMiLCAiLi4vLi4vc3JjL21pZGkvbXNndHlwZXMudHMiLCAiLi4vLi4vc3JjL2NvbmZpZy50cyIsICIuLi8uLi9zcmMvdmFyaWFibGVzLnRzIiwgIi4uLy4uL3NyYy91cGdyYWRlcy50cyIsICIuLi8uLi9zcmMvb3BlcmF0aW9ucy50cyIsICIuLi8uLi9zcmMvYWN0aW9ucy50cyIsICIuLi8uLi9zcmMvZmVlZGJhY2tzLnRzIiwgIi4uLy4uL3NyYy9wcmVzZXRzLnRzIiwgIi4uLy4uL3NyYy9tYWluLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJjb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJylcblxuLyoqXG4gKiBHZW5lcmF0ZSB0aGUgZmlsZW5hbWUgb2YgdGhlIHByZWJ1aWxkIGZpbGUuXG4gKiBUaGUgZm9ybWF0IG9mIHRoZSBuYW1lIGlzIHBvc3NpYmxlIHRvIGNhbGN1bGF0ZSBiYXNlZCBvbiBzb21lIG9wdGlvbnNcbiAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zXG4gKiBAcmV0dXJuc1xuICovXG5mdW5jdGlvbiBnZXRQcmVidWlsZE5hbWUob3B0aW9ucykge1xuXHRpZiAoIW9wdGlvbnMubmFwaV92ZXJzaW9uKSB0aHJvdyBuZXcgRXJyb3IoJ05BTiBub3QgaW1wbGVtZW50ZWQnKSAvLyBUT0RPXG5cblx0Y29uc3QgdG9rZW5zID0gW1xuXHRcdG9wdGlvbnMubmFtZSxcblx0XHRvcHRpb25zLnBsYXRmb3JtLFxuXHRcdG9wdGlvbnMuYXJjaCxcblx0XHQvLyBvcHRpb25zLmFybXYgPyAob3B0aW9ucy5hcmNoID09PSAnYXJtNjQnID8gJzgnIDogdmFycy5hcm1fdmVyc2lvbikgOiBudWxsLFxuXHRcdG9wdGlvbnMubGliYyAmJiBvcHRpb25zLnBsYXRmb3JtID09PSAnbGludXgnID8gb3B0aW9ucy5saWJjIDogbnVsbCxcblx0XVxuXHRyZXR1cm4gYCR7dG9rZW5zLmZpbHRlcigodCkgPT4gISF0KS5qb2luKCctJyl9LyR7b3B0aW9ucy5ydW50aW1lfS1uYXBpLXYke29wdGlvbnMubmFwaV92ZXJzaW9ufS5ub2RlYFxufVxuXG5mdW5jdGlvbiBpc053anMoKSB7XG5cdHJldHVybiAhIShwcm9jZXNzLnZlcnNpb25zICYmIHByb2Nlc3MudmVyc2lvbnMubncpXG59XG5cbmZ1bmN0aW9uIGlzRWxlY3Ryb24oKSB7XG5cdGlmIChwcm9jZXNzLnZlcnNpb25zICYmIHByb2Nlc3MudmVyc2lvbnMuZWxlY3Ryb24pIHJldHVybiB0cnVlXG5cdGlmIChwcm9jZXNzLmVudi5FTEVDVFJPTl9SVU5fQVNfTk9ERSkgcmV0dXJuIHRydWVcblx0cmV0dXJuIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHdpbmRvdy5wcm9jZXNzICYmIHdpbmRvdy5wcm9jZXNzLnR5cGUgPT09ICdyZW5kZXJlcidcbn1cblxuZnVuY3Rpb24gaXNBbHBpbmUocGxhdGZvcm0pIHtcblx0cmV0dXJuIHBsYXRmb3JtID09PSAnbGludXgnICYmIGZzLmV4aXN0c1N5bmMoJy9ldGMvYWxwaW5lLXJlbGVhc2UnKVxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0Z2V0UHJlYnVpbGROYW1lLFxuXHRpc053anMsXG5cdGlzRWxlY3Ryb24sXG5cdGlzQWxwaW5lLFxufVxuIiwgImNvbnN0IHBhdGggPSByZXF1aXJlKCdwYXRoJylcbmNvbnN0IG9zID0gcmVxdWlyZSgnb3MnKVxuY29uc3QgeyBnZXRQcmVidWlsZE5hbWUsIGlzTndqcywgaXNFbGVjdHJvbiwgaXNBbHBpbmUgfSA9IHJlcXVpcmUoJy4vbGliL3ByZWJ1aWxkJylcblxuLy8gSmVzdCBjYW4gYWxsb3cgdXNlcnMgdG8gbW9jayAnZnMnLCBidXQgd2UgbmVlZCB0aGUgcmVhbCBmc1xuY29uc3QgZnMgPSB0eXBlb2YgamVzdCAhPT0gJ3VuZGVmaW5lZCcgPyBqZXN0LnJlcXVpcmVBY3R1YWwoJ2ZzJykgOiByZXF1aXJlKCdmcycpXG5cbi8vIFdvcmthcm91bmQgdG8gZml4IHdlYnBhY2sncyBidWlsZCB3YXJuaW5nczogJ3RoZSByZXF1ZXN0IG9mIGEgZGVwZW5kZW5jeSBpcyBhbiBleHByZXNzaW9uJ1xuY29uc3QgcnVudGltZVJlcXVpcmUgPSB0eXBlb2YgX193ZWJwYWNrX3JlcXVpcmVfXyA9PT0gJ2Z1bmN0aW9uJyA/IF9fbm9uX3dlYnBhY2tfcmVxdWlyZV9fIDogcmVxdWlyZSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG5cbi8qKlxuICogRmluZCB0aGUgYmVzdCBwYXRoIHRvIHRoZSBiaW5kaW5nIGZpbGVcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYXNlUGF0aCAtIEJhc2UgcGF0aCBvZiB0aGUgbW9kdWxlLCB3aGVyZSBiaW5hcmllcyB3aWxsIGJlIGxvY2F0ZWRcbiAqIEBwYXJhbSB7b2JqZWN0fSBvcHRpb25zIC0gRGVzY3JpYmUgaG93IHRoZSBwcmVidWlsdCBiaW5hcnkgaXMgbmFtZWRcbiAqIEBwYXJhbSB7Ym9vbGVhbn0gdmVyaWZ5UHJlYnVpbGQgLSBUcnVlIGlmIHdlIGFyZSB2ZXJpZnlpbmcgdGhhdCBhIHByZWJ1aWxkIGV4aXN0c1xuICogQHBhcmFtIHtib29sZWFufSB0aHJvd09uTWlzc2luZyAtIFRydWUgaWYgYW4gZXJyb3Igc2hvdWxkIGJlIHRocm93biB3aGVuIHRoZSBiaW5hcnkgaXMgbWlzc2luZ1xuICogQHJldHVybnNcbiAqL1xuZnVuY3Rpb24gcmVzb2x2ZVBhdGgoYmFzZVBhdGgsIG9wdGlvbnMsIHZlcmlmeVByZWJ1aWxkLCB0aHJvd09uTWlzc2luZykge1xuXHRpZiAodHlwZW9mIGJhc2VQYXRoICE9PSAnc3RyaW5nJyB8fCAhYmFzZVBhdGgpIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBiYXNlUGF0aCB0byBwa2ctcHJlYnVpbGRzYClcblxuXHRpZiAodHlwZW9mIG9wdGlvbnMgIT09ICdvYmplY3QnIHx8ICFvcHRpb25zKSB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgb3B0aW9ucyB0byBwa2ctcHJlYnVpbGRzYClcblx0aWYgKHR5cGVvZiBvcHRpb25zLm5hbWUgIT09ICdzdHJpbmcnIHx8ICFvcHRpb25zLm5hbWUpIHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBuYW1lIHRvIHBrZy1wcmVidWlsZHNgKVxuXG5cdGxldCBpc05vZGVBcGkgPSBmYWxzZVxuXHRpZiAob3B0aW9ucy5uYXBpX3ZlcnNpb25zICYmIEFycmF5LmlzQXJyYXkob3B0aW9ucy5uYXBpX3ZlcnNpb25zKSkge1xuXHRcdGlzTm9kZUFwaSA9IHRydWVcblx0fVxuXG5cdGNvbnN0IGFyY2ggPSAodmVyaWZ5UHJlYnVpbGQgJiYgcHJvY2Vzcy5lbnYubnBtX2NvbmZpZ19hcmNoKSB8fCBvcy5hcmNoKClcblx0Y29uc3QgcGxhdGZvcm0gPSAodmVyaWZ5UHJlYnVpbGQgJiYgcHJvY2Vzcy5lbnYubnBtX2NvbmZpZ19wbGF0Zm9ybSkgfHwgb3MucGxhdGZvcm0oKVxuXG5cdGxldCBydW50aW1lID0gJ25vZGUnXG5cdC8vIElmIG5vZGUtYXBpLCB0aGVuIGV2ZXJ5dGhpbmcgY2FuIHNoYXJlIHRoZSBzYW1lIGJpbmFyeVxuXHRpZiAoIWlzTm9kZUFwaSkge1xuXHRcdGlmICh2ZXJpZnlQcmVidWlsZCAmJiBwcm9jZXNzLmVudi5ucG1fY29uZmlnX3J1bnRpbWUpIHtcblx0XHRcdHJ1bnRpbWUgPSBwcm9jZXNzLmVudi5ucG1fY29uZmlnX3J1bnRpbWVcblx0XHR9IGVsc2UgaWYgKGlzRWxlY3Ryb24oKSkge1xuXHRcdFx0cnVudGltZSA9ICdlbGVjdHJvbidcblx0XHR9IGVsc2UgaWYgKGlzTndqcygpKSB7XG5cdFx0XHRydW50aW1lID0gJ25vZGUtd2Via2l0J1xuXHRcdH1cblx0fVxuXG5cdGNvbnN0IGNhbmRpZGF0ZXMgPSBbXVxuXG5cdGlmICghdmVyaWZ5UHJlYnVpbGQpIHtcblx0XHQvLyBUcnkgZm9yIGEgbG9jYWxseSBidWlsdCBiaW5kaW5nXG5cdFx0Y2FuZGlkYXRlcy5wdXNoKFxuXHRcdFx0cGF0aC5qb2luKGJhc2VQYXRoLCAnYnVpbGQnLCAnRGVidWcnLCBgJHtvcHRpb25zLm5hbWV9Lm5vZGVgKSxcblx0XHRcdHBhdGguam9pbihiYXNlUGF0aCwgJ2J1aWxkJywgJ1JlbGVhc2UnLCBgJHtvcHRpb25zLm5hbWV9Lm5vZGVgKVxuXHRcdClcblx0fVxuXG5cdGxldCBsaWJjID0gdW5kZWZpbmVkXG5cdGlmIChpc0FscGluZShwbGF0Zm9ybSkpIGxpYmMgPSAnbXVzbCdcblxuXHQvLyBMb29rIGZvciBwcmVidWlsZHNcblx0aWYgKGlzTm9kZUFwaSkge1xuXHRcdC8vIExvb2sgZm9yIG5vZGUtYXBpIHZlcnNpb25lZCBidWlsZHNcblx0XHRmb3IgKGNvbnN0IHZlciBvZiBvcHRpb25zLm5hcGlfdmVyc2lvbnMpIHtcblx0XHRcdGNvbnN0IHByZWJ1aWxkTmFtZSA9IGdldFByZWJ1aWxkTmFtZSh7XG5cdFx0XHRcdG5hbWU6IG9wdGlvbnMubmFtZSxcblx0XHRcdFx0cGxhdGZvcm0sXG5cdFx0XHRcdGFyY2gsXG5cdFx0XHRcdGxpYmMsXG5cdFx0XHRcdG5hcGlfdmVyc2lvbjogdmVyLFxuXHRcdFx0XHRydW50aW1lLFxuXHRcdFx0XHQvLyBhcm12OiBvcHRpb25zLmFybXYgPyAoYXJjaCA9PT0gJ2FybTY0JyA/ICc4JyA6IHZhcnMuYXJtX3ZlcnNpb24pIDogbnVsbCxcblx0XHRcdH0pXG5cdFx0XHRjYW5kaWRhdGVzLnB1c2gocGF0aC5qb2luKGJhc2VQYXRoLCAncHJlYnVpbGRzJywgcHJlYnVpbGROYW1lKSlcblx0XHR9XG5cdH0gZWxzZSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdOb3QgaW1wbGVtZW50ZWQgZm9yIE5BTiEnKVxuXHR9XG5cblx0bGV0IGZvdW5kUGF0aCA9IG51bGxcblxuXHRmb3IgKGNvbnN0IGNhbmRpZGF0ZSBvZiBjYW5kaWRhdGVzKSB7XG5cdFx0aWYgKGZzLmV4aXN0c1N5bmMoY2FuZGlkYXRlKSkge1xuXHRcdFx0Y29uc3Qgc3RhdCA9IGZzLnN0YXRTeW5jKGNhbmRpZGF0ZSlcblx0XHRcdGlmIChzdGF0LmlzRmlsZSgpKSB7XG5cdFx0XHRcdGZvdW5kUGF0aCA9IGNhbmRpZGF0ZVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGlmICghZm91bmRQYXRoICYmIHRocm93T25NaXNzaW5nKSB7XG5cdFx0Y29uc3QgY2FuZGlkYXRlc1N0ciA9IGNhbmRpZGF0ZXMubWFwKChjYW5kKSA9PiBgIC0gJHtjYW5kfWApLmpvaW4oJ1xcbicpXG5cdFx0dGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZmluZCBiaW5kaW5nIGZvciAke29wdGlvbnMubmFtZX1cXG5UcmllZCBwYXRoczpcXG4ke2NhbmRpZGF0ZXNTdHJ9YClcblx0fVxuXG5cdHJldHVybiBmb3VuZFBhdGhcbn1cblxuZnVuY3Rpb24gbG9hZEJpbmRpbmcoYmFzZVBhdGgsIG9wdGlvbnMpIHtcblx0Y29uc3QgZm91bmRQYXRoID0gcmVzb2x2ZVBhdGgoYmFzZVBhdGgsIG9wdGlvbnMsIGZhbHNlLCB0cnVlKVxuXG5cdC8vIE5vdGU6IHRoaXMgZXJyb3Igc2hvdWxkIG5vdCBiZSBoaXQsIGFzIHJlc29sdmVQYXRoIHdpbGwgdGhyb3cgaWYgdGhlIGJpbmRpbmcgaXMgbWlzc2luZ1xuXHRpZiAoIWZvdW5kUGF0aCkgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZmluZCBiaW5kaW5nIGZvciAke29wdGlvbnMubmFtZX1gKVxuXG5cdHJldHVybiBydW50aW1lUmVxdWlyZShmb3VuZFBhdGgpXG59XG5sb2FkQmluZGluZy5yZXNvbHZlID0gcmVzb2x2ZVBhdGhcblxubW9kdWxlLmV4cG9ydHMgPSBsb2FkQmluZGluZ1xuIiwgIm1vZHVsZS5leHBvcnRzID0ge1xuICBuYW1lOiAnbWlkaScsXG4gIG5hcGlfdmVyc2lvbnM6IFs3XSxcbn1cbiIsICIvLyBHZW5lcmFsIE1JREkgcGF0Y2hlc1xubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICBBQ09VU1RJQ19HUkFORF9QSUFOTyAgICAgICAgOiAwLCBcbiAgICBCUklHSFRfQUNPVVNUSUNfUElBTk8gICAgICAgOiAxLFxuICAgIEVMRUNUUklDX0dSQU5EX1BJQU5PICAgICAgICA6IDIsXG4gICAgSE9OS1lfVE9OS19QSUFOTyAgICAgICAgICAgIDogMyxcbiAgICBFTEVDVFJJQ19QSUFOT18xXHRcdFx0OiA0LFxuICAgIEVMRUNUUklDX1BJQU5PXzIgICAgICAgICAgICA6IDUsXG4gICAgSEFSUFNJQ0hPUkQgICAgICAgICAgICAgICAgIDogNixcbiAgICBDTEFWSVx0XHRcdFx0XHQgICAgOiA3LFxuICAgIENFTEVTVEEgICBcdFx0XHRcdCAgICA6IDgsXG4gICAgR0xPQ0tFTlNQSUVMXHRcdFx0XHQ6IDksXG4gICAgTVVTSUNfQk9YXHRcdFx0XHQgICAgOiAxMCxcbiAgICBWSUJSQVBIT05FXHRcdFx0XHQgICAgOiAxMSxcbiAgICBNQVJJTUJBXHRcdFx0XHRcdCAgICA6IDEyLFxuICAgIFhZTE9QSE9ORSAgICAgICBcdFx0XHQ6IDEzLFxuICAgIFRVQlVMQVJfQkVMTFMgICAgICAgICAgICAgICA6IDE0LFxuICAgIERVTENJTUVSXHRcdFx0XHRcdDogMTUsXG4gICAgRFJBV0JBUl9PUkdBTiAgICAgICAgICAgICAgIDogMTYsXG4gICAgUEVSQ1VTU0lWRV9PUkdBTiAgICAgICAgICAgIDogMTcsXG4gICAgUk9DS19PUkdBTlx0XHRcdFx0ICAgIDogMTgsXG4gICAgQ0hVUkNIX09SR0FOXHRcdFx0XHQ6IDE5LFxuICAgIFJFRURfT1JHQU5cdFx0XHRcdCAgICA6IDIwLFxuICAgIEFDQ09SRElPTlx0XHRcdFx0ICAgIDogMjEsXG4gICAgSEFSTU9OSUNBXHRcdFx0XHQgICAgOiAyMixcbiAgICBUQU5HT19BQ0NPUkRJT04gICAgICAgICAgICAgOiAyMyxcbiAgICBBQ09VU1RJQ19HVUlUQVJfTllMT04gICAgICAgOiAyNCxcbiAgICBBQ09VU1RJQ19HVUlUQVJfU1RFRUwgICAgICAgOiAyNSxcbiAgICBFTEVDVFJJQ19HVUlUQVJfSkFaWiAgICAgICAgOiAyNixcbiAgICBFTEVDVFJJQ19HVUlUQVJfQ0xFQU4gICAgICAgOiAyNyxcbiAgICBFTEVDVFJJQ19HVUlUQVJfTVVURUQgICAgICAgOiAyOCxcbiAgICBPVkVSRFJJVkVOX0dVSVRBUlx0XHQgICAgOiAyOSxcbiAgICBESVNUT1JUSU9OX0dVSVRBUlx0XHQgICAgOiAzMCxcbiAgICBHVUlUQVJfSEFSTU9OSUNTXHRcdFx0OiAzMSxcbiAgICBBQ09VU1RJQ19CQVNTXHRcdCAgICBcdDogMzIsXG4gICAgRUxFQ1RSSUNfQkFTU19GSU5HRVJcdFx0OiAzMyxcbiAgICBFTEVDVFJJQ19CQVNTX1BJQ0tcdCAgICBcdDogMzQsXG4gICAgRlJFVExFU1NfQkFTUyAgICAgICAgICAgICAgIDogMzUsXG4gICAgU0xBUF9CQVNTXzEgICAgICAgICAgICAgICAgIDogMzYsXG4gICAgU0xBUF9CQVNTXzIgICAgICAgICAgICAgICAgIDogMzcsXG4gICAgU1lOVEhfQkFTU18xICAgICAgICAgICAgICAgIDogMzgsXG4gICAgU1lOVEhfQkFTU18yXHRcdFx0XHQ6IDM5LFxuICAgIFZJT0xJTlx0XHRcdFx0ICAgIFx0OiA0MCxcbiAgICBWSU9MQVx0XHRcdCAgICBcdFx0OiA0MSxcbiAgICBDRUxMTyBcdFx0XHQgICAgXHRcdDogNDIsXG4gICAgQ09OVFJBQkFTUyAgICAgICAgICAgICAgXHQ6IDQzLFxuICAgIFRSRU1PTE9fU1RSSU5HUyAgICAgICAgIFx0OiA0NCxcbiAgICBQSVpaSUNBVE9fU1RSSU5HU1x0ICAgIFx0OiA0NSxcbiAgICBPUkNIRVNUUkFMX0hBUlBcdFx0XHQgICAgOiA0NixcbiAgICBUSU1QQU5JICAgICAgICBcdFx0ICAgIFx0OiA0NyxcbiAgICBTVFJJTkdfRU5TRU1CTEVfMVx0XHQgICAgOiA0OCxcbiAgICBTVFJJTkdfRU5TRU1CTEVfMiAgICAgICAgICAgOiA0OSxcbiAgICBTWU5USFNUUklOR1NfMSAgICAgICAgICAgICAgOiA1MCxcbiAgICBTWU5USFNUUklOR1NfMiAgICAgICAgICAgICAgOiA1MSxcbiAgICBDSE9JUl9BQUhTXHRcdFx0ICAgIFx0OiA1MixcbiAgICBWT0lDRV9PT0hTXHRcdFx0ICAgIFx0OiA1MyxcbiAgICBTWU5USF9WT0lDRVx0XHRcdCAgICBcdDogNTQsXG4gICAgT1JDSEVTVFJBX0hJVFx0XHQgICAgXHQ6IDU1LFxuICAgIFRSVU1QRVRcdFx0XHRcdCAgICBcdDogNTYsXG4gICAgVFJPTUJPTkVcdFx0XHRcdFx0OiA1NyxcbiAgICBUVUJBXHRcdFx0XHRcdFx0OiA1OCxcbiAgICBNVVRFRF9UUlVNUEVUXHRcdCAgICBcdDogNTksXG4gICAgRlJFTkNIX0hPUk5cdFx0ICAgIFx0XHQ6IDYwLFxuICAgIEJSQVNTX1NFQ1RJT05cdCAgICBcdFx0OiA2MSxcbiAgICBTWU5USEJSQVNTXzFcdFx0XHRcdDogNjIsXG4gICAgU1lOVEhCUkFTU18yXHRcdFx0XHQ6IDYzLFxuICAgIFNPUFJBTk9fU0FYXHRcdFx0ICAgIFx0OiA2NCxcbiAgICBBTFRPX1NBWFx0XHRcdFx0XHQ6IDY1LFxuICAgIFRFTk9SX1NBWCAgICAgICAgICAgXHRcdDogNjYsXG4gICAgQkFSSVRPTkVfU0FYICAgICAgICBcdFx0OiA2NyxcbiAgICBPQk9FICAgICAgICAgICAgXHRcdFx0OiA2OCxcbiAgICBFTkdMSVNIX0hPUk4gICAgXHRcdCAgXHQ6IDY5LFxuICAgIEJBU1NPT04gICAgICAgICAgICBcdCAgICBcdDogNzAsXG4gICAgQ0xBUklORVQgICAgICAgICAgICBcdFx0OiA3MSxcbiAgICBQSUNDT0xPICAgICAgICAgICAgICBcdCAgICA6IDcyLFxuICAgIEZMVVRFICAgICAgICAgICAgICBcdCAgICBcdDogNzMsXG4gICAgUkVDT1JERVIgICAgICAgICAgIFx0XHQgICAgOiA3NCxcbiAgICBQQU5fRkxVVEVcdFx0XHQgICAgXHQ6IDc1LFxuICAgIEJMT1dOX0JPVFRMRVx0XHRcdFx0OiA3NixcbiAgICBTSEFLVUhBQ0hJXHRcdFx0ICAgIFx0OiA3NyxcbiAgICBXSElTVExFXHRcdFx0XHQgICAgXHQ6IDc4LFxuICAgIE9DQVJJTkFcdFx0XHRcdFx0ICAgIDogNzksXG4gICAgTEVBRF8xX1NRVUFSRVx0ICAgICAgICAgICAgOiA4MCxcbiAgICBMRUFEXzJfU0FXVE9PVEhcdFx0XHQgICAgOiA4MSxcbiAgICBMRUFEXzNfQ0FMTElPUEVcdFx0XHQgICAgOiA4MixcbiAgICBMRUFEXzRfQ0hJRkZcdFx0XHRcdDogODMsXG4gICAgTEVBRF81X0NIQVJBTkdcdFx0ICAgIFx0OiA4NCxcbiAgICBMRUFEXzZfVk9JQ0UgXHRcdCAgICBcdDogODUsXG4gICAgTEVBRF83X0ZJRlRIU1x0XHRcdCAgICA6IDg2LFxuICAgIExFQURfOF9CQVNTX0FORF9MRUFEXHRcdDogODcsXG4gICAgUEFEXzFfTkVXX0FHRVx0XHQgICAgXHQ6IDg4LFxuICAgIFBBRF8yX1dBUk1cdFx0XHQgICAgXHQ6IDg5LFxuICAgIFBBRF8zX1BPTFlTWU5USFx0XHQgICAgXHQ6IDkwLFxuICAgIFBBRF80X0NIT0lSXHRcdCAgICBcdFx0OiA5MSxcbiAgICBQQURfNV9CT1dFRFx0XHQgICAgXHRcdDogOTIsXG4gICAgUEFEXzZfTUVUQUxMSUNcdCAgICBcdFx0OiA5MyxcbiAgICBQQURfN19IQUxPXHRcdCAgICBcdFx0OiA5NCxcbiAgICBQQURfOF9TV0VFUFx0XHQgICAgXHRcdDogOTUsXG4gICAgRlhfMV9SQUlOXHRcdCAgICBcdFx0OiA5NixcbiAgICBGWF8yX1NPVU5EVFJBQ0tcdCAgICBcdFx0OiA5NyxcbiAgICBGWF8zX0NSWVNUQUxcdFx0XHRcdDogOTgsXG4gICAgRlhfNF9BVE1PU1BIRVJFXHQgICAgXHRcdDogOTksXG4gICAgRlhfNV9CUklHSFRORVNTXHQgICAgXHRcdDogMTAwLFxuICAgIEZYXzZfR09CTElOU1x0XHRcdFx0OiAxMDEsXG4gICAgRlhfN19FQ0hPRVNcdFx0ICAgIFx0XHQ6IDEwMixcbiAgICBGWF84X1NDSUZJXHRcdCAgICBcdFx0OiAxMDMsXG4gICAgU0lUQVJcdFx0XHQgICAgXHRcdDogMTA0LFxuICAgIEJBTkpPXHRcdFx0ICAgIFx0XHQ6IDEwNSxcbiAgICBTSEFNSVNFTlx0XHRcdFx0XHQ6IDEwNixcbiAgICBLT1RPXHRcdFx0XHRcdFx0OiAxMDcsXG4gICAgS0FMSU1CQVx0XHRcdCAgICBcdFx0OiAxMDgsXG4gICAgQkFHX1BJUEVcdFx0XHRcdFx0OiAxMDksXG4gICAgRklERExFXHRcdFx0ICAgIFx0XHQ6IDExMCxcbiAgICBTSEFOQUlcdFx0XHRcdCAgICBcdDogMTExLFxuICAgIFRJTktMRV9CRUxMXHRcdFx0ICAgIFx0OiAxMTIsXG4gICAgQUdPR09cdFx0XHRcdCAgICBcdDogMTEzLFxuICAgIFNURUVMX0RSVU1TXHRcdFx0ICAgIFx0OiAxMTQsXG4gICAgV09PREJMT0NLXHRcdFx0XHQgICAgOiAxMTUsXG4gICAgVEFJS09fRFJVTSAgXHRcdFx0XHQ6IDExNixcbiAgICBNRUxPRElDX1RPTVx0ICAgIFx0XHRcdDogMTE3LFxuICAgIFNZTlRIX0RSVU1cdFx0ICAgIFx0XHQ6IDExOCxcbiAgICBSRVZFUlNFX0NZTUJBTFx0XHQgICAgXHQ6IDExOSxcbiAgICBHVUlUQVJfRlJFVF9OT0lTRVx0XHQgICAgOiAxMjAsXHRcbiAgICBCUkVBVEhfTk9JU0VcdFx0XHRcdDogMTIxLFxuICAgIFNFQVNIT1JFXHRcdFx0XHRcdDogMTIyLFxuICAgIEJJUkRfVFdFRVRcdFx0ICAgIFx0XHQ6IDEyMyxcbiAgICBURUxFUEhPTkVfUklOR1x0XHQgICAgXHQ6IDEyNCxcbiAgICBIRUxJQ09QVEVSXHRcdFx0XHQgICAgOiAxMjUsXG4gICAgQVBQTEFVU0VcdFx0XHRcdFx0OiAxMjYsXG4gICAgR1VOU0hPVCAgICAgICAgICAgICAgICAgICAgIDogMTI3LFxufTtcbiIsICIvLyBHZW5lcmFsIE1JREkgZHJ1bSBwYXRjaGVzLCB0cmFjayAxMFxubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICBBQ09VU1RJQ19CQVNTX0RSVU1cdCAgICA6IDM1LFxuICAgIEJBU1NfRFJVTVx0XHRcdFx0OiAzNixcbiAgICBTSURFX1NUSUNLXHRcdFx0ICAgIDogMzcsXG4gICAgQUNPVVNUSUNfU05BUkVcdFx0ICAgIDogMzgsXG4gICAgSEFORF9DTEFQXHRcdFx0XHQ6IDM5LFxuICAgIEVMRUNUUklDX1NOQVJFXHRcdCAgICA6IDQwLFxuICAgIExPV19GTE9PUl9UT01cdFx0XHQ6IDQxLFxuICAgIENMT1NFRF9ISV9IQVRcdFx0XHQ6IDQyLFxuICAgIEhJR0hfRkxPT1JfVE9NXHRcdCAgICA6IDQzLFxuICAgIFBFREFMX0hJX0hBVFx0XHRcdDogNDQsXG4gICAgTE9XX1RPTVx0XHRcdFx0ICAgIDogNDUsXG4gICAgT1BFTl9ISV9IQVRcdCAgICBcdFx0OiA0NixcbiAgICBMT1dfTUlEX1RPTVx0ICAgIFx0XHQ6IDQ3LFxuICAgIEhJX01JRF9UT01cdCAgICBcdFx0OiA0OCxcbiAgICBDUkFTSF9DWU1CQUxfMVx0ICAgIFx0OiA0OSxcbiAgICBISUdIX1RPTVx0XHRcdFx0OiA1MCxcbiAgICBSSURFX0NZTUJBTF8xXHRcdFx0OiA1MSxcbiAgICBDSElORVNFX0NZTUJBTFx0ICAgIFx0OiA1MixcbiAgICBSSURFX0JFTExcdFx0XHRcdDogNTMsXG4gICAgVEFNQk9VUklORVx0XHQgICAgXHQ6IDU0LFxuICAgIFNQTEFTSF9DWU1CQUxcdFx0XHQ6IDU1LFxuICAgIENPV0JFTExcdFx0XHQgICAgXHQ6IDU2LFxuICAgIENSQVNIX0NZTUJBTF8yXHQgICAgXHQ6IDU3LFxuICAgIFZJQlJBX1NMQVBcdFx0ICAgIFx0OiA1OCxcbiAgICBSSURFX0NZTUJBTF8yXHRcdFx0OiA1OSxcbiAgICBISV9CT05HT1x0XHRcdFx0OiA2MCxcbiAgICBMT1dfQk9OR09cdFx0XHRcdDogNjEsXG4gICAgTVVURV9ISV9DT05HQVx0XHRcdDogNjIsXG4gICAgT1BFTl9ISV9DT05HQVx0XHRcdDogNjMsXG4gICAgTE9XX0NPTkdBXHRcdFx0XHQ6IDY0LFxuICAgIEhJR0hfVElNQkFMRVx0XHRcdDogNjUsXG4gICAgTE9XX1RJTUJBTEVcdCAgICBcdFx0OiA2NixcbiAgICBISUdIX0FHT0dPXHRcdCAgICBcdDogNjcsXG4gICAgTE9XX0FHT0dPXHRcdFx0XHQ6IDY4LFxuICAgIENBQkFTQVx0XHRcdCAgICBcdDogNjksXG4gICAgTUFSQUNBU1x0XHRcdCAgICBcdDogNzAsXG4gICAgU0hPUlRfV0hJU1RMRVx0XHRcdDogNzEsXG4gICAgTE9OR19XSElTVExFXHRcdFx0OiA3MixcbiAgICBTSE9SVF9HVUlST1x0XHQgICAgXHQ6IDczLFxuICAgIExPTkdfR1VJUk9cdFx0ICAgIFx0OiA3NCxcbiAgICBDTEFWRVNcdFx0XHQgICAgXHQ6IDc1LFxuICAgIEhJX1dPT0RfQkxPQ0tcdFx0XHQ6IDc2LFxuICAgIExPV19XT09EX0JMT0NLXHQgICAgXHQ6IDc3LFxuICAgIE1VVEVfQ1VJQ0FcdFx0ICAgIFx0OiA3OCxcbiAgICBPUEVOX0NVSUNBXHRcdCAgICBcdDogNzksXG4gICAgTVVURV9UUklBTkdMRVx0XHRcdDogODAsXG4gICAgT1BFTl9UUklBTkdMRVx0XHRcdDogODEsXG59O1xuIiwgIi8vIE1JREkgbm90ZXNcbm1vZHVsZS5leHBvcnRzID0ge1xuXG4gICAgLypcbiAgICAqKiBUaGUgTUlESSBzcGVjIG9ubHkgaW5kaWNhdGVzIG1pZGRsZSBDIHRvIGJlXG4gICAgKiogNjAuIEl0IGRvZXNuJ3QgaW5kaWNhdGUgd2hpY2ggb2N0YXZlIHRoaXMgaXMuXG4gICAgKiogU29tZSBtYXkgY29uc2lkZXIgNCwgaWYgdGhleSBsYWJlbCBvY3RhdmVzIFxuICAgICoqIGZyb20gLTEsIGluc3RlYWQgb2YgMC4gSSBoYXZlIGFkb3B0ZWQgb24gb2N0YXZlXG4gICAgKiogbnVtYmVyIEMgaGVyZS5cbiAgICAqL1xuICAgIE1JRERMRV9DIDogNjAsXG4gICAgXG4gICAgLy8gUmVsYXRpdmUgb2Zmc2V0c1xuICAgIENcdFx0OiAwLFxuICAgIENfU0hBUlAgOiAxLFxuICAgIENfRkxBVFx0OiAtMSxcbiAgICBEXHRcdDogMixcbiAgICBEX1NIQVJQIDogMyxcbiAgICBEX0ZMQVQgIDogMSxcbiAgICBFXHRcdDogNCxcbiAgICBFX1NIQVJQIDogNSxcbiAgICBFX0ZMQVQgIDogMyxcbiAgICBGXHRcdDogNSxcbiAgICBGX1NIQVJQIDogNixcbiAgICBGX0ZMQVQgIDogNCxcbiAgICBHXHRcdDogNyxcbiAgICBHX1NIQVJQIDogOCxcbiAgICBHX0ZMQVQgIDogNixcbiAgICBBXHRcdDogOSxcbiAgICBBX1NIQVJQIDogMTAsXG4gICAgQV9GTEFUICA6IDgsXG4gICAgQlx0XHQ6IDExLFxuICAgIEJfU0hBUlAgOiAxMixcbiAgICBCX0ZMQVQgIDogMTAsXG5cbiAgICAvLyBGb3IgdGhlIG9jdGF2ZXNcbiAgICBDMFx0OiAwLCBcbiAgICBDMVx0OiAxMixcbiAgICBDMlx0OiAyNCxcbiAgICBDM1x0OiAzNixcbiAgICBDNFx0OiA0OCxcbiAgICBDNVx0OiA2MCxcbiAgICBDNlx0OiA3MixcbiAgICBDN1x0OiA4NCxcbiAgICBDOFx0OiA5NixcbiAgICBDOVx0OiAxMDgsXG4gICAgQzEwXHQ6IDEyMCxcblxufTtcblxuIiwgIi8vIE1JREkgbWVzc2FnZXNcbm1vZHVsZS5leHBvcnRzID0ge1xuXG4gICAgLy8gQWxsIGJhc2ljIG1lc3NhZ2VzIGFyZSBoZWxkIGluIHRoZSByb290LCBiZWNhdXNlIG9mIGhvdyBjb21tb25seSB0aGV5J3JlXG4gICAgLy8gdXNlZC4gTHVja2lseSwgdGhlcmUncyBubyBuYW1lIGNsYXNoZXMgd2l0aCBzdWItbmFtZXNcbiAgICBOT1RFX09GRjogICAgICAgICAgIDB4ODAsXHRcdC8qIFsgcGl0Y2gsIHZvbHVtZSBdICovXG4gICAgTk9URV9PTjogICAgICAgICAgICAweDkwLFx0XHQvKiBbIHBpdGNoLCB2b2x1bWUgXSAqL1xuICAgIE5PVEVfS0VZX1BSRVNTVVJFOiAgMHhhMCxcdFx0LyogWyBwaXRjaCwgcHJlc3N1cmUgKGFmdGVyIHRvdWNoKSBdICovXG4gICAgU0VUX1BBUkFNRVRFUjogICAgICAweGIwLFx0XHQvKiBbIHBhcmFtIG51bWJlciAoQ0MpLCBzZXR0aW5nIF0gKi9cbiAgICBTRVRfUFJPR1JBTTogICAgICAgIDB4YzAsXHRcdC8qIFsgcHJvZ3JhbSBdICovXG4gICAgQ0hBTkdFX1BSRVNTVVJFOiAgICAweGQwLFx0XHQvKiBbIHByZXNzdXJlIChhZnRlciB0b3VjaCkgXSAqL1xuICAgIFNFVF9QSVRDSFdIRUVMOiAgICAgMHhlMCxcdFx0LyogWyBMU0IsICBNU0IgKHR3byA3IGJpdCB2YWx1ZXMpIF0gKi9cbiAgICBcbiAgICBNRVRBRVZFTlQ6ICAgICAgICAgIDB4ZmYsXG4gICAgU1lTX0VYMTogICAgICAgICAgICAweGYwLFxuICAgIFNZU19FWDI6ICAgICAgICAgICAgMHhmNyxcblxuICAgIC8qIEFsdGVybmF0aXZlIG5hbWVzICovXG4gICAgUEFUQ0hfQ0hBTkdFOiAgICAgICAweGMwLCAgICAgICAvKiBFcXVpdmFsZW50IHRvIFNFVF9QUk9HUkFNICovXG4gICAgQ09OVFJPTF9DSEFOR0U6ICAgICAweGIwLCAgICAgICAvKiBFcXVpdmFsZW50IHRvIFNFVF9QQVJBTUVURVIgKi9cblxuICAgIFNZU01BU0s6ICAgICAgICAgICAgMHhmMCxcblxuXG4gICAgLy8gQ29udHJvbCBjaGFuZ2VzXG4gICAgY2M6IHtcblx0XHQvKiAwLTMxLCB3aGVyZSBkZWZpbmVkLCBhbGwgaW5kaWNhdGUgdGhlIE1TQiAqL1xuXHRcdEJBTktfU0VMRUNUOlx0XHQgICAgMCxcblx0XHRNT0RVTEFUSU9OOiAgICAgICAgICAgICAxLFxuXHRcdEJSRUFUSF9DT05UUk9MOiAgICAgICAgIDIsXG5cdFx0VU5ERUZJTkVEXzM6ICAgICAgICAgICAgMyxcblx0XHRGT09UX0NPTlRST0w6ICAgICAgICAgICA0LFxuXHRcdFBPUlRBTUVOVE9fVElNRTogICAgICAgIDUsXG5cdFx0REFURV9FTlRSWTogICAgICAgICAgICAgNixcblx0XHRWT0xVTUU6ICAgICAgICAgICAgICAgICA3LFxuXHRcdEJBTEFOQ0U6ICAgICAgICAgICAgICAgIDgsXG5cdFx0VU5ERUZJTkVEXzk6ICAgICAgICAgICAgOSxcblx0XHRQQU46ICAgICAgICAgICAgICAgICAgICAxMCxcblx0XHRFWFBSRVNTSU9OOiAgICAgICAgICAgICAxMSxcblx0XHRFRkZFQ1RfQ09OVFJPTF8xOiAgICAgICAxMixcblx0XHRFRkZFQ1RfQ09OVFJPTF8yOiAgICAgICAxMyxcblx0XHRVTkRFRklORURfMTQ6ICAgICAgICAgICAxNCxcblx0XHRVTkRFRklORURfMTU6ICAgICAgICAgICAxNSxcblx0XHRHRU5FUkFMX1BVUlBPU0VfMTogICAgICAxNixcblx0XHRHRU5FUkFMX1BVUlBPU0VfMjpcdFx0MTcsXG5cdFx0R0VORVJBTF9QVVJQT1NFXzM6XHRcdDE4LFxuXHRcdEdFTkVSQUxfUFVSUE9TRV80Olx0XHQxOSxcblxuICAgICAgICAvKiAyMC0zMSBhcmUgdW5kZWZpbmVkICovXG5cdFx0VU5ERUZJTkVEXzIwOiAgICAgICAgICAgMjAsXG5cdFx0VU5ERUZJTkVEXzIxOiAgICAgICAgICAgMjEsXG5cdFx0VU5ERUZJTkVEXzIyOiAgICAgICAgICAgMjIsXG5cdFx0VU5ERUZJTkVEXzIzOiAgICAgICAgICAgMjMsXG5cdFx0VU5ERUZJTkVEXzI0OiAgICAgICAgICAgMjQsXG5cdFx0VU5ERUZJTkVEXzI1OiAgICAgICAgICAgMjUsXG5cdFx0VU5ERUZJTkVEXzI2OiAgICAgICAgICAgMjYsXG5cdFx0VU5ERUZJTkVEXzI3OiAgICAgICAgICAgMjcsXG5cdFx0VU5ERUZJTkVEXzI4OiAgICAgICAgICAgMjgsXG5cdFx0VU5ERUZJTkVEXzI5OiAgICAgICAgICAgMjksXG5cdFx0VU5ERUZJTkVEXzMwOiAgICAgICAgICAgMzAsXG5cdFx0VU5ERUZJTkVEXzMxOiAgICAgICAgICAgMzEsXG5cbiAgICAgICAgLyogTFNCIGZvciBjb250cm9sIGNoYW5nZXMgMC0zMVx0XHQzMi02MyAqL1xuXHRcdEJBTktfU0VMRUNUX0xTQjpcdFx0MzIsXG4gICAgICAgIE1PRFVMQVRJT05fTFNCOiAgICAgICAgIDMzLFxuICAgICAgICBCUkVBVEhfQ09OVFJPTF9MU0I6ICAgICAzNCxcblx0XHRVTkRFRklORURfMzU6ICAgICAgICAgICAzNSxcbiAgICAgICAgRk9PVF9DT05UUk9MX0xTQjogICAgICAgMzYsXG4gICAgICAgIFBPUlRBTUVOVE9fVElNRV9MU0I6ICAgIDM3LFxuICAgICAgICBEQVRBX0VOVFJZX0xTQjogICAgICAgICAzOCxcbiAgICAgICAgVk9MVU1FX0xTQjogICAgICAgICAgICAgMzksXG4gICAgICAgIEJBTEFOQ0VfTFNCOiAgICAgICAgICAgIDQwLFxuXHRcdFVOREVGSU5FRF80MTogICAgICAgICAgIDQxLFxuICAgICAgICBQQU5fTFNCOiAgICAgICAgICAgICAgICA0MixcbiAgICAgICAgRVhQUkVTU0lPTl9MU0I6ICAgICAgICAgNDMsXG4gICAgICAgIEVGRkVDVF9DT05UUk9MXzFfTFNCOiAgIDQ0LFxuICAgICAgICBFRkZFQ1RfQ09OVFJPTF8yX0xTQjogICA0NSxcblxuICAgICAgICBVTkRFRklORURfNDY6ICAgICAgICAgICA0Nixcblx0XHRVTkRFRklORURfNDc6ICAgICAgICAgICA0NyxcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzFfTFNCOiAgNDgsXG4gICAgICAgIEdFTkVSQUxfUFVSUE9TRV8yX0xTQjogIDQ5LFxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfM19MU0I6ICA1MCxcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzRfTFNCOiAgNTEsXG5cbiAgICAgICAgLyogNTItNjMgYXJlIHVuZGVmaW5lZCAqL1xuXHRcdFVOREVGSU5FRF81MjogICAgICAgICAgIDUyLFxuXHRcdFVOREVGSU5FRF81MzogICAgICAgICAgIDUzLFxuXHRcdFVOREVGSU5FRF81NDogICAgICAgICAgIDU0LFxuXHRcdFVOREVGSU5FRF81NTogICAgICAgICAgIDU1LFxuXHRcdFVOREVGSU5FRF81NjogICAgICAgICAgIDU2LFxuXHRcdFVOREVGSU5FRF81NzogICAgICAgICAgIDU3LFxuXHRcdFVOREVGSU5FRF81ODogICAgICAgICAgIDU4LFxuXHRcdFVOREVGSU5FRF81OTogICAgICAgICAgIDU5LFxuXHRcdFVOREVGSU5FRF82MDogICAgICAgICAgIDYwLFxuXHRcdFVOREVGSU5FRF82MTogICAgICAgICAgIDYxLFxuXHRcdFVOREVGSU5FRF82MjogICAgICAgICAgIDYyLFxuXHRcdFVOREVGSU5FRF82MzogICAgICAgICAgIDYzLFxuXG4gICAgICAgIFNVU1RBSU5fUEVEQUw6ICAgICAgICAgIDY0LFxuXHRcdFBPUlRBTUVOVE86ICAgICAgICAgICAgIDY1LFxuICAgICAgICBQRURBTF9TVVNURU5VVE86ICAgICAgICA2NixcbiAgICAgICAgUEVEQUxfU09GVDogICAgICAgICAgICAgNjcsXG4gICAgICAgIExFR0FUT19GT09UX1NXSVRDSDogICAgIDY4LFxuXHRcdEhPTERfMjogICAgICAgICAgICAgICAgIDY5LFxuICAgICAgICBTT1VORF9WQVJJQVRJT046ICAgICAgICA3MCxcblx0XHRUSU1CUkU6ICAgICAgICAgICAgICAgICA3MSxcbiAgICAgICAgUkVMRUFTRV9USU1FOiAgICAgICAgICAgNzIsXG5cdFx0QVRUQUNLVElNRTogICAgICAgICAgICAgNzMsXG4gICAgICAgIEJSSUdIVE5FU1M6ICAgICAgICAgICAgIDc0LFxuXHRcdFJFVkVSQjogICAgICAgICAgICAgICAgIDc1LFxuXHRcdERFTEFZOiAgICAgICAgICAgICAgICAgIDc2LFxuICAgICAgICBQSVRDSF9UUkFOU1BPU0U6ICAgICAgICA3Nyxcblx0XHRGTEFOR0U6ICAgICAgICAgICAgICAgICA3OCxcbiAgICAgICAgU1BFQ0lBTF9GWDogICAgICAgICAgICAgNzksXG5cbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzVfTFNCOiAgODAsXG4gICAgICAgIEdFTkVSQUxfUFVSUE9TRV82X0xTQjogIDgxLFxuICAgICAgICBHRU5FUkFMX1BVUlBPU0VfN19MU0I6ICA4MixcbiAgICAgICAgR0VORVJBTF9QVVJQT1NFXzhfTFNCOiAgODMsXG5cbiAgICAgICAgUE9SVEFNRU5UT19DT05UUk9MOiAgICAgODQsXG5cbiAgICAgICAgLyogODUtOTAgYXJlIHVuZGVmaW5lZCAqL1xuXHRcdFVOREVGSU5FRF84NTogICAgICAgICAgIDg1LFxuXHRcdFVOREVGSU5FRF84NjogICAgICAgICAgIDg2LFxuXHRcdFVOREVGSU5FRF84NzogICAgICAgICAgIDg3LFxuXHRcdFVOREVGSU5FRF84ODogICAgICAgICAgIDg4LFxuXHRcdFVOREVGSU5FRF84OTogICAgICAgICAgIDg5LFxuXHRcdFVOREVGSU5FRF85MDogICAgICAgICAgIDkwLFxuXG4gICAgICAgIC8qIEVmZmVjdHMgZGVwdGggKi9cblx0XHRGWF9ERVBUSDogICAgICAgICAgICAgICA5MSxcblx0XHRUUkVNRUxPX0RFUFRIOiAgICAgICAgICA5MixcbiAgICAgICAgQ0hPUlVTX0RFUFRIOiAgICAgICAgICAgOTMsXG4gICAgICAgIENFTEVTVEFfREVQVEg6ICAgICAgICAgIDk0LFxuICAgICAgICBQSEFTRVJfREVQVEg6ICAgICAgICAgICA5NSxcblx0XHREQVRBX0lOQzogICAgICAgICAgICAgICA5Nixcblx0XHREQVRBX0RFQzogICAgICAgICAgICAgICA5NyxcbiAgICAgICAgTk9OX1JFR19QQVJBTV9MU0I6ICAgICAgOTgsXG4gICAgICAgIE5PTl9SRUdfUEFSQU1fTVNCOiAgICAgIDk5LFxuICAgICAgICBSRUdfUEFSQU1fTFNCOiAgICAgICAgICAxMDAsXG4gICAgICAgIFJFR19QQVJBTV9NU0I6ICAgICAgICAgIDEwMSxcblxuICAgICAgICAvKiAxMDItMTE5IGFyZSB1bmRlZmluZWQgKi9cblx0XHRVTkRFRklORURfMTAyOiAgICAgICAgICAxMDIsXG5cdFx0VU5ERUZJTkVEXzEwMzogICAgICAgICAgMTAzLFxuXHRcdFVOREVGSU5FRF8xMDQ6ICAgICAgICAgIDEwNCxcblx0XHRVTkRFRklORURfMTA1OiAgICAgICAgICAxMDUsXG5cdFx0VU5ERUZJTkVEXzEwNjogICAgICAgICAgMTA2LFxuXHRcdFVOREVGSU5FRF8xMDc6ICAgICAgICAgIDEwNyxcblx0XHRVTkRFRklORURfMTA4OiAgICAgICAgICAxMDgsXG5cdFx0VU5ERUZJTkVEXzEwOTogICAgICAgICAgMTA5LFxuXHRcdFVOREVGSU5FRF8xMTA6ICAgICAgICAgIDExMCxcblx0XHRVTkRFRklORURfMTExOiAgICAgICAgICAxMTEsXG5cdFx0VU5ERUZJTkVEXzExMjogICAgICAgICAgMTEyLFxuXHRcdFVOREVGSU5FRF8xMTM6ICAgICAgICAgIDExMyxcblx0XHRVTkRFRklORURfMTE0OiAgICAgICAgICAxMTQsXG5cdFx0VU5ERUZJTkVEXzExNTogICAgICAgICAgMTE1LFxuXHRcdFVOREVGSU5FRF8xMTY6ICAgICAgICAgIDExNixcblx0XHRVTkRFRklORURfMTE3OiAgICAgICAgICAxMTcsXG5cdFx0VU5ERUZJTkVEXzExODogICAgICAgICAgMTE4LFxuXHRcdFVOREVGSU5FRF8xMTk6ICAgICAgICAgIDExOSxcblxuICAgICAgICAvLyBNb2Rlc1xuICAgICAgICBBTExfU09VTkRfT0ZGOiAgICAgICAgICAxMjAsXG4gICAgICAgIFJFU0VUX0FMTF9DT05UUk9MTEVSUzogIDEyMSxcblx0XHRMT0NBTF9DT05UUk9MOiAgICAgICAgICAxMjIsXG4gICAgICAgIEFMTF9OT1RFU19PRkY6ICAgICAgICAgIDEyMyxcblx0XHRPTU5JX01PREVfT0ZGOiAgICAgICAgICAxMjQsXG5cdFx0T01OSV9NT0RFX09OOiAgICAgICAgICAgMTI1LFxuXHRcdE1PTk9fTU9ERV9PTjogICAgICAgICAgIDEyNixcblx0XHRQT0xZX01PREVfT046ICAgICAgICAgICAxMjcsXG5cblx0XHQvKiBBbHRlcm5hdGl2ZSBuYW1lcyAqL1xuXHRcdE1PRF9XSEVFTDogICAgICAgICAgICAgIDEsXG5cblx0XHQvKiBBbGwgc291bmQgY29udHJvbGxlcnMgaGF2ZSBvbmx5IExTQiAqL1xuXHRcdEhBUk1fQ09OVEVOVDogICAgICAgICAgIDcxLFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzE6ICAgICA3MCxcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl8yOiAgICAgNzEsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfMzogICAgIDcyLFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzQ6ICAgICA3MyxcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl81OiAgICAgNzQsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfNjogICAgIDc1LFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzc6ICAgICA3NixcbiAgICAgICAgU09VTkRfQ09OVFJPTExFUl84OiAgICAgNzcsXG4gICAgICAgIFNPVU5EX0NPTlRST0xMRVJfOTogICAgIDc4LFxuICAgICAgICBTT1VORF9DT05UUk9MTEVSXzEwOiAgICA3OSxcblxuICAgICAgICBFRkZFQ1RfMV9ERVBUSDogICAgICAgICA5MSxcblx0XHRFRkZFQ1RfMl9ERVBUSDogICAgICAgICA5Mixcblx0XHRFRkZFQ1RfM19ERVBUSDogICAgICAgICA5Myxcblx0XHRFRkZFQ1RfNF9ERVBUSDogICAgICAgICA5NCxcblx0XHRFRkZFQ1RfNV9ERVBUSDogICAgICAgICA5NSxcblxuICAgICAgICBERVRVTkVfREVQVEg6ICAgICAgICAgICA5NCxcbiAgICB9LFxuXG5cbiAgICAvKlxuICAgICoqIFN5c3RlbSBDb21tb24gKFN0YXR1cyBieXRlOiAxMTExIDB0dHQpXG4gICAgKi9cbiAgICBzeXNjb21tb246IHtcbiAgICAgICAgVU5ERUZJTkVEXzE6ICAgICAgICAgICAgMHhmMSxcbiAgICAgICAgU09OR19QT1NJVElPTjogICAgICAgICAgMHhmMiwgLyogW0xTQiwgTVNCXSAqL1xuICAgICAgICBTT05HX1NFTEVDVDogICAgICAgICAgICAweGYzLFxuICAgICAgICBVTkRFRklORURfNDogICAgICAgICAgICAweGY0LFxuICAgICAgICBVTkRFRklORURfNTogICAgICAgICAgICAweGY1LFxuICAgICAgICBUVU5FX1JFUVVFU1Q6ICAgICAgICAgICAweGY2LFxuICAgICAgICBFT1g6ICAgICAgICAgICAgICAgICAgICAweGY3LCAvKiBFbmQgb2YgRXhjbHVzaXZlICovXG4gICAgfSxcblxuXG4gICAgLypcbiAgICAqKiBTeXN0ZW0gUmVhbCBUaW1lIChTdGF0dXMgYnl0ZTogMTExMSAxdHR0KVxuICAgICovXG4gICAgcmVhbHRpbWU6IHtcbiAgICAgICAgVElNSU5HX0NMT0NLOiAgIDB4ZjgsXG4gICAgICAgIFVOREVGSU5FRF9GOTogICAweGY5LFxuICAgICAgICBTVEFSVDogICAgICAgICAgMHhmYSxcbiAgICAgICAgQ09OVElOVUU6ICAgICAgIDB4ZmIsXG4gICAgICAgIFNUT1A6ICAgICAgICAgICAweGZjLFxuICAgICAgICBVTkRFRklORURfRkQ6ICAgMHhmZCxcbiAgICAgICAgQUNUSVZFX1NFTlNJTkc6IDB4ZmUsXG4gICAgICAgIFNZU1RFTV9SRVNFVDogICAweGZmLFxuICAgIH0sXG5cblxuICAgIC8qXG4gICAgKiogU3lzdGVtIEV4Y2x1c2l2ZSAoU3RhdHVzIGJ5dGU6IDExMTEgMDAwMClcbiAgICAqKlxuICAgICoqIFRoZSBmaXJzdCBieXRlIG9mIGEgc3lzZXggbXVzdCBiZSB0aGUgaWRlbnRpZmljYXRpb24gbnVtYmVyXG4gICAgKiogKDcgYml0cywgTVNCPTApLiBUaGlzIGlzIGZvbGxvd2VkIGJ5IGFuIGFyYml0YXJ5IG51bWJlciBvZlxuICAgICoqIGRhdGEgYnl0ZXMgKGFsbCBNU0I9MCksIGFuZCBlbmRpbmcgaW4gdGhlIHNleEVPWCBtc2cuXG4gICAgKiogTm90ZTogQW55IG90aGVyIHN0YXR1cyBieXRlICh3aGVyZSBNU0I9MSkgd2lsbCBhbHNvIHRlcm1pbmF0ZVxuICAgICoqIGEgc3lzZXggbWVzc2FnZSwgd2l0aCB0aGUgZXhjZXB0aW9uIG9mIHRoZSBTeXN0ZW0gUmVhbCBUaW1lXG4gICAgKiogZXZlbnRzIGFib3ZlLlxuICAgICovXG4gICAgc3lzZXg6IHtcbiAgICAgICAgRU9YOiAgICAgICAgICAgICAgICAgICAgMHhmNywgLyogRW5kIG9mIEV4Y2x1c2l2ZSAqL1xuICAgIH0sXG5cbn07XG4iLCAiY29uc3QgbWlkaSA9IHJlcXVpcmUoXCJwa2ctcHJlYnVpbGRzL2JpbmRpbmdzXCIpKFxuICBfX2Rpcm5hbWUsXG4gIHJlcXVpcmUoXCIuL2JpbmRpbmctb3B0aW9uc1wiKVxuKTtcbmNvbnN0IFN0cmVhbSA9IHJlcXVpcmUoJ3N0cmVhbScpO1xuXG4vLyBNSURJIGlucHV0IGluaGVyaXRzIGZyb20gRXZlbnRFbWl0dGVyXG5jb25zdCB7IEV2ZW50RW1pdHRlciB9ID0gcmVxdWlyZSgnZXZlbnRzJyk7XG5cbi8vIEJyaW5nIGluIHRoZSBzZXQgb2YgY29uc3RhbnRzIHRvIHJlZmxlY3QgTUlESSBtZXNzYWdlcyBhbmQgdGhlaXJcbi8vIHBhcmFtZXRlcnMsIHRvIGVsaW1pbmF0ZSB0aGUgbmVlZCBmb3IgbWFnaWMgbnVtYmVycy5cbi8qKiBBbiBpbnN0cnVtZW50IGxpc3QsIG9ubHkgdmFsaWQgaW4gdGhlIEdlbmVyYWwgTUlESSBzdGFuZGFyZCAqL1xuY29uc3QgSW5zdHJ1bWVudHMgPSByZXF1aXJlKCcuL2xpYi9pbnN0cnVtZW50cycpO1xuLyoqIEEgZHJ1bSBtYXAsIG9ubHkgdmFsaWQgaW4gdGhlIEdlbmVyYWwgTUlESSBzdGFuZGFyZCAqL1xuY29uc3QgRHJ1bXMgPSByZXF1aXJlKCcuL2xpYi9kcnVtcycpO1xuLyoqIE5vdGUgZGVzY3JpcHRpb25zLCB3aXRoIE1pZGRsZSBDID0gQzUgPSBNSURJIG5vdGUgNjAgKi9cbmNvbnN0IE5vdGVzID0gcmVxdWlyZSgnLi9saWIvbm90ZXMnKTtcbi8qKiBNZXNzYWdlIG5hbWVzLCBpbmNsdWRpbmcgQ0NzICovXG5jb25zdCBNZXNzYWdlcyA9IHJlcXVpcmUoJy4vbGliL21lc3NhZ2VzJyk7XG5cbmNsYXNzIElucHV0IGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKVxuICAgIFxuICAgIHRoaXMuaW5wdXQgPSBuZXcgbWlkaS5JbnB1dCgoZGVsdGFUaW1lLCBtZXNzYWdlKSA9PiB7XG4gICAgICB0aGlzLmVtaXQoJ21lc3NhZ2UnLCBkZWx0YVRpbWUsIEFycmF5LmZyb20obWVzc2FnZS52YWx1ZXMoKSkpXG4gICAgfSlcbiAgfVxuXG4gIGNsb3NlUG9ydCgpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5jbG9zZVBvcnQoKVxuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuZGVzdHJveSgpXG4gIH1cbiAgZ2V0UG9ydENvdW50KCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0LmdldFBvcnRDb3VudCgpXG4gIH1cbiAgZ2V0UG9ydE5hbWUocG9ydCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0LmdldFBvcnROYW1lKHBvcnQpXG4gIH1cbiAgaXNQb3J0T3BlbigpIHtcbiAgICByZXR1cm4gdGhpcy5pbnB1dC5pc1BvcnRPcGVuKClcbiAgfVxuICBpZ25vcmVUeXBlcyhzeXNleCwgdGltaW5nLCBhY3RpdmVTZW5zaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuaWdub3JlVHlwZXMoc3lzZXgsIHRpbWluZywgYWN0aXZlU2Vuc2luZylcbiAgfVxuICBvcGVuUG9ydChwb3J0KSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQub3BlblBvcnQocG9ydClcbiAgfVxuICBvcGVuUG9ydEJ5TmFtZShuYW1lKSB7XG4gICAgZm9yKGxldCBwb3J0PTA7IHBvcnQ8dGhpcy5pbnB1dC5nZXRQb3J0Q291bnQoKTsgKytwb3J0KSB7XG4gICAgICBpZiAobmFtZSA9PT0gdGhpcy5pbnB1dC5nZXRQb3J0TmFtZShwb3J0KSkge1xuICAgICAgICByZXR1cm4gdGhpcy5pbnB1dC5vcGVuUG9ydChwb3J0KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBvcGVuVmlydHVhbFBvcnQocG9ydCkge1xuICAgIHJldHVybiB0aGlzLmlucHV0Lm9wZW5WaXJ0dWFsUG9ydChwb3J0KVxuICB9XG4gIHNldEJ1ZmZlclNpemUoc2l6ZSwgY291bnQgPSA0KSB7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXQuc2V0QnVmZmVyU2l6ZShzaXplLCBjb3VudClcbiAgfVxufVxuXG5jbGFzcyBPdXRwdXQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLm91dHB1dCA9IG5ldyBtaWRpLk91dHB1dCgpXG4gIH1cblxuICBjbG9zZVBvcnQoKSB7XG4gICAgcmV0dXJuIHRoaXMub3V0cHV0LmNsb3NlUG9ydCgpXG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQuZGVzdHJveSgpXG4gIH1cbiAgZ2V0UG9ydENvdW50KCkge1xuICAgIHJldHVybiB0aGlzLm91dHB1dC5nZXRQb3J0Q291bnQoKVxuICB9XG4gIGdldFBvcnROYW1lKHBvcnQpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQuZ2V0UG9ydE5hbWUocG9ydClcbiAgfVxuICBpc1BvcnRPcGVuKCkge1xuICAgIHJldHVybiB0aGlzLm91dHB1dC5pc1BvcnRPcGVuKClcbiAgfVxuICBvcGVuUG9ydChwb3J0KSB7XG4gICAgcmV0dXJuIHRoaXMub3V0cHV0Lm9wZW5Qb3J0KHBvcnQpXG4gIH1cbiAgb3BlblBvcnRCeU5hbWUobmFtZSkge1xuICAgIGZvcihsZXQgcG9ydD0wOyBwb3J0PHRoaXMub3V0cHV0LmdldFBvcnRDb3VudCgpOyArK3BvcnQpIHtcbiAgICAgIGlmIChuYW1lID09PSB0aGlzLm91dHB1dC5nZXRQb3J0TmFtZShwb3J0KSkge1xuICAgICAgICByZXR1cm4gdGhpcy5vdXRwdXQub3BlblBvcnQocG9ydCk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgb3BlblZpcnR1YWxQb3J0KHBvcnQpIHtcbiAgICByZXR1cm4gdGhpcy5vdXRwdXQub3BlblZpcnR1YWxQb3J0KHBvcnQpXG4gIH1cbiAgc2VuZChtZXNzYWdlKSB7XG4gICAgcmV0dXJuIHRoaXMuc2VuZE1lc3NhZ2UobWVzc2FnZSlcbiAgfVxuICBzZW5kTWVzc2FnZShtZXNzYWdlKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobWVzc2FnZSkpIHtcbiAgICAgIG1lc3NhZ2UgPSBCdWZmZXIuZnJvbShtZXNzYWdlKVxuICAgIH1cbiAgICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcihtZXNzYWdlKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdGaXJzdCBhcmd1bWVudCBtdXN0IGJlIGFuIGFycmF5IG9yIEJ1ZmZlcicpXG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMub3V0cHV0LnNlbmRNZXNzYWdlKG1lc3NhZ2UpXG4gIH1cbn1cblxuXG5mdW5jdGlvbiBjcmVhdGVSZWFkU3RyZWFtKGlucHV0KSB7XG4gIGlucHV0ID0gaW5wdXQgfHwgbmV3IElucHV0KCk7XG4gIHZhciBzdHJlYW0gPSBuZXcgU3RyZWFtKCk7XG4gIHN0cmVhbS5yZWFkYWJsZSA9IHRydWU7XG4gIHN0cmVhbS5wYXVzZWQgPSBmYWxzZTtcbiAgc3RyZWFtLnF1ZXVlID0gW107XG5cbiAgaW5wdXQub24oJ21lc3NhZ2UnLCBmdW5jdGlvbihkZWx0YVRpbWUsIG1lc3NhZ2UpIHtcblxuICAgIHZhciBwYWNrZXQgPSBuZXcgQnVmZmVyLmZyb20obWVzc2FnZSk7XG5cbiAgICBpZiAoIXN0cmVhbS5wYXVzZWQpIHtcbiAgICAgIHN0cmVhbS5lbWl0KCdkYXRhJywgcGFja2V0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RyZWFtLnF1ZXVlLnB1c2gocGFja2V0KTtcbiAgICB9XG4gIH0pO1xuXG4gIHN0cmVhbS5wYXVzZSA9IGZ1bmN0aW9uKCkge1xuICAgIHN0cmVhbS5wYXVzZWQgPSB0cnVlO1xuICB9O1xuXG4gIHN0cmVhbS5yZXN1bWUgPSBmdW5jdGlvbigpIHtcbiAgICBzdHJlYW0ucGF1c2VkID0gZmFsc2U7XG4gICAgd2hpbGUgKHN0cmVhbS5xdWV1ZS5sZW5ndGggJiYgc3RyZWFtLmVtaXQoJ2RhdGEnLCBzdHJlYW0ucXVldWUuc2hpZnQoKSkpIHt9XG4gIH07XG5cbiAgcmV0dXJuIHN0cmVhbTtcbn07XG5cbmZ1bmN0aW9uIGNyZWF0ZVdyaXRlU3RyZWFtKG91dHB1dCkge1xuICBvdXRwdXQgPSBvdXRwdXQgfHwgbmV3IE91dHB1dCgpO1xuICB2YXIgc3RyZWFtID0gbmV3IFN0cmVhbSgpO1xuICBzdHJlYW0ud3JpdGFibGUgPSB0cnVlO1xuICBzdHJlYW0ucGF1c2VkID0gZmFsc2U7XG4gIHN0cmVhbS5xdWV1ZSA9IFtdO1xuXG4gIHN0cmVhbS53cml0ZSA9IGZ1bmN0aW9uKGQpIHtcblxuICAgIGlmIChCdWZmZXIuaXNCdWZmZXIoZCkpIHtcbiAgICAgIGQgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChkLCAwKTtcbiAgICB9XG5cbiAgICBvdXRwdXQuc2VuZE1lc3NhZ2UoZCk7XG5cbiAgICByZXR1cm4gIXRoaXMucGF1c2VkO1xuICB9XG5cbiAgc3RyZWFtLmVuZCA9IGZ1bmN0aW9uKGJ1Zikge1xuICAgIGJ1ZiAmJiBzdHJlYW0ud3JpdGUoYnVmKTtcbiAgICBzdHJlYW0ud3JpdGFibGUgPSBmYWxzZTtcbiAgfTtcblxuICBzdHJlYW0uZGVzdHJveSA9IGZ1bmN0aW9uKCkge1xuICAgIHN0cmVhbS53cml0YWJsZSA9IGZhbHNlO1xuICB9XG5cbiAgcmV0dXJuIHN0cmVhbTtcbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBJbnB1dCxcbiAgT3V0cHV0LFxuXG4gIGNyZWF0ZVJlYWRTdHJlYW0sXG4gIGNyZWF0ZVdyaXRlU3RyZWFtLFxuXG4gIENvbnN0YW50czoge1xuICAgIEluc3RydW1lbnRzLFxuICAgIERydW1zLFxuICAgIE5vdGVzLFxuICAgIE1lc3NhZ2VzLFxuICB9LFxuICBcbiAgLy8gQmFja3dhcmRzIGNvbXBhdGliaWxpdHkuXG4gIGlucHV0OiBJbnB1dCxcbiAgb3V0cHV0OiBPdXRwdXQsXG59O1xuIiwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgbnVsbCwgImltcG9ydCAqIGFzIG5vZGVfbWlkaSBmcm9tICdAanVsdXNpYW4vbWlkaSdcbmltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gJ2V2ZW50cydcbmltcG9ydCB7IE1pZGlNZXNzYWdlLCBNdGMgfSBmcm9tICcuL21zZ3R5cGVzLmpzJ1xuXG5leHBvcnQgY2xhc3MgSW5wdXQgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuXHRwcml2YXRlIF9pbnB1dFxuXHRwcml2YXRlIF9zbXB0ZTogbnVtYmVyW11cblx0cHJpdmF0ZSBfcGVuZGluZ1N5c2V4OiBib29sZWFuXG5cdHByaXZhdGUgX3N5c2V4OiBudW1iZXJbXVxuXHRwdWJsaWMgbmFtZTogc3RyaW5nXG5cblx0Y29uc3RydWN0b3IobmFtZTogc3RyaW5nLCB2aXJ0dWFsPzogYm9vbGVhbikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLl9pbnB1dCA9IG5ldyBub2RlX21pZGkuSW5wdXQoKVxuXHRcdHRoaXMuX2lucHV0Lmlnbm9yZVR5cGVzKGZhbHNlLCBmYWxzZSwgZmFsc2UpIC8vIEFsbG93IGFsbCBtZXNzYWdlIHR5cGVzXG5cdFx0dGhpcy5fcGVuZGluZ1N5c2V4ID0gZmFsc2Vcblx0XHR0aGlzLl9zeXNleCA9IFtdXG5cdFx0dGhpcy5fc21wdGUgPSBbXVxuXHRcdHRoaXMubmFtZSA9IG5hbWVcblx0XHRjb25zdCBpbnB1dFBvcnROdW1iZXJlZE5hbWVzOiBzdHJpbmdbXSA9IGdldElucHV0cygpXG5cblx0XHRpZiAodmlydHVhbCkge1xuXHRcdFx0dGhpcy5faW5wdXQub3BlblZpcnR1YWxQb3J0KG5hbWUpXG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IG51bUlucHV0cyA9IHRoaXMuX2lucHV0LmdldFBvcnRDb3VudCgpXG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG51bUlucHV0czsgaSsrKSB7XG5cdFx0XHRcdGlmIChuYW1lID09PSBpbnB1dFBvcnROdW1iZXJlZE5hbWVzW2ldKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuX2lucHV0Lm9wZW5Qb3J0KGkpXG5cdFx0XHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhgRXJyb3Igb3BlbmluZyBwb3J0ICR7bmFtZX0uXFxuRXJyb3I6ICR7ZXJyfWApXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0dGhpcy5faW5wdXQub24oJ21lc3NhZ2UnLCAoZGVsdGFUaW1lOiBudW1iZXIsIGJ5dGVzOiBudW1iZXJbXSk6IHZvaWQgPT4ge1xuXHRcdFx0Ly8gbm90IGRlYWxpbmcgd2l0aCBzeXNleCBjaHVua3MgbG9uZ2VyIHRoYW4gdGhlIGJ1ZmZlciBBVE1cblxuXHRcdFx0Y29uc3QgbXNnID0gTWlkaU1lc3NhZ2UucGFyc2VNZXNzYWdlKGJ5dGVzKVxuXHRcdFx0aWYgKG1zZyA9PT0gdW5kZWZpbmVkKSByZXR1cm5cblx0XHRcdHRoaXMuZW1pdCgnbWVzc2FnZScsIGRlbHRhVGltZSwgbXNnKVxuXHRcdFx0aWYgKG1zZy5pZCA9PSAnbXRjJykge1xuXHRcdFx0XHR0aGlzLnBhcnNlTXRjKG1zZyBhcyBNdGMpXG5cdFx0XHR9XG5cdFx0fSlcblx0fVxuXG5cdGNsb3NlKCk6IHZvaWQge1xuXHRcdHRoaXMuX2lucHV0LmNsb3NlUG9ydCgpXG5cdFx0dGhpcy5faW5wdXQuZGVzdHJveSgpXG5cdH1cblxuXHRpc1BvcnRPcGVuKCk6IGJvb2xlYW4ge1xuXHRcdHJldHVybiB0aGlzLl9pbnB1dC5pc1BvcnRPcGVuKClcblx0fVxuXG5cdHBhcnNlTXRjKGRhdGE6IE10Yyk6IHZvaWQge1xuXHRcdGNvbnN0IEZSQU1FX1JBVEVTID0gWzI0LCAyNSwgMjkuOTcsIDMwXVxuXHRcdGNvbnN0IGJ5dGVOdW1iZXI6IG51bWJlciA9IGRhdGEudHlwZVxuXHRcdGxldCB2YWx1ZTogbnVtYmVyID0gZGF0YS52YWx1ZVxuXHRcdGxldCBzbXB0ZUZyYW1lUmF0ZTogbnVtYmVyXG5cblx0XHR0aGlzLl9zbXB0ZVtieXRlTnVtYmVyXSA9IHZhbHVlXG5cblx0XHQvLyBDaGVjayBpZiB3ZSBoYXZlIDggY29tcGxldGUgbWVzc2FnZXMuIElmIHRoaXMuX3NtcHRlWzBdIGlzIHVuZGVmaW5lZCwgdGhlbiB3ZSBzdGFydGVkIGluIHRoZSBtaWRkbGUhXG5cdFx0aWYgKGJ5dGVOdW1iZXIgPT09IDcgJiYgdHlwZW9mIHRoaXMuX3NtcHRlWzBdID09PSAnbnVtYmVyJykge1xuXHRcdFx0Y29uc3QgYml0czogbnVtYmVyW10gPSBbXVxuXHRcdFx0Zm9yIChsZXQgaSA9IDM7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdGNvbnN0IGJpdCA9IHZhbHVlICYgKDEgPDwgaSkgPyAxIDogMFxuXHRcdFx0XHRiaXRzLnB1c2goYml0KVxuXHRcdFx0fVxuXHRcdFx0dmFsdWUgPSBiaXRzWzNdXG5cdFx0XHRzbXB0ZUZyYW1lUmF0ZSA9IEZSQU1FX1JBVEVTWyhiaXRzWzFdIDw8IDEpICsgYml0c1syXV1cblx0XHRcdHRoaXMuX3NtcHRlW2J5dGVOdW1iZXJdID0gdmFsdWVcblxuXHRcdFx0Y29uc3Qgc21wdGUgPSB0aGlzLl9zbXB0ZVxuXHRcdFx0Y29uc3Qgc21wdGVGb3JtYXR0ZWQgPVxuXHRcdFx0XHQoKHNtcHRlWzddIDw8IDQpICsgc21wdGVbNl0pLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKSArXG5cdFx0XHRcdCc6JyArXG5cdFx0XHRcdCgoc21wdGVbNV0gPDwgNCkgKyBzbXB0ZVs0XSkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpICtcblx0XHRcdFx0JzonICtcblx0XHRcdFx0KChzbXB0ZVszXSA8PCA0KSArIHNtcHRlWzJdKS50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJykgK1xuXHRcdFx0XHQnLicgK1xuXHRcdFx0XHQoKHNtcHRlWzFdIDw8IDQpICsgc21wdGVbMF0pLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKVxuXHRcdFx0dGhpcy5lbWl0KCdzbXB0ZScsIHtcblx0XHRcdFx0c21wdGU6IHNtcHRlRm9ybWF0dGVkLFxuXHRcdFx0XHRzbXB0ZUZSOiBzbXB0ZUZyYW1lUmF0ZSxcblx0XHRcdH0pXG5cdFx0fVxuXHR9XG59XG5cbmV4cG9ydCBjbGFzcyBPdXRwdXQge1xuXHRwcml2YXRlIF9vdXRwdXRcblx0cHVibGljIG5hbWU6IHN0cmluZ1xuXG5cdGNvbnN0cnVjdG9yKG5hbWU6IHN0cmluZywgdmlydHVhbD86IGJvb2xlYW4pIHtcblx0XHR0aGlzLl9vdXRwdXQgPSBuZXcgbm9kZV9taWRpLk91dHB1dCgpXG5cdFx0dGhpcy5uYW1lID0gbmFtZVxuXHRcdGNvbnN0IG91dHB1dFBvcnROdW1iZXJlZE5hbWVzOiBzdHJpbmdbXSA9IGdldE91dHB1dHMoKVxuXG5cdFx0aWYgKHZpcnR1YWwpIHtcblx0XHRcdHRoaXMuX291dHB1dC5vcGVuVmlydHVhbFBvcnQobmFtZSlcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgbnVtT3V0cHV0cyA9IHRoaXMuX291dHB1dC5nZXRQb3J0Q291bnQoKVxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCBudW1PdXRwdXRzOyBpKyspIHtcblx0XHRcdFx0aWYgKG5hbWUgPT09IG91dHB1dFBvcnROdW1iZXJlZE5hbWVzW2ldKSB7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdHRoaXMuX291dHB1dC5vcGVuUG9ydChpKVxuXHRcdFx0XHRcdH0gY2F0Y2ggKGVycikge1xuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coYEVycm9yIG9wZW5pbmcgcG9ydCAke25hbWV9LlxcbkVycm9yOiAke2Vycn1gKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGNsb3NlKCk6IHZvaWQge1xuXHRcdHRoaXMuX291dHB1dC5jbG9zZVBvcnQoKVxuXHRcdHRoaXMuX291dHB1dC5kZXN0cm95KClcblx0fVxuXG5cdGlzUG9ydE9wZW4oKTogYm9vbGVhbiB7XG5cdFx0cmV0dXJuIHRoaXMuX291dHB1dC5pc1BvcnRPcGVuKClcblx0fVxuXG5cdHNlbmQobXNnOiBNaWRpTWVzc2FnZSk6IHZvaWQge1xuXHRcdHRoaXMuX291dHB1dC5zZW5kTWVzc2FnZShtc2cuYnl0ZXMpXG5cdH1cbn1cblxuLy8gdXRpbGl0aWVzXG5leHBvcnQgZnVuY3Rpb24gZ2V0SW5wdXRzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3QgaW5wdXQgPSBuZXcgbm9kZV9taWRpLklucHV0KClcblx0Y29uc3QgaW5wdXRzOiBzdHJpbmdbXSA9IFtdXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQuZ2V0UG9ydENvdW50KCk7IGkrKykge1xuXHRcdGxldCBjb3VudGVyID0gMFxuXHRcdGNvbnN0IHBvcnROYW1lID0gaW5wdXQuZ2V0UG9ydE5hbWUoaSlcblx0XHRsZXQgbnVtYmVyZWRQb3J0TmFtZSA9IHBvcnROYW1lXG5cdFx0d2hpbGUgKGlucHV0cy5pbmNsdWRlcyhudW1iZXJlZFBvcnROYW1lKSkge1xuXHRcdFx0Y291bnRlcisrXG5cdFx0XHRudW1iZXJlZFBvcnROYW1lICs9IGAgJHtjb3VudGVyfWBcblx0XHR9XG5cdFx0aW5wdXRzLnB1c2gobnVtYmVyZWRQb3J0TmFtZSlcblx0fVxuXHRpbnB1dC5jbG9zZVBvcnQoKVxuXHRyZXR1cm4gaW5wdXRzXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRPdXRwdXRzKCk6IHN0cmluZ1tdIHtcblx0Y29uc3Qgb3V0cHV0ID0gbmV3IG5vZGVfbWlkaS5PdXRwdXQoKVxuXHRjb25zdCBvdXRwdXRzOiBzdHJpbmdbXSA9IFtdXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgb3V0cHV0LmdldFBvcnRDb3VudCgpOyBpKyspIHtcblx0XHRsZXQgY291bnRlciA9IDBcblx0XHRjb25zdCBwb3J0TmFtZSA9IG91dHB1dC5nZXRQb3J0TmFtZShpKVxuXHRcdGxldCBudW1iZXJlZFBvcnROYW1lID0gcG9ydE5hbWVcblx0XHR3aGlsZSAob3V0cHV0cy5pbmNsdWRlcyhudW1iZXJlZFBvcnROYW1lKSkge1xuXHRcdFx0Y291bnRlcisrXG5cdFx0XHRudW1iZXJlZFBvcnROYW1lICs9IGAgJHtjb3VudGVyfWBcblx0XHR9XG5cdFx0b3V0cHV0cy5wdXNoKG51bWJlcmVkUG9ydE5hbWUpXG5cdH1cblx0b3V0cHV0LmNsb3NlUG9ydCgpXG5cdHJldHVybiBvdXRwdXRzXG59XG4iLCAiY29uc3QgTUFYXzdfQklUID0gMHg3ZlxuY29uc3QgTUFYXzE0X0JJVCA9IDB4M2ZmZlxuXG5jb25zdCBNSURJX1NUQVRVU19UWVBFUyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KFtcblx0Wydub3Rlb2ZmJywgMHg4MF0sXG5cdFsnbm90ZW9uJywgMHg5MF0sXG5cdFsnYWZ0ZXJ0b3VjaCcsIDB4YTBdLFxuXHRbJ2NjJywgMHhiMF0sXG5cdFsncHJvZ3JhbScsIDB4YzBdLFxuXHRbJ2NoYW5uZWxwcmVzc3VyZScsIDB4ZDBdLFxuXHRbJ3BpdGNoJywgMHhlMF0sXG5cdFsnc3lzZXgnLCAweGYwXSxcblx0WydtdGMnLCAweGYxXSxcblx0Wydwb3NpdGlvbicsIDB4ZjJdLFxuXHRbJ3NlbGVjdCcsIDB4ZjNdLFxuXHRbJ3R1bmUnLCAweGY2XSxcblx0WydzeXNleCBlbmQnLCAweGY3XSxcblx0WydjbG9jaycsIDB4ZjhdLFxuXHRbJ3N0YXJ0JywgMHhmYV0sXG5cdFsnY29udGludWUnLCAweGZiXSxcblx0WydzdG9wJywgMHhmY10sXG5cdFsnYWN0aXZlc2Vuc2UnLCAweGZlXSxcblx0WydyZXNldCcsIDB4ZmZdLFxuXSlcblxuY29uc3QgaGV4ID0gKHZhbDogbnVtYmVyKSA9PiBgJHt2YWx9ICgweCR7dmFsLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpfSlgXG5cbmV4cG9ydCBpbnRlcmZhY2UgSU1zZ0FyZ3Mge1xuXHRpZD86IHN0cmluZ1xuXHRieXRlcz86IG51bWJlcltdXG5cdHN0YXR1cz86IG51bWJlclxuXHRjaGFubmVsPzogbnVtYmVyXG5cdHR5cGU/OiBudW1iZXJcblx0bm90ZT86IG51bWJlclxuXHR2ZWxvY2l0eT86IG51bWJlclxuXHRjb250cm9sbGVyPzogbnVtYmVyXG5cdHByZXNzdXJlPzogbnVtYmVyXG5cdHZhbHVlPzogbnVtYmVyXG5cdHByb2dyYW0/OiBudW1iZXJcblx0c29uZz86IG51bWJlclxufVxuXG5leHBvcnQgY2xhc3MgTWlkaU1lc3NhZ2Uge1xuXHRpZCA9ICcnXG5cdGJ5dGVzOiBudW1iZXJbXVxuXHRzdGF0aWMgbm9Nc2c6IElNc2dBcmdzID0ge1xuXHRcdGJ5dGVzOiBbXSxcblx0XHRzdGF0dXM6IDAsXG5cdFx0Y2hhbm5lbDogMCxcblx0XHR0eXBlOiAwLFxuXHRcdG5vdGU6IDAsXG5cdFx0dmVsb2NpdHk6IDAsXG5cdFx0Y29udHJvbGxlcjogMCxcblx0XHRwcmVzc3VyZTogMCxcblx0XHR2YWx1ZTogMCxcblx0XHRwcm9ncmFtOiAwLFxuXHRcdHNvbmc6IDAsXG5cdH1cblxuXHRjb25zdHJ1Y3RvcihieXRlczogbnVtYmVyW10gPSBbXSkge1xuXHRcdHRoaXMuYnl0ZXMgPSBieXRlc1xuXHR9XG5cblx0Z2V0IHN0YXR1cygpOiBudW1iZXIge1xuXHRcdHJldHVybiB0aGlzLmJ5dGVzWzBdID4gMHhlZiA/IHRoaXMuYnl0ZXNbMF0gOiB0aGlzLmJ5dGVzWzBdICYgMHhmMFxuXHR9XG5cdHNldCBzdGF0dXModjogbnVtYmVyKSB7XG5cdFx0dGhpcy5ieXRlc1swXSA9IHYgPiAweGVmID8gdiA6ICh0aGlzLmJ5dGVzWzBdICYgMHgwZikgfCAodiAmIDB4ZjApXG5cdH1cblxuXHRnZXQgY2hhbm5lbCgpOiBudW1iZXIge1xuXHRcdHJldHVybiAodGhpcy5ieXRlc1swXSAmIDB4MGYpICsgMVxuXHR9XG5cdHNldCBjaGFubmVsKHY6IG51bWJlcikge1xuXHRcdHYtLSAvLyBDaGFubmVscyBhcmUgbm9ybWFsbHkgc2hvd24gYXMgMS0xNiBidXQgaW50ZXJuYWxseSBhcmUgMC0xNVxuXHRcdHYgPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgMTUpXG5cdFx0dGhpcy5ieXRlc1swXSA9ICh0aGlzLmJ5dGVzWzBdICYgMHhmMCkgfCAodiAmIDB4MGYpXG5cdH1cblxuXHRwcm90ZWN0ZWQgZ2V0IGRhdGExKCk6IG51bWJlciB7XG5cdFx0cmV0dXJuIHRoaXMuYnl0ZXNbMV0gJiAweDdmXG5cdH1cblx0cHJvdGVjdGVkIHNldCBkYXRhMSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmJ5dGVzWzFdID0gTWlkaU1lc3NhZ2UuY29uc3RyYWluKHYsIE1BWF83X0JJVClcblx0fVxuXG5cdHByb3RlY3RlZCBnZXQgZGF0YTIoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gdGhpcy5ieXRlc1syXSAmIDB4N2Zcblx0fVxuXHRwcm90ZWN0ZWQgc2V0IGRhdGEyKHY6IG51bWJlcikge1xuXHRcdHRoaXMuYnl0ZXNbMl0gPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgTUFYXzdfQklUKVxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGJ5dGVzOiB0aGlzLmJ5dGVzIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3RoaXMuaWR9IE1lc3NhZ2VgXG5cdH1cblxuXHRzdGF0aWMgY29uc3RyYWluKG51bTogbnVtYmVyLCBtYXg6IG51bWJlcik6IG51bWJlciB7XG5cdFx0cmV0dXJuIG51bSA+IG1heCA/IG1heCA6IG51bSA8IDAgPyAwIDogbnVtXG5cdH1cblxuXHRzdGF0aWMgcGFyc2VNZXNzYWdlKGJ5dGVzOiBudW1iZXJbXSA9IFtdLCBtc2c6IElNc2dBcmdzID0gdGhpcy5ub01zZyk6IE1pZGlNZXNzYWdlIHwgdW5kZWZpbmVkIHtcblx0XHRsZXQgaW5jb21pbmcgPSBuZXcgTWlkaU1lc3NhZ2UoYnl0ZXMpXG5cdFx0bGV0IHN0YXR1cyA9IGJ5dGVzLmxlbmd0aCA+IDAgPyBpbmNvbWluZy5zdGF0dXMgOiBtc2cuc3RhdHVzIHx8IDBcblx0XHRpZiAoc3RhdHVzID09PSAwICYmIHR5cGVvZiBtc2cuaWQgIT09ICd1bmRlZmluZWQnKSBzdGF0dXMgPSBNSURJX1NUQVRVU19UWVBFUy5nZXQobXNnLmlkKSB8fCAwXG5cblx0XHRzd2l0Y2ggKHN0YXR1cykge1xuXHRcdFx0Y2FzZSAweDgwOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBOb3RlT2ZmKG1zZy5jaGFubmVsISwgbXNnLm5vdGUhLCBtc2cudmVsb2NpdHkhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweDkwOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBOb3RlT24obXNnLmNoYW5uZWwhLCBtc2cubm90ZSEsIG1zZy52ZWxvY2l0eSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4YTA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IEFmdGVydG91Y2gobXNnLmNoYW5uZWwhLCBtc2cubm90ZSEsIG1zZy5wcmVzc3VyZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4YjA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IENvbnRyb2xDaGFuZ2UobXNnLmNoYW5uZWwhLCBtc2cuY29udHJvbGxlciEsIG1zZy52YWx1ZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4YzA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IFByb2dyYW1DaGFuZ2UobXNnLmNoYW5uZWwhLCBtc2cucHJvZ3JhbSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4ZDA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IENoYW5uZWxQcmVzc3VyZShtc2cuY2hhbm5lbCEsIG1zZy5wcmVzc3VyZSEpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlIDB4ZTA6XG5cdFx0XHRcdGluY29taW5nID0gbmV3IFBpdGNoV2hlZWwobXNnLmNoYW5uZWwhLCBtc2cudmFsdWUhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweGYwOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBTeXNleChtc2cuYnl0ZXMhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweGYxOlxuXHRcdFx0XHRpbmNvbWluZyA9IG5ldyBNdGMobXNnLnR5cGUhLCBtc2cudmFsdWUhKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAweGY4OlxuXHRcdFx0XHRyZXR1cm4gLy8gaWdub3JlIE1JREkgQ2xvY2sgbWVzc2FnZXNcblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdGNvbnNvbGUubG9nKGBVbnN1cHBvcnRlZCBNSURJIG1lc3NhZ2UuIFN0YXR1cyA9ICR7aGV4KHN0YXR1cyl9YClcblx0XHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKGJ5dGVzLmxlbmd0aCA+IDApIGluY29taW5nLmJ5dGVzID0gYnl0ZXMgLy8gcHVzaCB0aGUgZGF0YSB0byB0aGlzIG1lc3NhZ2Vcblx0XHRyZXR1cm4gaW5jb21pbmdcblx0fVxufVxuXG5jbGFzcyBOb3RlT2ZmIGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIG46IG51bWJlciwgdjogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAnbm90ZW9mZidcblx0XHR0aGlzLnN0YXR1cyA9IDB4ODBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy5ub3RlID0gblxuXHRcdHRoaXMudmVsb2NpdHkgPSB2XG5cdH1cblxuXHRnZXQgbm90ZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMVxuXHR9XG5cdHNldCBub3RlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTEgPSB2XG5cdH1cblxuXHRnZXQgdmVsb2NpdHkoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTJcblx0fVxuXHRzZXQgdmVsb2NpdHkodjogbnVtYmVyKSB7XG5cdFx0dGhpcy5kYXRhMiA9IHZcblx0fVxuXG5cdGdldCBhcmdzKCk6IElNc2dBcmdzIHtcblx0XHRyZXR1cm4geyBjaGFubmVsOiB0aGlzLmNoYW5uZWwsIG5vdGU6IHRoaXMubm90ZSwgdmVsb2NpdHk6IHRoaXMudmVsb2NpdHkgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCBub3RlOiAke2hleCh0aGlzLm5vdGUpfSwgdmVsb2NpdHk6ICR7aGV4KFxuXHRcdFx0dGhpcy52ZWxvY2l0eSxcblx0XHQpfWBcblx0fVxufVxuXG5jbGFzcyBOb3RlT24gZXh0ZW5kcyBOb3RlT2ZmIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBuOiBudW1iZXIsIHY6IG51bWJlcikge1xuXHRcdHN1cGVyKGMsIG4sIHYpXG5cdFx0dGhpcy5pZCA9ICdub3Rlb24nXG5cdFx0dGhpcy5zdGF0dXMgPSAweDkwXG5cdH1cbn1cblxuY2xhc3MgQWZ0ZXJ0b3VjaCBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBuOiBudW1iZXIsIHA6IG51bWJlcikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ2FmdGVydG91Y2gnXG5cdFx0dGhpcy5zdGF0dXMgPSAweGEwXG5cdFx0dGhpcy5jaGFubmVsID0gY1xuXHRcdHRoaXMubm90ZSA9IG5cblx0XHR0aGlzLnByZXNzdXJlID0gcFxuXHR9XG5cblx0Z2V0IG5vdGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTFcblx0fVxuXHRzZXQgbm90ZSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IHByZXNzdXJlKCkge1xuXHRcdHJldHVybiB0aGlzLmRhdGEyXG5cdH1cblx0c2V0IHByZXNzdXJlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTIgPSB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCBub3RlOiB0aGlzLm5vdGUsIHByZXNzdXJlOiB0aGlzLnByZXNzdXJlIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCBjaGFubmVsOiAke2hleCh0aGlzLmNoYW5uZWwpfSwgbm90ZTogJHtoZXgodGhpcy5ub3RlKX0sIHByZXNzdXJlOiAke2hleChcblx0XHRcdHRoaXMucHJlc3N1cmUsXG5cdFx0KX1gXG5cdH1cbn1cblxuY2xhc3MgQ29udHJvbENoYW5nZSBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBjYzogbnVtYmVyLCB2OiBudW1iZXIpIHtcblx0XHRzdXBlcigpXG5cdFx0dGhpcy5pZCA9ICdjYydcblx0XHR0aGlzLnN0YXR1cyA9IDB4YjBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy5jb250cm9sbGVyID0gY2Ncblx0XHR0aGlzLnZhbHVlID0gdlxuXHR9XG5cblx0Z2V0IGNvbnRyb2xsZXIoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTFcblx0fVxuXHRzZXQgY29udHJvbGxlcih2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IHZhbHVlKCkge1xuXHRcdHJldHVybiB0aGlzLmRhdGEyXG5cdH1cblx0c2V0IHZhbHVlKHY6IG51bWJlcikge1xuXHRcdHRoaXMuZGF0YTIgPSB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCBjb250cm9sbGVyOiB0aGlzLmNvbnRyb2xsZXIsIHZhbHVlOiB0aGlzLnZhbHVlIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCBjaGFubmVsOiAke2hleCh0aGlzLmNoYW5uZWwpfSwgY29udHJvbGxlcjogJHtoZXgodGhpcy5jb250cm9sbGVyKX0sIHZhbHVlOiAke2hleChcblx0XHRcdHRoaXMudmFsdWUsXG5cdFx0KX1gXG5cdH1cbn1cblxuY2xhc3MgUHJvZ3JhbUNoYW5nZSBleHRlbmRzIE1pZGlNZXNzYWdlIHtcblx0Y29uc3RydWN0b3IoYzogbnVtYmVyLCBuOiBudW1iZXIpIHtcblx0XHRzdXBlcigpXG5cdFx0dGhpcy5pZCA9ICdwcm9ncmFtJ1xuXHRcdHRoaXMuc3RhdHVzID0gMHhjMFxuXHRcdHRoaXMuY2hhbm5lbCA9IGNcblx0XHR0aGlzLnByb2dyYW0gPSBuXG5cdH1cblxuXHRnZXQgcHJvZ3JhbSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMSArIDEgLy8gUEMgaXMgbm9ybWFsbHkgc2hvd24gYXMgMS0xMjgsIGJ1dCBpdCdzIGludGVybmFsbHkgMC0xMjdcblx0fVxuXHRzZXQgcHJvZ3JhbSh2OiBudW1iZXIpIHtcblx0XHR2LS1cblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGNoYW5uZWw6IHRoaXMuY2hhbm5lbCwgcHJvZ3JhbTogdGhpcy5wcm9ncmFtIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCBjaGFubmVsOiAke2hleCh0aGlzLmNoYW5uZWwpfSwgcHJvZ3JhbTogJHtoZXgodGhpcy5wcm9ncmFtKX1gXG5cdH1cbn1cblxuY2xhc3MgQ2hhbm5lbFByZXNzdXJlIGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihjOiBudW1iZXIsIHA6IG51bWJlcikge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ2NoYW5uZWxwcmVzc3VyZSdcblx0XHR0aGlzLnN0YXR1cyA9IDB4ZDBcblx0XHR0aGlzLmNoYW5uZWwgPSBjXG5cdFx0dGhpcy5wcmVzc3VyZSA9IHBcblx0fVxuXG5cdGdldCBwcmVzc3VyZSgpIHtcblx0XHRyZXR1cm4gdGhpcy5kYXRhMVxuXHR9XG5cdHNldCBwcmVzc3VyZSh2OiBudW1iZXIpIHtcblx0XHR0aGlzLmRhdGExID0gdlxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGNoYW5uZWw6IHRoaXMuY2hhbm5lbCwgcHJlc3N1cmU6IHRoaXMucHJlc3N1cmUgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCBwcmVzc3VyZTogJHtoZXgodGhpcy5wcmVzc3VyZSl9YFxuXHR9XG59XG5cbmNsYXNzIFBpdGNoV2hlZWwgZXh0ZW5kcyBNaWRpTWVzc2FnZSB7XG5cdGNvbnN0cnVjdG9yKGM6IG51bWJlciwgdjogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAncGl0Y2gnXG5cdFx0dGhpcy5zdGF0dXMgPSAweGUwXG5cdFx0dGhpcy5jaGFubmVsID0gY1xuXHRcdHRoaXMudmFsdWUgPSB2XG5cdH1cblxuXHRnZXQgdmFsdWUoKSB7XG5cdFx0cmV0dXJuICh0aGlzLmRhdGEyIDw8IDcpICsgdGhpcy5kYXRhMVxuXHR9XG5cdHNldCB2YWx1ZSh2OiBudW1iZXIpIHtcblx0XHR2ID0gTWlkaU1lc3NhZ2UuY29uc3RyYWluKHYsIE1BWF8xNF9CSVQpXG5cdFx0dGhpcy5kYXRhMiA9ICh2ID4+IDcpICYgMHg3ZlxuXHRcdHRoaXMuZGF0YTEgPSB2ICYgMHg3ZlxuXHR9XG5cblx0Z2V0IGFyZ3MoKTogSU1zZ0FyZ3Mge1xuXHRcdHJldHVybiB7IGNoYW5uZWw6IHRoaXMuY2hhbm5lbCwgdmFsdWU6IHRoaXMudmFsdWUgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGNoYW5uZWw6ICR7aGV4KHRoaXMuY2hhbm5lbCl9LCB2YWx1ZTogJHtoZXgodGhpcy52YWx1ZSl9YFxuXHR9XG59XG5cbmNsYXNzIFN5c2V4IGV4dGVuZHMgTWlkaU1lc3NhZ2Uge1xuXHRjb25zdHJ1Y3RvcihiOiBudW1iZXJbXSkge1xuXHRcdHN1cGVyKClcblx0XHR0aGlzLmlkID0gJ3N5c2V4J1xuXHRcdHRoaXMuYnl0ZXMgPSBiXG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgYnl0ZXM6IHRoaXMuYnl0ZXMgfVxuXHR9XG5cblx0dG9TdHJpbmcoKTogc3RyaW5nIHtcblx0XHRyZXR1cm4gYCR7c3VwZXIudG9TdHJpbmcoKX0sIGJ5dGVzOiAke3RoaXMuYnl0ZXN9YFxuXHR9XG59XG5cbmV4cG9ydCBjbGFzcyBNdGMgZXh0ZW5kcyBNaWRpTWVzc2FnZSB7XG5cdGNvbnN0cnVjdG9yKHQ6IG51bWJlciwgdjogbnVtYmVyKSB7XG5cdFx0c3VwZXIoKVxuXHRcdHRoaXMuaWQgPSAnbXRjJ1xuXHRcdHRoaXMuc3RhdHVzID0gMHhmMVxuXHRcdHRoaXMudHlwZSA9IHRcblx0XHR0aGlzLnZhbHVlID0gdlxuXHR9XG5cblx0Z2V0IHR5cGUoKTogbnVtYmVyIHtcblx0XHRyZXR1cm4gKHRoaXMuZGF0YTEgPj4gNCkgJiAweDA3XG5cdH1cblx0c2V0IHR5cGUodjogbnVtYmVyKSB7XG5cdFx0dGhpcy5kYXRhMSA9ICh0aGlzLmRhdGExICYgMHgwZikgfCAodiA8PCA0KVxuXHR9XG5cblx0Z2V0IHZhbHVlKCk6IG51bWJlciB7XG5cdFx0cmV0dXJuIHRoaXMuZGF0YTEgJiAweDBmXG5cdH1cblx0c2V0IHZhbHVlKHY6IG51bWJlcikge1xuXHRcdHYgPSBNaWRpTWVzc2FnZS5jb25zdHJhaW4odiwgMTUpXG5cdFx0dGhpcy5kYXRhMSA9ICh0aGlzLmRhdGExICYgMHhmMCkgfCB2XG5cdH1cblxuXHRnZXQgYXJncygpOiBJTXNnQXJncyB7XG5cdFx0cmV0dXJuIHsgY2hhbm5lbDogdGhpcy5jaGFubmVsLCB0eXBlOiB0aGlzLnR5cGUsIHZhbHVlOiB0aGlzLnZhbHVlIH1cblx0fVxuXG5cdHRvU3RyaW5nKCk6IHN0cmluZyB7XG5cdFx0cmV0dXJuIGAke3N1cGVyLnRvU3RyaW5nKCl9LCB0eXBlOiAke2hleCh0aGlzLnR5cGUpfSwgdmFsdWU6ICR7aGV4KHRoaXMudmFsdWUpfWBcblx0fVxufVxuIiwgImltcG9ydCB7IHR5cGUgU29tZUNvbXBhbmlvbkNvbmZpZ0ZpZWxkLCBKc29uT2JqZWN0LCBEcm9wZG93bkNob2ljZSB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBnZXRJbnB1dHMsIGdldE91dHB1dHMgfSBmcm9tICcuL21pZGkvbWlkaS5qcydcblxuZXhwb3J0IGludGVyZmFjZSBNb2R1bGVDb25maWcgZXh0ZW5kcyBKc29uT2JqZWN0IHtcblx0aW5Qb3J0TmFtZTogc3RyaW5nXG5cdGluUG9ydFZpcnR1YWxOYW1lOiBzdHJpbmdcblx0aW5Qb3J0SXNWaXJ0dWFsOiBib29sZWFuXG5cdG91dFBvcnROYW1lOiBzdHJpbmdcblx0b3V0UG9ydFZpcnR1YWxOYW1lOiBzdHJpbmdcblx0b3V0UG9ydElzVmlydHVhbDogYm9vbGVhblxuXHR1c2VUaW1lU3RhbXA6IGJvb2xlYW5cblx0YXV0b0NyZWF0ZVZhcnM6IGJvb2xlYW5cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdGNvbnN0IGluUG9ydE5hbWVzOiBEcm9wZG93bkNob2ljZVtdID0gW11cblx0Y29uc3Qgb3V0UG9ydE5hbWVzOiBEcm9wZG93bkNob2ljZVtdID0gW11cblx0Y29uc3QgaW5Qb3J0czogc3RyaW5nW10gPSBnZXRJbnB1dHMoKVxuXHRjb25zdCBvdXRQb3J0czogc3RyaW5nW10gPSBnZXRPdXRwdXRzKClcblx0aW5Qb3J0cy5mb3JFYWNoKChtKSA9PiB7XG5cdFx0aW5Qb3J0TmFtZXMucHVzaCh7IGlkOiBtLCBsYWJlbDogbSB9KVxuXHR9KVxuXHRvdXRQb3J0cy5mb3JFYWNoKChtKSA9PiB7XG5cdFx0b3V0UG9ydE5hbWVzLnB1c2goeyBpZDogbSwgbGFiZWw6IG0gfSlcblx0fSlcblxuXHRyZXR1cm4gW1xuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ2luUG9ydE5hbWUnLFxuXHRcdFx0bGFiZWw6ICdNSURJIEluJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogaW5Qb3J0c1swXSB8fCAnTk9ORSBERVRFQ1RFRCcsXG5cdFx0XHRjaG9pY2VzOiBpblBvcnROYW1lcyxcblx0XHRcdC8vXHRpc1Zpc2libGU6IChvcHRzKSA9PiAhb3B0cy5pblBvcnRJc1ZpcnR1YWwsXG5cdFx0fSxcblx0XHQvKlxuXHRcdHtcblx0XHRcdHR5cGU6ICd0ZXh0aW5wdXQnLFxuXHRcdFx0aWQ6ICdpblBvcnRWaXJ0dWFsTmFtZScsXG5cdFx0XHRsYWJlbDogJ01JREkgSW4nLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHRcdGlzVmlzaWJsZTogKG9wdHMpID0+ICEhb3B0cy5pblBvcnRJc1ZpcnR1YWwsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0aWQ6ICdpblBvcnRJc1ZpcnR1YWwnLFxuXHRcdFx0bGFiZWw6ICdWaXJ0dWFsJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHQqL1xuXHRcdHtcblx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRpZDogJ291dFBvcnROYW1lJyxcblx0XHRcdGxhYmVsOiAnTUlESSBPdXQnLFxuXHRcdFx0d2lkdGg6IDYsXG5cdFx0XHRkZWZhdWx0OiBvdXRQb3J0c1swXSB8fCAnTk9ORSBERVRFQ1RFRCcsXG5cdFx0XHRjaG9pY2VzOiBvdXRQb3J0TmFtZXMsXG5cdFx0XHQvL1x0aXNWaXNpYmxlOiAob3B0cykgPT4gIW9wdHMub3V0UG9ydElzVmlydHVhbCxcblx0XHR9LFxuXHRcdC8qXG5cdFx0e1xuXHRcdFx0dHlwZTogJ3RleHRpbnB1dCcsXG5cdFx0XHRpZDogJ291dFBvcnRWaXJ0dWFsTmFtZScsXG5cdFx0XHRsYWJlbDogJ01JREkgT3V0Jyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogJycsXG5cdFx0XHRpc1Zpc2libGU6IChvcHRzKSA9PiAhIW9wdHMub3V0UG9ydElzVmlydHVhbCxcblx0XHR9LFxuXHRcdHtcblx0XHRcdHR5cGU6ICdjaGVja2JveCcsXG5cdFx0XHRpZDogJ291dFBvcnRJc1ZpcnR1YWwnLFxuXHRcdFx0bGFiZWw6ICdWaXJ0dWFsJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnc3RhdGljLXRleHQnLFxuXHRcdFx0aWQ6ICdjdXN0b21UZXh0Jyxcblx0XHRcdGxhYmVsOiAnQ2hvb3NlIGV4aXN0aW5nIHBvcnRzLCBvciB0eXBlIGEgY3VzdG9tIG5hbWUgdG8gY3JlYXRlIGEgVmlydHVhbCBQb3J0Jyxcblx0XHRcdHdpZHRoOiAxMixcblx0XHRcdHZhbHVlOiAnJyxcblx0XHR9LFxuXHRcdCovXG5cdFx0e1xuXHRcdFx0dHlwZTogJ2NoZWNrYm94Jyxcblx0XHRcdGlkOiAndXNlVGltZVN0YW1wJyxcblx0XHRcdGxhYmVsOiAnVXNlIFRpbWVTdGFtcCB3aXRoIEFjdGlvbiBSZWNvcmRlcicsXG5cdFx0XHR0b29sdGlwOiAnRW5hYmxlIHRoaXMgc2V0dGluZyB0byBpbmNsdWRlIHRoZSBkZWxheSB0aW1lIGZvciBhY3Rpb25zIGNyZWF0ZWQgaW4gQWN0aW9uIFJlY29yZGVyJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0aWQ6ICdhdXRvQ3JlYXRlVmFycycsXG5cdFx0XHRsYWJlbDogJ0VuYWJsZSBcIkF1dG8tQ3JlYXRlZCBWYXJpYWJsZXMgZnVuY3Rpb25cIicsXG5cdFx0XHR0b29sdGlwOiAnRW5hYmxlIHRoaXMgc2V0dGluZyBPTkxZIGlmIHlvdSBuZWVkIGNvbXBhdGliaWxpdHkgd2l0aCBleGlzdGluZyBBdXRvLUNyZWF0ZWQgdmFyaWFibGVzJyxcblx0XHRcdHdpZHRoOiA2LFxuXHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0fSxcblx0XHR7XG5cdFx0XHR0eXBlOiAnc3RhdGljLXRleHQnLFxuXHRcdFx0aWQ6ICdhdXRvQ3JlYXRlVmFyTm90aWNlJyxcblx0XHRcdGxhYmVsOiAnKioqIFN1cHBvcnQgZm9yIHRoZSBkZXByZWNhdGVkIFwiQXV0by1DcmVhdGVkIFZhcmlhYmxlXCIgZnVuY3Rpb24gKioqJyxcblx0XHRcdHZhbHVlOlxuXHRcdFx0XHQnVGhlIFwiQXV0by1DcmVhdGUgVmFyaWFibGVcIiBmdW5jdGlvbiBoYXMgbm93IGJlZW4gc3VwZXJjZWRlZCBieSB0aGUgYnVpbHQtaW4gTG9jYWwgVmFyaWFibGVzIGZlYXR1cmUgd2l0aGluIENvbXBhbmlvbiA0LjIrLjxicj5JZiB5b3Ugc3RpbGwgaGF2ZSBhdXRvLWNyZWF0ZWQgdmFyaWFibGVzLCBwbGVhc2UgY2hhbmdlIHRoZW0gdG8gVmFsdWUgRmVlZGJhY2tzIGFzIHN1cHBvcnQgZm9yIEF1dG8tQ3JlYXRlZCBWYXJpYWJsZXMgbWF5IGRpc2FwcGVhciBpbiB0aGUgZnV0dXJlIScsXG5cdFx0XHR0b29sdGlwOiAnRW5hYmxlIHRoaXMgc2V0dGluZyBPTkxZIGlmIHlvdSBuZWVkIGNvbXBhdGliaWxpdHkgd2l0aCBleGlzdGluZyBBdXRvLUNyZWF0ZWQgdmFyaWFibGVzJyxcblx0XHRcdHdpZHRoOiAxMixcblx0XHR9LFxuXHRdXG59XG4iLCAiaW1wb3J0IHsgQ29tcGFuaW9uVmFyaWFibGVEZWZpbml0aW9ucywgSnNvbk9iamVjdCB9IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgSU1zZ0FyZ3MsIE1pZGlNZXNzYWdlIH0gZnJvbSAnLi9taWRpL21zZ3R5cGVzLmpzJ1xuXG5leHBvcnQgdHlwZSBtaWRpVmFycyA9IHtcblx0bWlkaUluOiBib29sZWFuXG5cdG1pZGlPdXQ6IGJvb2xlYW5cblx0bGFzdE1lc3NhZ2U6IHN0cmluZ1xuXHRzbXB0ZTogc3RyaW5nXG5cdHNtcHRlRlI6IG51bWJlclxuXHRub3RlU3RhdGVzOiBib29sZWFuW11bXVxufVxuXG5jb25zdCB2YXJpYWJsZXM6IENvbXBhbmlvblZhcmlhYmxlRGVmaW5pdGlvbnM8SnNvbk9iamVjdD4gPSB7XG5cdG1pZGlJbjogeyBuYW1lOiAnSXMgYSBNSURJIE1lc3NhZ2UgSW5jb21pbmc/JyB9LFxuXHRtaWRpT3V0OiB7IG5hbWU6ICdJcyBhIE1JREkgTWVzc2FnZSBPdXRnb2luZz8nIH0sXG5cdGxhc3RNZXNzYWdlOiB7IG5hbWU6ICdMYXN0IE1lc3NhZ2UgUmVjZWl2ZWQnIH0sXG5cdHNtcHRlOiB7IG5hbWU6ICdTTVBURSBUQyBmcm9tIE1UQycgfSxcblx0c21wdGVGUjogeyBuYW1lOiAnU01QVEUgRnJhbWUgUmF0ZSBmcm9tIE1UQycgfSxcblx0bm90ZVN0YXRlczogeyBuYW1lOiAnQ3VycmVudCBOb3RlIHN0YXRlcycgfSxcbn1cblxuY29uc3QgbWlkaVRpbWVyczogTWFwPHN0cmluZywgUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsPiA9IG5ldyBNYXAoKVxuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRzZWxmLnNldFZhcmlhYmxlRGVmaW5pdGlvbnModmFyaWFibGVzKVxuXHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHsgbWlkaUluOiBmYWxzZSwgbWlkaU91dDogZmFsc2UgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIEhhbmRsZU1pZGlJbmRpY2F0b3JzKHNlbGY6IE1vZHVsZUluc3RhbmNlLCB2YXJpYWJsZTogc3RyaW5nKTogdm9pZCB7XG5cdGxldCB0ID0gbWlkaVRpbWVycy5nZXQodmFyaWFibGUpID8/IG51bGxcblx0aWYgKHQgIT09IG51bGwpIGNsZWFyVGltZW91dCh0KVxuXHR0ID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7IFt2YXJpYWJsZV06IGZhbHNlIH0pXG5cdFx0c2VsZi5jaGVja0ZlZWRiYWNrcyh2YXJpYWJsZSlcblx0fSwgMjAwKVxuXHRtaWRpVGltZXJzLnNldCh2YXJpYWJsZSwgdClcblx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7IFt2YXJpYWJsZV06IHRydWUgfSlcblx0c2VsZi5jaGVja0ZlZWRiYWNrcyh2YXJpYWJsZSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFVwZGF0ZUxhc3RNc2coc2VsZjogTW9kdWxlSW5zdGFuY2UsIG1zZzogTWlkaU1lc3NhZ2UsIGRhdGE6IG51bWJlciB8IHVuZGVmaW5lZCk6IHZvaWQge1xuXHRjb25zdCBtc2dJbmZvID0gQ3JlYXRlVmFyTmFtZShtc2cpXG5cdGNvbnN0IGxhc3RNc2cgPSBtc2dJbmZvLm5hbWUgKyAnXycgKyBkYXRhXG5cdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBsYXN0TWVzc2FnZTogbGFzdE1zZyB9KVxuXG5cdEFkZE9yVXBkYXRlVmFyKHNlbGYsICdsYXN0TXNnVHlwZScsICdMYXN0IE1lc3NhZ2UgVHlwZSBSZWNlaXZlZCcsIG1zZy5pZClcblxuXHRpZiAobXNnLmlkID09ICdub3Rlb24nIHx8IG1zZy5pZCA9PSAnbm90ZW9mZicpIHtcblx0XHRjb25zdCBub3RlU3RhdGVzOiBib29sZWFuW11bXSA9IChzZWxmLmdldFZhcmlhYmxlVmFsdWUoJ25vdGVTdGF0ZXMnKSBhcyBib29sZWFuW11bXSkgfHwgW11cblx0XHRub3RlU3RhdGVzW21zZy5jaGFubmVsXSA/Pz0gW11cblx0XHRub3RlU3RhdGVzW21zZy5jaGFubmVsXVttc2cuYXJncy5ub3RlIV0gPSBtc2cuaWQgPT0gJ25vdGVvbicgJiYgZGF0YSEgPiAwXG5cdFx0c2VsZi5zZXRWYXJpYWJsZVZhbHVlcyh7IG5vdGVTdGF0ZXMgfSlcblx0fVxuXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbXNnSW5mby5rZXlzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5TmFtZSA9IG1zZ0luZm8ua2V5c1tpXVxuXHRcdGNvbnN0IGtleSA9IGtleU5hbWUgYXMga2V5b2YgSU1zZ0FyZ3Ncblx0XHRjb25zdCBDYXBLZXlOYW1lID0ga2V5TmFtZVswXS50b1VwcGVyQ2FzZSgpICsga2V5TmFtZS5zbGljZSgxKVxuXHRcdEFkZE9yVXBkYXRlVmFyKHNlbGYsICdsYXN0JyArIENhcEtleU5hbWUsICdMYXN0ICcgKyBDYXBLZXlOYW1lICsgJyBSZWNlaXZlZCcsIE51bWJlcihtc2cuYXJnc1trZXldKSlcblx0fVxufVxuXG5leHBvcnQgZnVuY3Rpb24gRkJDcmVhdGVzVmFyKHNlbGY6IE1vZHVsZUluc3RhbmNlLCBtc2c6IE1pZGlNZXNzYWdlLCBkYXRhOiBudW1iZXIgfCB1bmRlZmluZWQpOiB2b2lkIHtcblx0Ly8gQXV0by1jcmVhdGUgYSB2YXJpYWJsZVxuXHRBZGRPclVwZGF0ZVZhcihzZWxmLCAnXycgKyBDcmVhdGVWYXJOYW1lKG1zZykubmFtZSwgJ0F1dG8tQ3JlYXRlZCBWYXJpYWJsZScsIGRhdGEpXG59XG5cbmZ1bmN0aW9uIENyZWF0ZVZhck5hbWUobXNnOiBNaWRpTWVzc2FnZSk6IHsgbmFtZTogc3RyaW5nOyBrZXlzOiBzdHJpbmdbXSB9IHtcblx0Ly8gQXV0by1jcmVhdGUgYSB2YXJpYWJsZSBuYW1lXG5cblx0bGV0IHZhck5hbWUgPSBtc2cuaWRcblx0Y29uc3QgbXNnS2V5cyA9IE9iamVjdC5rZXlzKG1zZy5hcmdzKVxuXHRmb3IgKGxldCBpID0gMDsgaSA8IG1zZ0tleXMubGVuZ3RoIC0gMTsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gbXNnS2V5c1tpXSBhcyBrZXlvZiBJTXNnQXJnc1xuXHRcdGNvbnN0IHZhbDogbnVtYmVyIHwgdW5kZWZpbmVkID0gTnVtYmVyKG1zZy5hcmdzW2tleV0pXG5cdFx0aWYgKHZhbCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHR2YXJOYW1lICs9IGBfJHt2YWx9YFxuXHRcdH1cblx0fVxuXHRyZXR1cm4geyBuYW1lOiB2YXJOYW1lLCBrZXlzOiBtc2dLZXlzIH1cbn1cblxuZnVuY3Rpb24gQWRkT3JVcGRhdGVWYXIoXG5cdHNlbGY6IE1vZHVsZUluc3RhbmNlLFxuXHR2YXJOYW1lOiBzdHJpbmcsXG5cdHZhckRlc2NyOiBzdHJpbmcsXG5cdGRhdGE6IG51bWJlciB8IHN0cmluZyB8IHVuZGVmaW5lZCxcbik6IHZvaWQge1xuXHR2YXJpYWJsZXNbdmFyTmFtZV0gPSB7IG5hbWU6IHZhckRlc2NyIH0gLy8gaWYgVmFyaWFibGUgZG9lc24ndCBleGlzdCwgYWRkIGl0XG5cdHNlbGYuc2V0VmFyaWFibGVEZWZpbml0aW9ucyh2YXJpYWJsZXMpXG5cdHNlbGYuc2V0VmFyaWFibGVWYWx1ZXMoeyBbdmFyTmFtZV06IGRhdGEgfSlcbn1cbiIsICJpbXBvcnQge1xuXHRDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0LFxuXHRDb21wYW5pb25TdGF0aWNVcGdyYWRlUmVzdWx0LFxuXHRDb21wYW5pb25TdGF0aWNVcGdyYWRlUHJvcHMsXG5cdENvbXBhbmlvblVwZ3JhZGVDb250ZXh0LFxufSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHR5cGUgeyBNb2R1bGVDb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuZXhwb3J0IGNvbnN0IFVwZ3JhZGVTY3JpcHRzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlU2NyaXB0PE1vZHVsZUNvbmZpZz5bXSA9IFtcblx0Lypcblx0ICogUGxhY2UgeW91ciB1cGdyYWRlIHNjcmlwdHMgaGVyZVxuXHQgKiBSZW1lbWJlciB0aGF0IG9uY2UgaXQgaGFzIGJlZW4gYWRkZWQgaXQgY2Fubm90IGJlIHJlbW92ZWQhXG5cdCAqL1xuXHRmdW5jdGlvbiAoXG5cdFx0Y29udGV4dDogQ29tcGFuaW9uVXBncmFkZUNvbnRleHQ8TW9kdWxlQ29uZmlnPixcblx0XHRwcm9wczogQ29tcGFuaW9uU3RhdGljVXBncmFkZVByb3BzPE1vZHVsZUNvbmZpZywgdW5kZWZpbmVkPixcblx0KTogQ29tcGFuaW9uU3RhdGljVXBncmFkZVJlc3VsdDxNb2R1bGVDb25maWcsIHVuZGVmaW5lZD4ge1xuXHRcdGNvbnN0IGNoYW5nZXM6IENvbXBhbmlvblN0YXRpY1VwZ3JhZGVSZXN1bHQ8TW9kdWxlQ29uZmlnLCB1bmRlZmluZWQ+ID0ge1xuXHRcdFx0dXBkYXRlZENvbmZpZzogbnVsbCxcblx0XHRcdHVwZGF0ZWRBY3Rpb25zOiBbXSxcblx0XHRcdHVwZGF0ZWRGZWVkYmFja3M6IFtdLFxuXHRcdH1cblxuXHRcdGNvbnNvbGUubG9nKCdcXG5SdW5uaW5nIFVwZGF0ZSBTY3JpcHRzLi4uXFxuJylcblxuXHRcdGZvciAoY29uc3QgYSBvZiBwcm9wcy5hY3Rpb25zKSB7XG5cdFx0XHRpZiAoYS5hY3Rpb25JZCA9PSAncHJvZ3JhbScpIHtcblx0XHRcdFx0Y29uc29sZS5sb2coJ1VwZGF0aW5nIGFjdGlvblxcbicsIGEpXG5cdFx0XHRcdGEub3B0aW9ucy5wcm9ncmFtID0gYS5vcHRpb25zLm51bWJlciB8fCBhLm9wdGlvbnMucHJvZ3JhbVxuXHRcdFx0XHRkZWxldGUgYS5vcHRpb25zLm51bWJlclxuXHRcdFx0fVxuXHRcdFx0aWYgKCFhLm9wdGlvbnMuY2hWYWx1ZSkgYS5vcHRpb25zLmNoVmFsdWUgPSBhLm9wdGlvbnMuY2hhbm5lbFxuXHRcdFx0aWYgKCFhLm9wdGlvbnMubm90ZVZhbHVlKSBhLm9wdGlvbnMubm90ZVZhbHVlID0gYS5vcHRpb25zLm5vdGVcblx0XHRcdGlmICghYS5vcHRpb25zLmNjVmFsdWUpIGEub3B0aW9ucy5jY1ZhbHVlID0gYS5vcHRpb25zLmNvbnRyb2xsZXJcblxuXHRcdFx0Y2hhbmdlcy51cGRhdGVkQWN0aW9ucy5wdXNoKGEpXG5cdFx0XHRjb25zb2xlLmxvZygndG9cXG4nLCBhKVxuXHRcdH1cblxuXHRcdGZvciAoY29uc3QgZiBvZiBwcm9wcy5mZWVkYmFja3MpIHtcblx0XHRcdGlmIChmLmZlZWRiYWNrSWQgPT0gJ3JlY2VpdmVfbWVzc2FnZScpIHtcblx0XHRcdFx0Y29uc29sZS5sb2coJ1VwZGF0aW5nIGZlZWRiYWNrXFxuJywgZilcblx0XHRcdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1iYXNlLXRvLXN0cmluZ1xuXHRcdFx0XHRmLmZlZWRiYWNrSWQgPSBTdHJpbmcoZi5vcHRpb25zLm1zZ1R5cGUpXG5cdFx0XHRcdGRlbGV0ZSBmLm9wdGlvbnMubXNnVHlwZVxuXHRcdFx0XHRzd2l0Y2ggKGYuZmVlZGJhY2tJZCkge1xuXHRcdFx0XHRcdGNhc2UgJ3Byb2dyYW0nOlxuXHRcdFx0XHRcdFx0Zi5vcHRpb25zLnByb2dyYW0gPSBmLm9wdGlvbnMubnVtYmVyXG5cdFx0XHRcdFx0XHRkZWxldGUgZi5vcHRpb25zLm51bWJlclxuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHRjYXNlICdzeXNleCc6XG5cdFx0XHRcdFx0XHRmLm9wdGlvbnMuYnl0ZXMgPSBmLm9wdGlvbnMubWVzc2FnZVxuXHRcdFx0XHRcdFx0ZGVsZXRlIGYub3B0aW9ucy5tZXNzYWdlXG5cdFx0XHRcdFx0XHRicmVha1xuXHRcdFx0XHRcdGNhc2UgJ3BpdGNoJzpcblx0XHRcdFx0XHRcdGYub3B0aW9ucy52YWx1ZSA9IGYub3B0aW9ucy5waXRjaFxuXHRcdFx0XHRcdFx0ZGVsZXRlIGYub3B0aW9ucy5waXRjaFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoIWYub3B0aW9ucy5jaFZhbHVlKSBmLm9wdGlvbnMuY2hWYWx1ZSA9IGYub3B0aW9ucy5jaGFubmVsXG5cdFx0XHRpZiAoIWYub3B0aW9ucy5ub3RlVmFsdWUpIGYub3B0aW9ucy5ub3RlVmFsdWUgPSBmLm9wdGlvbnMubm90ZVxuXHRcdFx0aWYgKCFmLm9wdGlvbnMuY2NWYWx1ZSkgZi5vcHRpb25zLmNjVmFsdWUgPSBmLm9wdGlvbnMuY29udHJvbGxlclxuXG5cdFx0XHRjaGFuZ2VzLnVwZGF0ZWRGZWVkYmFja3MucHVzaChmKVxuXHRcdFx0Y29uc29sZS5sb2coJ3RvXFxuJywgZilcblx0XHR9XG5cblx0XHRyZXR1cm4gY2hhbmdlc1xuXHR9LFxuXG5cdGZ1bmN0aW9uIChcblx0XHRjb250ZXh0OiBDb21wYW5pb25VcGdyYWRlQ29udGV4dDxNb2R1bGVDb25maWc+LFxuXHRcdHByb3BzOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUHJvcHM8TW9kdWxlQ29uZmlnLCB1bmRlZmluZWQ+LFxuXHQpOiBDb21wYW5pb25TdGF0aWNVcGdyYWRlUmVzdWx0PE1vZHVsZUNvbmZpZywgdW5kZWZpbmVkPiB7XG5cdFx0Y29uc3QgY2hhbmdlczogQ29tcGFuaW9uU3RhdGljVXBncmFkZVJlc3VsdDxNb2R1bGVDb25maWcsIHVuZGVmaW5lZD4gPSB7XG5cdFx0XHR1cGRhdGVkQ29uZmlnOiBudWxsLFxuXHRcdFx0dXBkYXRlZEFjdGlvbnM6IFtdLFxuXHRcdFx0dXBkYXRlZEZlZWRiYWNrczogW10sXG5cdFx0fVxuXG5cdFx0Y29uc29sZS5sb2coJ1xcblJ1bm5pbmcgVXBkYXRlIFNjcmlwdHMuLi5cXG4nKVxuXG5cdFx0Zm9yIChjb25zdCBhIG9mIHByb3BzLmFjdGlvbnMpIHtcblx0XHRcdGNvbnNvbGUubG9nKCdcXG5VcGRhdGluZyBhY3Rpb25cXG4nLCBhKVxuXG5cdFx0XHRpZiAoIWEub3B0aW9ucy5zZW5kT3ZlclRpbWUpIGEub3B0aW9ucy5zZW5kT3ZlclRpbWUgPSB7IGlzRXhwcmVzc2lvbjogZmFsc2UsIHZhbHVlOiBmYWxzZSB9XG5cdFx0XHRpZiAoIWEub3B0aW9ucy50aW1lU3RhcnRWYWx1ZSkgYS5vcHRpb25zLnRpbWVTdGFydFZhbHVlID0geyBpc0V4cHJlc3Npb246IGZhbHNlLCB2YWx1ZTogMCB9XG5cdFx0XHRpZiAoIWEub3B0aW9ucy50aW1lKSBhLm9wdGlvbnMudGltZSA9IHsgaXNFeHByZXNzaW9uOiBmYWxzZSwgdmFsdWU6IDAgfVxuXHRcdFx0aWYgKCFhLm9wdGlvbnMuY3VydmUpIGEub3B0aW9ucy5jdXJ2ZSA9IHsgaXNFeHByZXNzaW9uOiBmYWxzZSwgdmFsdWU6ICdsaW5lYXInIH1cblxuXHRcdFx0Y2hhbmdlcy51cGRhdGVkQWN0aW9ucy5wdXNoKGEpXG5cdFx0XHRjb25zb2xlLmxvZygnXFxudG9cXG4nLCBhKVxuXHRcdH1cblxuXHRcdHJldHVybiBjaGFuZ2VzXG5cdH0sXG5dXG4iLCAiaW1wb3J0IHsgU29tZUNvbXBhbmlvbkFjdGlvbklucHV0RmllbGQsIFNvbWVDb21wYW5pb25GZWVkYmFja0lucHV0RmllbGQgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuXG5pbnRlcmZhY2UgbWlkaU1zZ1R5cGUge1xuXHRpZDogc3RyaW5nXG5cdGxhYmVsOiBzdHJpbmdcblx0ZGVzYzogc3RyaW5nXG5cdHZhbElkOiBzdHJpbmdcblx0dmFsTGFiZWw6IHN0cmluZ1xuXHR2YWxNaW46IG51bWJlclxuXHR2YWxNYXg6IG51bWJlclxuXHR2YWxEZWZhdWx0OiBudW1iZXJcbn1cblxuZXhwb3J0IGNvbnN0IG1pZGlNc2dUeXBlczogbWlkaU1zZ1R5cGVbXSA9IFtcblx0e1xuXHRcdGlkOiAnbm90ZW9mZicsXG5cdFx0bGFiZWw6ICdOb3RlIE9mZicsXG5cdFx0ZGVzYzogJ05vdGUgT2ZmIE1lc3NzYWdlJyxcblx0XHR2YWxJZDogJ3ZlbG9jaXR5Jyxcblx0XHR2YWxMYWJlbDogJ1ZlbG9jaXR5Jyxcblx0XHR2YWxNaW46IDAsXG5cdFx0dmFsTWF4OiAxMjcsXG5cdFx0dmFsRGVmYXVsdDogMCxcblx0fSxcblx0e1xuXHRcdGlkOiAnbm90ZW9uJyxcblx0XHRsYWJlbDogJ05vdGUgT24nLFxuXHRcdGRlc2M6ICdOb3RlIE9uIE1lc3NhZ2UnLFxuXHRcdHZhbElkOiAndmVsb2NpdHknLFxuXHRcdHZhbExhYmVsOiAnVmVsb2NpdHknLFxuXHRcdHZhbE1pbjogMCxcblx0XHR2YWxNYXg6IDEyNyxcblx0XHR2YWxEZWZhdWx0OiAxMjcsXG5cdH0sXG5cdC8vXHRcdHsgaWQ6ICdhZnRlcnRvdWNoJywgbmFtZTogJ0FmdGVydG91Y2gnIH0sXG5cdHtcblx0XHRpZDogJ2NjJyxcblx0XHRsYWJlbDogJ0NDJyxcblx0XHRkZXNjOiAnQ29udHJvbCBDaGFuZ2UgTWVzc2FnZScsXG5cdFx0dmFsSWQ6ICd2YWx1ZScsXG5cdFx0dmFsTGFiZWw6ICdWYWx1ZScsXG5cdFx0dmFsTWluOiAwLFxuXHRcdHZhbE1heDogMTI3LFxuXHRcdHZhbERlZmF1bHQ6IDAsXG5cdH0sXG5cdHtcblx0XHRpZDogJ3Byb2dyYW0nLFxuXHRcdGxhYmVsOiAnUHJvZ3JhbSBDaGFuZ2UnLFxuXHRcdGRlc2M6ICdQcm9ncmFtIENoYW5nZSBNZXNzYWdlJyxcblx0XHR2YWxJZDogJ3Byb2dyYW0nLFxuXHRcdHZhbExhYmVsOiAnUHJvZ3JhbSBOdW1iZXInLFxuXHRcdHZhbE1pbjogMSxcblx0XHR2YWxNYXg6IDEyOCxcblx0XHR2YWxEZWZhdWx0OiAxLFxuXHR9LFxuXHQvL1x0XHR7IGlkOiAnY2hhbm5lbHByZXNzdXJlJywgXHRuYW1lOiAnQ2hhbm5lbCBQcmVzc3VyZScgfSxcblx0e1xuXHRcdGlkOiAncGl0Y2gnLFxuXHRcdGxhYmVsOiAnUGl0Y2ggV2hlZWwnLFxuXHRcdGRlc2M6ICdQaXRjaCBXaGVlbCBNZXNzYWdlJyxcblx0XHR2YWxJZDogJ3ZhbHVlJyxcblx0XHR2YWxMYWJlbDogJ1ZhbHVlJyxcblx0XHR2YWxNaW46IDAsXG5cdFx0dmFsTWF4OiAxNjM4Myxcblx0XHR2YWxEZWZhdWx0OiA4MTkyLFxuXHR9LFxuXHR7XG5cdFx0aWQ6ICdzeXNleCcsXG5cdFx0bGFiZWw6ICdTeXNFeCcsXG5cdFx0ZGVzYzogJ1N5c3RlbSBFeGNsdXNpdmUgTWVzc2FnZScsXG5cdFx0dmFsSWQ6ICdieXRlcycsXG5cdFx0dmFsTGFiZWw6ICdTeXNFeCBCeXRlcycsXG5cdFx0dmFsTWluOiAwLFxuXHRcdHZhbE1heDogMTI3LFxuXHRcdHZhbERlZmF1bHQ6IDAsXG5cdH0sXG5cdC8vXHRcdHsgaWQ6ICdtdGMnLCBcdFx0XHRcdG5hbWU6ICdNSURJIFRpbWUgQ29kZScgfSxcblx0Ly9cdFx0eyBpZDogJ3Bvc2l0aW9uJyxcdFx0XHRuYW1lOiAnU29uZyBQb3NpdGlvbiBQb2ludGVyJyB9LFxuXHQvL1x0XHR7IGlkOiAnc2VsZWN0JyxcdFx0XHRcdG5hbWU6ICdTb25nIFNlbGVjdCcgfSxcblx0Ly9cdFx0eyBpZDogJ3R1bmUnLFx0XHRcdFx0bmFtZTogJ1R1bmUgUmVxdWVzdCcgfSxcblx0Ly9cdFx0eyBpZDogJ3N5c2V4IGVuZCcsXHRcdFx0bmFtZTogJ1N5c0V4IEVuZCcgfSxcblx0Ly9cdFx0eyBpZDogJ2Nsb2NrJyxcdFx0XHRcdG5hbWU6ICdDbG9jaycgfSxcblx0Ly9cdFx0eyBpZDogJ3N0YXJ0JyxcdFx0XHRcdG5hbWU6ICdTdGFydCcgfSxcblx0Ly9cdFx0eyBpZDogJ2NvbnRpbnVlJyxcdFx0XHRuYW1lOiAnQ29udGludWUnIH0sXG5cdC8vXHRcdHsgaWQ6ICdzdG9wJyxcdFx0XHRcdG5hbWU6ICdTdG9wJyB9LFxuXHQvL1x0XHR7IGlkOiAnYWN0aXZlc2Vuc2UnLFx0XHRuYW1lOiAnQWN0aXZlIFNlbnNpbmcnIH0sXG5cdC8vXHRcdHsgaWQ6ICdyZXNldCcsXHRcdFx0XHRuYW1lOiAnUmVzZXQnIH0sXG5dXG5cbnR5cGUgb3B0aW9uVHlwZXMgPSBTb21lQ29tcGFuaW9uQWN0aW9uSW5wdXRGaWVsZFtdIHwgU29tZUNvbXBhbmlvbkZlZWRiYWNrSW5wdXRGaWVsZFtdXG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVPcHRpb25zKG5ld09wdHM6IG9wdGlvblR5cGVzLCBtaWRpT3A6IG1pZGlNc2dUeXBlKTogb3B0aW9uVHlwZXMge1xuXHRpZiAoWydub3Rlb2ZmJywgJ25vdGVvbicsICdjYycsICdwcm9ncmFtJywgJ3BpdGNoJ10uaW5jbHVkZXMobWlkaU9wLmlkKSkge1xuXHRcdG5ld09wdHMucHVzaCh7XG5cdFx0XHRpZDogJ2NoYW5uZWwnLFxuXHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRsYWJlbDogJ0NoYW5uZWwnLFxuXHRcdFx0ZGVmYXVsdDogMSxcblx0XHRcdG1pbjogMSxcblx0XHRcdG1heDogMTYsXG5cdFx0fSlcblx0fVxuXHRpZiAoWydub3Rlb2ZmJywgJ25vdGVvbiddLmluY2x1ZGVzKG1pZGlPcC5pZCkpIHtcblx0XHRuZXdPcHRzLnB1c2goe1xuXHRcdFx0aWQ6ICdub3RlJyxcblx0XHRcdHR5cGU6ICdudW1iZXInLFxuXHRcdFx0bGFiZWw6ICdOb3RlIE51bWJlcicsXG5cdFx0XHRkZWZhdWx0OiA2MCxcblx0XHRcdG1pbjogMCxcblx0XHRcdG1heDogMTI3LFxuXHRcdH0pXG5cdH1cblx0aWYgKG1pZGlPcC5pZCA9PSAnY2MnKSB7XG5cdFx0bmV3T3B0cy5wdXNoKHtcblx0XHRcdGlkOiAnY29udHJvbGxlcicsXG5cdFx0XHR0eXBlOiAnbnVtYmVyJyxcblx0XHRcdGxhYmVsOiAnQ29udHJvbGxlcicsXG5cdFx0XHRkZWZhdWx0OiAxMjcsXG5cdFx0XHRtaW46IDAsXG5cdFx0XHRtYXg6IDEyNyxcblx0XHR9KVxuXHR9XG5cdGlmIChtaWRpT3AuaWQgIT0gJ3N5c2V4Jykge1xuXHRcdG5ld09wdHMucHVzaCh7XG5cdFx0XHRpZDogbWlkaU9wLnZhbElkLFxuXHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRsYWJlbDogbWlkaU9wLnZhbExhYmVsLFxuXHRcdFx0ZGVmYXVsdDogbWlkaU9wLnZhbERlZmF1bHQsXG5cdFx0XHRtaW46IG1pZGlPcC52YWxNaW4sXG5cdFx0XHRtYXg6IG1pZGlPcC52YWxNYXgsXG5cdFx0fSlcblx0fSBlbHNlIHtcblx0XHRuZXdPcHRzLnB1c2goe1xuXHRcdFx0aWQ6ICdieXRlcycsXG5cdFx0XHR0eXBlOiAndGV4dGlucHV0Jyxcblx0XHRcdGxhYmVsOiBtaWRpT3AudmFsTGFiZWwsXG5cdFx0XHR0b29sdGlwOlxuXHRcdFx0XHQnRW50ZXIgYSBzdHJpbmcgb2YgZGVjaW1hbCBvciBoZXggZGlnaXRzLCB3aXRoIHNwYWNlcyBvciBjb21tYXMgYmV0d2Vlbi4gTVVTVCBzdGFydCB3aXRoIDB4RjAgb3IgMjQwIGFuZCBlbmQgd2l0aCAweEY3IG9yIDI0NycsXG5cdFx0XHRkZWZhdWx0OiAnJyxcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIG5ld09wdHNcbn1cbiIsICJpbXBvcnQgTW9kdWxlSW5zdGFuY2UgZnJvbSAnLi9tYWluLmpzJ1xuaW1wb3J0IHsgQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbiwgQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgSGFuZGxlTWlkaUluZGljYXRvcnMgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IE1pZGlNZXNzYWdlIH0gZnJvbSAnLi9taWRpL21zZ3R5cGVzLmpzJ1xuaW1wb3J0IHsgbWlkaU1zZ1R5cGVzLCBjcmVhdGVPcHRpb25zIH0gZnJvbSAnLi9vcGVyYXRpb25zLmpzJ1xuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlQWN0aW9ucyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRzZWxmLnNldFZhcmlhYmxlVmFsdWVzKHsgbWlkaU91dERhdGE6IGZhbHNlIH0pXG5cblx0Y29uc3QgYWN0aW9uczogQ29tcGFuaW9uQWN0aW9uRGVmaW5pdGlvbnMgPSB7fVxuXHRmb3IgKGNvbnN0IGFjdGlvbiBvZiBtaWRpTXNnVHlwZXMpIHtcblx0XHRjb25zdCBuZXdBY3Rpb246IENvbXBhbmlvbkFjdGlvbkRlZmluaXRpb24gPSB7XG5cdFx0XHRuYW1lOiBTdHJpbmcoYWN0aW9uLmxhYmVsKSxcblx0XHRcdG9wdGlvbnM6IGNyZWF0ZU9wdGlvbnMoW10sIGFjdGlvbiksXG5cdFx0XHRjYWxsYmFjazogYXN5bmMgKGV2ZW50KTogUHJvbWlzZTx2b2lkPiA9PiB7XG5cdFx0XHRcdGNvbnN0IG9wdHMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGV2ZW50Lm9wdGlvbnMpKVxuXG5cdFx0XHRcdGlmICghc2VsZi5jb25maWcub3V0UG9ydElzVmlydHVhbCAmJiAhc2VsZi5taWRpT3V0cHV0LmlzUG9ydE9wZW4oKSkge1xuXHRcdFx0XHRcdHNlbGYubG9nKCdlcnJvcicsIGBPdXRwdXQgUG9ydCBcIiR7c2VsZi5taWRpT3V0cHV0Lm5hbWV9XCIgbm90IG9wZW4hYClcblx0XHRcdFx0XHRyZXR1cm5cblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChhY3Rpb24uaWQgPT0gJ3N5c2V4Jykge1xuXHRcdFx0XHRcdGNvbnN0IHBhcnNlZFN5c2V4ID0gYXdhaXQgb3B0c1thY3Rpb24udmFsSWRdXG5cdFx0XHRcdFx0b3B0cy5ieXRlcyA9IHBhcnNlZFN5c2V4LnNwbGl0KC9bICxdKy8pLm1hcCgobjogc3RyaW5nKTogbnVtYmVyID0+IHBhcnNlSW50KG4pKVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKG9wdHMucmVsVmFsdWUpIHtcblx0XHRcdFx0XHRvcHRzW2FjdGlvbi52YWxJZF0gPSBOdW1iZXIoYXdhaXQgb3B0cy52YXJWYWx1ZSlcblx0XHRcdFx0XHRpZiAob3B0cy5jaFZhbHVlKSBvcHRzLmNoYW5uZWwgPSBOdW1iZXIoYXdhaXQgb3B0cy5jaFZhbHVlKVxuXHRcdFx0XHRcdGlmIChvcHRzLm5vdGVWYWx1ZSkgb3B0cy5ub3RlID0gTnVtYmVyKGF3YWl0IG9wdHMubm90ZVZhbHVlKVxuXHRcdFx0XHRcdGlmIChvcHRzLmNjVmFsdWUpIG9wdHMuY29udHJvbGxlciA9IE51bWJlcihhd2FpdCBvcHRzLmNjVmFsdWUpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRsZXQgbXNnID0gTWlkaU1lc3NhZ2UucGFyc2VNZXNzYWdlKHVuZGVmaW5lZCwgeyBpZDogYWN0aW9uLmlkLCAuLi5vcHRzIH0pXG5cdFx0XHRcdGlmIChvcHRzLnJlbFZhbHVlKSB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsID0gc2VsZi5nZXRGcm9tRGF0YVN0b3JlKG1zZyEpXG5cdFx0XHRcdFx0aWYgKHZhbCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdFx0XHRzZWxmLmxvZygnaW5mbycsICdSZWxhdGl2ZSB2YWx1ZSBub3Qgc2VudC4gQ3VycmVudCB2YWx1ZSBmcm9tIGRldmljZSBpcyBuZWVkZWQhJylcblx0XHRcdFx0XHRcdHJldHVyblxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRvcHRzW2FjdGlvbi52YWxJZF0gPSB2YWwgKyBOdW1iZXIob3B0c1thY3Rpb24udmFsSWRdICogMSlcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChvcHRzLnNlbmRPdmVyVGltZSkge1xuXHRcdFx0XHRcdC8vIEhhbmRsZSBzZW5kaW5nIG92ZXIgdGltZVxuXHRcdFx0XHRcdGNvbnN0IGR1cmF0aW9uTXMgPSBvcHRzLnRpbWUgKiAxMDAwXG5cdFx0XHRcdFx0Y29uc3QgY3VydmUgPSBvcHRzLmN1cnZlXG5cdFx0XHRcdFx0Y29uc3QgdGlja01zID0gMTVcblxuXHRcdFx0XHRcdGxldCBzdGFydCA9IDBcblx0XHRcdFx0XHRpZiAob3B0cy5yZWxWYWx1ZSkge1xuXHRcdFx0XHRcdFx0c3RhcnQgPSBzZWxmLmdldEZyb21EYXRhU3RvcmUobXNnISkgfHwgMFxuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRzdGFydCA9IE51bWJlcihvcHRzLnRpbWVTdGFydFZhbHVlKVxuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdGxldCBlbmQgPSBOdW1iZXIob3B0c1thY3Rpb24udmFsSWRdICogMSlcblxuXHRcdFx0XHRcdC8vZW5zdXJlIGVuZCB2YWx1ZSBpcyB3aXRoaW4gYm91bmRzXG5cdFx0XHRcdFx0aWYgKGVuZCA8IDApIHtcblx0XHRcdFx0XHRcdGVuZCA9IDBcblx0XHRcdFx0XHR9IGVsc2UgaWYgKGVuZCA+IDEyNykge1xuXHRcdFx0XHRcdFx0ZW5kID0gMTI3XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Ly9pZiBzdGFydCA+IGVuZCwgc3dhcCB0aGVtXG5cdFx0XHRcdFx0aWYgKHN0YXJ0ID4gZW5kKSB7XG5cdFx0XHRcdFx0XHQvLztbc3RhcnQsIGVuZF0gPSBbZW5kLCBzdGFydF1cblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRjb25zdCB0MCA9IERhdGUubm93KClcblx0XHRcdFx0XHRsZXQgbGFzdCA9IC0xXG5cblx0XHRcdFx0XHRpbnRlcmZhY2UgRWFzZUZ1bmN0aW9ucyB7XG5cdFx0XHRcdFx0XHRba2V5OiBzdHJpbmddOiAoeDogbnVtYmVyKSA9PiBudW1iZXJcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRjb25zdCBlYXNlRnVuY3Rpb25zOiBFYXNlRnVuY3Rpb25zID0ge1xuXHRcdFx0XHRcdFx0bGluZWFyOiAoeDogbnVtYmVyKTogbnVtYmVyID0+IHgsXG5cdFx0XHRcdFx0XHRlYXNlSW46ICh4OiBudW1iZXIpOiBudW1iZXIgPT4geCAqIHgsXG5cdFx0XHRcdFx0XHRlYXNlT3V0OiAoeDogbnVtYmVyKTogbnVtYmVyID0+IDEgLSAoMSAtIHgpICogKDEgLSB4KSxcblx0XHRcdFx0XHRcdGVhc2VJbk91dDogKHg6IG51bWJlcik6IG51bWJlciA9PiAoeCA8IDAuNSA/IDIgKiB4ICogeCA6IDEgLSBNYXRoLnBvdygtMiAqIHggKyAyLCAyKSAvIDIpLFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRjb25zdCBlYXNlOiAoeDogbnVtYmVyKSA9PiBudW1iZXIgPSBlYXNlRnVuY3Rpb25zW2N1cnZlIGFzIHN0cmluZ10gfHwgKCh4OiBudW1iZXIpOiBudW1iZXIgPT4geClcblxuXHRcdFx0XHRcdGNvbnN0IHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuXHRcdFx0XHRcdFx0Y29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSB0MFxuXHRcdFx0XHRcdFx0Y29uc3QgdSA9IE1hdGgubWluKDEsIGVsYXBzZWQgLyBkdXJhdGlvbk1zKVxuXHRcdFx0XHRcdFx0Y29uc3QgdmFsID0gTWF0aC5yb3VuZChzdGFydCArIChlbmQgLSBzdGFydCkgKiBlYXNlKHUpKVxuXG5cdFx0XHRcdFx0XHRpZiAodmFsICE9PSBsYXN0KSB7XG5cdFx0XHRcdFx0XHRcdG9wdHNbYWN0aW9uLnZhbElkXSA9IHZhbFxuXHRcdFx0XHRcdFx0XHRtc2cgPSBNaWRpTWVzc2FnZS5wYXJzZU1lc3NhZ2UodW5kZWZpbmVkLCB7IGlkOiBhY3Rpb24uaWQsIC4uLm9wdHMgfSlcblx0XHRcdFx0XHRcdFx0c2VsZi5sb2coJ2RlYnVnJywgYFNlbmRpbmc6ICAke21zZ30gdG8gXCIke3NlbGYubWlkaU91dHB1dC5uYW1lfVwiYClcblx0XHRcdFx0XHRcdFx0c2VsZi5taWRpT3V0cHV0LnNlbmQobXNnISlcblx0XHRcdFx0XHRcdFx0SGFuZGxlTWlkaUluZGljYXRvcnMoc2VsZiwgJ21pZGlPdXQnKVxuXHRcdFx0XHRcdFx0XHRsYXN0ID0gdmFsXG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHRpZiAodSA+PSAxKSBjbGVhckludGVydmFsKHRpbWVyKVxuXHRcdFx0XHRcdH0sIHRpY2tNcylcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRtc2cgPSBNaWRpTWVzc2FnZS5wYXJzZU1lc3NhZ2UodW5kZWZpbmVkLCB7IGlkOiBhY3Rpb24uaWQsIC4uLm9wdHMgfSlcblx0XHRcdFx0XHRzZWxmLmxvZygnZGVidWcnLCBgU2VuZGluZzogICR7bXNnfSB0byBcIiR7c2VsZi5taWRpT3V0cHV0Lm5hbWV9XCJgKVxuXHRcdFx0XHRcdHNlbGYubWlkaU91dHB1dC5zZW5kKG1zZyEpXG5cdFx0XHRcdFx0SGFuZGxlTWlkaUluZGljYXRvcnMoc2VsZiwgJ21pZGlPdXQnKVxuXHRcdFx0XHR9XG5cdFx0XHR9LFxuXHRcdH1cblxuXHRcdGlmIChhY3Rpb24uaWQgIT0gJ3N5c2V4Jykge1xuXHRcdFx0bmV3QWN0aW9uLm9wdGlvbnMuYXQoLTEpIS5pc1Zpc2libGVFeHByZXNzaW9uID0gJyEkKG9wdGlvbnM6cmVsVmFsdWUpJ1xuXHRcdFx0bmV3QWN0aW9uLm9wdGlvbnMucHVzaChcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAndmFyVmFsdWUnLFxuXHRcdFx0XHRcdHR5cGU6ICdudW1iZXInLFxuXHRcdFx0XHRcdGxhYmVsOiBhY3Rpb24udmFsTGFiZWwsXG5cdFx0XHRcdFx0ZGVmYXVsdDogYWN0aW9uLnZhbERlZmF1bHQsXG5cdFx0XHRcdFx0bWluOiAtYWN0aW9uLnZhbE1heCxcblx0XHRcdFx0XHRtYXg6IGFjdGlvbi52YWxNYXgsXG5cdFx0XHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogJyEhJChvcHRpb25zOnJlbFZhbHVlKScsXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRpZDogJ3JlbFRleHQnLFxuXHRcdFx0XHRcdHR5cGU6ICdzdGF0aWMtdGV4dCcsXG5cdFx0XHRcdFx0bGFiZWw6ICcqKiBOT1RFICoqJyxcblx0XHRcdFx0XHR2YWx1ZTogJ1JlbGF0aXZlIHdpbGwgb25seSB3b3JrIGFmdGVyIGEgdmFsdWUgaGFzIGJlZW4gc2VudCBmcm9tIHRoZSBkZXZpY2UhJyxcblx0XHRcdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiAnJChvcHRpb25zOnJlbFZhbHVlKScsXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRpZDogJ3JlbFZhbHVlJyxcblx0XHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRcdGxhYmVsOiAnUmVsYXRpdmUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHRcdGRpc2FibGVBdXRvRXhwcmVzc2lvbjogdHJ1ZSxcblx0XHRcdFx0fSxcblx0XHRcdClcblxuXHRcdFx0Ly9vdmVyIHRpbWUgZmVhdHVyZXMgLSB0aW1lIGluIHNlY29uZHMsIGN1cnZlIHR5cGUgKGxpbmVhciwgZWFzZSBpbiwgZWFzZSBvdXQsIGVhc2UgaW4vb3V0KVxuXHRcdFx0bmV3QWN0aW9uLm9wdGlvbnMucHVzaChcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAnc2VuZE92ZXJUaW1lJyxcblx0XHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRcdGxhYmVsOiAnU2VuZCBPdmVyIFRpbWUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IGZhbHNlLFxuXHRcdFx0XHRcdGRpc2FibGVBdXRvRXhwcmVzc2lvbjogdHJ1ZSxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAndGltZVN0YXJ0VmFsdWUnLFxuXHRcdFx0XHRcdHR5cGU6ICdudW1iZXInLFxuXHRcdFx0XHRcdGxhYmVsOiAnU3RhcnQgVmFsdWUnLFxuXHRcdFx0XHRcdGRlZmF1bHQ6IDAsXG5cdFx0XHRcdFx0bWluOiAwLFxuXHRcdFx0XHRcdG1heDogMTI3LFxuXHRcdFx0XHRcdGlzVmlzaWJsZUV4cHJlc3Npb246ICchISQob3B0aW9uczpzZW5kT3ZlclRpbWUpICYmICEkKG9wdGlvbnM6cmVsVmFsdWUpJyxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAndGltZScsXG5cdFx0XHRcdFx0dHlwZTogJ251bWJlcicsXG5cdFx0XHRcdFx0bGFiZWw6ICdUaW1lIChzZWNvbmRzKScsXG5cdFx0XHRcdFx0ZGVmYXVsdDogMSxcblx0XHRcdFx0XHRtaW46IDAsXG5cdFx0XHRcdFx0bWF4OiA2MDAsXG5cdFx0XHRcdFx0aXNWaXNpYmxlRXhwcmVzc2lvbjogJyQob3B0aW9uczpzZW5kT3ZlclRpbWUpJyxcblx0XHRcdFx0fSxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGlkOiAnY3VydmUnLFxuXHRcdFx0XHRcdHR5cGU6ICdkcm9wZG93bicsXG5cdFx0XHRcdFx0bGFiZWw6ICdDdXJ2ZSBUeXBlJyxcblx0XHRcdFx0XHRkZWZhdWx0OiAnbGluZWFyJyxcblx0XHRcdFx0XHRjaG9pY2VzOiBbXG5cdFx0XHRcdFx0XHR7IGxhYmVsOiAnTGluZWFyJywgaWQ6ICdsaW5lYXInIH0sXG5cdFx0XHRcdFx0XHR7IGxhYmVsOiAnRWFzZSBJbicsIGlkOiAnZWFzZUluJyB9LFxuXHRcdFx0XHRcdFx0eyBsYWJlbDogJ0Vhc2UgT3V0JywgaWQ6ICdlYXNlT3V0JyB9LFxuXHRcdFx0XHRcdFx0eyBsYWJlbDogJ0Vhc2UgSW4vT3V0JywgaWQ6ICdlYXNlSW5PdXQnIH0sXG5cdFx0XHRcdFx0XSxcblx0XHRcdFx0XHRpc1Zpc2libGVFeHByZXNzaW9uOiAnJChvcHRpb25zOnNlbmRPdmVyVGltZSknLFxuXHRcdFx0XHR9LFxuXHRcdFx0KVxuXHRcdH1cblxuXHRcdGFjdGlvbnNbYWN0aW9uLmlkXSA9IG5ld0FjdGlvblxuXHR9XG5cblx0c2VsZi5zZXRBY3Rpb25EZWZpbml0aW9ucyhhY3Rpb25zKVxufVxuIiwgImltcG9ydCBNb2R1bGVJbnN0YW5jZSBmcm9tICcuL21haW4uanMnXG5pbXBvcnQge1xuXHRDb21wYW5pb25GZWVkYmFja0RlZmluaXRpb24sXG5cdENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbnMsXG5cdFNvbWVDb21wYW5pb25GZWVkYmFja0lucHV0RmllbGQsXG5cdGNvbWJpbmVSZ2IsXG59IGZyb20gJ0Bjb21wYW5pb24tbW9kdWxlL2Jhc2UnXG5pbXBvcnQgeyBGQkNyZWF0ZXNWYXIgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IE1pZGlNZXNzYWdlIH0gZnJvbSAnLi9taWRpL21zZ3R5cGVzLmpzJ1xuaW1wb3J0IHsgbWlkaU1zZ1R5cGVzLCBjcmVhdGVPcHRpb25zIH0gZnJvbSAnLi9vcGVyYXRpb25zLmpzJ1xuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlRmVlZGJhY2tzKHNlbGY6IE1vZHVsZUluc3RhbmNlKTogdm9pZCB7XG5cdGNvbnN0IGZlZWRiYWNrczogQ29tcGFuaW9uRmVlZGJhY2tEZWZpbml0aW9ucyA9IHt9XG5cdGZvciAoY29uc3QgZmVlZGJhY2sgb2YgbWlkaU1zZ1R5cGVzKSB7XG5cdFx0Y29uc3QgbmV3RmVlZGJhY2s6IENvbXBhbmlvbkZlZWRiYWNrRGVmaW5pdGlvbiA9IHtcblx0XHRcdG5hbWU6IGZlZWRiYWNrLmxhYmVsLFxuXHRcdFx0ZGVzY3JpcHRpb246IGZlZWRiYWNrLmRlc2MsXG5cdFx0XHR0eXBlOiAnYm9vbGVhbicsXG5cdFx0XHRkZWZhdWx0U3R5bGU6IHtcblx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigyNTUsIDAsIDApLFxuXHRcdFx0XHRjb2xvcjogY29tYmluZVJnYigwLCAwLCAwKSxcblx0XHRcdH0sXG5cdFx0XHRvcHRpb25zOiBjcmVhdGVPcHRpb25zKFtdLCBmZWVkYmFjaykgYXMgU29tZUNvbXBhbmlvbkZlZWRiYWNrSW5wdXRGaWVsZFtdLFxuXHRcdFx0Y2FsbGJhY2s6IGFzeW5jIChldmVudCk6IFByb21pc2U8Ym9vbGVhbj4gPT4ge1xuXHRcdFx0XHRjb25zdCBvcHRzID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShldmVudC5vcHRpb25zKSlcblxuXHRcdFx0XHRpZiAoZXZlbnQuZmVlZGJhY2tJZCA9PSAnc3lzZXgnKSB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyc2VkU3lzZXggPSBhd2FpdCBvcHRzW2ZlZWRiYWNrLnZhbElkXVxuXHRcdFx0XHRcdG9wdHMuYnl0ZXMgPSBwYXJzZWRTeXNleC5zcGxpdCgvWyAsXSsvKS5tYXAoKG46IHN0cmluZyk6IG51bWJlciA9PiBwYXJzZUludChuKSlcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlmIChvcHRzLnJlbFZhbHVlKSB7XG5cdFx0XHRcdFx0b3B0c1tmZWVkYmFjay52YWxJZF0gPSBOdW1iZXIoYXdhaXQgb3B0cy52YXJWYWx1ZSlcblx0XHRcdFx0XHRpZiAob3B0cy5jaFZhbHVlKSBvcHRzLmNoYW5uZWwgPSBOdW1iZXIoYXdhaXQgb3B0cy5jaFZhbHVlKVxuXHRcdFx0XHRcdGlmIChvcHRzLm5vdGVWYWx1ZSkgb3B0cy5ub3RlID0gTnVtYmVyKGF3YWl0IG9wdHMubm90ZVZhbHVlKVxuXHRcdFx0XHRcdGlmIChvcHRzLmNjVmFsdWUpIG9wdHMuY29udHJvbGxlciA9IE51bWJlcihhd2FpdCBvcHRzLmNjVmFsdWUpXG5cdFx0XHRcdH1cblxuXHRcdFx0XHRjb25zdCBtc2cgPSBNaWRpTWVzc2FnZS5wYXJzZU1lc3NhZ2UodW5kZWZpbmVkLCB7IGlkOiBldmVudC5mZWVkYmFja0lkLCAuLi5vcHRzIH0pXG5cblx0XHRcdFx0Y29uc3QgZGF0YVN0b3JlVmFsID0gc2VsZi5nZXRGcm9tRGF0YVN0b3JlKG1zZyEpXG5cdFx0XHRcdGlmIChldmVudC5mZWVkYmFja0lkICE9PSAnc3lzZXgnICYmIG9wdHMuY3JlYXRlVmFyICYmIHNlbGYuY29uZmlnLmF1dG9DcmVhdGVWYXJzICYmIG1zZyAhPT0gdW5kZWZpbmVkKVxuXHRcdFx0XHRcdEZCQ3JlYXRlc1ZhcihzZWxmLCBtc2csIGRhdGFTdG9yZVZhbClcblx0XHRcdFx0aWYgKGRhdGFTdG9yZVZhbCA9PSB1bmRlZmluZWQpIHJldHVybiBmYWxzZVxuXHRcdFx0XHRpZiAoZGF0YVN0b3JlVmFsID09IHNlbGYuZ2V0VmFsRnJvbU1zZyhtc2chKS52YWwpIHtcblx0XHRcdFx0XHRyZXR1cm4gdHJ1ZVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBmYWxzZVxuXHRcdFx0fSxcblx0XHR9XG5cblx0XHRpZiAoZmVlZGJhY2suaWQgIT0gJ3N5c2V4JyAmJiBzZWxmLmNvbmZpZy5hdXRvQ3JlYXRlVmFycykge1xuXHRcdFx0bmV3RmVlZGJhY2sub3B0aW9ucy5hdCgtMSkhLmlzVmlzaWJsZUV4cHJlc3Npb24gPSAnISQob3B0aW9uczpjcmVhdGVWYXIpJ1xuXHRcdFx0bmV3RmVlZGJhY2sub3B0aW9ucy5wdXNoKHtcblx0XHRcdFx0aWQ6ICdjcmVhdGVWYXInLFxuXHRcdFx0XHR0eXBlOiAnY2hlY2tib3gnLFxuXHRcdFx0XHRsYWJlbDogJ0F1dG8tQ3JlYXRlIFZhcmlhYmxlJyxcblx0XHRcdFx0ZGVmYXVsdDogZmFsc2UsXG5cdFx0XHRcdGRpc2FibGVBdXRvRXhwcmVzc2lvbjogdHJ1ZSxcblx0XHRcdH0pXG5cdFx0fVxuXG5cdFx0ZmVlZGJhY2tzW2ZlZWRiYWNrLmlkXSA9IG5ld0ZlZWRiYWNrXG5cblx0XHRmZWVkYmFja3NbZmVlZGJhY2suaWQgKyAnX3ZhbHVlJ10gPSB7XG5cdFx0XHQuLi5uZXdGZWVkYmFjayxcblx0XHRcdG5hbWU6IGZlZWRiYWNrLmxhYmVsICsgJyBWYWx1ZScsXG5cdFx0XHR0eXBlOiAndmFsdWUnLFxuXHRcdFx0b3B0aW9uczogbmV3RmVlZGJhY2sub3B0aW9ucy5maWx0ZXIoKG8pID0+IG8uaWQgIT09IGZlZWRiYWNrLnZhbElkICYmIG8uaWQgIT09ICdjcmVhdGVWYXInKSxcblx0XHRcdGNhbGxiYWNrOiBhc3luYyAoZXZlbnQpOiBQcm9taXNlPG51bWJlcj4gPT4ge1xuXHRcdFx0XHRjb25zdCBvcHRzID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShldmVudC5vcHRpb25zKSlcblx0XHRcdFx0Y29uc3QgbXNnSWQgPSBldmVudC5mZWVkYmFja0lkLnJlcGxhY2UoJ192YWx1ZScsICcnKVxuXHRcdFx0XHRjb25zdCBtc2cgPSBNaWRpTWVzc2FnZS5wYXJzZU1lc3NhZ2UodW5kZWZpbmVkLCB7IGlkOiBtc2dJZCwgLi4ub3B0cyB9KVxuXHRcdFx0XHRyZXR1cm4gc2VsZi5nZXRGcm9tRGF0YVN0b3JlKG1zZyEpID8/IDBcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0ZmVlZGJhY2tzWydtaWRpSW4nXSA9IHtcblx0XHRuYW1lOiAnTUlESSBNZXNzYWdlIEluY29taW5nPycsXG5cdFx0ZGVzY3JpcHRpb246ICdGaXJlIHdoZW5ldmVyIEFOWSBNSURJIG1lc3NhZ2UgaXMgcmVjZWl2ZWQnLFxuXHRcdHR5cGU6ICdib29sZWFuJyxcblx0XHRkZWZhdWx0U3R5bGU6IHtcblx0XHRcdGJnY29sb3I6IGNvbWJpbmVSZ2IoMjU1LCAwLCAwKSxcblx0XHRcdGNvbG9yOiBjb21iaW5lUmdiKDAsIDAsIDApLFxuXHRcdH0sXG5cdFx0b3B0aW9uczogW10sXG5cdFx0Y2FsbGJhY2s6IGFzeW5jICgpOiBQcm9taXNlPGJvb2xlYW4+ID0+IHtcblx0XHRcdHJldHVybiAhIXNlbGYuZ2V0VmFyaWFibGVWYWx1ZSgnbWlkaUluJylcblx0XHR9LFxuXHR9XG5cblx0ZmVlZGJhY2tzWydtaWRpT3V0J10gPSB7XG5cdFx0bmFtZTogJ01JREkgTWVzc2FnZSBPdXRnb2luZz8nLFxuXHRcdGRlc2NyaXB0aW9uOiAnRmlyZSB3aGVuZXZlciBBTlkgTUlESSBtZXNzYWdlIGlzIHNlbnQnLFxuXHRcdHR5cGU6ICdib29sZWFuJyxcblx0XHRkZWZhdWx0U3R5bGU6IHtcblx0XHRcdGJnY29sb3I6IGNvbWJpbmVSZ2IoMjU1LCAwLCAwKSxcblx0XHRcdGNvbG9yOiBjb21iaW5lUmdiKDAsIDAsIDApLFxuXHRcdH0sXG5cdFx0b3B0aW9uczogW10sXG5cdFx0Y2FsbGJhY2s6IGFzeW5jICgpOiBQcm9taXNlPGJvb2xlYW4+ID0+IHtcblx0XHRcdHJldHVybiAhIXNlbGYuZ2V0VmFyaWFibGVWYWx1ZSgnbWlkaU91dCcpXG5cdFx0fSxcblx0fVxuXG5cdHNlbGYuc2V0RmVlZGJhY2tEZWZpbml0aW9ucyhmZWVkYmFja3MpXG59XG4iLCAiaW1wb3J0IE1vZHVsZUluc3RhbmNlIGZyb20gJy4vbWFpbi5qcydcbmltcG9ydCB7IGNvbWJpbmVSZ2IgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuXG5leHBvcnQgZnVuY3Rpb24gVXBkYXRlUHJlc2V0cyhzZWxmOiBNb2R1bGVJbnN0YW5jZSk6IHZvaWQge1xuXHRjb25zdCBwcmVzZXRzID0ge1xuXHRcdG1pZGlfaW46IHtcblx0XHRcdHR5cGU6ICdzaW1wbGUnIGFzIGNvbnN0LFxuXHRcdFx0bmFtZTogYE1JREkgTWVzc2FnZSBJbiBJbmRpY2F0b3JgLFxuXHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0dGV4dDogYE1JREkgSU5gLFxuXHRcdFx0XHRzaXplOiAnYXV0bycgYXMgY29uc3QsXG5cdFx0XHRcdGNvbG9yOiBjb21iaW5lUmdiKDI1NSwgMjU1LCAyNTUpLFxuXHRcdFx0XHRiZ2NvbG9yOiBjb21iaW5lUmdiKDAsIDAsIDApLFxuXHRcdFx0fSxcblx0XHRcdHN0ZXBzOiBbXSxcblx0XHRcdGZlZWRiYWNrczogW1xuXHRcdFx0XHR7XG5cdFx0XHRcdFx0ZmVlZGJhY2tJZDogJ21pZGlJbicsXG5cdFx0XHRcdFx0b3B0aW9uczoge30sXG5cdFx0XHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0XHRcdGNvbG9yOiBjb21iaW5lUmdiKDI1NSwgMjU1LCAyNTUpLFxuXHRcdFx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAyNTUsIDApLFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdH0sXG5cdFx0XHRdLFxuXHRcdH0sXG5cdFx0bWlkaV9vdXQ6IHtcblx0XHRcdHR5cGU6ICdzaW1wbGUnIGFzIGNvbnN0LFxuXHRcdFx0bmFtZTogYE1JREkgTWVzc2FnZSBPdXQgSW5kaWNhdG9yYCxcblx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdHRleHQ6IGBNSURJIE9VVGAsXG5cdFx0XHRcdHNpemU6ICdhdXRvJyBhcyBjb25zdCxcblx0XHRcdFx0Y29sb3I6IGNvbWJpbmVSZ2IoMjU1LCAyNTUsIDI1NSksXG5cdFx0XHRcdGJnY29sb3I6IGNvbWJpbmVSZ2IoMCwgMCwgMCksXG5cdFx0XHR9LFxuXHRcdFx0c3RlcHM6IFtdLFxuXHRcdFx0ZmVlZGJhY2tzOiBbXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRmZWVkYmFja0lkOiAnbWlkaU91dCcsXG5cdFx0XHRcdFx0b3B0aW9uczoge30sXG5cdFx0XHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0XHRcdGNvbG9yOiBjb21iaW5lUmdiKDI1NSwgMjU1LCAyNTUpLFxuXHRcdFx0XHRcdFx0Ymdjb2xvcjogY29tYmluZVJnYigwLCAyNTUsIDApLFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdH0sXG5cdFx0XHRdLFxuXHRcdH0sXG5cdH1cblxuXHRjb25zdCBzdHJ1Y3R1cmUgPSBbXG5cdFx0e1xuXHRcdFx0aWQ6ICdpbmRpY2F0b3JzJyxcblx0XHRcdG5hbWU6ICdJbmRpY2F0b3JzJyxcblx0XHRcdGRlZmluaXRpb25zOiBbXG5cdFx0XHRcdHtcblx0XHRcdFx0XHRpZDogJ21pZGlfaW5kaWNhdG9ycycsXG5cdFx0XHRcdFx0dHlwZTogJ3NpbXBsZScgYXMgY29uc3QsXG5cdFx0XHRcdFx0bmFtZTogJ01JREkgSW5kaWNhdG9ycycsXG5cdFx0XHRcdFx0cHJlc2V0czogWydtaWRpX2luJywgJ21pZGlfb3V0J10sXG5cdFx0XHRcdH0sXG5cdFx0XHRdLFxuXHRcdH0sXG5cdF1cblxuXHRzZWxmLnNldFByZXNldERlZmluaXRpb25zKHN0cnVjdHVyZSwgcHJlc2V0cylcbn1cbiIsICJpbXBvcnQgeyBJbnN0YW5jZUJhc2UsIEluc3RhbmNlVHlwZXMsIEluc3RhbmNlU3RhdHVzLCBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGQgfSBmcm9tICdAY29tcGFuaW9uLW1vZHVsZS9iYXNlJ1xuaW1wb3J0IHsgR2V0Q29uZmlnRmllbGRzLCB0eXBlIE1vZHVsZUNvbmZpZyB9IGZyb20gJy4vY29uZmlnLmpzJ1xuaW1wb3J0IHsgVXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucywgSGFuZGxlTWlkaUluZGljYXRvcnMsIFVwZGF0ZUxhc3RNc2cgfSBmcm9tICcuL3ZhcmlhYmxlcy5qcydcbmltcG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH0gZnJvbSAnLi91cGdyYWRlcy5qcydcbmltcG9ydCB7IFVwZGF0ZUFjdGlvbnMgfSBmcm9tICcuL2FjdGlvbnMuanMnXG5pbXBvcnQgeyBVcGRhdGVGZWVkYmFja3MgfSBmcm9tICcuL2ZlZWRiYWNrcy5qcydcbmltcG9ydCB7IFVwZGF0ZVByZXNldHMgfSBmcm9tICcuL3ByZXNldHMuanMnXG5pbXBvcnQgKiBhcyBtaWRpIGZyb20gJy4vbWlkaS9taWRpLmpzJ1xuaW1wb3J0IHsgTWlkaU1lc3NhZ2UgfSBmcm9tICcuL21pZGkvbXNndHlwZXMuanMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgRGF0YVN0b3JlRW50cnkge1xuXHRrZXk6IG51bWJlclxuXHR2YWw6IG51bWJlclxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNb2R1bGVJbnN0YW5jZSBleHRlbmRzIEluc3RhbmNlQmFzZTxJbnN0YW5jZVR5cGVzPiB7XG5cdGNvbmZpZyE6IE1vZHVsZUNvbmZpZyAvLyBTZXR1cCBpbiBpbml0KClcblx0bWlkaUlucHV0ITogbWlkaS5JbnB1dFxuXHRtaWRpT3V0cHV0ITogbWlkaS5PdXRwdXRcblx0ZGF0YVN0b3JlITogTWFwPG51bWJlciwgbnVtYmVyPlxuXHRpc1JlY29yZGluZ0FjdGlvbnMhOiBib29sZWFuXG5cblx0Y29uc3RydWN0b3IoaW50ZXJuYWw6IHVua25vd24pIHtcblx0XHRzdXBlcihpbnRlcm5hbClcblx0fVxuXG5cdGFzeW5jIGluaXQoY29uZmlnOiBNb2R1bGVDb25maWcpOiBQcm9taXNlPHZvaWQ+IHtcblx0XHR0aGlzLmNvbmZpZyA9IGNvbmZpZ1xuXHRcdHRoaXMuZGF0YVN0b3JlID0gbmV3IE1hcCgpXG5cblx0XHR0aGlzLnVwZGF0ZUFjdGlvbnMoKVxuXHRcdHRoaXMudXBkYXRlRmVlZGJhY2tzKClcblx0XHR0aGlzLnVwZGF0ZVByZXNldHMoKVxuXHRcdHRoaXMudXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucygpXG5cdFx0YXdhaXQgdGhpcy5jb25maWdVcGRhdGVkKGNvbmZpZylcblx0fVxuXG5cdC8vIFdoZW4gbW9kdWxlIGdldHMgZGVsZXRlZFxuXHRhc3luYyBkZXN0cm95KCk6IFByb21pc2U8dm9pZD4ge1xuXHRcdHRoaXMubWlkaUlucHV0LmNsb3NlKClcblx0XHR0aGlzLm1pZGlPdXRwdXQuY2xvc2UoKVxuXHRcdHRoaXMubG9nKCdkZWJ1ZycsIGAke3RoaXMuaWR9IGRlc3Ryb3llZGApXG5cdH1cblxuXHRhc3luYyBjb25maWdVcGRhdGVkKGNvbmZpZzogTW9kdWxlQ29uZmlnKTogUHJvbWlzZTx2b2lkPiB7XG5cdFx0dGhpcy5jb25maWcgPSBjb25maWdcblx0XHR0aGlzLmNvbmZpZy5pblBvcnRJc1ZpcnR1YWwgPSBmYWxzZSAvLyBkZWxldGUgaWYgVmlydHVhbCBwb3J0cyBldmVyIGdldCBzdXBwb3J0ZWQgYnkgV2luZG93c1xuXHRcdHRoaXMuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwgPSBmYWxzZVxuXHRcdGNvbnN0IGluUG9ydE5hbWUgPSB0aGlzLmNvbmZpZy5pblBvcnRJc1ZpcnR1YWwgPyB0aGlzLmNvbmZpZy5pblBvcnRWaXJ0dWFsTmFtZSA6IHRoaXMuY29uZmlnLmluUG9ydE5hbWVcblx0XHRjb25zdCBvdXRQb3J0TmFtZSA9IHRoaXMuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwgPyB0aGlzLmNvbmZpZy5vdXRQb3J0VmlydHVhbE5hbWUgOiB0aGlzLmNvbmZpZy5vdXRQb3J0TmFtZVxuXHRcdHRoaXMubG9nKFxuXHRcdFx0J2RlYnVnJyxcblx0XHRcdGBBdmFpbGFibGUgTUlESSBJbnB1dHM6ICR7SlNPTi5zdHJpbmdpZnkobWlkaS5nZXRJbnB1dHMoKSl9XFxuXFx0U2VsZWN0ZWQgTUlESSBJbnB1dDogICR7aW5Qb3J0TmFtZX1gLFxuXHRcdClcblx0XHR0aGlzLmxvZyhcblx0XHRcdCdkZWJ1ZycsXG5cdFx0XHRgQXZhaWxhYmxlIE1JREkgT3V0cHV0czogJHtKU09OLnN0cmluZ2lmeShtaWRpLmdldE91dHB1dHMoKSl9XFxuXFx0U2VsZWN0ZWQgTUlESSBPdXRwdXQ6ICR7b3V0UG9ydE5hbWV9YCxcblx0XHQpXG5cdFx0dGhpcy5sb2coJ2RlYnVnJywgJycpXG5cdFx0aWYgKHRoaXMubWlkaUlucHV0KSB0aGlzLm1pZGlJbnB1dC5jbG9zZSgpXG5cdFx0aWYgKHRoaXMubWlkaU91dHB1dCkgdGhpcy5taWRpT3V0cHV0LmNsb3NlKClcblx0XHR0aGlzLm1pZGlJbnB1dCA9IG5ldyBtaWRpLklucHV0KGluUG9ydE5hbWUsIHRoaXMuY29uZmlnLmluUG9ydElzVmlydHVhbClcblx0XHR0aGlzLm1pZGlPdXRwdXQgPSBuZXcgbWlkaS5PdXRwdXQob3V0UG9ydE5hbWUsIHRoaXMuY29uZmlnLm91dFBvcnRJc1ZpcnR1YWwpXG5cdFx0Y29uc3QgbWlkaUluU3RhdHVzID0gdGhpcy5jb25maWcuaW5Qb3J0SXNWaXJ0dWFsIHx8IHRoaXMubWlkaUlucHV0LmlzUG9ydE9wZW4oKVxuXHRcdGNvbnN0IG1pZGlPdXRTdGF0dXMgPSB0aGlzLmNvbmZpZy5vdXRQb3J0SXNWaXJ0dWFsIHx8IHRoaXMubWlkaU91dHB1dC5pc1BvcnRPcGVuKClcblx0XHR0aGlzLmxvZygnaW5mbycsIGBTZWxlY3RlZCBJbiAgUG9ydCBcIiR7dGhpcy5taWRpSW5wdXQubmFtZX1cIiBpcyAke21pZGlJblN0YXR1cyA/ICcnIDogJ05PVCAnfU9wZW4uYClcblx0XHR0aGlzLmxvZygnaW5mbycsIGBTZWxlY3RlZCBPdXQgUG9ydCBcIiR7dGhpcy5taWRpT3V0cHV0Lm5hbWV9XCIgaXMgJHttaWRpT3V0U3RhdHVzID8gJycgOiAnTk9UICd9T3Blbi5gKVxuXHRcdHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkRpc2Nvbm5lY3RlZClcblx0XHRpZiAoIW1pZGlJblN0YXR1cyAmJiBtaWRpT3V0U3RhdHVzKSB0aGlzLnVwZGF0ZVN0YXR1cyhJbnN0YW5jZVN0YXR1cy5CYWRDb25maWcsICdNSURJIEluIFBvcnQgbm90IG9wZW4nKVxuXHRcdGlmIChtaWRpSW5TdGF0dXMgJiYgIW1pZGlPdXRTdGF0dXMpIHRoaXMudXBkYXRlU3RhdHVzKEluc3RhbmNlU3RhdHVzLkJhZENvbmZpZywgJ01JREkgT3V0IFBvcnQgbm90IG9wZW4nKVxuXHRcdGlmIChtaWRpSW5TdGF0dXMgJiYgbWlkaU91dFN0YXR1cykgdGhpcy51cGRhdGVTdGF0dXMoSW5zdGFuY2VTdGF0dXMuT2spXG5cblx0XHR0aGlzLnN0YXJ0KClcblx0fVxuXG5cdC8vIFJldHVybiBjb25maWcgZmllbGRzIGZvciB3ZWIgY29uZmlnXG5cdGdldENvbmZpZ0ZpZWxkcygpOiBTb21lQ29tcGFuaW9uQ29uZmlnRmllbGRbXSB7XG5cdFx0cmV0dXJuIEdldENvbmZpZ0ZpZWxkcygpXG5cdH1cblx0dXBkYXRlQWN0aW9ucygpOiB2b2lkIHtcblx0XHRVcGRhdGVBY3Rpb25zKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVGZWVkYmFja3MoKTogdm9pZCB7XG5cdFx0VXBkYXRlRmVlZGJhY2tzKHRoaXMpXG5cdH1cblxuXHR1cGRhdGVQcmVzZXRzKCk6IHZvaWQge1xuXHRcdFVwZGF0ZVByZXNldHModGhpcylcblx0fVxuXG5cdHVwZGF0ZVZhcmlhYmxlRGVmaW5pdGlvbnMoKTogdm9pZCB7XG5cdFx0VXBkYXRlVmFyaWFibGVEZWZpbml0aW9ucyh0aGlzKVxuXHR9XG5cblx0Ly8gVGhlIG1haW4gbG9vcFxuXHRzdGFydCgpOiB2b2lkIHtcblx0XHR0aGlzLmxvZygnZGVidWcnLCAnXFxuRW50ZXJpbmcgKm1haW4qXFxuJylcblxuXHRcdHRoaXMubWlkaUlucHV0Lm9uKCdzbXB0ZScsIChhcmdzOiB7IHNtcHRlOiBzdHJpbmc7IHNtcHRlRlI6IG51bWJlciB9KSA9PiB7XG5cdFx0XHR0aGlzLnNldFZhcmlhYmxlVmFsdWVzKHtcblx0XHRcdFx0c21wdGU6IGFyZ3Muc21wdGUsXG5cdFx0XHRcdHNtcHRlRlI6IGFyZ3Muc21wdGVGUixcblx0XHRcdH0pXG5cdFx0fSlcblx0XHR0aGlzLm1pZGlJbnB1dC5vbignbWVzc2FnZScsIChkZWx0YVRpbWU6IG51bWJlciwgbXNnOiBNaWRpTWVzc2FnZSkgPT4ge1xuXHRcdFx0aWYgKG1zZy5pZCAhPT0gJ210YycpIHtcblx0XHRcdFx0dGhpcy5sb2coJ2RlYnVnJywgYFske2RlbHRhVGltZS50b0ZpeGVkKDIpLnBhZFN0YXJ0KDYsICcwJyl9XSBSZWNlaXZlZDogJHttc2d9IGZyb20gXCIke3RoaXMubWlkaUlucHV0Lm5hbWV9XCJgKVxuXHRcdFx0XHR0aGlzLmFkZFRvRGF0YVN0b3JlKG1zZylcblx0XHRcdFx0aWYgKHRoaXMuaXNSZWNvcmRpbmdBY3Rpb25zKSB0aGlzLmFkZFRvQWN0aW9uUmVjb3JkaW5nKGRlbHRhVGltZSwgbXNnKVxuXHRcdFx0fVxuXHRcdFx0SGFuZGxlTWlkaUluZGljYXRvcnModGhpcywgJ21pZGlJbicpXG5cdFx0fSlcblx0fVxuXG5cdGFkZFRvRGF0YVN0b3JlKG1zZzogTWlkaU1lc3NhZ2UpOiB2b2lkIHtcblx0XHRjb25zdCBkYXRhOiBEYXRhU3RvcmVFbnRyeSA9IHRoaXMuZ2V0VmFsRnJvbU1zZyhtc2cpXG5cdFx0aWYgKGRhdGEua2V5ID4gMCkge1xuXHRcdFx0VXBkYXRlTGFzdE1zZyh0aGlzLCBtc2csIGRhdGEudmFsKVxuXHRcdFx0dGhpcy5kYXRhU3RvcmUuc2V0KGRhdGEua2V5LCBkYXRhLnZhbClcblx0XHRcdHRoaXMuY2hlY2tBbGxGZWVkYmFja3MoKVxuXHRcdH1cblx0fVxuXG5cdGdldEZyb21EYXRhU3RvcmUobXNnOiBNaWRpTWVzc2FnZSk6IG51bWJlciB8IHVuZGVmaW5lZCB7XG5cdFx0Y29uc3QgZGF0YTogRGF0YVN0b3JlRW50cnkgPSB0aGlzLmdldFZhbEZyb21Nc2cobXNnKVxuXHRcdGlmIChkYXRhLmtleSA+IDApIHtcblx0XHRcdHJldHVybiB0aGlzLmRhdGFTdG9yZS5nZXQoZGF0YS5rZXkpXG5cdFx0fVxuXHRcdHJldHVybiB1bmRlZmluZWRcblx0fVxuXG5cdGdldFZhbEZyb21Nc2cobXNnOiBNaWRpTWVzc2FnZSk6IERhdGFTdG9yZUVudHJ5IHtcblx0XHRsZXQgbGFzdEluZGV4OiBudW1iZXIgPSBtc2cuYnl0ZXMubGVuZ3RoIC0gMVxuXHRcdGxldCBwYXJzZWRLZXkgPSAwXG5cdFx0bGV0IHBhcnNlZFZhbCA9IDBcblx0XHQvLyB2YWwgaXMgbGFzdCBieXRlLCBrZXkgaXMgYWxsIGJ5dGVzIHVwIHRvIHRoZSBsYXN0XG5cdFx0Ly8gZS5nLiBbMHg5MCwgMHg2MCwgMHg3Rl06IGtleSA9IDB4OTA2MCwgdmFsID0gMHg3RlxuXHRcdGlmIChsYXN0SW5kZXggPj0gMCAmJiBtc2cuc3RhdHVzIDwgMHhmMCkge1xuXHRcdFx0aWYgKG1zZy5pZCA9PSAncGl0Y2gnKSB7XG5cdFx0XHRcdHBhcnNlZFZhbCA9IG1zZy5hcmdzLnZhbHVlID8/IDBcblx0XHRcdFx0bGFzdEluZGV4LS1cblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHBhcnNlZFZhbCA9IG1zZy5ieXRlc1tsYXN0SW5kZXhdXG5cdFx0XHR9XG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGxhc3RJbmRleDsgaSsrKSB7XG5cdFx0XHRcdHBhcnNlZEtleSArPSBtc2cuYnl0ZXNbaV0gPDwgKChsYXN0SW5kZXggLSBpIC0gMSkgPDwgMylcblx0XHRcdH1cblx0XHRcdGlmIChwYXJzZWRLZXkgPT0gMCkgcGFyc2VkS2V5ID0gcGFyc2VkVmFsXG5cdFx0fVxuXHRcdHJldHVybiB7IGtleTogcGFyc2VkS2V5LCB2YWw6IHBhcnNlZFZhbCB9XG5cdH1cblxuXHQvLyBUcmFjayB3aGV0aGVyIGFjdGlvbnMgYXJlIGJlaW5nIHJlY29yZGVkXG5cdGhhbmRsZVN0YXJ0U3RvcFJlY29yZEFjdGlvbnMoaXNSZWNvcmRpbmc6IGJvb2xlYW4pOiB2b2lkIHtcblx0XHR0aGlzLmlzUmVjb3JkaW5nQWN0aW9ucyA9IGlzUmVjb3JkaW5nXG5cdH1cblxuXHQvLyBBZGQgYSBjb21tYW5kIHRvIHRoZSBBY3Rpb24gUmVjb3JkZXJcblx0YWRkVG9BY3Rpb25SZWNvcmRpbmcoZGVsdGFUaW1lOiBudW1iZXIsIG1zZzogTWlkaU1lc3NhZ2UpOiB2b2lkIHtcblx0XHRjb25zdCBhcmdzID0geyAuLi5tc2cuYXJncyB9XG5cdFx0bGV0IHVuaXF1ZUlkID0gYCR7bXNnLmlkfSAke3RoaXMuZ2V0VmFsRnJvbU1zZyhtc2cpLmtleX1gXG5cdFx0aWYgKHRoaXMuY29uZmlnLnVzZVRpbWVTdGFtcCkge1xuXHRcdFx0ZGVsdGFUaW1lID0gTWF0aC5yb3VuZChkZWx0YVRpbWUgKiAxMDAwKVxuXHRcdFx0dW5pcXVlSWQgPSAnJ1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRkZWx0YVRpbWUgPSAwXG5cdFx0fVxuXHRcdHRoaXMucmVjb3JkQWN0aW9uKFxuXHRcdFx0e1xuXHRcdFx0XHRhY3Rpb25JZDogbXNnLmlkLFxuXHRcdFx0XHRvcHRpb25zOiBhcmdzLFxuXHRcdFx0XHRkZWxheTogZGVsdGFUaW1lLFxuXHRcdFx0fSxcblx0XHRcdHVuaXF1ZUlkLCAvLyB1bmlxdWVJZCB0byBzdG9wIGR1cGxpY2F0ZXMgd2hlbiBub3QgdXNpbmcgVGltZVN0YW1wXG5cdFx0KVxuXHR9XG59XG5cbmV4cG9ydCB7IFVwZ3JhZGVTY3JpcHRzIH1cbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQSxRQUFNLEtBQUssVUFBUSxJQUFJO0FBUXZCLGFBQVMsZ0JBQWdCLFNBQVM7QUFDakMsVUFBSSxDQUFDLFFBQVEsYUFBYyxPQUFNLElBQUksTUFBTSxxQkFBcUI7QUFFaEUsWUFBTSxTQUFTO0FBQUEsUUFDZCxRQUFRO0FBQUEsUUFDUixRQUFRO0FBQUEsUUFDUixRQUFRO0FBQUE7QUFBQSxRQUVSLFFBQVEsUUFBUSxRQUFRLGFBQWEsVUFBVSxRQUFRLE9BQU87QUFBQSxNQUMvRDtBQUNBLGFBQU8sR0FBRyxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxHQUFHLENBQUMsSUFBSSxRQUFRLE9BQU8sVUFBVSxRQUFRLFlBQVk7QUFBQSxJQUMvRjtBQUVBLGFBQVMsU0FBUztBQUNqQixhQUFPLENBQUMsRUFBRSxRQUFRLFlBQVksUUFBUSxTQUFTO0FBQUEsSUFDaEQ7QUFFQSxhQUFTLGFBQWE7QUFDckIsVUFBSSxRQUFRLFlBQVksUUFBUSxTQUFTLFNBQVUsUUFBTztBQUMxRCxVQUFJLFFBQVEsSUFBSSxxQkFBc0IsUUFBTztBQUM3QyxhQUFPLE9BQU8sV0FBVyxlQUFlLE9BQU8sV0FBVyxPQUFPLFFBQVEsU0FBUztBQUFBLElBQ25GO0FBRUEsYUFBUyxTQUFTLFVBQVU7QUFDM0IsYUFBTyxhQUFhLFdBQVcsR0FBRyxXQUFXLHFCQUFxQjtBQUFBLElBQ25FO0FBRUEsV0FBTyxVQUFVO0FBQUEsTUFDaEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNEO0FBQUE7QUFBQTs7O0FDeENBO0FBQUE7QUFBQSxRQUFNLE9BQU8sVUFBUSxNQUFNO0FBQzNCLFFBQU0sS0FBSyxVQUFRLElBQUk7QUFDdkIsUUFBTSxFQUFFLGlCQUFpQixRQUFRLFlBQVksU0FBUyxJQUFJO0FBRzFELFFBQU0sS0FBSyxPQUFPLFNBQVMsY0FBYyxLQUFLLGNBQWMsSUFBSSxJQUFJLFVBQVEsSUFBSTtBQUdoRixRQUFNLGlCQUFpQixPQUFPLHdCQUF3QixhQUFhLDBCQUEwQjtBQVU3RixhQUFTLFlBQVksVUFBVSxTQUFTLGdCQUFnQixnQkFBZ0I7QUFDdkUsVUFBSSxPQUFPLGFBQWEsWUFBWSxDQUFDLFNBQVUsT0FBTSxJQUFJLE1BQU0sbUNBQW1DO0FBRWxHLFVBQUksT0FBTyxZQUFZLFlBQVksQ0FBQyxRQUFTLE9BQU0sSUFBSSxNQUFNLGtDQUFrQztBQUMvRixVQUFJLE9BQU8sUUFBUSxTQUFTLFlBQVksQ0FBQyxRQUFRLEtBQU0sT0FBTSxJQUFJLE1BQU0sK0JBQStCO0FBRXRHLFVBQUksWUFBWTtBQUNoQixVQUFJLFFBQVEsaUJBQWlCLE1BQU0sUUFBUSxRQUFRLGFBQWEsR0FBRztBQUNsRSxvQkFBWTtBQUFBLE1BQ2I7QUFFQSxZQUFNLE9BQVEsa0JBQWtCLFFBQVEsSUFBSSxtQkFBb0IsR0FBRyxLQUFLO0FBQ3hFLFlBQU0sV0FBWSxrQkFBa0IsUUFBUSxJQUFJLHVCQUF3QixHQUFHLFNBQVM7QUFFcEYsVUFBSSxVQUFVO0FBRWQsVUFBSSxDQUFDLFdBQVc7QUFDZixZQUFJLGtCQUFrQixRQUFRLElBQUksb0JBQW9CO0FBQ3JELG9CQUFVLFFBQVEsSUFBSTtBQUFBLFFBQ3ZCLFdBQVcsV0FBVyxHQUFHO0FBQ3hCLG9CQUFVO0FBQUEsUUFDWCxXQUFXLE9BQU8sR0FBRztBQUNwQixvQkFBVTtBQUFBLFFBQ1g7QUFBQSxNQUNEO0FBRUEsWUFBTSxhQUFhLENBQUM7QUFFcEIsVUFBSSxDQUFDLGdCQUFnQjtBQUVwQixtQkFBVztBQUFBLFVBQ1YsS0FBSyxLQUFLLFVBQVUsU0FBUyxTQUFTLEdBQUcsUUFBUSxJQUFJLE9BQU87QUFBQSxVQUM1RCxLQUFLLEtBQUssVUFBVSxTQUFTLFdBQVcsR0FBRyxRQUFRLElBQUksT0FBTztBQUFBLFFBQy9EO0FBQUEsTUFDRDtBQUVBLFVBQUksT0FBTztBQUNYLFVBQUksU0FBUyxRQUFRLEVBQUcsUUFBTztBQUcvQixVQUFJLFdBQVc7QUFFZCxtQkFBVyxPQUFPLFFBQVEsZUFBZTtBQUN4QyxnQkFBTSxlQUFlLGdCQUFnQjtBQUFBLFlBQ3BDLE1BQU0sUUFBUTtBQUFBLFlBQ2Q7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0EsY0FBYztBQUFBLFlBQ2Q7QUFBQTtBQUFBLFVBRUQsQ0FBQztBQUNELHFCQUFXLEtBQUssS0FBSyxLQUFLLFVBQVUsYUFBYSxZQUFZLENBQUM7QUFBQSxRQUMvRDtBQUFBLE1BQ0QsT0FBTztBQUNOLGNBQU0sSUFBSSxNQUFNLDBCQUEwQjtBQUFBLE1BQzNDO0FBRUEsVUFBSSxZQUFZO0FBRWhCLGlCQUFXLGFBQWEsWUFBWTtBQUNuQyxZQUFJLEdBQUcsV0FBVyxTQUFTLEdBQUc7QUFDN0IsZ0JBQU0sT0FBTyxHQUFHLFNBQVMsU0FBUztBQUNsQyxjQUFJLEtBQUssT0FBTyxHQUFHO0FBQ2xCLHdCQUFZO0FBQ1o7QUFBQSxVQUNEO0FBQUEsUUFDRDtBQUFBLE1BQ0Q7QUFFQSxVQUFJLENBQUMsYUFBYSxnQkFBZ0I7QUFDakMsY0FBTSxnQkFBZ0IsV0FBVyxJQUFJLENBQUMsU0FBUyxNQUFNLElBQUksRUFBRSxFQUFFLEtBQUssSUFBSTtBQUN0RSxjQUFNLElBQUksTUFBTSw4QkFBOEIsUUFBUSxJQUFJO0FBQUE7QUFBQSxFQUFtQixhQUFhLEVBQUU7QUFBQSxNQUM3RjtBQUVBLGFBQU87QUFBQSxJQUNSO0FBRUEsYUFBUyxZQUFZLFVBQVUsU0FBUztBQUN2QyxZQUFNLFlBQVksWUFBWSxVQUFVLFNBQVMsT0FBTyxJQUFJO0FBRzVELFVBQUksQ0FBQyxVQUFXLE9BQU0sSUFBSSxNQUFNLDhCQUE4QixRQUFRLElBQUksRUFBRTtBQUU1RSxhQUFPLGVBQWUsU0FBUztBQUFBLElBQ2hDO0FBQ0EsZ0JBQVksVUFBVTtBQUV0QixXQUFPLFVBQVU7QUFBQTtBQUFBOzs7QUMxR2pCO0FBQUE7QUFBQSxXQUFPLFVBQVU7QUFBQSxNQUNmLE1BQU07QUFBQSxNQUNOLGVBQWUsQ0FBQyxDQUFDO0FBQUEsSUFDbkI7QUFBQTtBQUFBOzs7QUNIQTtBQUFBO0FBQ0EsV0FBTyxVQUFVO0FBQUEsTUFFYixzQkFBOEI7QUFBQSxNQUM5Qix1QkFBOEI7QUFBQSxNQUM5QixzQkFBOEI7QUFBQSxNQUM5QixrQkFBOEI7QUFBQSxNQUM5QixrQkFBcUI7QUFBQSxNQUNyQixrQkFBOEI7QUFBQSxNQUM5QixhQUE4QjtBQUFBLE1BQzlCLE9BQWdCO0FBQUEsTUFDaEIsU0FBb0I7QUFBQSxNQUNwQixjQUFrQjtBQUFBLE1BQ2xCLFdBQW1CO0FBQUEsTUFDbkIsWUFBb0I7QUFBQSxNQUNwQixTQUFrQjtBQUFBLE1BQ2xCLFdBQXFCO0FBQUEsTUFDckIsZUFBOEI7QUFBQSxNQUM5QixVQUFlO0FBQUEsTUFDZixlQUE4QjtBQUFBLE1BQzlCLGtCQUE4QjtBQUFBLE1BQzlCLFlBQW9CO0FBQUEsTUFDcEIsY0FBa0I7QUFBQSxNQUNsQixZQUFvQjtBQUFBLE1BQ3BCLFdBQW1CO0FBQUEsTUFDbkIsV0FBbUI7QUFBQSxNQUNuQixpQkFBOEI7QUFBQSxNQUM5Qix1QkFBOEI7QUFBQSxNQUM5Qix1QkFBOEI7QUFBQSxNQUM5QixzQkFBOEI7QUFBQSxNQUM5Qix1QkFBOEI7QUFBQSxNQUM5Qix1QkFBOEI7QUFBQSxNQUM5QixtQkFBeUI7QUFBQSxNQUN6QixtQkFBeUI7QUFBQSxNQUN6QixrQkFBcUI7QUFBQSxNQUNyQixlQUFzQjtBQUFBLE1BQ3RCLHNCQUF3QjtBQUFBLE1BQ3hCLG9CQUEwQjtBQUFBLE1BQzFCLGVBQThCO0FBQUEsTUFDOUIsYUFBOEI7QUFBQSxNQUM5QixhQUE4QjtBQUFBLE1BQzlCLGNBQThCO0FBQUEsTUFDOUIsY0FBa0I7QUFBQSxNQUNsQixRQUFpQjtBQUFBLE1BQ2pCLE9BQWdCO0FBQUEsTUFDaEIsT0FBaUI7QUFBQSxNQUNqQixZQUEyQjtBQUFBLE1BQzNCLGlCQUEyQjtBQUFBLE1BQzNCLG1CQUF5QjtBQUFBLE1BQ3pCLGlCQUF3QjtBQUFBLE1BQ3hCLFNBQXdCO0FBQUEsTUFDeEIsbUJBQXlCO0FBQUEsTUFDekIsbUJBQThCO0FBQUEsTUFDOUIsZ0JBQThCO0FBQUEsTUFDOUIsZ0JBQThCO0FBQUEsTUFDOUIsWUFBb0I7QUFBQSxNQUNwQixZQUFvQjtBQUFBLE1BQ3BCLGFBQXFCO0FBQUEsTUFDckIsZUFBc0I7QUFBQSxNQUN0QixTQUFrQjtBQUFBLE1BQ2xCLFVBQWU7QUFBQSxNQUNmLE1BQVk7QUFBQSxNQUNaLGVBQXNCO0FBQUEsTUFDdEIsYUFBcUI7QUFBQSxNQUNyQixlQUFzQjtBQUFBLE1BQ3RCLGNBQWtCO0FBQUEsTUFDbEIsY0FBa0I7QUFBQSxNQUNsQixhQUFxQjtBQUFBLE1BQ3JCLFVBQWU7QUFBQSxNQUNmLFdBQXdCO0FBQUEsTUFDeEIsY0FBd0I7QUFBQSxNQUN4QixNQUFxQjtBQUFBLE1BQ3JCLGNBQXVCO0FBQUEsTUFDdkIsU0FBMkI7QUFBQSxNQUMzQixVQUF3QjtBQUFBLE1BQ3hCLFNBQTRCO0FBQUEsTUFDNUIsT0FBMkI7QUFBQSxNQUMzQixVQUEyQjtBQUFBLE1BQzNCLFdBQW1CO0FBQUEsTUFDbkIsY0FBa0I7QUFBQSxNQUNsQixZQUFvQjtBQUFBLE1BQ3BCLFNBQWtCO0FBQUEsTUFDbEIsU0FBa0I7QUFBQSxNQUNsQixlQUE0QjtBQUFBLE1BQzVCLGlCQUF3QjtBQUFBLE1BQ3hCLGlCQUF3QjtBQUFBLE1BQ3hCLGNBQWtCO0FBQUEsTUFDbEIsZ0JBQXVCO0FBQUEsTUFDdkIsY0FBc0I7QUFBQSxNQUN0QixlQUFzQjtBQUFBLE1BQ3RCLHNCQUF3QjtBQUFBLE1BQ3hCLGVBQXNCO0FBQUEsTUFDdEIsWUFBb0I7QUFBQSxNQUNwQixpQkFBd0I7QUFBQSxNQUN4QixhQUFxQjtBQUFBLE1BQ3JCLGFBQXFCO0FBQUEsTUFDckIsZ0JBQXVCO0FBQUEsTUFDdkIsWUFBb0I7QUFBQSxNQUNwQixhQUFxQjtBQUFBLE1BQ3JCLFdBQW1CO0FBQUEsTUFDbkIsaUJBQXdCO0FBQUEsTUFDeEIsY0FBa0I7QUFBQSxNQUNsQixpQkFBd0I7QUFBQSxNQUN4QixpQkFBd0I7QUFBQSxNQUN4QixjQUFrQjtBQUFBLE1BQ2xCLGFBQXFCO0FBQUEsTUFDckIsWUFBb0I7QUFBQSxNQUNwQixPQUFnQjtBQUFBLE1BQ2hCLE9BQWdCO0FBQUEsTUFDaEIsVUFBZTtBQUFBLE1BQ2YsTUFBWTtBQUFBLE1BQ1osU0FBa0I7QUFBQSxNQUNsQixVQUFlO0FBQUEsTUFDZixRQUFpQjtBQUFBLE1BQ2pCLFFBQWlCO0FBQUEsTUFDakIsYUFBcUI7QUFBQSxNQUNyQixPQUFnQjtBQUFBLE1BQ2hCLGFBQXFCO0FBQUEsTUFDckIsV0FBbUI7QUFBQSxNQUNuQixZQUFrQjtBQUFBLE1BQ2xCLGFBQXFCO0FBQUEsTUFDckIsWUFBb0I7QUFBQSxNQUNwQixnQkFBdUI7QUFBQSxNQUN2QixtQkFBeUI7QUFBQSxNQUN6QixjQUFrQjtBQUFBLE1BQ2xCLFVBQWU7QUFBQSxNQUNmLFlBQW9CO0FBQUEsTUFDcEIsZ0JBQXVCO0FBQUEsTUFDdkIsWUFBb0I7QUFBQSxNQUNwQixVQUFlO0FBQUEsTUFDZixTQUE4QjtBQUFBLElBQ2xDO0FBQUE7QUFBQTs7O0FDbklBO0FBQUE7QUFDQSxXQUFPLFVBQVU7QUFBQSxNQUViLG9CQUF5QjtBQUFBLE1BQ3pCLFdBQWU7QUFBQSxNQUNmLFlBQW1CO0FBQUEsTUFDbkIsZ0JBQXNCO0FBQUEsTUFDdEIsV0FBZTtBQUFBLE1BQ2YsZ0JBQXNCO0FBQUEsTUFDdEIsZUFBa0I7QUFBQSxNQUNsQixlQUFrQjtBQUFBLE1BQ2xCLGdCQUFzQjtBQUFBLE1BQ3RCLGNBQWlCO0FBQUEsTUFDakIsU0FBaUI7QUFBQSxNQUNqQixhQUFvQjtBQUFBLE1BQ3BCLGFBQW9CO0FBQUEsTUFDcEIsWUFBbUI7QUFBQSxNQUNuQixnQkFBc0I7QUFBQSxNQUN0QixVQUFjO0FBQUEsTUFDZCxlQUFrQjtBQUFBLE1BQ2xCLGdCQUFzQjtBQUFBLE1BQ3RCLFdBQWU7QUFBQSxNQUNmLFlBQW1CO0FBQUEsTUFDbkIsZUFBa0I7QUFBQSxNQUNsQixTQUFpQjtBQUFBLE1BQ2pCLGdCQUFzQjtBQUFBLE1BQ3RCLFlBQW1CO0FBQUEsTUFDbkIsZUFBa0I7QUFBQSxNQUNsQixVQUFjO0FBQUEsTUFDZCxXQUFlO0FBQUEsTUFDZixlQUFrQjtBQUFBLE1BQ2xCLGVBQWtCO0FBQUEsTUFDbEIsV0FBZTtBQUFBLE1BQ2YsY0FBaUI7QUFBQSxNQUNqQixhQUFvQjtBQUFBLE1BQ3BCLFlBQW1CO0FBQUEsTUFDbkIsV0FBZTtBQUFBLE1BQ2YsUUFBZ0I7QUFBQSxNQUNoQixTQUFpQjtBQUFBLE1BQ2pCLGVBQWtCO0FBQUEsTUFDbEIsY0FBaUI7QUFBQSxNQUNqQixhQUFvQjtBQUFBLE1BQ3BCLFlBQW1CO0FBQUEsTUFDbkIsUUFBZ0I7QUFBQSxNQUNoQixlQUFrQjtBQUFBLE1BQ2xCLGdCQUFzQjtBQUFBLE1BQ3RCLFlBQW1CO0FBQUEsTUFDbkIsWUFBbUI7QUFBQSxNQUNuQixlQUFrQjtBQUFBLE1BQ2xCLGVBQWtCO0FBQUEsSUFDdEI7QUFBQTtBQUFBOzs7QUNsREE7QUFBQTtBQUNBLFdBQU8sVUFBVTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTYixVQUFXO0FBQUE7QUFBQSxNQUdYLEdBQUs7QUFBQSxNQUNMLFNBQVU7QUFBQSxNQUNWLFFBQVM7QUFBQSxNQUNULEdBQUs7QUFBQSxNQUNMLFNBQVU7QUFBQSxNQUNWLFFBQVU7QUFBQSxNQUNWLEdBQUs7QUFBQSxNQUNMLFNBQVU7QUFBQSxNQUNWLFFBQVU7QUFBQSxNQUNWLEdBQUs7QUFBQSxNQUNMLFNBQVU7QUFBQSxNQUNWLFFBQVU7QUFBQSxNQUNWLEdBQUs7QUFBQSxNQUNMLFNBQVU7QUFBQSxNQUNWLFFBQVU7QUFBQSxNQUNWLEdBQUs7QUFBQSxNQUNMLFNBQVU7QUFBQSxNQUNWLFFBQVU7QUFBQSxNQUNWLEdBQUs7QUFBQSxNQUNMLFNBQVU7QUFBQSxNQUNWLFFBQVU7QUFBQTtBQUFBLE1BR1YsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsSUFBSztBQUFBLE1BQ0wsS0FBTTtBQUFBLElBRVY7QUFBQTtBQUFBOzs7QUNoREE7QUFBQTtBQUNBLFdBQU8sVUFBVTtBQUFBO0FBQUE7QUFBQSxNQUliLFVBQW9CO0FBQUE7QUFBQSxNQUNwQixTQUFvQjtBQUFBO0FBQUEsTUFDcEIsbUJBQW9CO0FBQUE7QUFBQSxNQUNwQixlQUFvQjtBQUFBO0FBQUEsTUFDcEIsYUFBb0I7QUFBQTtBQUFBLE1BQ3BCLGlCQUFvQjtBQUFBO0FBQUEsTUFDcEIsZ0JBQW9CO0FBQUE7QUFBQSxNQUVwQixXQUFvQjtBQUFBLE1BQ3BCLFNBQW9CO0FBQUEsTUFDcEIsU0FBb0I7QUFBQTtBQUFBLE1BR3BCLGNBQW9CO0FBQUE7QUFBQSxNQUNwQixnQkFBb0I7QUFBQTtBQUFBLE1BRXBCLFNBQW9CO0FBQUE7QUFBQSxNQUlwQixJQUFJO0FBQUE7QUFBQSxRQUVOLGFBQWtCO0FBQUEsUUFDbEIsWUFBd0I7QUFBQSxRQUN4QixnQkFBd0I7QUFBQSxRQUN4QixhQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsaUJBQXdCO0FBQUEsUUFDeEIsWUFBd0I7QUFBQSxRQUN4QixRQUF3QjtBQUFBLFFBQ3hCLFNBQXdCO0FBQUEsUUFDeEIsYUFBd0I7QUFBQSxRQUN4QixLQUF3QjtBQUFBLFFBQ3hCLFlBQXdCO0FBQUEsUUFDeEIsa0JBQXdCO0FBQUEsUUFDeEIsa0JBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLG1CQUF3QjtBQUFBLFFBQ3hCLG1CQUFvQjtBQUFBLFFBQ3BCLG1CQUFvQjtBQUFBLFFBQ3BCLG1CQUFvQjtBQUFBO0FBQUEsUUFHcEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUE7QUFBQSxRQUd4QixpQkFBa0I7QUFBQSxRQUNaLGdCQUF3QjtBQUFBLFFBQ3hCLG9CQUF3QjtBQUFBLFFBQzlCLGNBQXdCO0FBQUEsUUFDbEIsa0JBQXdCO0FBQUEsUUFDeEIscUJBQXdCO0FBQUEsUUFDeEIsZ0JBQXdCO0FBQUEsUUFDeEIsWUFBd0I7QUFBQSxRQUN4QixhQUF3QjtBQUFBLFFBQzlCLGNBQXdCO0FBQUEsUUFDbEIsU0FBd0I7QUFBQSxRQUN4QixnQkFBd0I7QUFBQSxRQUN4QixzQkFBd0I7QUFBQSxRQUN4QixzQkFBd0I7QUFBQSxRQUV4QixjQUF3QjtBQUFBLFFBQzlCLGNBQXdCO0FBQUEsUUFDbEIsdUJBQXdCO0FBQUEsUUFDeEIsdUJBQXdCO0FBQUEsUUFDeEIsdUJBQXdCO0FBQUEsUUFDeEIsdUJBQXdCO0FBQUE7QUFBQSxRQUc5QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUVsQixlQUF3QjtBQUFBLFFBQzlCLFlBQXdCO0FBQUEsUUFDbEIsaUJBQXdCO0FBQUEsUUFDeEIsWUFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUM5QixRQUF3QjtBQUFBLFFBQ2xCLGlCQUF3QjtBQUFBLFFBQzlCLFFBQXdCO0FBQUEsUUFDbEIsY0FBd0I7QUFBQSxRQUM5QixZQUF3QjtBQUFBLFFBQ2xCLFlBQXdCO0FBQUEsUUFDOUIsUUFBd0I7QUFBQSxRQUN4QixPQUF3QjtBQUFBLFFBQ2xCLGlCQUF3QjtBQUFBLFFBQzlCLFFBQXdCO0FBQUEsUUFDbEIsWUFBd0I7QUFBQSxRQUV4Qix1QkFBd0I7QUFBQSxRQUN4Qix1QkFBd0I7QUFBQSxRQUN4Qix1QkFBd0I7QUFBQSxRQUN4Qix1QkFBd0I7QUFBQSxRQUV4QixvQkFBd0I7QUFBQTtBQUFBLFFBRzlCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBO0FBQUEsUUFHeEIsVUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ2xCLGNBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQzlCLFVBQXdCO0FBQUEsUUFDeEIsVUFBd0I7QUFBQSxRQUNsQixtQkFBd0I7QUFBQSxRQUN4QixtQkFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUE7QUFBQSxRQUc5QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQSxRQUN4QixlQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUEsUUFDeEIsZUFBd0I7QUFBQTtBQUFBLFFBR2xCLGVBQXdCO0FBQUEsUUFDeEIsdUJBQXdCO0FBQUEsUUFDOUIsZUFBd0I7QUFBQSxRQUNsQixlQUF3QjtBQUFBLFFBQzlCLGVBQXdCO0FBQUEsUUFDeEIsY0FBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLGNBQXdCO0FBQUE7QUFBQSxRQUd4QixXQUF3QjtBQUFBO0FBQUEsUUFHeEIsY0FBd0I7QUFBQSxRQUNsQixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixvQkFBd0I7QUFBQSxRQUN4QixxQkFBd0I7QUFBQSxRQUV4QixnQkFBd0I7QUFBQSxRQUM5QixnQkFBd0I7QUFBQSxRQUN4QixnQkFBd0I7QUFBQSxRQUN4QixnQkFBd0I7QUFBQSxRQUN4QixnQkFBd0I7QUFBQSxRQUVsQixjQUF3QjtBQUFBLE1BQzVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQSxXQUFXO0FBQUEsUUFDUCxhQUF3QjtBQUFBLFFBQ3hCLGVBQXdCO0FBQUE7QUFBQSxRQUN4QixhQUF3QjtBQUFBLFFBQ3hCLGFBQXdCO0FBQUEsUUFDeEIsYUFBd0I7QUFBQSxRQUN4QixjQUF3QjtBQUFBLFFBQ3hCLEtBQXdCO0FBQUE7QUFBQSxNQUM1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUEsVUFBVTtBQUFBLFFBQ04sY0FBZ0I7QUFBQSxRQUNoQixjQUFnQjtBQUFBLFFBQ2hCLE9BQWdCO0FBQUEsUUFDaEIsVUFBZ0I7QUFBQSxRQUNoQixNQUFnQjtBQUFBLFFBQ2hCLGNBQWdCO0FBQUEsUUFDaEIsZ0JBQWdCO0FBQUEsUUFDaEIsY0FBZ0I7QUFBQSxNQUNwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFhQSxPQUFPO0FBQUEsUUFDSCxLQUF3QjtBQUFBO0FBQUEsTUFDNUI7QUFBQSxJQUVKO0FBQUE7QUFBQTs7O0FDblBBO0FBQUE7QUFBQSxRQUFNLE9BQU87QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFNLFNBQVMsVUFBUSxRQUFRO0FBRy9CLFFBQU0sRUFBRSxjQUFBQSxjQUFhLElBQUksVUFBUSxRQUFRO0FBS3pDLFFBQU0sY0FBYztBQUVwQixRQUFNLFFBQVE7QUFFZCxRQUFNLFFBQVE7QUFFZCxRQUFNLFdBQVc7QUFFakIsUUFBTUMsU0FBTixjQUFvQkQsY0FBYTtBQUFBLE1BQy9CLGNBQWM7QUFDWixjQUFNO0FBRU4sYUFBSyxRQUFRLElBQUksS0FBSyxNQUFNLENBQUMsV0FBVyxZQUFZO0FBQ2xELGVBQUssS0FBSyxXQUFXLFdBQVcsTUFBTSxLQUFLLFFBQVEsT0FBTyxDQUFDLENBQUM7QUFBQSxRQUM5RCxDQUFDO0FBQUEsTUFDSDtBQUFBLE1BRUEsWUFBWTtBQUNWLGVBQU8sS0FBSyxNQUFNLFVBQVU7QUFBQSxNQUM5QjtBQUFBLE1BQ0EsVUFBVTtBQUNSLGVBQU8sS0FBSyxNQUFNLFFBQVE7QUFBQSxNQUM1QjtBQUFBLE1BQ0EsZUFBZTtBQUNiLGVBQU8sS0FBSyxNQUFNLGFBQWE7QUFBQSxNQUNqQztBQUFBLE1BQ0EsWUFBWSxNQUFNO0FBQ2hCLGVBQU8sS0FBSyxNQUFNLFlBQVksSUFBSTtBQUFBLE1BQ3BDO0FBQUEsTUFDQSxhQUFhO0FBQ1gsZUFBTyxLQUFLLE1BQU0sV0FBVztBQUFBLE1BQy9CO0FBQUEsTUFDQSxZQUFZLE9BQU8sUUFBUSxlQUFlO0FBQ3hDLGVBQU8sS0FBSyxNQUFNLFlBQVksT0FBTyxRQUFRLGFBQWE7QUFBQSxNQUM1RDtBQUFBLE1BQ0EsU0FBUyxNQUFNO0FBQ2IsZUFBTyxLQUFLLE1BQU0sU0FBUyxJQUFJO0FBQUEsTUFDakM7QUFBQSxNQUNBLGVBQWUsTUFBTTtBQUNuQixpQkFBUSxPQUFLLEdBQUcsT0FBSyxLQUFLLE1BQU0sYUFBYSxHQUFHLEVBQUUsTUFBTTtBQUN0RCxjQUFJLFNBQVMsS0FBSyxNQUFNLFlBQVksSUFBSSxHQUFHO0FBQ3pDLG1CQUFPLEtBQUssTUFBTSxTQUFTLElBQUk7QUFBQSxVQUNqQztBQUFBLFFBQ0Y7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BQ0EsZ0JBQWdCLE1BQU07QUFDcEIsZUFBTyxLQUFLLE1BQU0sZ0JBQWdCLElBQUk7QUFBQSxNQUN4QztBQUFBLE1BQ0EsY0FBYyxNQUFNLFFBQVEsR0FBRztBQUM3QixlQUFPLEtBQUssTUFBTSxjQUFjLE1BQU0sS0FBSztBQUFBLE1BQzdDO0FBQUEsSUFDRjtBQUVBLFFBQU1FLFVBQU4sTUFBYTtBQUFBLE1BQ1gsY0FBYztBQUNaLGFBQUssU0FBUyxJQUFJLEtBQUssT0FBTztBQUFBLE1BQ2hDO0FBQUEsTUFFQSxZQUFZO0FBQ1YsZUFBTyxLQUFLLE9BQU8sVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxVQUFVO0FBQ1IsZUFBTyxLQUFLLE9BQU8sUUFBUTtBQUFBLE1BQzdCO0FBQUEsTUFDQSxlQUFlO0FBQ2IsZUFBTyxLQUFLLE9BQU8sYUFBYTtBQUFBLE1BQ2xDO0FBQUEsTUFDQSxZQUFZLE1BQU07QUFDaEIsZUFBTyxLQUFLLE9BQU8sWUFBWSxJQUFJO0FBQUEsTUFDckM7QUFBQSxNQUNBLGFBQWE7QUFDWCxlQUFPLEtBQUssT0FBTyxXQUFXO0FBQUEsTUFDaEM7QUFBQSxNQUNBLFNBQVMsTUFBTTtBQUNiLGVBQU8sS0FBSyxPQUFPLFNBQVMsSUFBSTtBQUFBLE1BQ2xDO0FBQUEsTUFDQSxlQUFlLE1BQU07QUFDbkIsaUJBQVEsT0FBSyxHQUFHLE9BQUssS0FBSyxPQUFPLGFBQWEsR0FBRyxFQUFFLE1BQU07QUFDdkQsY0FBSSxTQUFTLEtBQUssT0FBTyxZQUFZLElBQUksR0FBRztBQUMxQyxtQkFBTyxLQUFLLE9BQU8sU0FBUyxJQUFJO0FBQUEsVUFDbEM7QUFBQSxRQUNGO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBLGdCQUFnQixNQUFNO0FBQ3BCLGVBQU8sS0FBSyxPQUFPLGdCQUFnQixJQUFJO0FBQUEsTUFDekM7QUFBQSxNQUNBLEtBQUssU0FBUztBQUNaLGVBQU8sS0FBSyxZQUFZLE9BQU87QUFBQSxNQUNqQztBQUFBLE1BQ0EsWUFBWSxTQUFTO0FBQ25CLFlBQUksTUFBTSxRQUFRLE9BQU8sR0FBRztBQUMxQixvQkFBVSxPQUFPLEtBQUssT0FBTztBQUFBLFFBQy9CO0FBQ0EsWUFBSSxDQUFDLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDN0IsZ0JBQU0sSUFBSSxNQUFNLDJDQUEyQztBQUFBLFFBQzdEO0FBRUEsZUFBTyxLQUFLLE9BQU8sWUFBWSxPQUFPO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBR0EsYUFBUyxpQkFBaUIsT0FBTztBQUMvQixjQUFRLFNBQVMsSUFBSUQsT0FBTTtBQUMzQixVQUFJLFNBQVMsSUFBSSxPQUFPO0FBQ3hCLGFBQU8sV0FBVztBQUNsQixhQUFPLFNBQVM7QUFDaEIsYUFBTyxRQUFRLENBQUM7QUFFaEIsWUFBTSxHQUFHLFdBQVcsU0FBUyxXQUFXLFNBQVM7QUFFL0MsWUFBSSxTQUFTLElBQUksT0FBTyxLQUFLLE9BQU87QUFFcEMsWUFBSSxDQUFDLE9BQU8sUUFBUTtBQUNsQixpQkFBTyxLQUFLLFFBQVEsTUFBTTtBQUFBLFFBQzVCLE9BQU87QUFDTCxpQkFBTyxNQUFNLEtBQUssTUFBTTtBQUFBLFFBQzFCO0FBQUEsTUFDRixDQUFDO0FBRUQsYUFBTyxRQUFRLFdBQVc7QUFDeEIsZUFBTyxTQUFTO0FBQUEsTUFDbEI7QUFFQSxhQUFPLFNBQVMsV0FBVztBQUN6QixlQUFPLFNBQVM7QUFDaEIsZUFBTyxPQUFPLE1BQU0sVUFBVSxPQUFPLEtBQUssUUFBUSxPQUFPLE1BQU0sTUFBTSxDQUFDLEdBQUc7QUFBQSxRQUFDO0FBQUEsTUFDNUU7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsa0JBQWtCLFFBQVE7QUFDakMsZUFBUyxVQUFVLElBQUlDLFFBQU87QUFDOUIsVUFBSSxTQUFTLElBQUksT0FBTztBQUN4QixhQUFPLFdBQVc7QUFDbEIsYUFBTyxTQUFTO0FBQ2hCLGFBQU8sUUFBUSxDQUFDO0FBRWhCLGFBQU8sUUFBUSxTQUFTLEdBQUc7QUFFekIsWUFBSSxPQUFPLFNBQVMsQ0FBQyxHQUFHO0FBQ3RCLGNBQUksTUFBTSxVQUFVLE1BQU0sS0FBSyxHQUFHLENBQUM7QUFBQSxRQUNyQztBQUVBLGVBQU8sWUFBWSxDQUFDO0FBRXBCLGVBQU8sQ0FBQyxLQUFLO0FBQUEsTUFDZjtBQUVBLGFBQU8sTUFBTSxTQUFTLEtBQUs7QUFDekIsZUFBTyxPQUFPLE1BQU0sR0FBRztBQUN2QixlQUFPLFdBQVc7QUFBQSxNQUNwQjtBQUVBLGFBQU8sVUFBVSxXQUFXO0FBQzFCLGVBQU8sV0FBVztBQUFBLE1BQ3BCO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLFVBQVU7QUFBQSxNQUNmLE9BQUFEO0FBQUEsTUFDQSxRQUFBQztBQUFBLE1BRUE7QUFBQSxNQUNBO0FBQUEsTUFFQSxXQUFXO0FBQUEsUUFDVDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQTtBQUFBLE1BR0EsT0FBT0Q7QUFBQSxNQUNQLFFBQVFDO0FBQUEsSUFDVjtBQUFBO0FBQUE7OztBQy9LQSxJQUFNLHFCQUFrQyxDQUFDLFFBQVEsT0FBTyxZQUFXO0FBRWxFLFVBQVEsSUFBSSxJQUFJLE1BQU0sWUFBVyxDQUFFLElBQUksU0FBUyxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksT0FBTyxFQUFFO0FBQ2pGO0FBRUEsU0FBUyxVQUFVLFFBQTRCLE9BQWlCLFNBQWU7QUFDOUUsUUFBTSxPQUFPLE9BQU8sT0FBTyxxQkFBcUIsYUFBYSxPQUFPLG1CQUFtQjtBQUN2RixPQUFLLFFBQVEsT0FBTyxPQUFPO0FBQzVCO0FBT00sU0FBVSxtQkFBbUIsUUFBZTtBQUNqRCxTQUFPO0lBQ04sT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87SUFDOUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsTUFBTSxDQUFDLFlBQW9CLFVBQVUsUUFBUSxRQUFRLE9BQU87SUFDNUQsT0FBTyxDQUFDLFlBQW9CLFVBQVUsUUFBUSxTQUFTLE9BQU87O0FBRWhFOzs7QUNUTSxTQUFVLFlBQVksTUFBVztBQUV2QztBQXlCTSxTQUFVLFdBQVcsR0FBVyxHQUFXLEdBQVcsR0FBVTtBQUNyRSxNQUFJLGVBQXdCLElBQUksUUFBUyxNQUFRLElBQUksUUFBUyxJQUFNLElBQUk7QUFDeEUsTUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUc7QUFDekIsbUJBQWUsV0FBWSxLQUFLLE1BQU0sT0FBTyxJQUFJLEVBQUU7RUFDcEQ7QUFDQSxTQUFPO0FBQ1I7OztBQy9EQSxTQUFTLG9CQUFvQjtBQTJFdkIsSUFBTyxzQkFBUCxjQUFtQyxhQUFtQztFQUNsRTtFQUNBO0VBRVQsSUFBVyxXQUFRO0FBQ2xCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBQ0EsSUFBVyxhQUFVO0FBQ3BCLFdBQU8sS0FBSyxZQUFZO0VBQ3pCO0VBRUEsSUFBWSxhQUFVO0FBQ3JCLFFBQUksS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXLFVBQVU7QUFDbkQsYUFBTyxLQUFLO0lBQ2IsT0FBTztBQUNOLGFBQU87SUFDUjtFQUNEO0VBRUEsU0FBdUU7RUFFdkUsWUFBWSxTQUF5QyxTQUErQjtBQUNuRixVQUFLO0FBRUwsU0FBSyxXQUFXO0FBQ2hCLFNBQUssV0FBVyxFQUFFLEdBQUcsUUFBTztFQUM3QjtFQUVBLEtBQUssTUFBYyxVQUFtQixVQUFxQjtBQUMxRCxRQUFJLEtBQUssVUFBVSxPQUFPLEtBQUssV0FBVztBQUFVLFlBQU0sSUFBSSxNQUFNLHlCQUF5QjtBQUM3RixZQUFRLEtBQUssUUFBUTtNQUNwQixLQUFLO0FBQ0osY0FBTSxJQUFJLE1BQU0sb0NBQW9DO01BQ3JELEtBQUs7QUFDSixjQUFNLElBQUksTUFBTSx5QkFBeUI7TUFDMUMsS0FBSztBQUNKLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtNQUNwQyxLQUFLO0FBQ0o7TUFDRDtBQUNDLG9CQUFZLEtBQUssTUFBTTtBQUN2QixjQUFNLElBQUksTUFBTSxzQkFBc0I7SUFDeEM7QUFFQSxTQUFLLFNBQVM7QUFFZCxRQUFJO0FBQVUsV0FBSyxHQUFHLGFBQWEsUUFBUTtBQUUzQyxTQUFLLFNBQ0gsb0JBQW9CO01BQ3BCLFFBQVEsS0FBSyxTQUFTO01BQ3RCLFlBQVk7O0tBRVosRUFDQSxLQUNBLENBQUMsYUFBWTtBQUNaLFdBQUssU0FBUyxFQUFFLFlBQVksTUFBTSxTQUFRO0FBQzFDLFdBQUssU0FBUyx3QkFBd0IsSUFBSSxVQUFVLElBQUk7QUFDeEQsV0FBSyxLQUFLLFdBQVc7SUFDdEIsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLFNBQVM7QUFDZCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLE1BQU0sVUFBcUI7QUFDMUIsUUFBSSxLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVcsVUFBVTtJQUVwRCxPQUFPO0FBQ04sY0FBUSxLQUFLLFFBQVE7UUFDcEIsS0FBSztBQUNKLGdCQUFNLElBQUksTUFBTSxvQ0FBb0M7UUFDckQsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO0FBQ0osZ0JBQU0sSUFBSSxNQUFNLG9CQUFvQjtRQUNyQztBQUNDLHNCQUFZLEtBQUssTUFBTTtBQUN2QixnQkFBTSxJQUFJLE1BQU0sc0JBQXNCO01BQ3hDO0lBQ0Q7QUFFQSxVQUFNLFdBQVcsS0FBSyxPQUFPO0FBQzdCLFNBQUssU0FBUztBQUVkLFFBQUk7QUFBVSxXQUFLLEdBQUcsU0FBUyxRQUFRO0FBRXZDLFNBQUssU0FDSCxxQkFBcUI7TUFDckI7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0FBQ3JELFdBQUssS0FBSyxPQUFPO0lBQ2xCLEdBQ0EsQ0FBQyxRQUFPO0FBQ1AsV0FBSyxTQUFTLHdCQUF3QixPQUFPLFFBQVE7QUFDckQsV0FBSyxLQUFLLFNBQVMsZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLEdBQUcsQ0FBQztJQUMvRCxDQUFDLEVBRUQsTUFBTSxNQUFNLElBQUk7RUFDbkI7RUFXQSxLQUNDLGNBQ0EsY0FDQSxpQkFDQSxnQkFDQSxTQUNBLFVBQXFCO0FBRXJCLFFBQUksT0FBTyxpQkFBaUI7QUFBVSxZQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDekUsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3hDLFVBQUksT0FBTyxtQkFBbUIsWUFBWSxPQUFPLFlBQVk7QUFBVSxjQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDMUcsVUFBSSxhQUFhLFVBQWEsT0FBTyxhQUFhO0FBQVksY0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBRWpHLFlBQU0sU0FBUyxLQUFLLGVBQWUsY0FBYyxjQUFjLGVBQWU7QUFDOUUsV0FBSyxXQUFXLFFBQVEsZ0JBQWdCLFNBQVMsUUFBUTtJQUMxRCxXQUFXLE9BQU8sb0JBQW9CLFVBQVU7QUFDL0MsVUFBSSxtQkFBbUIsVUFBYSxPQUFPLG1CQUFtQjtBQUFZLGNBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUU3RyxZQUFNLFNBQVMsS0FBSyxlQUFlLGNBQWMsR0FBRyxNQUFTO0FBQzdELFdBQUssV0FBVyxRQUFRLGNBQWMsaUJBQWlCLGNBQWM7SUFDdEUsT0FBTztBQUNOLFlBQU0sSUFBSSxNQUFNLG1CQUFtQjtJQUNwQztFQUNEO0VBRUEsZUFDQyxjQUNBLFFBQ0EsUUFBMEI7QUFFMUIsUUFBSTtBQUNKLFFBQUksT0FBTyxpQkFBaUIsVUFBVTtBQUNyQyxlQUFTLE9BQU8sS0FBSyxjQUFjLE9BQU87SUFDM0MsV0FBVyxPQUFPLFNBQVMsWUFBWSxHQUFHO0FBQ3pDLGVBQVM7SUFDVixXQUFXLE1BQU0sUUFBUSxZQUFZLEdBQUc7QUFFdkMsYUFBTyxPQUFPLEtBQUssWUFBWTtJQUNoQyxPQUFPO0FBQ04sZUFBUyxPQUFPLEtBQUssYUFBYSxRQUFRLGFBQWEsWUFBWSxhQUFhLFVBQVU7SUFDM0Y7QUFFQSxXQUFPLE9BQU8sU0FBUyxRQUFRLFdBQVcsU0FBWSxTQUFTLFNBQVMsTUFBUztFQUNsRjtFQUVBLFdBQVcsUUFBZ0IsTUFBYyxTQUFpQixVQUFxQjtBQUM5RSxRQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxXQUFXO0FBQVUsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBRXpGLFNBQUssU0FDSCxvQkFBb0I7TUFDcEIsVUFBVSxLQUFLLE9BQU87TUFDdEIsU0FBUztNQUVUO01BQ0E7S0FDQSxFQUNBLEtBQ0EsTUFBSztBQUNKLGlCQUFVO0lBQ1gsR0FDQSxDQUFDLFFBQU87QUFDUCxXQUFLLEtBQUssU0FBUyxlQUFlLFFBQVEsTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQy9ELENBQUMsRUFFRCxNQUFNLE1BQU0sSUFBSTtFQUNuQjtFQUVBLHFCQUFxQixTQUErQjtBQUNuRCxRQUFJO0FBQ0gsV0FBSyxLQUFLLFdBQVcsUUFBUSxTQUFTLFFBQVEsTUFBTTtJQUNyRCxTQUFTLElBQUk7SUFFYjtFQUNEO0VBQ0EsbUJBQW1CLE9BQVk7QUFDOUIsU0FBSyxTQUFTO0FBRWQsVUFBTSxhQUFhLEtBQUs7QUFDeEIsUUFBSTtBQUFZLFdBQUssU0FBUyx3QkFBd0IsT0FBTyxXQUFXLFFBQVE7QUFFaEYsUUFBSTtBQUNILFdBQUssS0FBSyxTQUFTLEtBQUs7SUFDekIsU0FBUyxJQUFJO0lBRWI7RUFDRDs7OztBQzlQSyxTQUFVLGtCQUFtRCxLQUFZO0FBQzlFLFFBQU0sT0FBTztBQUNiLFNBQU8sQ0FBQyxDQUFDLFFBQVEsT0FBTyxTQUFTLFlBQVksT0FBTyxLQUFLLE9BQU8sWUFBWSxLQUFLLHVCQUF1QjtBQUN6Rzs7O0FDNkJNLElBQWdCLGVBQWhCLE1BQTRCO0VBQ3hCO0VBQ0E7RUFFQTtFQUVULElBQVcsS0FBRTtBQUNaLFdBQU8sS0FBSyxTQUFTO0VBQ3RCO0VBRUEsSUFBVyxrQkFBZTtBQUN6QixXQUFPLEtBQUs7RUFDYjs7Ozs7RUFNQSxJQUFXLFFBQUs7QUFDZixXQUFPLEtBQUssU0FBUztFQUN0Qjs7OztFQUtBLFlBQVksVUFBaUI7QUFDNUIsUUFBSSxDQUFDLGtCQUE2QixRQUFRLEtBQUssQ0FBQyxTQUFTO0FBQ3hELFlBQU0sSUFBSSxNQUNULG1HQUFtRztBQUdyRyxTQUFLLFdBQVc7QUFFaEIsU0FBSyxVQUFVLG1CQUFrQjtBQUVqQyxTQUFLLHdCQUF3QixLQUFLLHNCQUFzQixLQUFLLElBQUk7QUFFakUsU0FBSyxXQUFXO01BQ2YsMkJBQTJCO01BQzNCLHdCQUF3Qjs7QUFHekIsU0FBSyxJQUFJLFNBQVMsY0FBYztFQUNqQztFQStCQSxXQUFXLFdBQTRDLFlBQWlDO0FBQ3ZGLFNBQUssU0FBUyxXQUFXLFdBQVcsVUFBVTtFQUMvQzs7Ozs7RUF1QkEscUJBQXFCLFNBQXlEO0FBQzdFLFNBQUssU0FBUyxxQkFBcUIsT0FBTztFQUMzQzs7Ozs7RUFNQSx1QkFBdUIsV0FBK0Q7QUFDckYsU0FBSyxTQUFTLHVCQUF1QixTQUFTO0VBQy9DOzs7Ozs7RUFPQSxxQkFDQyxXQUNBLFNBQThDO0FBRTlDLFNBQUssU0FBUyxxQkFBcUIsV0FBVyxPQUFPO0VBQ3REOzs7OztFQU1BLHVCQUF1QkMsWUFBK0Q7QUFDckYsUUFBSSxNQUFNLFFBQVFBLFVBQVM7QUFBRyxZQUFNLElBQUksTUFBTSx3REFBd0Q7QUFFdEcsU0FBSyxTQUFTLHVCQUF1QkEsVUFBUztFQUMvQzs7Ozs7RUFNQSxrQkFBa0IsUUFBdUM7QUFDeEQsU0FBSyxTQUFTLGtCQUFrQixNQUFNO0VBQ3ZDOzs7Ozs7RUFPQSxpQkFBbUMsWUFBYTtBQUMvQyxXQUFPLEtBQUssU0FBUyxpQkFBaUIsVUFBVTtFQUNqRDs7OztFQUtBLG9CQUFpQjtBQUNoQixTQUFLLFNBQVMsa0JBQWlCO0VBQ2hDOzs7Ozs7O0VBUUEsZUFDQyxpQkFDRyxlQUFtRDtBQUV0RCxTQUFLLFNBQVMsZUFBZSxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7RUFDOUQ7Ozs7O0VBTUEsc0JBQXNCLGFBQXFCO0FBQzFDLFNBQUssU0FBUyxtQkFBbUIsV0FBVztFQUM3Qzs7Ozs7O0VBT0Esb0JBQW9CLFdBQW1CO0FBQ3RDLFNBQUssU0FBUyxpQkFBaUIsU0FBUztFQUN6Qzs7Ozs7O0VBTUEsc0JBQXNCLFdBQW1CO0FBQ3hDLFNBQUssU0FBUyxtQkFBbUIsU0FBUztFQUMzQzs7Ozs7O0VBT0Esd0JBQXdCLGFBQXFCO0FBQzVDLFNBQUssU0FBUyxxQkFBcUIsV0FBVztFQUMvQzs7Ozs7O0VBT0EsYUFBYSxRQUFpQyxjQUFxQjtBQUNsRSxTQUFLLFNBQVMsYUFBYSxRQUFRLFlBQVk7RUFDaEQ7Ozs7Ozs7O0VBU0EsUUFBUSxNQUFjLE1BQWMsTUFBYyxNQUFzQjtBQUN2RSxTQUFLLFNBQVMsUUFBUSxNQUFNLE1BQU0sTUFBTSxJQUFJO0VBQzdDOzs7Ozs7Ozs7OztFQVlBLGFBQWEsUUFBd0IsU0FBdUI7QUFDM0QsU0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLElBQUk7RUFDbkQ7Ozs7OztFQU9BLElBQUksT0FBaUIsU0FBZTtBQUNuQyxZQUFRLE9BQU87TUFDZCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNELEtBQUs7QUFDSixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO01BQ0QsS0FBSztBQUNKLGFBQUssUUFBUSxLQUFLLE9BQU87QUFDekI7TUFDRCxLQUFLO0FBQ0osYUFBSyxRQUFRLE1BQU0sT0FBTztBQUMxQjtNQUNEO0FBQ0Msb0JBQVksS0FBSztBQUNqQixhQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ3pCO0lBQ0Y7RUFDRDtFQVlBLHNCQUNDLGVBQ0EsVUFBeUM7QUFFekMsVUFBTSxVQUFrQyxPQUFPLGtCQUFrQixXQUFXLEVBQUUsTUFBTSxjQUFhLElBQUs7QUFFdEcsVUFBTSxTQUFTLElBQUksb0JBQW9CLEtBQUssVUFBVSxPQUFPO0FBQzdELFFBQUk7QUFBVSxhQUFPLEdBQUcsV0FBVyxRQUFRO0FBRTNDLFdBQU87RUFDUjs7OztBQy9VRCxJQUFZO0NBQVosU0FBWUMsaUJBQWM7QUFDekIsRUFBQUEsZ0JBQUEsSUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsWUFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsY0FBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEsbUJBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLFdBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGNBQUEsSUFBQTtBQUNBLEVBQUFBLGdCQUFBLGdCQUFBLElBQUE7QUFDQSxFQUFBQSxnQkFBQSx1QkFBQSxJQUFBO0FBQ0EsRUFBQUEsZ0JBQUEseUJBQUEsSUFBQTtBQUNELEdBVlksbUJBQUEsaUJBQWMsQ0FBQSxFQUFBO0FBYXBCLElBQVc7Q0FBakIsU0FBaUJDLFFBQUs7QUFFUixFQUFBQSxPQUFBLEtBQUs7QUFDTCxFQUFBQSxPQUFBLFdBQ1o7QUFDWSxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLE9BQ1o7QUFDWSxFQUFBQSxPQUFBLGNBQWM7QUFDZCxFQUFBQSxPQUFBLFVBQVU7QUFDVixFQUFBQSxPQUFBLFFBQVE7QUFDUixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLGVBQWU7QUFDZixFQUFBQSxPQUFBLFNBQVM7QUFDVCxFQUFBQSxPQUFBLGdCQUFnQjtBQUNoQixFQUFBQSxPQUFBLFlBQVk7QUFDWixFQUFBQSxPQUFBLFdBQ1o7QUFDRixHQWxCaUIsVUFBQSxRQUFLLENBQUEsRUFBQTs7O0FDakJ0QixnQkFBMkI7QUFDM0IsU0FBUyxnQkFBQUMscUJBQW9COzs7QUNEN0IsSUFBTSxZQUFZO0FBQ2xCLElBQU0sYUFBYTtBQUVuQixJQUFNLG9CQUFvQixvQkFBSSxJQUFvQjtFQUNqRCxDQUFDLFdBQVcsR0FBSTtFQUNoQixDQUFDLFVBQVUsR0FBSTtFQUNmLENBQUMsY0FBYyxHQUFJO0VBQ25CLENBQUMsTUFBTSxHQUFJO0VBQ1gsQ0FBQyxXQUFXLEdBQUk7RUFDaEIsQ0FBQyxtQkFBbUIsR0FBSTtFQUN4QixDQUFDLFNBQVMsR0FBSTtFQUNkLENBQUMsU0FBUyxHQUFJO0VBQ2QsQ0FBQyxPQUFPLEdBQUk7RUFDWixDQUFDLFlBQVksR0FBSTtFQUNqQixDQUFDLFVBQVUsR0FBSTtFQUNmLENBQUMsUUFBUSxHQUFJO0VBQ2IsQ0FBQyxhQUFhLEdBQUk7RUFDbEIsQ0FBQyxTQUFTLEdBQUk7RUFDZCxDQUFDLFNBQVMsR0FBSTtFQUNkLENBQUMsWUFBWSxHQUFJO0VBQ2pCLENBQUMsUUFBUSxHQUFJO0VBQ2IsQ0FBQyxlQUFlLEdBQUk7RUFDcEIsQ0FBQyxTQUFTLEdBQUk7Q0FDZDtBQUVELElBQU0sTUFBTSxDQUFDLFFBQWdCLEdBQUcsR0FBRyxPQUFPLElBQUksU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQWlCckUsSUFBTyxjQUFQLE1BQU8sYUFBVztFQUN2QixLQUFLO0VBQ0w7RUFDQSxPQUFPLFFBQWtCO0lBQ3hCLE9BQU8sQ0FBQTtJQUNQLFFBQVE7SUFDUixTQUFTO0lBQ1QsTUFBTTtJQUNOLE1BQU07SUFDTixVQUFVO0lBQ1YsWUFBWTtJQUNaLFVBQVU7SUFDVixPQUFPO0lBQ1AsU0FBUztJQUNULE1BQU07O0VBR1AsWUFBWSxRQUFrQixDQUFBLEdBQUU7QUFDL0IsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLFNBQU07QUFDVCxXQUFPLEtBQUssTUFBTSxDQUFDLElBQUksTUFBTyxLQUFLLE1BQU0sQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLElBQUk7RUFDL0Q7RUFDQSxJQUFJLE9BQU8sR0FBUztBQUNuQixTQUFLLE1BQU0sQ0FBQyxJQUFJLElBQUksTUFBTyxJQUFLLEtBQUssTUFBTSxDQUFDLElBQUksS0FBUyxJQUFJO0VBQzlEO0VBRUEsSUFBSSxVQUFPO0FBQ1YsWUFBUSxLQUFLLE1BQU0sQ0FBQyxJQUFJLE1BQVE7RUFDakM7RUFDQSxJQUFJLFFBQVEsR0FBUztBQUNwQjtBQUNBLFFBQUksYUFBWSxVQUFVLEdBQUcsRUFBRTtBQUMvQixTQUFLLE1BQU0sQ0FBQyxJQUFLLEtBQUssTUFBTSxDQUFDLElBQUksTUFBUyxJQUFJO0VBQy9DO0VBRUEsSUFBYyxRQUFLO0FBQ2xCLFdBQU8sS0FBSyxNQUFNLENBQUMsSUFBSTtFQUN4QjtFQUNBLElBQWMsTUFBTSxHQUFTO0FBQzVCLFNBQUssTUFBTSxDQUFDLElBQUksYUFBWSxVQUFVLEdBQUcsU0FBUztFQUNuRDtFQUVBLElBQWMsUUFBSztBQUNsQixXQUFPLEtBQUssTUFBTSxDQUFDLElBQUk7RUFDeEI7RUFDQSxJQUFjLE1BQU0sR0FBUztBQUM1QixTQUFLLE1BQU0sQ0FBQyxJQUFJLGFBQVksVUFBVSxHQUFHLFNBQVM7RUFDbkQ7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsT0FBTyxLQUFLLE1BQUs7RUFDM0I7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLEtBQUssRUFBRTtFQUNsQjtFQUVBLE9BQU8sVUFBVSxLQUFhLEtBQVc7QUFDeEMsV0FBTyxNQUFNLE1BQU0sTUFBTSxNQUFNLElBQUksSUFBSTtFQUN4QztFQUVBLE9BQU8sYUFBYSxRQUFrQixDQUFBLEdBQUksTUFBZ0IsS0FBSyxPQUFLO0FBQ25FLFFBQUksV0FBVyxJQUFJLGFBQVksS0FBSztBQUNwQyxRQUFJLFNBQVMsTUFBTSxTQUFTLElBQUksU0FBUyxTQUFTLElBQUksVUFBVTtBQUNoRSxRQUFJLFdBQVcsS0FBSyxPQUFPLElBQUksT0FBTztBQUFhLGVBQVMsa0JBQWtCLElBQUksSUFBSSxFQUFFLEtBQUs7QUFFN0YsWUFBUSxRQUFRO01BQ2YsS0FBSztBQUNKLG1CQUFXLElBQUksUUFBUSxJQUFJLFNBQVUsSUFBSSxNQUFPLElBQUksUUFBUztBQUM3RDtNQUNELEtBQUs7QUFDSixtQkFBVyxJQUFJLE9BQU8sSUFBSSxTQUFVLElBQUksTUFBTyxJQUFJLFFBQVM7QUFDNUQ7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxXQUFXLElBQUksU0FBVSxJQUFJLE1BQU8sSUFBSSxRQUFTO0FBQ2hFO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksY0FBYyxJQUFJLFNBQVUsSUFBSSxZQUFhLElBQUksS0FBTTtBQUN0RTtNQUNELEtBQUs7QUFDSixtQkFBVyxJQUFJLGNBQWMsSUFBSSxTQUFVLElBQUksT0FBUTtBQUN2RDtNQUNELEtBQUs7QUFDSixtQkFBVyxJQUFJLGdCQUFnQixJQUFJLFNBQVUsSUFBSSxRQUFTO0FBQzFEO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksV0FBVyxJQUFJLFNBQVUsSUFBSSxLQUFNO0FBQ2xEO01BQ0QsS0FBSztBQUNKLG1CQUFXLElBQUksTUFBTSxJQUFJLEtBQU07QUFDL0I7TUFDRCxLQUFLO0FBQ0osbUJBQVcsSUFBSSxJQUFJLElBQUksTUFBTyxJQUFJLEtBQU07QUFDeEM7TUFDRCxLQUFLO0FBQ0o7O01BQ0Q7QUFDQyxnQkFBUSxJQUFJLHNDQUFzQyxJQUFJLE1BQU0sQ0FBQyxFQUFFO0FBQy9EO0lBQ0Y7QUFFQSxRQUFJLE1BQU0sU0FBUztBQUFHLGVBQVMsUUFBUTtBQUN2QyxXQUFPO0VBQ1I7O0FBR0QsSUFBTSxVQUFOLGNBQXNCLFlBQVc7RUFDaEMsWUFBWSxHQUFXLEdBQVcsR0FBUztBQUMxQyxVQUFLO0FBQ0wsU0FBSyxLQUFLO0FBQ1YsU0FBSyxTQUFTO0FBQ2QsU0FBSyxVQUFVO0FBQ2YsU0FBSyxPQUFPO0FBQ1osU0FBSyxXQUFXO0VBQ2pCO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLEtBQUssR0FBUztBQUNqQixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksV0FBUTtBQUNYLFdBQU8sS0FBSztFQUNiO0VBQ0EsSUFBSSxTQUFTLEdBQVM7QUFDckIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsTUFBTSxLQUFLLE1BQU0sVUFBVSxLQUFLLFNBQVE7RUFDekU7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxXQUFXLElBQUksS0FBSyxJQUFJLENBQUMsZUFBZSxJQUNoRyxLQUFLLFFBQVEsQ0FDYjtFQUNGOztBQUdELElBQU0sU0FBTixjQUFxQixRQUFPO0VBQzNCLFlBQVksR0FBVyxHQUFXLEdBQVM7QUFDMUMsVUFBTSxHQUFHLEdBQUcsQ0FBQztBQUNiLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztFQUNmOztBQUdELElBQU0sYUFBTixjQUF5QixZQUFXO0VBQ25DLFlBQVksR0FBVyxHQUFXLEdBQVM7QUFDMUMsVUFBSztBQUNMLFNBQUssS0FBSztBQUNWLFNBQUssU0FBUztBQUNkLFNBQUssVUFBVTtBQUNmLFNBQUssT0FBTztBQUNaLFNBQUssV0FBVztFQUNqQjtFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sS0FBSztFQUNiO0VBQ0EsSUFBSSxLQUFLLEdBQVM7QUFDakIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLFdBQVE7QUFDWCxXQUFPLEtBQUs7RUFDYjtFQUNBLElBQUksU0FBUyxHQUFTO0FBQ3JCLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLE1BQU0sS0FBSyxNQUFNLFVBQVUsS0FBSyxTQUFRO0VBQ3pFO0VBRUEsV0FBUTtBQUNQLFdBQU8sR0FBRyxNQUFNLFNBQVEsQ0FBRSxjQUFjLElBQUksS0FBSyxPQUFPLENBQUMsV0FBVyxJQUFJLEtBQUssSUFBSSxDQUFDLGVBQWUsSUFDaEcsS0FBSyxRQUFRLENBQ2I7RUFDRjs7QUFHRCxJQUFNLGdCQUFOLGNBQTRCLFlBQVc7RUFDdEMsWUFBWSxHQUFXLElBQVksR0FBUztBQUMzQyxVQUFLO0FBQ0wsU0FBSyxLQUFLO0FBQ1YsU0FBSyxTQUFTO0FBQ2QsU0FBSyxVQUFVO0FBQ2YsU0FBSyxhQUFhO0FBQ2xCLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxhQUFVO0FBQ2IsV0FBTyxLQUFLO0VBQ2I7RUFDQSxJQUFJLFdBQVcsR0FBUztBQUN2QixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksUUFBSztBQUNSLFdBQU8sS0FBSztFQUNiO0VBQ0EsSUFBSSxNQUFNLEdBQVM7QUFDbEIsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsWUFBWSxLQUFLLFlBQVksT0FBTyxLQUFLLE1BQUs7RUFDL0U7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxpQkFBaUIsSUFBSSxLQUFLLFVBQVUsQ0FBQyxZQUFZLElBQ3pHLEtBQUssS0FBSyxDQUNWO0VBQ0Y7O0FBR0QsSUFBTSxnQkFBTixjQUE0QixZQUFXO0VBQ3RDLFlBQVksR0FBVyxHQUFTO0FBQy9CLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLFVBQVU7RUFDaEI7RUFFQSxJQUFJLFVBQU87QUFDVixXQUFPLEtBQUssUUFBUTtFQUNyQjtFQUNBLElBQUksUUFBUSxHQUFTO0FBQ3BCO0FBQ0EsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsU0FBUyxLQUFLLFFBQU87RUFDdEQ7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLGNBQWMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxjQUFjLElBQUksS0FBSyxPQUFPLENBQUM7RUFDekY7O0FBR0QsSUFBTSxrQkFBTixjQUE4QixZQUFXO0VBQ3hDLFlBQVksR0FBVyxHQUFTO0FBQy9CLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLFdBQVc7RUFDakI7RUFFQSxJQUFJLFdBQVE7QUFDWCxXQUFPLEtBQUs7RUFDYjtFQUNBLElBQUksU0FBUyxHQUFTO0FBQ3JCLFNBQUssUUFBUTtFQUNkO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLFVBQVUsS0FBSyxTQUFRO0VBQ3hEO0VBRUEsV0FBUTtBQUNQLFdBQU8sR0FBRyxNQUFNLFNBQVEsQ0FBRSxjQUFjLElBQUksS0FBSyxPQUFPLENBQUMsZUFBZSxJQUFJLEtBQUssUUFBUSxDQUFDO0VBQzNGOztBQUdELElBQU0sYUFBTixjQUF5QixZQUFXO0VBQ25DLFlBQVksR0FBVyxHQUFTO0FBQy9CLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksUUFBSztBQUNSLFlBQVEsS0FBSyxTQUFTLEtBQUssS0FBSztFQUNqQztFQUNBLElBQUksTUFBTSxHQUFTO0FBQ2xCLFFBQUksWUFBWSxVQUFVLEdBQUcsVUFBVTtBQUN2QyxTQUFLLFFBQVMsS0FBSyxJQUFLO0FBQ3hCLFNBQUssUUFBUSxJQUFJO0VBQ2xCO0VBRUEsSUFBSSxPQUFJO0FBQ1AsV0FBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLE9BQU8sS0FBSyxNQUFLO0VBQ2xEO0VBRUEsV0FBUTtBQUNQLFdBQU8sR0FBRyxNQUFNLFNBQVEsQ0FBRSxjQUFjLElBQUksS0FBSyxPQUFPLENBQUMsWUFBWSxJQUFJLEtBQUssS0FBSyxDQUFDO0VBQ3JGOztBQUdELElBQU0sUUFBTixjQUFvQixZQUFXO0VBQzlCLFlBQVksR0FBVztBQUN0QixVQUFLO0FBQ0wsU0FBSyxLQUFLO0FBQ1YsU0FBSyxRQUFRO0VBQ2Q7RUFFQSxJQUFJLE9BQUk7QUFDUCxXQUFPLEVBQUUsT0FBTyxLQUFLLE1BQUs7RUFDM0I7RUFFQSxXQUFRO0FBQ1AsV0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFLFlBQVksS0FBSyxLQUFLO0VBQ2pEOztBQUdLLElBQU8sTUFBUCxjQUFtQixZQUFXO0VBQ25DLFlBQVksR0FBVyxHQUFTO0FBQy9CLFVBQUs7QUFDTCxTQUFLLEtBQUs7QUFDVixTQUFLLFNBQVM7QUFDZCxTQUFLLE9BQU87QUFDWixTQUFLLFFBQVE7RUFDZDtFQUVBLElBQUksT0FBSTtBQUNQLFdBQVEsS0FBSyxTQUFTLElBQUs7RUFDNUI7RUFDQSxJQUFJLEtBQUssR0FBUztBQUNqQixTQUFLLFFBQVMsS0FBSyxRQUFRLEtBQVMsS0FBSztFQUMxQztFQUVBLElBQUksUUFBSztBQUNSLFdBQU8sS0FBSyxRQUFRO0VBQ3JCO0VBQ0EsSUFBSSxNQUFNLEdBQVM7QUFDbEIsUUFBSSxZQUFZLFVBQVUsR0FBRyxFQUFFO0FBQy9CLFNBQUssUUFBUyxLQUFLLFFBQVEsTUFBUTtFQUNwQztFQUVBLElBQUksT0FBSTtBQUNQLFdBQU8sRUFBRSxTQUFTLEtBQUssU0FBUyxNQUFNLEtBQUssTUFBTSxPQUFPLEtBQUssTUFBSztFQUNuRTtFQUVBLFdBQVE7QUFDUCxXQUFPLEdBQUcsTUFBTSxTQUFRLENBQUUsV0FBVyxJQUFJLEtBQUssSUFBSSxDQUFDLFlBQVksSUFBSSxLQUFLLEtBQUssQ0FBQztFQUMvRTs7OztBRC9YSyxJQUFPQyxTQUFQLGNBQXFCQyxjQUFZO0VBQzlCO0VBQ0E7RUFDQTtFQUNBO0VBQ0Q7RUFFUCxZQUFZLE1BQWMsU0FBaUI7QUFDMUMsVUFBSztBQUNMLFNBQUssU0FBUyxJQUFjLGdCQUFLO0FBQ2pDLFNBQUssT0FBTyxZQUFZLE9BQU8sT0FBTyxLQUFLO0FBQzNDLFNBQUssZ0JBQWdCO0FBQ3JCLFNBQUssU0FBUyxDQUFBO0FBQ2QsU0FBSyxTQUFTLENBQUE7QUFDZCxTQUFLLE9BQU87QUFDWixVQUFNLHlCQUFtQyxVQUFTO0FBRWxELFFBQUksU0FBUztBQUNaLFdBQUssT0FBTyxnQkFBZ0IsSUFBSTtJQUNqQyxPQUFPO0FBQ04sWUFBTSxZQUFZLEtBQUssT0FBTyxhQUFZO0FBQzFDLGVBQVMsSUFBSSxHQUFHLElBQUksV0FBVyxLQUFLO0FBQ25DLFlBQUksU0FBUyx1QkFBdUIsQ0FBQyxHQUFHO0FBQ3ZDLGNBQUk7QUFDSCxpQkFBSyxPQUFPLFNBQVMsQ0FBQztVQUN2QixTQUFTLEtBQUs7QUFDYixvQkFBUSxJQUFJLHNCQUFzQixJQUFJO1NBQWEsR0FBRyxFQUFFO1VBQ3pEO1FBQ0Q7TUFDRDtJQUNEO0FBRUEsU0FBSyxPQUFPLEdBQUcsV0FBVyxDQUFDLFdBQW1CLFVBQXlCO0FBR3RFLFlBQU0sTUFBTSxZQUFZLGFBQWEsS0FBSztBQUMxQyxVQUFJLFFBQVE7QUFBVztBQUN2QixXQUFLLEtBQUssV0FBVyxXQUFXLEdBQUc7QUFDbkMsVUFBSSxJQUFJLE1BQU0sT0FBTztBQUNwQixhQUFLLFNBQVMsR0FBVTtNQUN6QjtJQUNELENBQUM7RUFDRjtFQUVBLFFBQUs7QUFDSixTQUFLLE9BQU8sVUFBUztBQUNyQixTQUFLLE9BQU8sUUFBTztFQUNwQjtFQUVBLGFBQVU7QUFDVCxXQUFPLEtBQUssT0FBTyxXQUFVO0VBQzlCO0VBRUEsU0FBUyxNQUFTO0FBQ2pCLFVBQU0sY0FBYyxDQUFDLElBQUksSUFBSSxPQUFPLEVBQUU7QUFDdEMsVUFBTSxhQUFxQixLQUFLO0FBQ2hDLFFBQUksUUFBZ0IsS0FBSztBQUN6QixRQUFJO0FBRUosU0FBSyxPQUFPLFVBQVUsSUFBSTtBQUcxQixRQUFJLGVBQWUsS0FBSyxPQUFPLEtBQUssT0FBTyxDQUFDLE1BQU0sVUFBVTtBQUMzRCxZQUFNLE9BQWlCLENBQUE7QUFDdkIsZUFBUyxJQUFJLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDNUIsY0FBTSxNQUFNLFFBQVMsS0FBSyxJQUFLLElBQUk7QUFDbkMsYUFBSyxLQUFLLEdBQUc7TUFDZDtBQUNBLGNBQVEsS0FBSyxDQUFDO0FBQ2QsdUJBQWlCLGFBQWEsS0FBSyxDQUFDLEtBQUssS0FBSyxLQUFLLENBQUMsQ0FBQztBQUNyRCxXQUFLLE9BQU8sVUFBVSxJQUFJO0FBRTFCLFlBQU0sUUFBUSxLQUFLO0FBQ25CLFlBQU0sbUJBQ0gsTUFBTSxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsR0FBRyxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUcsSUFDdkQsUUFDRSxNQUFNLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQyxHQUFHLFNBQVEsRUFBRyxTQUFTLEdBQUcsR0FBRyxJQUN2RCxRQUNFLE1BQU0sQ0FBQyxLQUFLLEtBQUssTUFBTSxDQUFDLEdBQUcsU0FBUSxFQUFHLFNBQVMsR0FBRyxHQUFHLElBQ3ZELFFBQ0UsTUFBTSxDQUFDLEtBQUssS0FBSyxNQUFNLENBQUMsR0FBRyxTQUFRLEVBQUcsU0FBUyxHQUFHLEdBQUc7QUFDeEQsV0FBSyxLQUFLLFNBQVM7UUFDbEIsT0FBTztRQUNQLFNBQVM7T0FDVDtJQUNGO0VBQ0Q7O0FBR0ssSUFBT0MsVUFBUCxNQUFhO0VBQ1Y7RUFDRDtFQUVQLFlBQVksTUFBYyxTQUFpQjtBQUMxQyxTQUFLLFVBQVUsSUFBYyxpQkFBTTtBQUNuQyxTQUFLLE9BQU87QUFDWixVQUFNLDBCQUFvQyxXQUFVO0FBRXBELFFBQUksU0FBUztBQUNaLFdBQUssUUFBUSxnQkFBZ0IsSUFBSTtJQUNsQyxPQUFPO0FBQ04sWUFBTSxhQUFhLEtBQUssUUFBUSxhQUFZO0FBQzVDLGVBQVMsSUFBSSxHQUFHLElBQUksWUFBWSxLQUFLO0FBQ3BDLFlBQUksU0FBUyx3QkFBd0IsQ0FBQyxHQUFHO0FBQ3hDLGNBQUk7QUFDSCxpQkFBSyxRQUFRLFNBQVMsQ0FBQztVQUN4QixTQUFTLEtBQUs7QUFDYixvQkFBUSxJQUFJLHNCQUFzQixJQUFJO1NBQWEsR0FBRyxFQUFFO1VBQ3pEO1FBQ0Q7TUFDRDtJQUNEO0VBQ0Q7RUFFQSxRQUFLO0FBQ0osU0FBSyxRQUFRLFVBQVM7QUFDdEIsU0FBSyxRQUFRLFFBQU87RUFDckI7RUFFQSxhQUFVO0FBQ1QsV0FBTyxLQUFLLFFBQVEsV0FBVTtFQUMvQjtFQUVBLEtBQUssS0FBZ0I7QUFDcEIsU0FBSyxRQUFRLFlBQVksSUFBSSxLQUFLO0VBQ25DOztBQUlLLFNBQVUsWUFBUztBQUN4QixRQUFNLFFBQVEsSUFBYyxnQkFBSztBQUNqQyxRQUFNLFNBQW1CLENBQUE7QUFDekIsV0FBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLGFBQVksR0FBSSxLQUFLO0FBQzlDLFFBQUksVUFBVTtBQUNkLFVBQU0sV0FBVyxNQUFNLFlBQVksQ0FBQztBQUNwQyxRQUFJLG1CQUFtQjtBQUN2QixXQUFPLE9BQU8sU0FBUyxnQkFBZ0IsR0FBRztBQUN6QztBQUNBLDBCQUFvQixJQUFJLE9BQU87SUFDaEM7QUFDQSxXQUFPLEtBQUssZ0JBQWdCO0VBQzdCO0FBQ0EsUUFBTSxVQUFTO0FBQ2YsU0FBTztBQUNSO0FBRU0sU0FBVSxhQUFVO0FBQ3pCLFFBQU0sU0FBUyxJQUFjLGlCQUFNO0FBQ25DLFFBQU0sVUFBb0IsQ0FBQTtBQUMxQixXQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sYUFBWSxHQUFJLEtBQUs7QUFDL0MsUUFBSSxVQUFVO0FBQ2QsVUFBTSxXQUFXLE9BQU8sWUFBWSxDQUFDO0FBQ3JDLFFBQUksbUJBQW1CO0FBQ3ZCLFdBQU8sUUFBUSxTQUFTLGdCQUFnQixHQUFHO0FBQzFDO0FBQ0EsMEJBQW9CLElBQUksT0FBTztJQUNoQztBQUNBLFlBQVEsS0FBSyxnQkFBZ0I7RUFDOUI7QUFDQSxTQUFPLFVBQVM7QUFDaEIsU0FBTztBQUNSOzs7QUV2Sk0sU0FBVSxrQkFBZTtBQUM5QixRQUFNLGNBQWdDLENBQUE7QUFDdEMsUUFBTSxlQUFpQyxDQUFBO0FBQ3ZDLFFBQU0sVUFBb0IsVUFBUztBQUNuQyxRQUFNLFdBQXFCLFdBQVU7QUFDckMsVUFBUSxRQUFRLENBQUMsTUFBSztBQUNyQixnQkFBWSxLQUFLLEVBQUUsSUFBSSxHQUFHLE9BQU8sRUFBQyxDQUFFO0VBQ3JDLENBQUM7QUFDRCxXQUFTLFFBQVEsQ0FBQyxNQUFLO0FBQ3RCLGlCQUFhLEtBQUssRUFBRSxJQUFJLEdBQUcsT0FBTyxFQUFDLENBQUU7RUFDdEMsQ0FBQztBQUVELFNBQU87SUFDTjtNQUNDLE1BQU07TUFDTixJQUFJO01BQ0osT0FBTztNQUNQLE9BQU87TUFDUCxTQUFTLFFBQVEsQ0FBQyxLQUFLO01BQ3ZCLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBb0JWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FBTztNQUNQLFNBQVMsU0FBUyxDQUFDLEtBQUs7TUFDeEIsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBMkJWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsU0FBUztNQUNULE9BQU87TUFDUCxTQUFTOztJQUVWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsU0FBUztNQUNULE9BQU87TUFDUCxTQUFTOztJQUVWO01BQ0MsTUFBTTtNQUNOLElBQUk7TUFDSixPQUFPO01BQ1AsT0FDQztNQUNELFNBQVM7TUFDVCxPQUFPOzs7QUFHVjs7O0FDbkdBLElBQU0sWUFBc0Q7RUFDM0QsUUFBUSxFQUFFLE1BQU0sOEJBQTZCO0VBQzdDLFNBQVMsRUFBRSxNQUFNLDhCQUE2QjtFQUM5QyxhQUFhLEVBQUUsTUFBTSx3QkFBdUI7RUFDNUMsT0FBTyxFQUFFLE1BQU0sb0JBQW1CO0VBQ2xDLFNBQVMsRUFBRSxNQUFNLDRCQUEyQjtFQUM1QyxZQUFZLEVBQUUsTUFBTSxzQkFBcUI7O0FBRzFDLElBQU0sYUFBZ0Usb0JBQUksSUFBRztBQUV2RSxTQUFVLDBCQUEwQixNQUFvQjtBQUM3RCxPQUFLLHVCQUF1QixTQUFTO0FBQ3JDLE9BQUssa0JBQWtCLEVBQUUsUUFBUSxPQUFPLFNBQVMsTUFBSyxDQUFFO0FBQ3pEO0FBRU0sU0FBVSxxQkFBcUIsTUFBc0IsVUFBZ0I7QUFDMUUsTUFBSSxJQUFJLFdBQVcsSUFBSSxRQUFRLEtBQUs7QUFDcEMsTUFBSSxNQUFNO0FBQU0saUJBQWEsQ0FBQztBQUM5QixNQUFJLFdBQVcsTUFBSztBQUNuQixTQUFLLGtCQUFrQixFQUFFLENBQUMsUUFBUSxHQUFHLE1BQUssQ0FBRTtBQUM1QyxTQUFLLGVBQWUsUUFBUTtFQUM3QixHQUFHLEdBQUc7QUFDTixhQUFXLElBQUksVUFBVSxDQUFDO0FBQzFCLE9BQUssa0JBQWtCLEVBQUUsQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFFO0FBQzNDLE9BQUssZUFBZSxRQUFRO0FBQzdCO0FBRU0sU0FBVSxjQUFjLE1BQXNCLEtBQWtCLE1BQXdCO0FBQzdGLFFBQU0sVUFBVSxjQUFjLEdBQUc7QUFDakMsUUFBTSxVQUFVLFFBQVEsT0FBTyxNQUFNO0FBQ3JDLE9BQUssa0JBQWtCLEVBQUUsYUFBYSxRQUFPLENBQUU7QUFFL0MsaUJBQWUsTUFBTSxlQUFlLDhCQUE4QixJQUFJLEVBQUU7QUFFeEUsTUFBSSxJQUFJLE1BQU0sWUFBWSxJQUFJLE1BQU0sV0FBVztBQUM5QyxVQUFNLGFBQTJCLEtBQUssaUJBQWlCLFlBQVksS0FBcUIsQ0FBQTtBQUN4RixlQUFXLElBQUksT0FBTyxNQUFNLENBQUE7QUFDNUIsZUFBVyxJQUFJLE9BQU8sRUFBRSxJQUFJLEtBQUssSUFBSyxJQUFJLElBQUksTUFBTSxZQUFZLE9BQVE7QUFDeEUsU0FBSyxrQkFBa0IsRUFBRSxXQUFVLENBQUU7RUFDdEM7QUFFQSxXQUFTLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUs7QUFDN0MsVUFBTSxVQUFVLFFBQVEsS0FBSyxDQUFDO0FBQzlCLFVBQU0sTUFBTTtBQUNaLFVBQU0sYUFBYSxRQUFRLENBQUMsRUFBRSxZQUFXLElBQUssUUFBUSxNQUFNLENBQUM7QUFDN0QsbUJBQWUsTUFBTSxTQUFTLFlBQVksVUFBVSxhQUFhLGFBQWEsT0FBTyxJQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7RUFDcEc7QUFDRDtBQUVNLFNBQVUsYUFBYSxNQUFzQixLQUFrQixNQUF3QjtBQUU1RixpQkFBZSxNQUFNLE1BQU0sY0FBYyxHQUFHLEVBQUUsTUFBTSx5QkFBeUIsSUFBSTtBQUNsRjtBQUVBLFNBQVMsY0FBYyxLQUFnQjtBQUd0QyxNQUFJLFVBQVUsSUFBSTtBQUNsQixRQUFNLFVBQVUsT0FBTyxLQUFLLElBQUksSUFBSTtBQUNwQyxXQUFTLElBQUksR0FBRyxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUs7QUFDNUMsVUFBTSxNQUFNLFFBQVEsQ0FBQztBQUNyQixVQUFNLE1BQTBCLE9BQU8sSUFBSSxLQUFLLEdBQUcsQ0FBQztBQUNwRCxRQUFJLFFBQVEsUUFBVztBQUN0QixpQkFBVyxJQUFJLEdBQUc7SUFDbkI7RUFDRDtBQUNBLFNBQU8sRUFBRSxNQUFNLFNBQVMsTUFBTSxRQUFPO0FBQ3RDO0FBRUEsU0FBUyxlQUNSLE1BQ0EsU0FDQSxVQUNBLE1BQWlDO0FBRWpDLFlBQVUsT0FBTyxJQUFJLEVBQUUsTUFBTSxTQUFRO0FBQ3JDLE9BQUssdUJBQXVCLFNBQVM7QUFDckMsT0FBSyxrQkFBa0IsRUFBRSxDQUFDLE9BQU8sR0FBRyxLQUFJLENBQUU7QUFDM0M7OztBQ3BGTyxJQUFNLGlCQUErRDs7Ozs7RUFLM0UsU0FDQyxTQUNBLE9BQTJEO0FBRTNELFVBQU0sVUFBaUU7TUFDdEUsZUFBZTtNQUNmLGdCQUFnQixDQUFBO01BQ2hCLGtCQUFrQixDQUFBOztBQUduQixZQUFRLElBQUksK0JBQStCO0FBRTNDLGVBQVcsS0FBSyxNQUFNLFNBQVM7QUFDOUIsVUFBSSxFQUFFLFlBQVksV0FBVztBQUM1QixnQkFBUSxJQUFJLHFCQUFxQixDQUFDO0FBQ2xDLFVBQUUsUUFBUSxVQUFVLEVBQUUsUUFBUSxVQUFVLEVBQUUsUUFBUTtBQUNsRCxlQUFPLEVBQUUsUUFBUTtNQUNsQjtBQUNBLFVBQUksQ0FBQyxFQUFFLFFBQVE7QUFBUyxVQUFFLFFBQVEsVUFBVSxFQUFFLFFBQVE7QUFDdEQsVUFBSSxDQUFDLEVBQUUsUUFBUTtBQUFXLFVBQUUsUUFBUSxZQUFZLEVBQUUsUUFBUTtBQUMxRCxVQUFJLENBQUMsRUFBRSxRQUFRO0FBQVMsVUFBRSxRQUFRLFVBQVUsRUFBRSxRQUFRO0FBRXRELGNBQVEsZUFBZSxLQUFLLENBQUM7QUFDN0IsY0FBUSxJQUFJLFFBQVEsQ0FBQztJQUN0QjtBQUVBLGVBQVcsS0FBSyxNQUFNLFdBQVc7QUFDaEMsVUFBSSxFQUFFLGNBQWMsbUJBQW1CO0FBQ3RDLGdCQUFRLElBQUksdUJBQXVCLENBQUM7QUFFcEMsVUFBRSxhQUFhLE9BQU8sRUFBRSxRQUFRLE9BQU87QUFDdkMsZUFBTyxFQUFFLFFBQVE7QUFDakIsZ0JBQVEsRUFBRSxZQUFZO1VBQ3JCLEtBQUs7QUFDSixjQUFFLFFBQVEsVUFBVSxFQUFFLFFBQVE7QUFDOUIsbUJBQU8sRUFBRSxRQUFRO0FBQ2pCO1VBQ0QsS0FBSztBQUNKLGNBQUUsUUFBUSxRQUFRLEVBQUUsUUFBUTtBQUM1QixtQkFBTyxFQUFFLFFBQVE7QUFDakI7VUFDRCxLQUFLO0FBQ0osY0FBRSxRQUFRLFFBQVEsRUFBRSxRQUFRO0FBQzVCLG1CQUFPLEVBQUUsUUFBUTtRQUNuQjtNQUNEO0FBQ0EsVUFBSSxDQUFDLEVBQUUsUUFBUTtBQUFTLFVBQUUsUUFBUSxVQUFVLEVBQUUsUUFBUTtBQUN0RCxVQUFJLENBQUMsRUFBRSxRQUFRO0FBQVcsVUFBRSxRQUFRLFlBQVksRUFBRSxRQUFRO0FBQzFELFVBQUksQ0FBQyxFQUFFLFFBQVE7QUFBUyxVQUFFLFFBQVEsVUFBVSxFQUFFLFFBQVE7QUFFdEQsY0FBUSxpQkFBaUIsS0FBSyxDQUFDO0FBQy9CLGNBQVEsSUFBSSxRQUFRLENBQUM7SUFDdEI7QUFFQSxXQUFPO0VBQ1I7RUFFQSxTQUNDLFNBQ0EsT0FBMkQ7QUFFM0QsVUFBTSxVQUFpRTtNQUN0RSxlQUFlO01BQ2YsZ0JBQWdCLENBQUE7TUFDaEIsa0JBQWtCLENBQUE7O0FBR25CLFlBQVEsSUFBSSwrQkFBK0I7QUFFM0MsZUFBVyxLQUFLLE1BQU0sU0FBUztBQUM5QixjQUFRLElBQUksdUJBQXVCLENBQUM7QUFFcEMsVUFBSSxDQUFDLEVBQUUsUUFBUTtBQUFjLFVBQUUsUUFBUSxlQUFlLEVBQUUsY0FBYyxPQUFPLE9BQU8sTUFBSztBQUN6RixVQUFJLENBQUMsRUFBRSxRQUFRO0FBQWdCLFVBQUUsUUFBUSxpQkFBaUIsRUFBRSxjQUFjLE9BQU8sT0FBTyxFQUFDO0FBQ3pGLFVBQUksQ0FBQyxFQUFFLFFBQVE7QUFBTSxVQUFFLFFBQVEsT0FBTyxFQUFFLGNBQWMsT0FBTyxPQUFPLEVBQUM7QUFDckUsVUFBSSxDQUFDLEVBQUUsUUFBUTtBQUFPLFVBQUUsUUFBUSxRQUFRLEVBQUUsY0FBYyxPQUFPLE9BQU8sU0FBUTtBQUU5RSxjQUFRLGVBQWUsS0FBSyxDQUFDO0FBQzdCLGNBQVEsSUFBSSxVQUFVLENBQUM7SUFDeEI7QUFFQSxXQUFPO0VBQ1I7Ozs7QUNsRk0sSUFBTSxlQUE4QjtFQUMxQztJQUNDLElBQUk7SUFDSixPQUFPO0lBQ1AsTUFBTTtJQUNOLE9BQU87SUFDUCxVQUFVO0lBQ1YsUUFBUTtJQUNSLFFBQVE7SUFDUixZQUFZOztFQUViO0lBQ0MsSUFBSTtJQUNKLE9BQU87SUFDUCxNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVU7SUFDVixRQUFRO0lBQ1IsUUFBUTtJQUNSLFlBQVk7OztFQUdiO0lBQ0MsSUFBSTtJQUNKLE9BQU87SUFDUCxNQUFNO0lBQ04sT0FBTztJQUNQLFVBQVU7SUFDVixRQUFRO0lBQ1IsUUFBUTtJQUNSLFlBQVk7O0VBRWI7SUFDQyxJQUFJO0lBQ0osT0FBTztJQUNQLE1BQU07SUFDTixPQUFPO0lBQ1AsVUFBVTtJQUNWLFFBQVE7SUFDUixRQUFRO0lBQ1IsWUFBWTs7O0VBR2I7SUFDQyxJQUFJO0lBQ0osT0FBTztJQUNQLE1BQU07SUFDTixPQUFPO0lBQ1AsVUFBVTtJQUNWLFFBQVE7SUFDUixRQUFRO0lBQ1IsWUFBWTs7RUFFYjtJQUNDLElBQUk7SUFDSixPQUFPO0lBQ1AsTUFBTTtJQUNOLE9BQU87SUFDUCxVQUFVO0lBQ1YsUUFBUTtJQUNSLFFBQVE7SUFDUixZQUFZOzs7Ozs7Ozs7Ozs7OztBQWlCUixTQUFVLGNBQWMsU0FBc0IsUUFBbUI7QUFDdEUsTUFBSSxDQUFDLFdBQVcsVUFBVSxNQUFNLFdBQVcsT0FBTyxFQUFFLFNBQVMsT0FBTyxFQUFFLEdBQUc7QUFDeEUsWUFBUSxLQUFLO01BQ1osSUFBSTtNQUNKLE1BQU07TUFDTixPQUFPO01BQ1AsU0FBUztNQUNULEtBQUs7TUFDTCxLQUFLO0tBQ0w7RUFDRjtBQUNBLE1BQUksQ0FBQyxXQUFXLFFBQVEsRUFBRSxTQUFTLE9BQU8sRUFBRSxHQUFHO0FBQzlDLFlBQVEsS0FBSztNQUNaLElBQUk7TUFDSixNQUFNO01BQ04sT0FBTztNQUNQLFNBQVM7TUFDVCxLQUFLO01BQ0wsS0FBSztLQUNMO0VBQ0Y7QUFDQSxNQUFJLE9BQU8sTUFBTSxNQUFNO0FBQ3RCLFlBQVEsS0FBSztNQUNaLElBQUk7TUFDSixNQUFNO01BQ04sT0FBTztNQUNQLFNBQVM7TUFDVCxLQUFLO01BQ0wsS0FBSztLQUNMO0VBQ0Y7QUFDQSxNQUFJLE9BQU8sTUFBTSxTQUFTO0FBQ3pCLFlBQVEsS0FBSztNQUNaLElBQUksT0FBTztNQUNYLE1BQU07TUFDTixPQUFPLE9BQU87TUFDZCxTQUFTLE9BQU87TUFDaEIsS0FBSyxPQUFPO01BQ1osS0FBSyxPQUFPO0tBQ1o7RUFDRixPQUFPO0FBQ04sWUFBUSxLQUFLO01BQ1osSUFBSTtNQUNKLE1BQU07TUFDTixPQUFPLE9BQU87TUFDZCxTQUNDO01BQ0QsU0FBUztLQUNUO0VBQ0Y7QUFFQSxTQUFPO0FBQ1I7OztBQ3pJTSxTQUFVLGNBQWMsTUFBb0I7QUFDakQsT0FBSyxrQkFBa0IsRUFBRSxhQUFhLE1BQUssQ0FBRTtBQUU3QyxRQUFNLFVBQXNDLENBQUE7QUFDNUMsYUFBVyxVQUFVLGNBQWM7QUFDbEMsVUFBTSxZQUF1QztNQUM1QyxNQUFNLE9BQU8sT0FBTyxLQUFLO01BQ3pCLFNBQVMsY0FBYyxDQUFBLEdBQUksTUFBTTtNQUNqQyxVQUFVLE9BQU8sVUFBd0I7QUFDeEMsY0FBTSxPQUFPLEtBQUssTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPLENBQUM7QUFFckQsWUFBSSxDQUFDLEtBQUssT0FBTyxvQkFBb0IsQ0FBQyxLQUFLLFdBQVcsV0FBVSxHQUFJO0FBQ25FLGVBQUssSUFBSSxTQUFTLGdCQUFnQixLQUFLLFdBQVcsSUFBSSxhQUFhO0FBQ25FO1FBQ0Q7QUFFQSxZQUFJLE9BQU8sTUFBTSxTQUFTO0FBQ3pCLGdCQUFNLGNBQWMsTUFBTSxLQUFLLE9BQU8sS0FBSztBQUMzQyxlQUFLLFFBQVEsWUFBWSxNQUFNLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBc0IsU0FBUyxDQUFDLENBQUM7UUFDL0U7QUFFQSxZQUFJLEtBQUssVUFBVTtBQUNsQixlQUFLLE9BQU8sS0FBSyxJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVE7QUFDL0MsY0FBSSxLQUFLO0FBQVMsaUJBQUssVUFBVSxPQUFPLE1BQU0sS0FBSyxPQUFPO0FBQzFELGNBQUksS0FBSztBQUFXLGlCQUFLLE9BQU8sT0FBTyxNQUFNLEtBQUssU0FBUztBQUMzRCxjQUFJLEtBQUs7QUFBUyxpQkFBSyxhQUFhLE9BQU8sTUFBTSxLQUFLLE9BQU87UUFDOUQ7QUFFQSxZQUFJLE1BQU0sWUFBWSxhQUFhLFFBQVcsRUFBRSxJQUFJLE9BQU8sSUFBSSxHQUFHLEtBQUksQ0FBRTtBQUN4RSxZQUFJLEtBQUssVUFBVTtBQUNsQixnQkFBTSxNQUFNLEtBQUssaUJBQWlCLEdBQUk7QUFDdEMsY0FBSSxRQUFRLFFBQVc7QUFDdEIsaUJBQUssSUFBSSxRQUFRLCtEQUErRDtBQUNoRjtVQUNEO0FBQ0EsZUFBSyxPQUFPLEtBQUssSUFBSSxNQUFNLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDO1FBQ3pEO0FBRUEsWUFBSSxLQUFLLGNBQWM7QUFFdEIsZ0JBQU0sYUFBYSxLQUFLLE9BQU87QUFDL0IsZ0JBQU0sUUFBUSxLQUFLO0FBQ25CLGdCQUFNLFNBQVM7QUFFZixjQUFJLFFBQVE7QUFDWixjQUFJLEtBQUssVUFBVTtBQUNsQixvQkFBUSxLQUFLLGlCQUFpQixHQUFJLEtBQUs7VUFDeEMsT0FBTztBQUNOLG9CQUFRLE9BQU8sS0FBSyxjQUFjO1VBQ25DO0FBRUEsY0FBSSxNQUFNLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDO0FBR3ZDLGNBQUksTUFBTSxHQUFHO0FBQ1osa0JBQU07VUFDUCxXQUFXLE1BQU0sS0FBSztBQUNyQixrQkFBTTtVQUNQO0FBR0EsY0FBSSxRQUFRLEtBQUs7VUFFakI7QUFFQSxnQkFBTSxLQUFLLEtBQUssSUFBRztBQUNuQixjQUFJLE9BQU87QUFNWCxnQkFBTSxnQkFBK0I7WUFDcEMsUUFBUSxDQUFDLE1BQXNCO1lBQy9CLFFBQVEsQ0FBQyxNQUFzQixJQUFJO1lBQ25DLFNBQVMsQ0FBQyxNQUFzQixLQUFLLElBQUksTUFBTSxJQUFJO1lBQ25ELFdBQVcsQ0FBQyxNQUF1QixJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsQ0FBQyxJQUFJOztBQUV4RixnQkFBTSxPQUE4QixjQUFjLEtBQWUsTUFBTSxDQUFDLE1BQXNCO0FBRTlGLGdCQUFNLFFBQVEsWUFBWSxNQUFLO0FBQzlCLGtCQUFNLFVBQVUsS0FBSyxJQUFHLElBQUs7QUFDN0Isa0JBQU0sSUFBSSxLQUFLLElBQUksR0FBRyxVQUFVLFVBQVU7QUFDMUMsa0JBQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFFdEQsZ0JBQUksUUFBUSxNQUFNO0FBQ2pCLG1CQUFLLE9BQU8sS0FBSyxJQUFJO0FBQ3JCLG9CQUFNLFlBQVksYUFBYSxRQUFXLEVBQUUsSUFBSSxPQUFPLElBQUksR0FBRyxLQUFJLENBQUU7QUFDcEUsbUJBQUssSUFBSSxTQUFTLGFBQWEsR0FBRyxRQUFRLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFDakUsbUJBQUssV0FBVyxLQUFLLEdBQUk7QUFDekIsbUNBQXFCLE1BQU0sU0FBUztBQUNwQyxxQkFBTztZQUNSO0FBQ0EsZ0JBQUksS0FBSztBQUFHLDRCQUFjLEtBQUs7VUFDaEMsR0FBRyxNQUFNO1FBQ1YsT0FBTztBQUNOLGdCQUFNLFlBQVksYUFBYSxRQUFXLEVBQUUsSUFBSSxPQUFPLElBQUksR0FBRyxLQUFJLENBQUU7QUFDcEUsZUFBSyxJQUFJLFNBQVMsYUFBYSxHQUFHLFFBQVEsS0FBSyxXQUFXLElBQUksR0FBRztBQUNqRSxlQUFLLFdBQVcsS0FBSyxHQUFJO0FBQ3pCLCtCQUFxQixNQUFNLFNBQVM7UUFDckM7TUFDRDs7QUFHRCxRQUFJLE9BQU8sTUFBTSxTQUFTO0FBQ3pCLGdCQUFVLFFBQVEsR0FBRyxFQUFFLEVBQUcsc0JBQXNCO0FBQ2hELGdCQUFVLFFBQVEsS0FDakI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU8sT0FBTztRQUNkLFNBQVMsT0FBTztRQUNoQixLQUFLLENBQUMsT0FBTztRQUNiLEtBQUssT0FBTztRQUNaLHFCQUFxQjtTQUV0QjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLE9BQU87UUFDUCxxQkFBcUI7U0FFdEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsdUJBQXVCO09BQ3ZCO0FBSUYsZ0JBQVUsUUFBUSxLQUNqQjtRQUNDLElBQUk7UUFDSixNQUFNO1FBQ04sT0FBTztRQUNQLFNBQVM7UUFDVCx1QkFBdUI7U0FFeEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsS0FBSztRQUNMLEtBQUs7UUFDTCxxQkFBcUI7U0FFdEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsS0FBSztRQUNMLEtBQUs7UUFDTCxxQkFBcUI7U0FFdEI7UUFDQyxJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsU0FBUztVQUNSLEVBQUUsT0FBTyxVQUFVLElBQUksU0FBUTtVQUMvQixFQUFFLE9BQU8sV0FBVyxJQUFJLFNBQVE7VUFDaEMsRUFBRSxPQUFPLFlBQVksSUFBSSxVQUFTO1VBQ2xDLEVBQUUsT0FBTyxlQUFlLElBQUksWUFBVzs7UUFFeEMscUJBQXFCO09BQ3JCO0lBRUg7QUFFQSxZQUFRLE9BQU8sRUFBRSxJQUFJO0VBQ3RCO0FBRUEsT0FBSyxxQkFBcUIsT0FBTztBQUNsQzs7O0FDOUtNLFNBQVUsZ0JBQWdCLE1BQW9CO0FBQ25ELFFBQU0sWUFBMEMsQ0FBQTtBQUNoRCxhQUFXLFlBQVksY0FBYztBQUNwQyxVQUFNLGNBQTJDO01BQ2hELE1BQU0sU0FBUztNQUNmLGFBQWEsU0FBUztNQUN0QixNQUFNO01BQ04sY0FBYztRQUNiLFNBQVMsV0FBVyxLQUFLLEdBQUcsQ0FBQztRQUM3QixPQUFPLFdBQVcsR0FBRyxHQUFHLENBQUM7O01BRTFCLFNBQVMsY0FBYyxDQUFBLEdBQUksUUFBUTtNQUNuQyxVQUFVLE9BQU8sVUFBMkI7QUFDM0MsY0FBTSxPQUFPLEtBQUssTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPLENBQUM7QUFFckQsWUFBSSxNQUFNLGNBQWMsU0FBUztBQUNoQyxnQkFBTSxjQUFjLE1BQU0sS0FBSyxTQUFTLEtBQUs7QUFDN0MsZUFBSyxRQUFRLFlBQVksTUFBTSxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQXNCLFNBQVMsQ0FBQyxDQUFDO1FBQy9FO0FBRUEsWUFBSSxLQUFLLFVBQVU7QUFDbEIsZUFBSyxTQUFTLEtBQUssSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRO0FBQ2pELGNBQUksS0FBSztBQUFTLGlCQUFLLFVBQVUsT0FBTyxNQUFNLEtBQUssT0FBTztBQUMxRCxjQUFJLEtBQUs7QUFBVyxpQkFBSyxPQUFPLE9BQU8sTUFBTSxLQUFLLFNBQVM7QUFDM0QsY0FBSSxLQUFLO0FBQVMsaUJBQUssYUFBYSxPQUFPLE1BQU0sS0FBSyxPQUFPO1FBQzlEO0FBRUEsY0FBTSxNQUFNLFlBQVksYUFBYSxRQUFXLEVBQUUsSUFBSSxNQUFNLFlBQVksR0FBRyxLQUFJLENBQUU7QUFFakYsY0FBTSxlQUFlLEtBQUssaUJBQWlCLEdBQUk7QUFDL0MsWUFBSSxNQUFNLGVBQWUsV0FBVyxLQUFLLGFBQWEsS0FBSyxPQUFPLGtCQUFrQixRQUFRO0FBQzNGLHVCQUFhLE1BQU0sS0FBSyxZQUFZO0FBQ3JDLFlBQUksZ0JBQWdCO0FBQVcsaUJBQU87QUFDdEMsWUFBSSxnQkFBZ0IsS0FBSyxjQUFjLEdBQUksRUFBRSxLQUFLO0FBQ2pELGlCQUFPO1FBQ1I7QUFDQSxlQUFPO01BQ1I7O0FBR0QsUUFBSSxTQUFTLE1BQU0sV0FBVyxLQUFLLE9BQU8sZ0JBQWdCO0FBQ3pELGtCQUFZLFFBQVEsR0FBRyxFQUFFLEVBQUcsc0JBQXNCO0FBQ2xELGtCQUFZLFFBQVEsS0FBSztRQUN4QixJQUFJO1FBQ0osTUFBTTtRQUNOLE9BQU87UUFDUCxTQUFTO1FBQ1QsdUJBQXVCO09BQ3ZCO0lBQ0Y7QUFFQSxjQUFVLFNBQVMsRUFBRSxJQUFJO0FBRXpCLGNBQVUsU0FBUyxLQUFLLFFBQVEsSUFBSTtNQUNuQyxHQUFHO01BQ0gsTUFBTSxTQUFTLFFBQVE7TUFDdkIsTUFBTTtNQUNOLFNBQVMsWUFBWSxRQUFRLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTLFNBQVMsRUFBRSxPQUFPLFdBQVc7TUFDMUYsVUFBVSxPQUFPLFVBQTBCO0FBQzFDLGNBQU0sT0FBTyxLQUFLLE1BQU0sS0FBSyxVQUFVLE1BQU0sT0FBTyxDQUFDO0FBQ3JELGNBQU0sUUFBUSxNQUFNLFdBQVcsUUFBUSxVQUFVLEVBQUU7QUFDbkQsY0FBTSxNQUFNLFlBQVksYUFBYSxRQUFXLEVBQUUsSUFBSSxPQUFPLEdBQUcsS0FBSSxDQUFFO0FBQ3RFLGVBQU8sS0FBSyxpQkFBaUIsR0FBSSxLQUFLO01BQ3ZDOztFQUVGO0FBRUEsWUFBVSxRQUFRLElBQUk7SUFDckIsTUFBTTtJQUNOLGFBQWE7SUFDYixNQUFNO0lBQ04sY0FBYztNQUNiLFNBQVMsV0FBVyxLQUFLLEdBQUcsQ0FBQztNQUM3QixPQUFPLFdBQVcsR0FBRyxHQUFHLENBQUM7O0lBRTFCLFNBQVMsQ0FBQTtJQUNULFVBQVUsWUFBNkI7QUFDdEMsYUFBTyxDQUFDLENBQUMsS0FBSyxpQkFBaUIsUUFBUTtJQUN4Qzs7QUFHRCxZQUFVLFNBQVMsSUFBSTtJQUN0QixNQUFNO0lBQ04sYUFBYTtJQUNiLE1BQU07SUFDTixjQUFjO01BQ2IsU0FBUyxXQUFXLEtBQUssR0FBRyxDQUFDO01BQzdCLE9BQU8sV0FBVyxHQUFHLEdBQUcsQ0FBQzs7SUFFMUIsU0FBUyxDQUFBO0lBQ1QsVUFBVSxZQUE2QjtBQUN0QyxhQUFPLENBQUMsQ0FBQyxLQUFLLGlCQUFpQixTQUFTO0lBQ3pDOztBQUdELE9BQUssdUJBQXVCLFNBQVM7QUFDdEM7OztBQ3hHTSxTQUFVLGNBQWMsTUFBb0I7QUFDakQsUUFBTSxVQUFVO0lBQ2YsU0FBUztNQUNSLE1BQU07TUFDTixNQUFNO01BQ04sT0FBTztRQUNOLE1BQU07UUFDTixNQUFNO1FBQ04sT0FBTyxXQUFXLEtBQUssS0FBSyxHQUFHO1FBQy9CLFNBQVMsV0FBVyxHQUFHLEdBQUcsQ0FBQzs7TUFFNUIsT0FBTyxDQUFBO01BQ1AsV0FBVztRQUNWO1VBQ0MsWUFBWTtVQUNaLFNBQVMsQ0FBQTtVQUNULE9BQU87WUFDTixPQUFPLFdBQVcsS0FBSyxLQUFLLEdBQUc7WUFDL0IsU0FBUyxXQUFXLEdBQUcsS0FBSyxDQUFDOzs7OztJQUtqQyxVQUFVO01BQ1QsTUFBTTtNQUNOLE1BQU07TUFDTixPQUFPO1FBQ04sTUFBTTtRQUNOLE1BQU07UUFDTixPQUFPLFdBQVcsS0FBSyxLQUFLLEdBQUc7UUFDL0IsU0FBUyxXQUFXLEdBQUcsR0FBRyxDQUFDOztNQUU1QixPQUFPLENBQUE7TUFDUCxXQUFXO1FBQ1Y7VUFDQyxZQUFZO1VBQ1osU0FBUyxDQUFBO1VBQ1QsT0FBTztZQUNOLE9BQU8sV0FBVyxLQUFLLEtBQUssR0FBRztZQUMvQixTQUFTLFdBQVcsR0FBRyxLQUFLLENBQUM7Ozs7OztBQU9sQyxRQUFNLFlBQVk7SUFDakI7TUFDQyxJQUFJO01BQ0osTUFBTTtNQUNOLGFBQWE7UUFDWjtVQUNDLElBQUk7VUFDSixNQUFNO1VBQ04sTUFBTTtVQUNOLFNBQVMsQ0FBQyxXQUFXLFVBQVU7Ozs7O0FBTW5DLE9BQUsscUJBQXFCLFdBQVcsT0FBTztBQUM3Qzs7O0FDbERBLElBQXFCLGlCQUFyQixjQUE0QyxhQUEyQjtFQUN0RTs7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUVBLFlBQVksVUFBaUI7QUFDNUIsVUFBTSxRQUFRO0VBQ2Y7RUFFQSxNQUFNLEtBQUssUUFBb0I7QUFDOUIsU0FBSyxTQUFTO0FBQ2QsU0FBSyxZQUFZLG9CQUFJLElBQUc7QUFFeEIsU0FBSyxjQUFhO0FBQ2xCLFNBQUssZ0JBQWU7QUFDcEIsU0FBSyxjQUFhO0FBQ2xCLFNBQUssMEJBQXlCO0FBQzlCLFVBQU0sS0FBSyxjQUFjLE1BQU07RUFDaEM7O0VBR0EsTUFBTSxVQUFPO0FBQ1osU0FBSyxVQUFVLE1BQUs7QUFDcEIsU0FBSyxXQUFXLE1BQUs7QUFDckIsU0FBSyxJQUFJLFNBQVMsR0FBRyxLQUFLLEVBQUUsWUFBWTtFQUN6QztFQUVBLE1BQU0sY0FBYyxRQUFvQjtBQUN2QyxTQUFLLFNBQVM7QUFDZCxTQUFLLE9BQU8sa0JBQWtCO0FBQzlCLFNBQUssT0FBTyxtQkFBbUI7QUFDL0IsVUFBTSxhQUFhLEtBQUssT0FBTyxrQkFBa0IsS0FBSyxPQUFPLG9CQUFvQixLQUFLLE9BQU87QUFDN0YsVUFBTSxjQUFjLEtBQUssT0FBTyxtQkFBbUIsS0FBSyxPQUFPLHFCQUFxQixLQUFLLE9BQU87QUFDaEcsU0FBSyxJQUNKLFNBQ0EsMEJBQTBCLEtBQUssVUFBZSxVQUFTLENBQUUsQ0FBQzt5QkFBNkIsVUFBVSxFQUFFO0FBRXBHLFNBQUssSUFDSixTQUNBLDJCQUEyQixLQUFLLFVBQWUsV0FBVSxDQUFFLENBQUM7eUJBQTZCLFdBQVcsRUFBRTtBQUV2RyxTQUFLLElBQUksU0FBUyxFQUFFO0FBQ3BCLFFBQUksS0FBSztBQUFXLFdBQUssVUFBVSxNQUFLO0FBQ3hDLFFBQUksS0FBSztBQUFZLFdBQUssV0FBVyxNQUFLO0FBQzFDLFNBQUssWUFBWSxJQUFTQyxPQUFNLFlBQVksS0FBSyxPQUFPLGVBQWU7QUFDdkUsU0FBSyxhQUFhLElBQVNDLFFBQU8sYUFBYSxLQUFLLE9BQU8sZ0JBQWdCO0FBQzNFLFVBQU0sZUFBZSxLQUFLLE9BQU8sbUJBQW1CLEtBQUssVUFBVSxXQUFVO0FBQzdFLFVBQU0sZ0JBQWdCLEtBQUssT0FBTyxvQkFBb0IsS0FBSyxXQUFXLFdBQVU7QUFDaEYsU0FBSyxJQUFJLFFBQVEsc0JBQXNCLEtBQUssVUFBVSxJQUFJLFFBQVEsZUFBZSxLQUFLLE1BQU0sT0FBTztBQUNuRyxTQUFLLElBQUksUUFBUSxzQkFBc0IsS0FBSyxXQUFXLElBQUksUUFBUSxnQkFBZ0IsS0FBSyxNQUFNLE9BQU87QUFDckcsU0FBSyxhQUFhLGVBQWUsWUFBWTtBQUM3QyxRQUFJLENBQUMsZ0JBQWdCO0FBQWUsV0FBSyxhQUFhLGVBQWUsV0FBVyx1QkFBdUI7QUFDdkcsUUFBSSxnQkFBZ0IsQ0FBQztBQUFlLFdBQUssYUFBYSxlQUFlLFdBQVcsd0JBQXdCO0FBQ3hHLFFBQUksZ0JBQWdCO0FBQWUsV0FBSyxhQUFhLGVBQWUsRUFBRTtBQUV0RSxTQUFLLE1BQUs7RUFDWDs7RUFHQSxrQkFBZTtBQUNkLFdBQU8sZ0JBQWU7RUFDdkI7RUFDQSxnQkFBYTtBQUNaLGtCQUFjLElBQUk7RUFDbkI7RUFFQSxrQkFBZTtBQUNkLG9CQUFnQixJQUFJO0VBQ3JCO0VBRUEsZ0JBQWE7QUFDWixrQkFBYyxJQUFJO0VBQ25CO0VBRUEsNEJBQXlCO0FBQ3hCLDhCQUEwQixJQUFJO0VBQy9COztFQUdBLFFBQUs7QUFDSixTQUFLLElBQUksU0FBUyxxQkFBcUI7QUFFdkMsU0FBSyxVQUFVLEdBQUcsU0FBUyxDQUFDLFNBQTRDO0FBQ3ZFLFdBQUssa0JBQWtCO1FBQ3RCLE9BQU8sS0FBSztRQUNaLFNBQVMsS0FBSztPQUNkO0lBQ0YsQ0FBQztBQUNELFNBQUssVUFBVSxHQUFHLFdBQVcsQ0FBQyxXQUFtQixRQUFvQjtBQUNwRSxVQUFJLElBQUksT0FBTyxPQUFPO0FBQ3JCLGFBQUssSUFBSSxTQUFTLElBQUksVUFBVSxRQUFRLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLGVBQWUsR0FBRyxVQUFVLEtBQUssVUFBVSxJQUFJLEdBQUc7QUFDN0csYUFBSyxlQUFlLEdBQUc7QUFDdkIsWUFBSSxLQUFLO0FBQW9CLGVBQUsscUJBQXFCLFdBQVcsR0FBRztNQUN0RTtBQUNBLDJCQUFxQixNQUFNLFFBQVE7SUFDcEMsQ0FBQztFQUNGO0VBRUEsZUFBZSxLQUFnQjtBQUM5QixVQUFNLE9BQXVCLEtBQUssY0FBYyxHQUFHO0FBQ25ELFFBQUksS0FBSyxNQUFNLEdBQUc7QUFDakIsb0JBQWMsTUFBTSxLQUFLLEtBQUssR0FBRztBQUNqQyxXQUFLLFVBQVUsSUFBSSxLQUFLLEtBQUssS0FBSyxHQUFHO0FBQ3JDLFdBQUssa0JBQWlCO0lBQ3ZCO0VBQ0Q7RUFFQSxpQkFBaUIsS0FBZ0I7QUFDaEMsVUFBTSxPQUF1QixLQUFLLGNBQWMsR0FBRztBQUNuRCxRQUFJLEtBQUssTUFBTSxHQUFHO0FBQ2pCLGFBQU8sS0FBSyxVQUFVLElBQUksS0FBSyxHQUFHO0lBQ25DO0FBQ0EsV0FBTztFQUNSO0VBRUEsY0FBYyxLQUFnQjtBQUM3QixRQUFJLFlBQW9CLElBQUksTUFBTSxTQUFTO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLFlBQVk7QUFHaEIsUUFBSSxhQUFhLEtBQUssSUFBSSxTQUFTLEtBQU07QUFDeEMsVUFBSSxJQUFJLE1BQU0sU0FBUztBQUN0QixvQkFBWSxJQUFJLEtBQUssU0FBUztBQUM5QjtNQUNELE9BQU87QUFDTixvQkFBWSxJQUFJLE1BQU0sU0FBUztNQUNoQztBQUNBLGVBQVMsSUFBSSxHQUFHLElBQUksV0FBVyxLQUFLO0FBQ25DLHFCQUFhLElBQUksTUFBTSxDQUFDLE1BQU8sWUFBWSxJQUFJLEtBQU07TUFDdEQ7QUFDQSxVQUFJLGFBQWE7QUFBRyxvQkFBWTtJQUNqQztBQUNBLFdBQU8sRUFBRSxLQUFLLFdBQVcsS0FBSyxVQUFTO0VBQ3hDOztFQUdBLDZCQUE2QixhQUFvQjtBQUNoRCxTQUFLLHFCQUFxQjtFQUMzQjs7RUFHQSxxQkFBcUIsV0FBbUIsS0FBZ0I7QUFDdkQsVUFBTSxPQUFPLEVBQUUsR0FBRyxJQUFJLEtBQUk7QUFDMUIsUUFBSSxXQUFXLEdBQUcsSUFBSSxFQUFFLElBQUksS0FBSyxjQUFjLEdBQUcsRUFBRSxHQUFHO0FBQ3ZELFFBQUksS0FBSyxPQUFPLGNBQWM7QUFDN0Isa0JBQVksS0FBSyxNQUFNLFlBQVksR0FBSTtBQUN2QyxpQkFBVztJQUNaLE9BQU87QUFDTixrQkFBWTtJQUNiO0FBQ0EsU0FBSyxhQUNKO01BQ0MsVUFBVSxJQUFJO01BQ2QsU0FBUztNQUNULE9BQU87T0FFUixRQUFRO0VBRVY7OyIsCiAgIm5hbWVzIjogWyJFdmVudEVtaXR0ZXIiLCAiSW5wdXQiLCAiT3V0cHV0IiwgInZhcmlhYmxlcyIsICJJbnN0YW5jZVN0YXR1cyIsICJSZWdleCIsICJFdmVudEVtaXR0ZXIiLCAiSW5wdXQiLCAiRXZlbnRFbWl0dGVyIiwgIk91dHB1dCIsICJJbnB1dCIsICJPdXRwdXQiXQp9Cg==
